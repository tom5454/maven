package com.tom.createores.network;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.menu.OreVeinAtlasMenu;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class OreVeinAtlasClickPacket2 implements Packet {
	public static final class_2960 ATLAS_CLICK_S2C = new class_2960(CreateOreExcavation.MODID, "atlas_click2");
	private Option opt;
	private int id;

	public OreVeinAtlasClickPacket2(Option opt, int id) {
		this.opt = opt;
		this.id = id;
	}

	public OreVeinAtlasClickPacket2(class_2540 pb) {
		opt = pb.method_10818(Option.class);
		id = pb.method_10816();
	}

	@Override
	public void toBytes(class_2540 pb) {
		pb.method_10817(opt);
		pb.method_10804(id);
	}

	@Override
	public class_2960 getId() {
		return ATLAS_CLICK_S2C;
	}

	@Override
	public void handleClient() {
	}

	@Override
	public void handleServer(class_3222 p) {
		if (p.field_7512 instanceof OreVeinAtlasMenu m) {
			m.click2(opt, id);
		}
	}

	public static enum Option {
		TOGGLE_HIDE,
	}
}

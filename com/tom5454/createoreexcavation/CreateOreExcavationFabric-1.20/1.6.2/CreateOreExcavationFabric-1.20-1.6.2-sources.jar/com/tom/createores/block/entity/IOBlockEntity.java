package com.tom.createores.block.entity;

import java.util.List;

import org.jetbrains.annotations.Nullable;

import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.FilteringStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SidedStorageBlockEntity;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import com.simibubi.create.api.equipment.goggles.IHaveGoggleInformation;

import com.tom.createores.block.IOBlock;
import com.tom.createores.block.MultiblockPart;
import com.tom.createores.block.MultiblockPart.MultiblockGhostPart;
import com.tom.createores.util.IOBlockType;

public class IOBlockEntity extends class_2586 implements IHaveGoggleInformation, SidedStorageBlockEntity {
	private IOBlockType type;
	private Storage<?> cap;

	public IOBlockEntity(class_2591<?> pType, class_2338 pWorldPosition, class_2680 pBlockState) {
		super(pType, pWorldPosition, pBlockState);
		type = pBlockState.method_11654(IOBlock.TYPE);
	}

	private <T> Storage<T> getCapability() {
		if(this.cap == null) {
			class_2680 state = field_11863.method_8320(field_11867);
			class_2338 pos = field_11867;
			for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
				class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
				pos = pos.method_10079(d, 1);
				state = field_11863.method_8320(pos);
			}
			if (state.method_26204() instanceof MultiblockPart) {
				MultiblockPart d = (MultiblockPart) state.method_26204();
				if (d instanceof MultiblockGhostPart)this.cap = null;
				else {
					class_2586 te = field_11863.method_8321(pos);
					if (te instanceof MultiblockCapHandler) {
						this.cap = ((MultiblockCapHandler)te).getCaps(type);
					} else {
						this.cap = null;
					}
				}
			}
		}
		return (Storage<T>) cap;
	}

	@Override
	public boolean addToGoggleTooltip(List<class_2561> tooltip, boolean isPlayerSneaking) {
		class_2680 state = field_11863.method_8320(field_11867);
		class_2338 pos = field_11867;
		for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
			class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
			pos = pos.method_10079(d, 1);
			state = field_11863.method_8320(pos);
		}
		if (state.method_26204() instanceof MultiblockPart) {
			MultiblockPart d = (MultiblockPart) state.method_26204();
			if (d instanceof MultiblockGhostPart)return false;
			else {
				class_2586 te = field_11863.method_8321(pos);
				if (te instanceof MultiblockCapHandler) {
					return ((MultiblockCapHandler)te).addToGoggleTooltip(tooltip, isPlayerSneaking);
				} else {
					return false;
				}
			}
		}
		return false;
	}

	@Override
	public @Nullable Storage<ItemVariant> getItemStorage(class_2350 side) {
		if(!type.item)return null;
		Storage<ItemVariant> cap = getCapability();
		return type.in ? FilteringStorage.insertOnlyOf(cap) : FilteringStorage.extractOnlyOf(cap);
	}

	@Override
	public @Nullable Storage<FluidVariant> getFluidStorage(class_2350 side) {
		if(type.item)return null;
		Storage<FluidVariant> cap = getCapability();
		return type.in ? FilteringStorage.insertOnlyOf(cap) : FilteringStorage.extractOnlyOf(cap);
	}
}

package com.tom.createores.jei;

import com.simibubi.create.compat.jei.category.animations.AnimatedKinetics;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import net.minecraft.class_2680;
import net.minecraft.class_332;

public class AnimatedBlock extends AnimatedKinetics {
	private class_2680 block;
	private float scale;

	public AnimatedBlock(class_2680 block, float scale) {
		this.block = block;
		this.scale = scale;
	}

	@Override
	public void draw(class_332 matrixStack, int xOffset, int yOffset) {
		matrixStack.method_51448().method_22903();
		matrixStack.method_51448().method_46416(xOffset, yOffset, 0);
		AllGuiTextures.JEI_SHADOW.render(matrixStack, -16, 13);
		matrixStack.method_51448().method_46416(5, 10, 24);

		blockElement(block)
		.rotateBlock(22.5, 22.5, 0)
		.scale(scale)
		.render(matrixStack);

		matrixStack.method_51448().method_22909();
	}

}

package com.tom.createores.cc;

import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_7784;
import com.tom.createores.CreateOreExcavation;
import com.tom.createores.Registration;

import dan200.computercraft.api.turtle.TurtleUpgradeDataProvider;
import dan200.computercraft.api.turtle.TurtleUpgradeSerialiser;

public class TurtleUpgradeData extends TurtleUpgradeDataProvider {

	public TurtleUpgradeData(class_7784 output) {
		super(output);
	}

	@Override
	protected void addUpgrades(Consumer<Upgrade<TurtleUpgradeSerialiser<?>>> addUpgrade) {
		simpleWithCustomItem(id("vein_finder"), CCRegistration.VEIN_FINDER.get(), Registration.VEIN_FINDER_ITEM.get()).add(addUpgrade);
	}

	private static class_2960 id(String id) {
		return new class_2960(CreateOreExcavation.MODID, id);
	}
}

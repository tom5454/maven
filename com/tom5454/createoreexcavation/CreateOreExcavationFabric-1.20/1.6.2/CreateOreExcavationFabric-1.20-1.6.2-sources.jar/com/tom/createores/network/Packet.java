package com.tom.createores.network;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public interface Packet {
	void toBytes(class_2540 buf);
	class_2960 getId();
	void handleClient();
	void handleServer(class_3222 p);
}

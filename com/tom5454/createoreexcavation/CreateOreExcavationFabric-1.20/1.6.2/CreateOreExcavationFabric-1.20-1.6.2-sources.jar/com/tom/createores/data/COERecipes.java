package com.tom.createores.data;

import java.util.Random;
import java.util.function.Consumer;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_1959;
import net.minecraft.class_2066;
import net.minecraft.class_2073;
import net.minecraft.class_2246;
import net.minecraft.class_2371;
import net.minecraft.class_2444;
import net.minecraft.class_2447;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3612;
import net.minecraft.class_6862;
import net.minecraft.class_6872;
import net.minecraft.class_6873;
import net.minecraft.class_6908;
import net.minecraft.class_7800;
import net.minecraft.class_7924;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.AllItems;
import com.simibubi.create.AllRecipeTypes;
import com.simibubi.create.api.data.recipe.MechanicalCraftingRecipeBuilder;
import com.simibubi.create.content.processing.recipe.ProcessingOutput;
import com.simibubi.create.content.processing.recipe.ProcessingRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeBuilder;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeSerializer;
import com.simibubi.create.foundation.fluid.FluidIngredient;

import com.google.gson.JsonObject;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.Registration;
import com.tom.createores.recipe.DrillingRecipe;
import com.tom.createores.recipe.ExcavatingRecipe;
import com.tom.createores.recipe.ExtractorRecipe;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.ThreeState;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.tags.Tags;

public class COERecipes extends FabricRecipeProvider {
	private static Random seedRandom;

	public COERecipes(FabricDataOutput output) {
		super(output);
	}

	@Override
	public void method_10419(Consumer<class_2444> consumer) {
		class_2447.method_10437(class_7800.field_40642, Registration.NORMAL_DRILL_ITEM.get())
		.method_10439("bi ")
		.method_10439("ibi")
		.method_10439(" ii")
		.method_10433('b', Tags.Items.STORAGE_BLOCKS_IRON)
		.method_10433('i', Tags.Items.INGOTS_IRON)
		.method_10435("create")
		.method_10429("iron", class_2066.class_2068.method_8957(class_2073.class_2074.method_8973().method_8975(Tags.Items.INGOTS_IRON).method_8976()))
		.method_10431(consumer);

		class_2447.method_10437(class_7800.field_40642, Registration.DIAMOND_DRILL_ITEM.get())
		.method_10439("bi ")
		.method_10439("idi")
		.method_10439(" ii")
		.method_10433('b', Tags.Items.STORAGE_BLOCKS_DIAMOND)
		.method_10433('i', Tags.Items.GEMS_DIAMOND)
		.method_10434('d', Registration.NORMAL_DRILL_ITEM.get())
		.method_10435("create")
		.method_10429("diamond", class_2066.class_2068.method_8957(class_2073.class_2074.method_8973().method_8975(Tags.Items.GEMS_DIAMOND).method_8976()))
		.method_10431(consumer);

		method_29728(consumer, Registration.DIAMOND_DRILL_ITEM.get(), class_7800.field_40642, Registration.NETHERITE_DRILL_ITEM.get());

		class_2447.method_10437(class_7800.field_40642, Registration.VEIN_FINDER_ITEM.get())
		.method_10439("ea ")
		.method_10439("rs ")
		.method_10439("  s")
		.method_10434('e', class_1802.field_8449)
		.method_10433('a', Tags.Items.GEMS_AMETHYST)
		.method_10433('s', Tags.Items.RODS_WOODEN)
		.method_10433('r', Tags.Items.ORES_REDSTONE)
		.method_10435("create")
		.method_10429("diamond", class_2066.class_2068.method_8959(class_1802.field_8449))
		.method_10431(consumer);

		MechanicalCraftingRecipeBuilder.shapedRecipe(Registration.DRILL_BLOCK.get())
		.patternLine("BbtbB")
		.patternLine("beSeb")
		.patternLine("CmDmF")
		.patternLine("bsssb")
		.patternLine("BbbbB")
		.key('B', class_6862.method_40092(class_7924.field_41197, new class_2960("c:brass_blocks")))
		.key('b', class_6862.method_40092(class_7924.field_41197, new class_2960("c:brass_plates")))
		.key('e', AllItems.ELECTRON_TUBE.get())
		.key('S', AllBlocks.SPOUT.get())
		.key('C', AllBlocks.BRASS_CASING.get())
		.key('m', AllItems.PRECISION_MECHANISM.get())
		.key('D', AllBlocks.MECHANICAL_DRILL.get())
		.key('s', AllItems.STURDY_SHEET.get())
		.key('F', AllBlocks.BRASS_TUNNEL.get())
		.key('t', AllBlocks.COPPER_CASING.get())
		.build(consumer);

		MechanicalCraftingRecipeBuilder.shapedRecipe(Registration.EXTRACTOR_BLOCK.get())
		.patternLine("BbPbB")
		.patternLine("beHeb")
		.patternLine("CmDmb")
		.patternLine("bsssb")
		.patternLine("BbbbB")
		.key('B', class_6862.method_40092(class_7924.field_41197, new class_2960("c:brass_blocks")))
		.key('b', class_6862.method_40092(class_7924.field_41197, new class_2960("c:brass_plates")))
		.key('e', AllItems.ELECTRON_TUBE.get())
		.key('H', AllBlocks.HOSE_PULLEY.get())
		.key('C', AllBlocks.BRASS_CASING.get())
		.key('m', AllItems.PRECISION_MECHANISM.get())
		.key('D', AllBlocks.MECHANICAL_DRILL.get())
		.key('s', AllItems.STURDY_SHEET.get())
		.key('P', AllBlocks.MECHANICAL_PUMP.get())
		.build(consumer);

		seedRandom = new Random(10387320);

		new DrillingBuilder(class_1802.field_33400, 30*20, 1024, 128).setBiomeWhitelist(class_6908.field_37393).veinSize(10, 30).save("iron", consumer);
		new DrillingBuilder(class_1802.field_33402, 30*20, 1024, 512).setBiomeWhitelist(class_6908.field_37393).veinSize(2, 4).setStress(192).save("gold", consumer);
		new DrillingBuilder(class_1802.field_33401, 30*20, 1024, 128).setBiomeWhitelist(class_6908.field_37393).veinSize(10, 30).save("copper", consumer);
		new DrillingBuilder(class_1802.field_8713, 10*20, 1024, 128).setBiomeWhitelist(class_6908.field_37393).veinSize(15, 40).save("coal", consumer);
		new DrillingBuilder(Registration.RAW_DIAMOND.get(), 60*20, 2048, 1024).setBiomeWhitelist(class_6908.field_37393).setStress(512).veinSize(0.5f, 2).save("diamond", consumer);
		new DrillingBuilder(Registration.RAW_REDSTONE.get(), 30*20, 1024, 256).setBiomeWhitelist(class_6908.field_37393).veinSize(10, 30).save("redstone", consumer);
		new DrillingBuilder(Registration.RAW_EMERALD.get(), 60*20, 2048, 1024).setBiomeWhitelist(class_6908.field_37393).veinSize(0.2f, 1).setStress(512).save("emerald", consumer);
		new DrillingBuilder(new ProcessingOutput(new class_1799(Registration.RAW_DIAMOND.get()), 1F), 20*20, class_2561.method_43471("ore.coe.hardenedDiamond"), 4096, 2048).addOutput(class_1802.field_8477, 0.1f).setDrill(class_1856.method_8091(Registration.NETHERITE_DRILL_ITEM.get())).setDrillingFluid(FluidIngredient.fromFluid(class_3612.field_15908, 500)).setBiomeWhitelist(class_6908.field_37393).setStress(1024).veinSize(1f, 3f).save("hardened_diamond", consumer);
		new DrillingBuilder(AllItems.RAW_ZINC.get(), 30*20, 1024, 128).setBiomeWhitelist(class_6908.field_37393).veinSize(8, 24).save("zinc", consumer);
		new DrillingBuilder(class_1802.field_8759, 20*20, 1024, 128).setBiomeWhitelist(class_6908.field_37393).veinSize(8, 24).save("lapis", consumer);

		new DrillingBuilder(class_1802.field_8601, 60*20, 1024, 128).setBiomeWhitelist(class_6908.field_36518).veinSize(5, 12).save("glowstone", consumer);
		new DrillingBuilder(class_1802.field_8155, 60*20, 1024, 128).setBiomeWhitelist(class_6908.field_36518).setStress(512).veinSize(8, 24).save("quartz", consumer);
		new DrillingBuilder(new class_1799(class_2246.field_22109), 0.2f, 200*20, 4096, 2048).addOutput(class_1802.field_8397, 0.8f).addOutput(class_2246.field_10515, 0.8f).addOutput(class_2246.field_10092, 0.5f).setBiomeWhitelist(class_6908.field_36518).setDrill(class_1856.method_8091(Registration.NETHERITE_DRILL_ITEM.get())).setDrillingFluid(FluidIngredient.fromFluid(class_3612.field_15908, 1000)).setStress(2048).veinSize(0.5f, 0.8f).save("netherite", consumer);
		new DrillingBuilder(new class_1799(class_1802.field_8397, 3), 20*20, 2048, 1024).setBiomeWhitelist(class_6908.field_36518).addOutput(class_1802.field_8397, 0.5f).veinSize(3, 8).setStress(192).save("nether_gold", consumer);

		new ExtractorBuilder(new FluidStack(class_3612.field_15910, 500), 20, 512, 128).setBiomeWhitelist(class_6908.field_37393).setFinite(ThreeState.NEVER).save("water", consumer);

		processing("redstone_milling", AllRecipeTypes.MILLING, consumer, b -> b.withItemIngredients(class_1856.method_8091(Registration.RAW_REDSTONE.get())).output(new class_1799(class_1802.field_8725, 3)).duration(250));
		processing("redstone_crushing", AllRecipeTypes.CRUSHING, consumer, b -> b.withItemIngredients(class_1856.method_8091(Registration.RAW_REDSTONE.get())).output(new class_1799(class_1802.field_8725, 4)).duration(250));

		processing("diamond_cutting", AllRecipeTypes.CUTTING, consumer, b -> b.withItemIngredients(class_1856.method_8091(Registration.RAW_DIAMOND.get())).output(class_1802.field_8477).duration(250));
		processing("emerald_cutting", AllRecipeTypes.CUTTING, consumer, b -> b.withItemIngredients(class_1856.method_8091(Registration.RAW_EMERALD.get())).output(class_1802.field_8687).duration(250));

		class_2447.method_10437(class_7800.field_40642, Registration.VEIN_ATLAS_ITEM.get())
		.method_10439("ca")
		.method_10439("mb")
		.method_10433('c', Tags.Items.CHESTS)
		.method_10433('a', Tags.Items.GEMS_AMETHYST)
		.method_10434('m', class_1802.field_8895)
		.method_10434('b', class_1802.field_8674)
		.method_10435("create")
		.method_10429("map", class_2066.class_2068.method_8959(class_1802.field_8895))
		.method_10431(consumer);

		MechanicalCraftingRecipeBuilder.shapedRecipe(Registration.SAMPLE_DRILL_BLOCK.get())
		.patternLine("beb")
		.patternLine("mCb")
		.patternLine("sDs")
		.key('b', class_6862.method_40092(class_7924.field_41197, new class_2960("c:brass_plates")))
		.key('e', AllItems.ELECTRON_TUBE.get())
		.key('C', AllBlocks.BRASS_CASING.get())
		.key('m', AllItems.PRECISION_MECHANISM.get())
		.key('D', AllBlocks.MECHANICAL_DRILL.get())
		.key('s', AllItems.STURDY_SHEET.get())
		.build(consumer);
	}

	@SuppressWarnings("unchecked")
	private static <T extends ProcessingRecipe<?>> void processing(String name, AllRecipeTypes type, Consumer<class_2444> consumer, Consumer<ProcessingRecipeBuilder<?>> f) {
		class_2960 id = i(name);
		ProcessingRecipeBuilder<T> b = new ProcessingRecipeBuilder<>(((ProcessingRecipeSerializer<T>) type.getSerializer()).getFactory(), id);
		f.accept(b);
		b.build(consumer);
	}

	/*private static void genRarities(Item item, String name, int w, int a, boolean water, UnaryOperator<DrillingBuilder> b, Consumer<FinishedRecipe> consumer) {
		b.apply(new DrillingBuilder(item, w, 2*a*20)).save(name + "_impure", consumer);
		b.apply(new DrillingBuilder(item, w, a*20)).save(name + "_normal", consumer);
		b.apply(new DrillingBuilder(item, w / 2, a*10)).save(name + "_pure", consumer);
	}*/

	private static class_2960 i(String name) {
		return new class_2960(CreateOreExcavation.MODID, name);
	}

	@SuppressWarnings("unchecked")
	public static interface AbstractExcavatingBuilder<T extends AbstractExcavatingBuilder<T>> {

		public default void init(int ticks, class_2561 name, int spacing, int separation) {
			self().ticks = ticks;
			self().drill = class_1856.method_8106(CreateOreExcavation.DRILL_TAG);
			self().stressMul = 256;
			self().drillingFluid = FluidIngredient.EMPTY;
			initVein(ticks, name, spacing, separation);
		}

		public default void initVein(int ticks, class_2561 name, int spacing, int separation) {
			vein().veinName = name;
			vein().finite = ThreeState.DEFAULT;
			vein().amountMultiplierMin = 1;
			vein().amountMultiplierMax = 2;
			vein().placement = new class_6872(spacing / 8, separation / 16, class_6873.field_36421, seedRandom.nextInt(Integer.MAX_VALUE));
		}

		public default ExcavatingRecipe self() {
			return (ExcavatingRecipe) this;
		}

		public VeinRecipe vein();

		public default T setDrill(class_1856 drill) {
			self().drill = drill;
			return (T) this;
		}

		public default T setStress(int stress) {
			self().stressMul = stress;
			return (T) this;
		}

		public default T setBiomeWhitelist(class_6862<class_1959> tag) {
			vein().biomeWhitelist = tag;
			return (T) this;
		}

		public default T setBiomeBlacklist(class_6862<class_1959> tag) {
			vein().biomeBlacklist = tag;
			return (T) this;
		}

		public default T veinSize(float min, float max) {
			vein().amountMultiplierMin = min;
			vein().amountMultiplierMax = max;
			return (T) this;
		}

		public default T setFinite(ThreeState finite) {
			vein().finite = finite;
			return (T) this;
		}

		public default T setPriority(int priority) {
			vein().priority = priority;
			return (T) this;
		}

		public default void save(String name, Consumer<class_2444> consumer) {
			class_2960 vein = i(vein().method_8112() + "/" + name);
			self().veinId = vein;
			consumer.accept(new Result(i(self().method_8112() + "/" + name), self().serializer, json -> {
				new ExcavatingRecipe.Serializer<>(null, null).toJson(self(), json);
			}));
			consumer.accept(new Result(vein, vein().serializer, json -> {
				new VeinRecipe.Serializer<>(null, null).toJson(vein(), json);
			}));
		}
	}

	public static class DrillingBuilder extends DrillingRecipe implements AbstractExcavatingBuilder<DrillingBuilder> {
		private VeinRecipe vein;

		public DrillingBuilder(ProcessingOutput output, int ticks, class_2561 name, int spacing, int separation) {
			super(null, null, CreateOreExcavation.DRILLING_RECIPES.getSerializer());
			init(ticks, name, spacing, separation);
			this.output = class_2371.method_10211();
			this.output.add(output);
			vein.icon = output.getStack();
		}

		public DrillingBuilder(class_1799 output, float chance, int ticks, int spacing, int separation) {
			this(new ProcessingOutput(output, chance), ticks, output.method_7964(), spacing, separation);
		}

		public DrillingBuilder(class_1799 output, int ticks, int spacing, int separation) {
			this(new ProcessingOutput(output, 1F), ticks, output.method_7964(), spacing, separation);
		}

		public DrillingBuilder(class_1935 output, int ticks, int spacing, int separation) {
			this(new class_1799(output), ticks, spacing, separation);
		}

		public DrillingBuilder setDrillingFluid(FluidIngredient drillingFluid) {
			this.drillingFluid = drillingFluid;
			return this;
		}

		public DrillingBuilder addOutput(ProcessingOutput output) {
			this.output.add(output);
			return this;
		}

		public DrillingBuilder addOutput(class_1799 output) {
			addOutput(new ProcessingOutput(output, 1F));
			return this;
		}

		public DrillingBuilder addOutput(class_1935 output) {
			addOutput(new class_1799(output));
			return this;
		}

		public DrillingBuilder addOutput(class_1799 output, float chance) {
			addOutput(new ProcessingOutput(output, chance));
			return this;
		}

		public DrillingBuilder addOutput(class_1935 output, float chance) {
			addOutput(new class_1799(output), chance);
			return this;
		}

		@Override
		public VeinRecipe vein() {
			return vein;
		}

		@Override
		public void initVein(int ticks, class_2561 name, int spacing, int separation) {
			vein = new VeinRecipe(null, null, CreateOreExcavation.VEIN_RECIPES.getSerializer());
			AbstractExcavatingBuilder.super.initVein(ticks, name, spacing, separation);
		}
	}

	public static class ExtractorBuilder extends ExtractorRecipe implements AbstractExcavatingBuilder<ExtractorBuilder> {
		private VeinRecipe vein;

		public ExtractorBuilder(FluidStack output, int ticks, int spacing, int separation) {
			this(output, ticks, output.getDisplayName(), spacing, separation);
		}

		public ExtractorBuilder(FluidStack output, int ticks, class_2561 name, int spacing, int separation) {
			super(null, null, CreateOreExcavation.EXTRACTING_RECIPES.getSerializer());
			init(ticks, name, spacing, separation);
			this.output = output;
			vein.icon = new class_1799(output.getFluid().method_15774());
		}

		@Override
		public void initVein(int ticks, class_2561 name, int spacing, int separation) {
			vein = new VeinRecipe(null, null, CreateOreExcavation.VEIN_RECIPES.getSerializer());
			AbstractExcavatingBuilder.super.initVein(ticks, name, spacing, separation);
		}

		@Override
		public VeinRecipe vein() {
			return vein;
		}
	}

	public static class Result implements class_2444 {
		private final class_2960 id;
		private final Consumer<JsonObject> writer;
		private final class_1865<?> type;

		public Result(class_2960 pId, class_1865<?> pType, Consumer<JsonObject> writer) {
			this.id = pId;
			this.type = pType;
			this.writer = writer;
		}

		@Override
		public void method_10416(JsonObject pJson) {
			writer.accept(pJson);
		}

		@Override
		public class_2960 method_10417() {
			return this.id;
		}

		@Override
		public class_1865<?> method_17800() {
			return this.type;
		}

		@Override
		public JsonObject method_10415() {
			return null;
		}

		@Override
		public class_2960 method_10418() {
			return null;
		}
	}
}
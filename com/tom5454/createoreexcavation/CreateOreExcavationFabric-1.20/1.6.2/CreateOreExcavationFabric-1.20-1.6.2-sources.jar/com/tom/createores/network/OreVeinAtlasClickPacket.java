package com.tom.createores.network;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.menu.OreVeinAtlasMenu;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class OreVeinAtlasClickPacket implements Packet {
	public static final class_2960 ATLAS_CLICK_S2C = new class_2960(CreateOreExcavation.MODID, "atlas_click");
	private Option opt;
	private class_2960 id;

	public OreVeinAtlasClickPacket(Option opt, class_2960 id) {
		this.opt = opt;
		this.id = id;
	}

	public OreVeinAtlasClickPacket(class_2540 pb) {
		opt = pb.method_10818(Option.class);
		if (pb.readBoolean())
			id = pb.method_10810();
	}

	@Override
	public void toBytes(class_2540 pb) {
		pb.method_10817(opt);
		pb.writeBoolean(id != null);
		if (id != null)
			pb.method_10812(id);
	}

	@Override
	public class_2960 getId() {
		return ATLAS_CLICK_S2C;
	}

	@Override
	public void handleClient() {
	}

	@Override
	public void handleServer(class_3222 p) {
		if (p.field_7512 instanceof OreVeinAtlasMenu m) {
			m.click(opt, id);
		}
	}

	public static enum Option {
		ADD_EXCLUDE,
		REMOVE_EXCLUDE,
		SET_TARGET,
		REMOVE_TARGET,
	}
}

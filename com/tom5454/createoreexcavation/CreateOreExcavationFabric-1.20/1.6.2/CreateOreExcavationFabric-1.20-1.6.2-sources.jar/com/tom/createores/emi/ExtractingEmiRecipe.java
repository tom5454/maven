package com.tom.createores.emi;

import java.util.ArrayList;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import com.tom.createores.CreateOreExcavation;
import com.tom.createores.Registration;
import com.tom.createores.recipe.ExtractorRecipe;

import dev.emi.emi.api.widget.WidgetHolder;

public class ExtractingEmiRecipe extends ExcavatingEmiRecipe<ExtractorRecipe> {

	public ExtractingEmiRecipe(ExtractorRecipe recipe) {
		super(EMIPlugin.EXTRACTING, recipe);
		class_2960 rid = recipe.method_8114();
		this.id = new class_2960("emi", CreateOreExcavation.MODID + "/extracting/" + rid.method_12836() + "/" + rid.method_12832());
		output = new ArrayList<>();
		output.add(fluidStack(recipe.output));
	}

	@Override
	public void addWidgets(WidgetHolder widgets) {
		super.addWidgets(widgets);

		addSlot(widgets, output.get(0), width / 2 - 8, 78);
	}

	@Override
	protected class_2680 getBlock() {
		return Registration.EXTRACTOR_BLOCK.getDefaultState();
	}
}

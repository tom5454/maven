package com.tom.createores.block;

import static com.tom.createores.block.MultiblockPart.MultiblockMainPart.MultiblockPartType.*;

import com.simibubi.create.foundation.block.IBE;

import com.tom.createores.Registration;
import com.tom.createores.block.entity.DrillBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class DrillBlock extends MultiblockController implements IBE<DrillBlockEntity> {

	private static final MultiblockPartType[][][] LAYOUT = new MultiblockPartType[][][] {
		{
			{BLANK,   FLUID_IN, BLANK},
			{KINETIC, BLANK,    BLANK},
			{BLANK,   BLANK,    BLANK}
		},
		{
			{BLANK, BLANK,    BLANK},
			{BLANK, MAIN,     BLANK},
			{BLANK, ITEM_OUT, BLANK}
		}
	};

	public DrillBlock(class_2251 pr) {
		super(pr);
	}

	@Override
	public Class<DrillBlockEntity> getBlockEntityClass() {
		return DrillBlockEntity.class;
	}

	@Override
	public class_2591<? extends DrillBlockEntity> getBlockEntityType() {
		return Registration.DRILL_TILE.get();
	}

	@Override
	public MultiblockPartType[][][] getMultiblockLayout() {
		return LAYOUT;
	}

	@Override
	public class_2382 getStart(class_2350 facing) {
		return new class_2382(-1, 0, -1);
	}

	@Override
	public class_2350 getBlockRotation(class_2350 facing, MultiblockPartType part) {
		if(part == KINETIC)return facing.method_10160();
		return facing;
	}

	@Override
	public class_1269 onActivate(class_2680 state, class_1937 level, class_2338 pos, class_1657 player,
			class_1268 hand, class_3965 pHit) {
		return level.method_35230(pos, Registration.DRILL_TILE.get()).map(te -> te.onClick(player, hand)).orElse(class_1269.field_5811);
	}
}

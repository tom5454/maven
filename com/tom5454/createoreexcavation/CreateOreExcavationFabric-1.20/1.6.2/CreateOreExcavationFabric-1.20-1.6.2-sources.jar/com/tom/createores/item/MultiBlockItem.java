package com.tom.createores.item;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1747;
import net.minecraft.class_1750;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import com.tom.createores.block.MultiblockPart.MultiblockMainPart;
import com.tom.createores.block.MultiblockPart.MultiblockMainPart.MultiblockPartType;

public class MultiBlockItem extends class_1747 {

	public MultiBlockItem(class_2248 pBlock, class_1793 pProperties) {
		super(pBlock, pProperties);
	}

	@Override
	protected boolean method_7709(class_1750 pContext, class_2680 pState) {
		MultiblockMainPart part = (MultiblockMainPart) method_7711();
		class_2350 facing = pState.method_11654(class_2741.field_12481);
		class_2338 place = pContext.method_8037().method_10081(part.getStart(facing));
		class_2382 s = part.getSize(facing);
		for(int x = 0;x<s.method_10263();x++) {
			for(int y = 0;y<s.method_10264();y++) {
				for(int z = 0;z<s.method_10260();z++) {
					class_2338 pos = place.method_10069(x, y, z);
					MultiblockPartType type = part.getPartTypeAt(facing, x, y, z);
					if(type != null) {
						if(pContext.method_8045().method_31606(pos))return false;
						class_1750 p = class_1750.method_16355(pContext, pos.method_10074(), class_2350.field_11036);
						if(p.method_7717()) {
							p = class_1750.method_16355(pContext, pos, class_2350.field_11036);
							if(!p.method_7717())return false;
						}
						if(!p.method_7716())return false;
						if(!super.method_7709(p, pState))return false;
					}
				}
			}
		}
		return true;
	}

	@Override
	protected boolean method_7708(class_1750 pContext, class_2680 pState) {
		MultiblockMainPart part = (MultiblockMainPart) method_7711();
		class_1937 lvl = pContext.method_8045();
		class_2350 facing = pState.method_11654(class_2741.field_12481);
		class_2338 place = pContext.method_8037().method_10081(part.getStart(facing));
		class_2382 s = part.getSize(facing);
		Map<class_2338, PlaceAction> placeActions = new HashMap<>();
		for(int x = 0;x<s.method_10263();x++) {
			for(int y = 0;y<s.method_10264();y++) {
				for(int z = 0;z<s.method_10260();z++) {
					class_2338 pos = place.method_10069(x, y, z);
					MultiblockPartType type = part.getPartTypeAt(facing, x, y, z);
					if(type == MultiblockPartType.MAIN)lvl.method_8652(pos, pState, 11);
					else {
						class_2350 f = part.getGhostDirection(facing, x, y, z);
						class_2680 pl = type.getBlockState(part.getBlockRotation(facing, type)).method_11657(class_2741.field_12525, f);
						placeActions.put(pos, new PlaceAction(placeActions, pos, pl, f));
					}
				}
			}
		}
		List<PlaceAction> pa = new ArrayList<>(placeActions.values());
		pa.forEach(PlaceAction::computeOrder);
		pa.sort(Comparator.naturalOrder());
		pa.forEach(p -> p.place(lvl));
		return true;
	}

	private static class PlaceAction implements Comparable<PlaceAction> {
		private final Map<class_2338, PlaceAction> placeActions;
		private final class_2338 pos;
		private final class_2680 state;
		private final class_2350 parentDir;
		private int placeOrder = -1;

		public PlaceAction(Map<class_2338, PlaceAction> placeActions, class_2338 pos, class_2680 state, class_2350 parentDir) {
			this.placeActions = placeActions;
			this.pos = pos;
			this.state = state;
			this.parentDir = parentDir;
		}

		public void computeOrder() {
			if(placeOrder == -1) {
				placeOrder = 0;
				class_2338 p = pos.method_10093(parentDir);
				PlaceAction a = placeActions.get(p);
				if(a != null) {
					a.computeOrder();
					placeOrder = a.placeOrder + 1;
				}
			}
		}

		@Override
		public int compareTo(PlaceAction o) {
			return Integer.compare(placeOrder, o.placeOrder);
		}

		public void place(class_1937 lvl) {
			lvl.method_8652(pos, state, 11);
		}
	}
}

package com.tom.createores.rei;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.simibubi.create.compat.rei.category.WidgetUtil;
import com.simibubi.create.compat.rei.display.CreateDisplay;
import com.simibubi.create.foundation.fluid.FluidIngredient;
import com.simibubi.create.foundation.gui.AllGuiTextures;

import com.tom.createores.recipe.ExcavatingRecipe;
import com.tom.createores.recipe.VeinRecipe;

import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.api.client.gui.widgets.Tooltip;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.gui.widgets.WidgetWithBounds;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.client.registry.display.DisplayCategory;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import net.minecraft.class_1863;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_364;

public abstract class ExcavatingCategory<R extends ExcavatingRecipe> implements DisplayCategory<CreateDisplay<R>> {
	protected Renderer icon;

	public ExcavatingCategory() {
	}

	@Override
	public Renderer getIcon() {
		return icon;
	}

	@Override
	public List<Widget> setupDisplay(CreateDisplay<R> display, Rectangle bounds) {
		ExcavatingRecipe recipe = display.getRecipe();
		Point origin = new Point(bounds.getX(), bounds.getY() + 4);
		List<Widget> widgets = new ArrayList<>();
		widgets.add(Widgets.createRecipeBase(bounds));
		widgets.add(Widgets.createSlot(new Point(origin.x + 51, origin.y + 3)).disableBackground().markInput().entries(EntryIngredients.ofIngredient(recipe.drill)));
		widgets.add(WidgetUtil.textured(AllGuiTextures.JEI_SLOT, origin.x + 50, origin.y + 2));
		if(recipe.getDrillingFluid() != FluidIngredient.EMPTY) {
			widgets.add(WidgetUtil.textured(AllGuiTextures.JEI_SLOT, origin.x + 50 + 18, origin.y + 2));
			widgets.add(Widgets.createSlot(new Point(origin.x + 51 + 18, origin.y + 3)).disableBackground().markInput().entries(EntryIngredients.of(ReiPlatform.wrapFluid(recipe.getDrillingFluid().getMatchingFluidStacks().get(0)))));
		}
		setupDisplay0(display, bounds, widgets);
		widgets.add(new WidgetWithBounds() {

			@Override
			public List<? extends class_364> method_25396() {
				return Collections.emptyList();
			}

			@Override
			public void method_25394(class_332 poseStack, int mouseX, int mouseY, float f) {
				mouseX -= bounds.x;
				mouseY -= bounds.y;
				List<class_2561> tooltip = new ArrayList<>();
				if(mouseX > 40 && mouseX < 80 && mouseY > 25 && mouseY < 60) {
					tooltip.add(class_2561.method_43469("tooltip.coe.processTime", recipe.getTicks()));
				}
				if(!tooltip.isEmpty())Tooltip.create(tooltip).queue();
			}

			@Override
			public Rectangle getBounds() {
				return bounds;
			}
		});

		class_1863 mngr = class_310.method_1551().method_1562().method_2877();
		mngr.method_8130(recipe.veinId).ifPresent(rec -> {
			if(rec instanceof VeinRecipe r)
				widgets.add(Widgets.createSlot(new Point(origin.x + 100, origin.y + 3)).disableBackground().markInput().entries(Collections.singletonList(EntryStack.of(REIPlugin.VEIN_TYPE, r))));
		});
		return widgets;
	}

	public abstract void setupDisplay0(CreateDisplay<R> display, Rectangle bounds, List<Widget> widgets);

	@Override
	public int getDisplayHeight() {
		return 120;
	}
}

package com.tom.createores.client;

import com.google.common.base.Strings;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;

public class ClientUtil {

	public static class_2561 makeProgressBar(float progress) {
		class_327 fontRenderer = class_310.method_1551().field_1772;
		float charWidth = fontRenderer.method_1727("|");
		float tipWidth = 60;

		int total = (int) (tipWidth / charWidth);
		int current = (int) (progress * total);
		if(progress < 0)progress = 0;

		String bars = "";
		bars += class_124.field_1080 + Strings.repeat("|", current);
		if (progress < 1)
			bars += class_124.field_1063 + Strings.repeat("|", total - current);
		return class_2561.method_43470(bars);
	}
}

package com.tom.createores.menu;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_474;
import net.minecraft.class_5321;
import net.minecraft.class_7919;
import net.minecraft.class_7924;
import com.mojang.blaze3d.systems.RenderSystem;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.item.OreVeinAtlasItem;
import com.tom.createores.network.NetworkHandler;
import com.tom.createores.network.OreVeinAtlasClickPacket;
import com.tom.createores.network.OreVeinAtlasClickPacket.Option;
import com.tom.createores.network.OreVeinAtlasClickPacket2;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.DimChunkPos;
import com.tom.createores.util.NumberFormatter;
import com.tom.createores.util.ThreeState;

public class OreVeinAtlasScreen extends class_465<OreVeinAtlasMenu> {
	private static final class_2960 GUI_TEXTURES = class_2960.method_43902(CreateOreExcavation.MODID, "textures/gui/atlas.png");
	private static final class_2960 EXCLUDE = class_2960.method_43902(CreateOreExcavation.MODID, "textures/gui/atlas_exclude.png");
	private static final class_2960 TARGET = class_2960.method_43902(CreateOreExcavation.MODID, "textures/gui/atlas_target.png");
	private static final class_2960 BUTTON_LOCATION = class_2960.method_43902(CreateOreExcavation.MODID, "textures/gui/atlas_buttons.png");
	private static final class_2960 SHOW = class_2960.method_43902(CreateOreExcavation.MODID, "textures/gui/atlas_show.png");
	private static final class_2960 HIDE = class_2960.method_43902(CreateOreExcavation.MODID, "textures/gui/atlas_hidden.png");

	private static final class_4185.class_4241 NULL_PRESS = b -> {};

	private List<Vein> veinsList = new ArrayList<>();
	private List<VeinRecipe> veinTypesList = new ArrayList<>();
	private List<Vein> veinsListSorted = new ArrayList<>();
	private List<VeinRecipe> veinTypesListSorted = new ArrayList<>();
	private Set<class_2960> excluded = new HashSet<>();
	private String target;
	private VeinsListWidget discovered;
	private VeinTypesListWidget veinTypes;
	private class_2561 veinTypesTitle = class_2561.method_43471("info.coe.atlas.vein_types");
	private class_474 backButton;
	private Vein selected;
	private boolean showHidden;
	private ToggleHideButton toggleHideButton;

	public OreVeinAtlasScreen(OreVeinAtlasMenu p_97741_, class_1661 p_97742_, class_2561 p_97743_) {
		super(p_97741_, p_97742_, p_97743_);
	}

	@Override
	protected void method_2389(class_332 gr, float partial, int mx, int my) {
		gr.method_25290(GUI_TEXTURES, this.field_2776, this.field_2800, 0, 0, this.field_2792, this.field_2779, 512, 256);
	}

	@Override
	protected void method_25426() {
		field_2792 = 282;
		field_2779 = 182;
		super.method_25426();
		int i = this.field_2776;
		int j = this.field_2800;
		discovered = method_37063(new VeinsListWidget(i + 20, j + 24, 110, 140));
		veinTypes = method_37063(new VeinTypesListWidget(i + 150, j + 24, 110, 140));
		backButton = method_37063(new class_474(i + 20 + 4, j + 24 + 140 - 12, false, p_98287_ -> this.pageBack(), true));
		toggleHideButton = method_37063(new ToggleHideButton(i + 118, j + 9, b -> toggleHide()));
		toggleHideButton.method_47400(class_7919.method_47407(class_2561.method_43471("tooltip.coe.atlas.show_hide")));
		backButton.field_22763 = false;
		discovered.list = () -> veinsListSorted;
		veinTypes.list = () -> veinTypesListSorted;
		fillLists();
		updateVeinsList();
		updateVeinTypesList();
		discovered.updateContent();
		veinTypes.updateContent();
	}

	private void toggleHide() {
		if (selected != null) {
			toggleHideButton.hideMode = selected.hidden = !selected.hidden;
			send2(OreVeinAtlasClickPacket2.Option.TOGGLE_HIDE, veinsList.indexOf(selected));
			updateVeinsList();
		} else {
			toggleHideButton.hideMode = showHidden = !showHidden;
			updateVeinsList();
		}
	}

	private void pageBack() {
		backButton.field_22763 = false;
		discovered.setVisible(true);
		selected = null;
		toggleHideButton.hideMode = showHidden;
		toggleHideButton.method_47400(class_7919.method_47407(class_2561.method_43471("tooltip.coe.atlas.show_hide")));
		toggleHideButton.method_46421(field_2776 + 118);
		toggleHideButton.method_46419(field_2800 + 9);
	}

	public void setSelected(Vein selected) {
		this.selected = selected;
		toggleHideButton.hideMode = selected.hidden;
		toggleHideButton.method_47400(class_7919.method_47407(class_2561.method_43471("tooltip.coe.atlas.hide_vein")));
		toggleHideButton.method_46421(field_2776 + 18);
		toggleHideButton.method_46419(field_2800 + 24);
	}

	private void updateVeinTypesList() {
		veinTypesListSorted.clear();
		veinTypesListSorted.addAll(veinTypesList);
		veinTypes.updateContent();
	}

	private void updateVeinsList() {
		veinsListSorted.clear();
		veinsList.stream().filter(e -> e.hidden == showHidden).forEach(veinsListSorted::add);
		discovered.updateContent();
	}

	private void fillLists() {
		veinsList.clear();
		veinTypesList.clear();
		excluded.clear();
		class_1799 is = field_2797.getHeldItem();
		class_2487 tag = is.method_7969();
		if (tag == null)return;
		target = tag.method_10558(OreVeinAtlasItem.TARGET);
		class_2499 disc = tag.method_10554(OreVeinAtlasItem.DISCOVERED, class_2520.field_33258);
		class_2499 veins = tag.method_10554(OreVeinAtlasItem.VEINS, class_2520.field_33260);
		class_2499 exc = tag.method_10554(OreVeinAtlasItem.EXCLUDE, class_2520.field_33258);

		for (int i = 0;i < disc.size(); i++) {
			class_2960 v = class_2960.method_12829(disc.method_10608(i));
			if (class_310.method_1551().field_1687.method_8433().method_8130(v).orElse(null) instanceof VeinRecipe vr) {
				veinTypesList.add(vr);
			}
		}

		for (int i = 0;i < veins.size(); i++) {
			var v = veins.method_10602(i);
			int x = v.method_10550(OreVeinAtlasItem.POS_X);
			int z = v.method_10550(OreVeinAtlasItem.POS_Z);
			var vid = class_2960.method_12829(v.method_10558(OreVeinAtlasItem.VEIN_ID));
			var dim = class_2960.method_12829(v.method_10558(OreVeinAtlasItem.DIMENSION));
			var pos = new DimChunkPos(class_5321.method_29179(class_7924.field_41223, dim), x, z);
			float size = v.method_10583(OreVeinAtlasItem.SIZE);
			boolean hide = v.method_10577(OreVeinAtlasItem.HIDE);
			if (class_310.method_1551().field_1687.method_8433().method_8130(vid).orElse(null) instanceof VeinRecipe vr) {
				veinsList.add(new Vein(pos, vr, size, hide));
			}
		}

		for (int i = 0;i < exc.size(); i++) {
			class_2960 v = class_2960.method_12829(exc.method_10608(i));
			if (v != null)excluded.add(v);
		}
	}

	@Override
	public void method_25394(class_332 st, int mouseX, int mouseY, float partialTicks) {
		this.method_25420(st);
		super.method_25394(st, mouseX, mouseY, partialTicks);

		if (selected != null) {
			st.method_51448().method_22903();
			st.method_51448().method_46416(this.field_2776 + 60, this.field_2800 + 40, 0);
			float f = 2f;
			st.method_51448().method_22905(f, f, f);
			st.method_51427(selected.recipe.icon, 0, 0);
			st.method_51448().method_22909();

			var t = selected.recipe.veinName;
			st.method_51439(field_22793, t, this.field_2776 + 75 - field_22793.method_27525(t) / 2, this.field_2800 + 80, 4210752, false);

			long size = getVeinSize();
			if (size == 0)
				t = class_2561.method_43471("info.coe.atlas.vein_size.infinite");
			else
				t = class_2561.method_43470("~" + NumberFormatter.formatNumber(size));
			t = class_2561.method_43469("info.coe.atlas.vein_size", t);
			st.method_51439(field_22793, t, this.field_2776 + 15, this.field_2800 + 100, 4210752, false);

			t = class_2561.method_43471("info.coe.atlas.location");
			st.method_51439(field_22793, t, this.field_2776 + 15, this.field_2800 + 110, 4210752, false);
			t = class_2561.method_43469("info.coe.atlas.location2", Math.round((selected.pos.x * 16 + 8) / 10f) * 10, Math.round((selected.pos.z * 16 + 8) / 10f) * 10);
			st.method_51439(field_22793, t, this.field_2776 + 25, this.field_2800 + 120, 4210752, false);
			t = class_2561.method_43469("info.coe.atlas.dimension", selected.pos.dimension.method_29177().toString());
			st.method_51439(field_22793, t, this.field_2776 + 15, this.field_2800 + 130, 4210752, false);
		}
	}

	private long getVeinSize() {
		if (selected.recipe.isFinite() != ThreeState.NEVER) {
			if (selected.recipe.isFinite() == ThreeState.DEFAULT && field_2797.isDefaultInfinite())return 0L;
			double mul = (selected.recipe.getMaxAmount() - selected.recipe.getMinAmount()) * selected.size + selected.recipe.getMinAmount();
			long am = Math.round(mul * field_2797.getFiniteBase());
			return am;
		}
		return 0L;
	}

	@Override
	protected void method_2388(class_332 gr, int pMouseX, int pMouseY) {
		gr.method_51439(field_22793, field_22785, 75 - field_22793.method_27525(field_22785) / 2, 16, 4210752, false);
		gr.method_51439(field_22793, veinTypesTitle, 205 - field_22793.method_27525(veinTypesTitle) / 2, 16, 4210752, false);
	}

	private static class Vein {
		private final DimChunkPos pos;
		private final VeinRecipe recipe;
		private final float size;
		private boolean hidden;

		public Vein(DimChunkPos pos, VeinRecipe recipe, float size, boolean hidden) {
			this.pos = pos;
			this.recipe = recipe;
			this.size = size;
			this.hidden = hidden;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((pos == null) ? 0 : pos.hashCode());
			result = prime * result + ((recipe == null) ? 0 : recipe.id.hashCode());
			result = prime * result + Float.floatToIntBits(size);
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj) return true;
			if (obj == null) return false;
			if (getClass() != obj.getClass()) return false;
			Vein other = (Vein) obj;
			if (pos == null) {
				if (other.pos != null) return false;
			} else if (!pos.equals(other.pos)) return false;
			if (recipe == null) {
				if (other.recipe != null) return false;
			} else if (!recipe.id.equals(other.recipe.id)) return false;
			if (Float.floatToIntBits(size) != Float.floatToIntBits(other.size)) return false;
			return true;
		}
	}

	private static record VeinWidgetHolder(VeinInfoButton btn) {}

	private class VeinsListWidget extends PagedListWidget<VeinWidgetHolder, Vein> {

		public VeinsListWidget(int x, int y, int w, int h) {
			super(x, y, w, h, 20);
		}

		@Override
		protected <W extends class_339> W addWidgetToGUI(W w) {
			return method_37063(w);
		}

		@Override
		protected VeinWidgetHolder makeElement(int x, int y) {
			return new VeinWidgetHolder(method_37063(new VeinInfoButton(x, y, 110)));
		}

		@Override
		protected void updateElement(VeinWidgetHolder element, Vein data) {
			element.btn.field_22764 = data != null;
			if (data != null) {
				element.btn.setVein(data);
			}
		}
	}

	private class VeinTypeButton extends class_4185 {
		protected VeinRecipe recipe;

		private VeinTypeButton(int pX, int pY, int pWidth, int pHeight) {
			super(pX, pY, pWidth, pHeight, class_2561.method_43473(), NULL_PRESS, field_40754);
		}

		@Override
		protected void method_48579(class_332 pGuiGraphics, int pMouseX, int pMouseY, float pPartialTick) {
			class_310 minecraft = class_310.method_1551();
			pGuiGraphics.method_51422(1.0F, 1.0F, 1.0F, this.field_22765);
			RenderSystem.enableBlend();
			RenderSystem.enableDepthTest();
			pGuiGraphics.method_49697(BUTTON_LOCATION, this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364(), 20, 4, 200, 20, 0, this.getBtnTextureY());
			pGuiGraphics.method_51422(1.0F, 1.0F, 1.0F, 1.0F);
			int i = field_22762 ? 0xFCFCA0 : 0xC0C0C0;
			this.renderScrollingText(pGuiGraphics, minecraft.field_1772, 20, i | class_3532.method_15386(this.field_22765 * 255.0F) << 24);
			renderItem(pGuiGraphics);
		}

		protected void renderItem(class_332 pGuiGraphics) {
			pGuiGraphics.method_51427(recipe.icon, method_46426() + 1, method_46427() + 1);
		}

		protected void renderScrollingText(class_332 pGuiGraphics, class_327 pFont, int pWidth, int pColor) {
			int i = this.method_46426() + pWidth;
			int j = this.method_46426() + this.method_25368();
			method_49605(pGuiGraphics, pFont, this.method_25369(), i, this.method_46427(), j, this.method_46427() + this.method_25364(), pColor);
		}

		private int getBtnTextureY() {
			int i = 1;
			if (!this.field_22763) {
				i = 0;
			} else if (this.method_25367()) {
				i = 2;
			}

			return 46 + i * 20;
		}

		public class_7919 createTooltip() {
			return null;
		}

		public void method_47401() {
			method_47400(createTooltip());
		}

		@Override
		public void method_25306() {
		}
	}

	private class ToggleHideButton extends class_4185 {
		private boolean hideMode;

		private ToggleHideButton(int pX, int pY, class_4185.class_4241 pOnPress) {
			super(pX, pY, 16, 16, class_2561.method_43473(), pOnPress, field_40754);
		}

		@Override
		protected void method_48579(class_332 pGuiGraphics, int pMouseX, int pMouseY, float pPartialTick) {
			pGuiGraphics.method_51422(1.0F, 1.0F, 1.0F, this.field_22765);
			RenderSystem.enableBlend();
			RenderSystem.enableDepthTest();
			pGuiGraphics.method_49697(BUTTON_LOCATION, this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364(), 20, 4, 200, 20, 0, this.getBtnTextureY());
			pGuiGraphics.method_51422(1.0F, 1.0F, 1.0F, 1.0F);
			pGuiGraphics.method_25293(hideMode ? HIDE : SHOW, this.method_46426(), this.method_46427(), 16, 16, 0, 0, 16, 16, 16, 16);
		}

		private int getBtnTextureY() {
			int i = 1;
			if (!this.field_22763) {
				i = 0;
			} else if (this.method_25367()) {
				i = 2;
			}

			return 46 + i * 20;
		}
	}

	private class VeinInfoButton extends VeinTypeButton {
		private Vein vein;

		private VeinInfoButton(int pX, int pY, int pWidth) {
			super(pX, pY, pWidth, 20);
		}

		@Override
		public void method_25306() {
			discovered.setVisible(false);
			backButton.field_22763 = true;
			setSelected(vein);
		}

		public void setVein(Vein vein) {
			this.vein = vein;
			recipe = vein.recipe;
			method_25355(vein.recipe.getName());
		}
	}

	private class VeinTargetButton extends VeinTypeButton {
		private class_7919 TT_TARGET;
		private class_7919 TT_SWITCH_TARGET;
		private class_7919 TT_SET_TARGET;

		private VeinTargetButton(int pX, int pY, int pWidth) {
			super(pX, pY, pWidth, 10);
			TT_TARGET = class_7919.method_47407(class_2561.method_43471("tooltip.coe.atlas.target"));
			TT_SWITCH_TARGET = class_7919.method_47407(class_2561.method_43471("tooltip.coe.atlas.switch_target"));
			TT_SET_TARGET = class_7919.method_47407(class_2561.method_43471("tooltip.coe.atlas.set_target"));
		}

		@Override
		protected void renderItem(class_332 pGuiGraphics) {
			pGuiGraphics.method_51448().method_22903();
			pGuiGraphics.method_51448().method_46416(method_46426() + 1, method_46427() + 1, 0);
			float f = 0.5f;
			pGuiGraphics.method_51448().method_22905(f, f, f);
			pGuiGraphics.method_51427(recipe.icon, 0, 0);
			pGuiGraphics.method_51448().method_22909();

			if (target != null && !target.isEmpty() && target.equals(recipe.id.toString())) {
				pGuiGraphics.method_25293(TARGET, this.method_46426() + 10, this.method_46427() + 1, 8, 8, 0, 0, 16, 16, 16, 16);
			}
		}

		@Override
		public class_7919 createTooltip() {
			if(target != null && !target.isEmpty()) {
				if (target.equals(recipe.id.toString()))
					return TT_TARGET;
				else
					return TT_SWITCH_TARGET;
			} else {
				return TT_SET_TARGET;
			}
		}

		@Override
		public void method_25306() {
			if(target != null && !target.isEmpty()) {
				if (target.equals(recipe.id.toString()))target(null);
				else target(recipe);
			} else {
				target(recipe);
			}
		}
	}

	private class VeinExcludeButton extends class_4185 {
		private VeinRecipe data;
		private class_7919 TT_EXCLUDE;
		private class_7919 TT_INCLUDE;

		protected VeinExcludeButton(int pX, int pY) {
			super(pX, pY, 10, 10, class_2561.method_43473(), NULL_PRESS, field_40754);
			TT_EXCLUDE = class_7919.method_47407(class_2561.method_43471("tooltip.coe.atlas.exclude"));
			TT_INCLUDE = class_7919.method_47407(class_2561.method_43471("tooltip.coe.atlas.include"));
		}

		@Override
		protected void method_48579(class_332 pGuiGraphics, int pMouseX, int pMouseY, float pPartialTick) {
			pGuiGraphics.method_51422(1.0F, 1.0F, 1.0F, this.field_22765);
			RenderSystem.enableBlend();
			RenderSystem.enableDepthTest();
			pGuiGraphics.method_49697(BUTTON_LOCATION, this.method_46426(), this.method_46427(), this.method_25368(), this.method_25364(), 20, 4, 200, 20, 0, this.getBtnTextureY());
			pGuiGraphics.method_51422(1.0F, 1.0F, 1.0F, 1.0F);

			if (excluded.contains(data.id)) {
				pGuiGraphics.method_25293(EXCLUDE, this.method_46426() + 1, this.method_46427() + 1, 8, 8, 0, 0, 16, 16, 16, 16);
			}
		}

		private int getBtnTextureY() {
			int i = 1;
			if (!this.field_22763) {
				i = 0;
			} else if (this.method_25367()) {
				i = 2;
			}

			return 106 + i * 20;
		}

		@Override
		public void method_25306() {
			if(excluded.contains(data.id)) {
				exclude(data, false);
			} else {
				exclude(data, true);
			}
		}

		public class_7919 createTooltip() {
			if(excluded.contains(data.id)) {
				return TT_EXCLUDE;
			} else {
				return TT_INCLUDE;
			}
		}

		public void method_47401() {
			method_47400(createTooltip());
		}
	}

	private static record VeinTypeWidgetHolder(VeinTargetButton btn, VeinExcludeButton trg) {}

	private class VeinTypesListWidget extends PagedListWidget<VeinTypeWidgetHolder, VeinRecipe> {

		public VeinTypesListWidget(int x, int y, int w, int h) {
			super(x, y, w, h, 10);
		}

		@Override
		protected <W extends class_339> W addWidgetToGUI(W w) {
			return method_37063(w);
		}

		@Override
		protected VeinTypeWidgetHolder makeElement(int x, int y) {
			return new VeinTypeWidgetHolder(
					method_37063(new VeinTargetButton(x, y, 100)),
					method_37063(new VeinExcludeButton(x + 100, y))
					);
		}

		@Override
		protected void updateElement(VeinTypeWidgetHolder element, VeinRecipe data) {
			element.btn.field_22764 = data != null;
			element.trg.field_22764 = data != null;
			if (data != null) {
				element.btn.recipe = data;
				element.btn.method_25355(data.getName());
				element.btn.method_47401();
				element.trg.data = data;
				element.trg.method_47401();
			}
		}
	}

	public void exclude(VeinRecipe data, boolean ex) {
		if (ex) {
			excluded.add(data.id);
			target = null;
			send(Option.ADD_EXCLUDE, data.id);
		} else {
			excluded.remove(data.id);
			send(Option.REMOVE_EXCLUDE, data.id);
		}
		veinTypes.updateContent();
	}

	private void send(Option opt, class_2960 id) {
		NetworkHandler.sendDataToServer(new OreVeinAtlasClickPacket(opt, id));
	}

	private void send2(OreVeinAtlasClickPacket2.Option opt, int id) {
		NetworkHandler.sendDataToServer(new OreVeinAtlasClickPacket2(opt, id));
	}

	public void target(VeinRecipe data) {
		if (data != null) {
			target = data.id.toString();
			send(Option.SET_TARGET, data.id);
		} else {
			target = null;
			send(Option.REMOVE_TARGET, null);
		}
		veinTypes.updateContent();
	}
}

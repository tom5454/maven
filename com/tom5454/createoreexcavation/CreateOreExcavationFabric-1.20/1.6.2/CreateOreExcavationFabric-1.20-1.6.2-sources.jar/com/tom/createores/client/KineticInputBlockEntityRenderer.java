package com.tom.createores.client;

import net.createmod.catnip.render.CachedBuffers;
import net.createmod.catnip.render.SuperByteBuffer;
import net.minecraft.class_2680;
import net.minecraft.class_5614;
import com.simibubi.create.AllPartialModels;
import com.simibubi.create.content.kinetics.base.KineticBlockEntityRenderer;

import com.tom.createores.block.KineticInputBlock;
import com.tom.createores.block.entity.KineticInputBlockEntity;

public class KineticInputBlockEntityRenderer extends KineticBlockEntityRenderer<KineticInputBlockEntity> {

	public KineticInputBlockEntityRenderer(class_5614.class_5615 dispatcher) {
		super(dispatcher);
	}

	@Override
	protected SuperByteBuffer getRotatedModel(KineticInputBlockEntity te, class_2680 state) {
		return CachedBuffers.partialFacing(AllPartialModels.SHAFT_HALF, state, state.method_11654(KineticInputBlock.SHAFT_FACING));
	}
}
package com.tom.createores.jm;

import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.Registration;
import com.tom.createores.item.OreVeinAtlasItem;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.DimChunkPos;

import journeymap.api.v2.client.IClientAPI;
import journeymap.api.v2.client.display.Displayable;
import journeymap.api.v2.client.display.PolygonOverlay;
import journeymap.api.v2.client.fullscreen.IThemeButton;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

public enum OreVeinsOverlay {
	INSTANCE;
	private static final Gson gson = new GsonBuilder().create();
	private IClientAPI api;
	private Map<DimChunkPos, OreVeinInfo> chunkDataLegacy = new HashMap<>();
	private Map<DimChunkPos, OreVeinInfo> chunkDataAtlas = new HashMap<>();
	private Map<DimChunkPos, PolygonOverlay> chunkOverlays = new HashMap<>();
	private List<OreDistanceInfo> oreDistanceInfos = new ArrayList<>();
	private List<OreNearbyInfo> oreNearbyInfos = new ArrayList<>();
	private final class_310 mc = class_310.method_1551();
	private boolean activated = true;

	public void setApi(IClientAPI api) {
		this.api = api;
	}

	@SuppressWarnings("unchecked")
	public void onMappingStarted() {
		final var level = mc.field_1687;

		if (level == null) return;

		File modFolder = api.getDataPath(CreateOreExcavation.MODID);
		File veins = new File(modFolder, "veins.json");
		if (veins.exists()) {
			class_1863 mngr = class_310.method_1551().method_1562().method_2877();
			try (FileReader rd = new FileReader(veins)) {
				Map<String, Object> root = (Map<String, Object>) gson.fromJson(rd, Object.class);
				((List<Map<String, Object>>) root.getOrDefault("veins", Collections.emptyList())).forEach(dimMap -> {
					class_2960 dimKey = class_2960.method_12829((String) dimMap.get("dim"));
					class_5321<class_1937> lvl = class_5321.method_29179(class_7924.field_41223, dimKey);
					((List<Map<String, Object>>) dimMap.getOrDefault("veins", Collections.emptyList())).forEach(vein -> {
						int x = ((Number) vein.get("x")).intValue();
						int z = ((Number) vein.get("z")).intValue();
						class_2960 key = class_2960.method_12829((String) vein.get("id"));
						VeinRecipe v = mngr.method_8130(key).filter(r -> r instanceof VeinRecipe).map(r -> (VeinRecipe) r).orElse(null);
						if (v != null) {
							var p = new DimChunkPos(lvl, x, z);
							chunkDataLegacy.put(p, new OreVeinInfo(p, v, true));
						}
					});
				});
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		chunkDataLegacy.forEach((k, data) -> {
			if (!k.dimension.equals(level.method_27983())) return;
			showOverlay(data.getOverlay());
			chunkOverlays.put(k, data.getOverlay());
		});
	}

	public void showOverlay(Displayable overlay) {
		try {
			api.show(overlay);
		} catch (Throwable t) {
			CreateOreExcavation.LOGGER.error(String.valueOf(t));
		}
	}

	public void showOverlays(Collection<? extends Displayable> overlays) {
		overlays.forEach(this::showOverlay);
	}

	public void removeOverlays(Collection<? extends Displayable> overlays) {
		overlays.forEach(o -> api.remove(o));
	}

	public void onMappingStopped() {
		File modFolder = api.getDataPath(CreateOreExcavation.MODID);
		File veins = new File(modFolder, "veins.json");
		modFolder.mkdirs();
		try {
			Map<class_2960, List<Map<String, Object>>> dimMap = new HashMap<>();
			chunkDataLegacy.forEach((k, v) -> {
				Map<String, Object> m = new HashMap<>();
				m.put("x", k.x);
				m.put("z", k.z);
				m.put("id", v.id.toString());
				dimMap.computeIfAbsent(k.dimension.method_29177(), __ -> new ArrayList<>()).add(m);
			});
			Map<String, Object> root = new HashMap<>();
			List<Map<String, Object>> vs = new ArrayList<>();
			root.put("veins", vs);
			dimMap.forEach((k, v) -> {
				Map<String, Object> d = new HashMap<>();
				vs.add(d);
				d.put("dim", k.toString());
				d.put("veins", v);
			});
			try (PrintWriter w = new PrintWriter(veins)) {
				gson.toJson(root, w);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		chunkDataLegacy.clear();
		chunkDataAtlas.clear();
		chunkOverlays.clear();
		oreDistanceInfos.clear();
		oreNearbyInfos.clear();
	}

	private void toggleOverlay() {
		if (isActivated()) {
			removeOverlays(chunkOverlays.values());
			oreDistanceInfos.forEach(e -> api.remove(e.getOverlay()));
			oreNearbyInfos.forEach(e -> api.remove(e.getOverlay()));
		} else {
			showOverlays(chunkOverlays.values());
			oreDistanceInfos.forEach(e -> showOverlay(e.getOverlay()));
			oreNearbyInfos.forEach(e -> showOverlay(e.getOverlay()));
		}

		activated = !isActivated();
	}

	public boolean isActivated() {
		return activated;
	}

	public void toggle(IThemeButton button) {
		toggleOverlay();
		button.setToggled(activated);
	}

	public void setVeinInfo(class_1923 posIn, class_2960 id) {
		DimChunkPos pos = new DimChunkPos(mc.field_1687, posIn);
		if (chunkDataLegacy.containsKey(pos)) {
			PolygonOverlay ov = chunkOverlays.remove(pos);
			if (activated && ov != null)api.remove(ov);
		}
		class_1863 mngr = class_310.method_1551().method_1562().method_2877();
		VeinRecipe vein = mngr.method_8130(id).filter(r -> r instanceof VeinRecipe).map(r -> (VeinRecipe) r).orElse(null);
		if (vein != null) {
			var info = new OreVeinInfo(pos, vein, true);
			chunkDataLegacy.put(pos, info);
			if (activated) showOverlay(info.getOverlay());
			chunkOverlays.put(pos, info.getOverlay());
		}
	}

	public void addVeinNearbyInfo(class_1923 center, class_2960 id) {
		if (oreDistanceInfos.size() > 2) {
			OreDistanceInfo ov = oreDistanceInfos.remove(0);
			if (activated && ov != null)api.remove(ov.getOverlay());
		}
		long time = mc.field_1687.method_8510();
		class_1863 mngr = class_310.method_1551().method_1562().method_2877();
		VeinRecipe vein = mngr.method_8130(id).filter(r -> r instanceof VeinRecipe).map(r -> (VeinRecipe) r).orElse(null);
		if (vein != null) {
			var v = new OreNearbyInfo(mc.field_1687.method_27983(), center, vein, time + 30 * 20);
			oreNearbyInfos.add(v);
			if (activated) showOverlay(v.getOverlay());
		}
	}

	public void addVeinDistanceInfo(class_2338 center, int radius, class_2960 id) {
		if (oreDistanceInfos.size() > 2) {
			OreDistanceInfo ov = oreDistanceInfos.remove(0);
			if (activated && ov != null)api.remove(ov.getOverlay());
		}
		long time = mc.field_1687.method_8510();
		class_1863 mngr = class_310.method_1551().method_1562().method_2877();
		VeinRecipe vein = mngr.method_8130(id).filter(r -> r instanceof VeinRecipe).map(r -> (VeinRecipe) r).orElse(null);
		if (vein != null) {
			var v = new OreDistanceInfo(mc.field_1687.method_27983(), center, radius, vein, time + 30 * 20);
			oreDistanceInfos.add(v);
			if (activated) showOverlay(v.getOverlay());
		}
	}

	public void tick() {
		if (mc.field_1687 == null)return;
		long time = mc.field_1687.method_8510();
		if (time % 20 == 0 && isActivated()) {
			class_1799 atlas = class_1799.field_8037;
			int c = mc.field_1724.method_31548().method_5439();
			for (int i = 0;i<c;i++) {
				var is = mc.field_1724.method_31548().method_5438(i);
				if (is.method_7909() == Registration.VEIN_ATLAS_ITEM.get()) {
					atlas = is;
					break;
				}
			}
			Set<DimChunkPos> found = new HashSet<>();
			if (!atlas.method_7960() && atlas.method_7969() != null) {
				class_2499 veins = atlas.method_7969().method_10554(OreVeinAtlasItem.VEINS, class_2520.field_33260);
				for (int i = 0;i < veins.size(); i++) {
					var v = veins.method_10602(i);
					if (v.method_10577(OreVeinAtlasItem.HIDE))continue;
					int x = v.method_10550(OreVeinAtlasItem.POS_X);
					int z = v.method_10550(OreVeinAtlasItem.POS_Z);
					var vid = class_2960.method_12829(v.method_10558(OreVeinAtlasItem.VEIN_ID));
					var dim = class_2960.method_12829(v.method_10558(OreVeinAtlasItem.DIMENSION));
					if (!dim.equals(mc.field_1687.method_27983().method_29177()))continue;
					var pos = new DimChunkPos(class_5321.method_29179(class_7924.field_41223, dim), x, z);
					if (class_310.method_1551().field_1687.method_8433().method_8130(vid).orElse(null) instanceof VeinRecipe vr) {
						found.add(pos);
						OreVeinInfo info = new OreVeinInfo(pos, vr, false);
						if (chunkDataAtlas.containsKey(pos)) {
							if (!chunkDataAtlas.get(pos).equals(info)) {
								PolygonOverlay ov = chunkOverlays.remove(pos);
								if (activated && ov != null)api.remove(ov);
							} else continue;
						}
						chunkDataAtlas.put(pos, info);
						if (activated) showOverlay(info.getOverlay());
						chunkOverlays.put(pos, info.getOverlay());
						chunkDataLegacy.remove(pos);
					}
				}
			}
			chunkDataAtlas.keySet().removeIf(e -> {
				if (!found.contains(e)) {
					PolygonOverlay ov = chunkOverlays.remove(e);
					if (activated && ov != null)api.remove(ov);
					return true;
				}
				return false;
			});
		}
		if (!oreDistanceInfos.isEmpty()) {
			oreDistanceInfos.removeIf(i -> {
				var t = i.timedOut(time);
				if (t)api.remove(i.getOverlay());
				return t;
			});
		}
		if (!oreNearbyInfos.isEmpty()) {
			oreNearbyInfos.removeIf(i -> {
				var t = i.timedOut(time);
				if (t)api.remove(i.getOverlay());
				return t;
			});
		}
	}

	public static void addOreInfoToMap(class_2487 tag) {
		int x = tag.method_10550("x");
		int z = tag.method_10550("z");
		class_2338 pos = new class_2338(x, 0, z);
		class_1923 center = new class_1923(pos);
		if (tag.method_10545("found")) {
			class_2960 id = class_2960.method_12829(tag.method_10558("found"));
			OreVeinsOverlay.INSTANCE.setVeinInfo(center, id);
		}
		if (tag.method_10545("nearby")) {
			class_2960 id = class_2960.method_12829(tag.method_10558("nearby"));
			OreVeinsOverlay.INSTANCE.addVeinNearbyInfo(center, id);
		}
		if (tag.method_10545("far")) {
			class_2960 id = class_2960.method_12829(tag.method_10558("far"));
			int dist = tag.method_10550("dist");
			OreVeinsOverlay.INSTANCE.addVeinDistanceInfo(pos, dist, id);
		}
	}
}

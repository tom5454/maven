package com.tom.createores;

import org.slf4j.Logger;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1792;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraftforge.fml.config.ModConfig;

import com.mojang.logging.LogUtils;
import com.simibubi.create.foundation.data.CreateRegistrate;

import com.tom.createores.network.Packets;
import com.tom.createores.recipe.DrillingRecipe;
import com.tom.createores.recipe.ExcavatingRecipe;
import com.tom.createores.recipe.ExtractorRecipe;
import com.tom.createores.recipe.VeinRecipe;

import fuzs.forgeconfigapiport.api.config.v2.ForgeConfigRegistry;
import fuzs.forgeconfigapiport.api.config.v2.ModConfigEvents;

public class CreateOreExcavation implements ModInitializer {
	public static final String MODID = "createoreexcavation";
	public static final Logger LOGGER = LogUtils.getLogger();

	private static CreateRegistrate registrate;
	public static boolean journeyMap;

	public static final RecipeTypeGroup<DrillingRecipe> DRILLING_RECIPES = recipe("drilling", DrillingRecipe::new);
	public static final RecipeTypeGroup<ExtractorRecipe> EXTRACTING_RECIPES = recipe("extracting", ExtractorRecipe::new);
	public static final RecipeTypeGroup<VeinRecipe> VEIN_RECIPES = recipe("vein", VeinRecipe::new);

	public static final class_6862<class_1792> DRILL_TAG = class_6862.method_40092(class_7924.field_41197, new class_2960(MODID, "drills"));

	public CreateOreExcavation() {
		registrate = CreateRegistrate.create(MODID);

		ForgeConfigRegistry.INSTANCE.register(CreateOreExcavation.MODID, ModConfig.Type.COMMON, Config.commonSpec);
		ForgeConfigRegistry.INSTANCE.register(CreateOreExcavation.MODID, ModConfig.Type.SERVER, Config.serverSpec);

		ModConfigEvents.loading(CreateOreExcavation.MODID).register(c -> {
			LOGGER.info("Loaded Create Ore Excavation config file {}", c.getFileName());
			Config.load(c);
		});
		ModConfigEvents.reloading(CreateOreExcavation.MODID).register(c -> {
			LOGGER.info("Create Ore Excavation config just got changed on the file system!");
			Config.load(c);
		});
		Packets.init();

		Registration.register();
	}

	private static <T extends ExcavatingRecipe> RecipeTypeGroup<T> recipe(String name, ExcavatingRecipe.RecipeFactory<T> factory) {
		RecipeTypeGroup<T> rg = new RecipeTypeGroup<>(new class_2960(MODID, name));
		String stringId = rg.id.toString();
		rg.recipeType = class_2378.method_10230(class_7923.field_41188, rg.id, new class_3956<T>() {

			@Override
			public String toString() {
				return stringId;
			}
		});
		rg.serializer = class_2378.method_10230(class_7923.field_41189, rg.id, new ExcavatingRecipe.Serializer<>(rg, factory));
		return rg;
	}

	private static <T extends VeinRecipe> RecipeTypeGroup<T> recipe(String name, VeinRecipe.RecipeFactory<T> factory) {
		RecipeTypeGroup<T> rg = new RecipeTypeGroup<>(new class_2960(MODID, name));
		String stringId = rg.id.toString();
		rg.recipeType = class_2378.method_10230(class_7923.field_41188, rg.id, new class_3956<T>() {

			@Override
			public String toString() {
				return stringId;
			}
		});
		rg.serializer = class_2378.method_10230(class_7923.field_41189, rg.id, new VeinRecipe.Serializer<>(rg, factory));
		return rg;
	}

	public static class RecipeTypeGroup<T extends class_1860<?>> {
		private class_1865<T> serializer;
		private class_3956<T> recipeType;
		private class_2960 id;

		public RecipeTypeGroup(class_2960 id) {
			this.id = id;
		}

		public class_3956<T> getRecipeType() {
			return recipeType;
		}

		public class_1865<T> getSerializer() {
			return serializer;
		}

		public class_2960 getId() {
			return id;
		}
	}

	public static CreateRegistrate registrate() {
		return registrate;
	}

	@Override
	public void onInitialize() {
		LOGGER.info("Create Ore Excavation starting");
		registrate.register();
		Registration.postRegister();
		OreDataCapability.init();
		//BlockStressValues.registerProvider(MODID, AllConfigs.SERVER.kinetics.stressValues);
		COECommand.init();
	}

	public static boolean isModLoaded(String string) {
		return FabricLoader.getInstance().isModLoaded(string);
	}
}

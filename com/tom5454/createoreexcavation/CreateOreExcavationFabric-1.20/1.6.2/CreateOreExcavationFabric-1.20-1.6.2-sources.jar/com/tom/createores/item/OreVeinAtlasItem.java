package com.tom.createores.item;

import com.tom.createores.Registration;
import com.tom.createores.menu.OreVeinAtlasMenu;
import com.tom.createores.network.OreVeinAtlasClickPacket.Option;
import com.tom.createores.network.OreVeinAtlasClickPacket2;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.DimChunkPos;
import com.tom.createores.util.PlatformMenuProvider;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class OreVeinAtlasItem extends class_1792 implements PlatformMenuProvider {
	public static final String DISCOVERED = "discovered";
	public static final String EXCLUDE = "exclude";
	public static final String VEINS = "veins";
	public static final String TARGET = "veinTarget";
	public static final String SIZE = "size";
	public static final String DIMENSION = "dim";
	public static final String POS_X = "x";
	public static final String POS_Z = "z";
	public static final String VEIN_ID = "id";
	public static final String HIDE = "hide";

	public OreVeinAtlasItem(class_1793 p_41383_) {
		super(p_41383_);
	}

	public void addVein(class_1657 player, class_1799 is, VeinRecipe vein, DimChunkPos pos, float randomMul) {
		player.method_7353(class_2561.method_43471("chat.coe.sampleDrill.addedToAtlas"), false);

		var tag = is.method_7948();
		class_2499 disc = tag.method_10554(DISCOVERED, class_2520.field_33258);
		tag.method_10566(DISCOVERED, disc);
		String id = vein.method_8114().toString();
		boolean found = false;
		for (int i = 0;i < disc.size(); i++) {
			var v = disc.method_10608(i);
			if (id.equals(v)) {
				found = true;
				break;
			}
		}
		if (!found) {
			disc.add(class_2519.method_23256(id));
		}

		class_2499 veins = tag.method_10554(VEINS, class_2520.field_33260);
		tag.method_10566(VEINS, veins);
		String dimId = pos.dimension.method_29177().toString();
		found = false;
		for (int i = 0;i < veins.size(); i++) {
			var v = veins.method_10602(i);
			int x = v.method_10550(POS_X);
			int z = v.method_10550(POS_Z);
			var vid = v.method_10558(VEIN_ID);
			var dim = v.method_10558(DIMENSION);
			if (dimId.equals(dim) && x == pos.x && z == pos.z) {
				if(!vid.equals(id))
					v.method_10582(VEIN_ID, id);
				v.method_10548(SIZE, randomMul);
				found = true;
				break;
			}
		}
		if (!found) {
			var t = new class_2487();
			t.method_10569(POS_X, pos.x);
			t.method_10569(POS_Z, pos.z);
			t.method_10582(DIMENSION, dimId);
			t.method_10582(VEIN_ID, id);
			veins.add(t);
		}
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 world, class_1657 player, class_1268 hand) {
		if (!world.field_9236) {
			player.method_17355(this);
		}
		return class_1271.method_22430(player.method_5998(hand));
	}

	@Override
	public class_1703 createMenu(int pContainerId, class_1661 pPlayerInventory, class_1657 pPlayer) {
		class_1799 heldItem = pPlayer.method_6047();
		return new OreVeinAtlasMenu(Registration.VEIN_ATLAS_MENU.get(), pContainerId, pPlayerInventory, heldItem);
	}

	@Override
	public class_2561 method_5476() {
		return method_7848();
	}

	public void menuClicked(class_1799 is, Option opt, class_2960 id) {
		var tag = is.method_7948();

		switch (opt) {
		case ADD_EXCLUDE:
		{
			class_2499 ex = tag.method_10554(EXCLUDE, class_2520.field_33258);
			tag.method_10566(EXCLUDE, ex);
			ex.add(class_2519.method_23256(id.toString()));
		}
		break;

		case REMOVE_EXCLUDE:
		{
			class_2499 ex = tag.method_10554(EXCLUDE, class_2520.field_33258);
			tag.method_10566(EXCLUDE, ex);
			String st = id.toString();
			ex.removeIf(t -> t instanceof class_2519 s && s.method_10714().equals(st));
		}
		break;

		case REMOVE_TARGET:
			tag.method_10551(TARGET);
			break;

		case SET_TARGET:
			tag.method_10582(TARGET, id.toString());
			class_2499 ex = tag.method_10554(EXCLUDE, class_2520.field_33258);
			tag.method_10566(EXCLUDE, ex);
			String st = id.toString();
			ex.removeIf(t -> t instanceof class_2519 s && s.method_10714().equals(st));
			break;

		default:
			break;
		}
	}

	public void menuClicked2(class_1799 is, OreVeinAtlasClickPacket2.Option opt, int id) {
		var tag = is.method_7948();

		switch (opt) {
		case TOGGLE_HIDE:
		{
			class_2499 veins = tag.method_10554(VEINS, class_2520.field_33260);
			if (veins.size() > id) {
				var v = veins.method_10602(id);
				v.method_10556(HIDE, !v.method_10577(HIDE));
			}
		}
		break;

		default:
			break;
		}
	}
}

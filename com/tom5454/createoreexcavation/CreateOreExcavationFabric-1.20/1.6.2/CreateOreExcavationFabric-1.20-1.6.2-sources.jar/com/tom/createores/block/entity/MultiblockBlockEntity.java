package com.tom.createores.block.entity;

import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import com.simibubi.create.api.equipment.goggles.IHaveGoggleInformation;

import com.tom.createores.block.MultiblockPart;
import com.tom.createores.block.MultiblockPart.MultiblockGhostPart;

public class MultiblockBlockEntity extends class_2586 implements IHaveGoggleInformation {

	public MultiblockBlockEntity(class_2591<?> pType, class_2338 pWorldPosition, class_2680 pBlockState) {
		super(pType, pWorldPosition, pBlockState);
	}

	@Override
	public boolean addToGoggleTooltip(List<class_2561> tooltip, boolean isPlayerSneaking) {
		class_2680 state = field_11863.method_8320(field_11867);
		class_2338 pos = field_11867;
		for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
			class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
			pos = pos.method_10079(d, 1);
			state = field_11863.method_8320(pos);
		}
		if (state.method_26204() instanceof MultiblockPart) {
			MultiblockPart d = (MultiblockPart) state.method_26204();
			if (d instanceof MultiblockGhostPart)return false;
			else {
				class_2586 te = field_11863.method_8321(pos);
				if (te instanceof MultiblockCapHandler) {
					return ((MultiblockCapHandler)te).addToGoggleTooltip(tooltip, isPlayerSneaking);
				} else {
					return false;
				}
			}
		}
		return false;
	}
}

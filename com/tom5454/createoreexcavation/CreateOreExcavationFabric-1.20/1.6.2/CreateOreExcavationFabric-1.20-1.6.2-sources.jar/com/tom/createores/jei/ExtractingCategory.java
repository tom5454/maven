package com.tom.createores.jei;

import com.simibubi.create.compat.jei.DoubleItemIcon;
import com.simibubi.create.compat.jei.category.CreateRecipeCategory;

import com.tom.createores.Registration;
import com.tom.createores.recipe.ExtractorRecipe;

import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.recipe.IFocusGroup;
import mezz.jei.api.recipe.RecipeType;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

public class ExtractingCategory extends ExcavatingCategory<ExtractorRecipe> {

	public ExtractingCategory() {
		block = new AnimatedBlock(Registration.EXTRACTOR_BLOCK.getDefaultState(), 11);
		icon = new DoubleItemIcon(Registration.EXTRACTOR_BLOCK::asStack, () -> new class_1799(class_1802.field_8550));
	}

	@Override
	public class_2561 getTitle() {
		return class_2561.method_43471("jei.coe.recipe.extracting");
	}

	@Override
	public RecipeType<ExtractorRecipe> getRecipeType() {
		return JEIHandler.EXTRACTING;
	}

	@Override
	public void setRecipe(IRecipeLayoutBuilder builder, ExtractorRecipe recipe, IFocusGroup focuses) {
		super.setRecipe(builder, recipe, focuses);

		int xOffset = getBackground().getWidth() / 2;
		int yOffset = 86;

		CreateRecipeCategory.addFluidSlot(builder, xOffset - 8, yOffset - 8, recipe.getOutput());
	}
}

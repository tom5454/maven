package com.tom.createores.network;

import java.util.function.Function;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import io.netty.buffer.Unpooled;

public class NetworkHandler {

	public static void sendDataToServer(Packet packet) {
		class_2540 buf = new class_2540(Unpooled.buffer());
		packet.toBytes(buf);
		ClientPlayNetworking.send(packet.getId(), buf);
	}

	public static void sendTo(class_3222 player, Packet packet) {
		class_2540 buf = new class_2540(Unpooled.buffer());
		packet.toBytes(buf);
		ServerPlayNetworking.send(player, packet.getId(), buf);
	}

	public static <T extends Packet> void register(class_2960 rl, Class<T> clazz, Function<class_2540, T> factory) {
		ServerPlayNetworking.registerGlobalReceiver(rl, (s, p, h, buf, rp) -> {
			T f = factory.apply(buf);
			s.method_20493(() -> f.handleServer(p));
		});
	}

}

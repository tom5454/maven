package com.tom.createores.emi;

import com.simibubi.create.compat.emi.CreateEmiAnimations;

import dev.emi.emi.api.widget.WidgetHolder;
import net.minecraft.class_2680;
import net.minecraft.class_7833;

public class AnimatedBlock  {

	public static void addBlock(class_2680 state, WidgetHolder widgets, int x, int y) {
		widgets.addDrawable(x, y, 0, 0, (matrices, mouseX, mouseY, delta) -> {
			matrices.method_51448().method_46416(0, 0, 200);
			matrices.method_51448().method_22907(class_7833.field_40714.rotationDegrees(-12.5f));
			matrices.method_51448().method_22907(class_7833.field_40716.rotationDegrees(22.5f));
			int scale = 16;

			CreateEmiAnimations.blockElement(state)
			.rotateBlock(0, 0, 0)
			.scale(scale)
			.render(matrices);
		});
	}
}

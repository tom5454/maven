package com.tom.createores;

import java.util.stream.Stream;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1923;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2172;
import net.minecraft.class_2232;
import net.minecraft.class_2262;
import net.minecraft.class_2321;
import net.minecraft.class_2338;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2564;
import net.minecraft.class_2568;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_637;
import net.minecraft.class_7157;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.SuggestionProvider;

import com.google.common.base.Stopwatch;

import com.tom.createores.OreDataCapability.OreData;
import com.tom.createores.recipe.ExcavatingRecipe;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.RandomSpreadGenerator;

public class COECommand {
	private static final DynamicCommandExceptionType ERROR_VEIN_NOT_FOUND = new DynamicCommandExceptionType((p_214514_) -> {
		return class_2561.method_43469("command.coe.locate.failed", p_214514_);
	});

	public static void init() {
		CommandRegistrationCallback.EVENT.register(COECommand::register);
	}

	public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 registryAccess, class_2170.class_5364 environment) {
		LiteralArgumentBuilder<class_2168> l = class_2170.method_9247("coe");
		l.then(class_2170.method_9247("setvein").requires(s -> s.method_9259(2)).
				then(class_2170.method_9244("pos", class_2262.method_9698()).
						then(class_2170.method_9244("recipe", class_2232.method_9441()).suggests(ALL_RECIPES).
								executes(c -> {
									class_2338 p = class_2262.method_9696(c, "pos");
									class_1860<?> rl = class_2232.method_9442(c, "recipe");
									if(rl instanceof VeinRecipe) {
										setVein(c.getSource(), p, rl.method_8114(), 0.8F);
										c.getSource().method_9226(() -> class_2561.method_43469("command.coe.setvein.success", rl.method_8114()), true);
										return 1;
									}
									return 0;
								}).
								then(class_2170.method_9244("multiplier", FloatArgumentType.floatArg(0, 1000)).
										executes(c -> {
											float mul = FloatArgumentType.getFloat(c, "multiplier");
											class_2338 p = class_2262.method_9696(c, "pos");
											class_1860<?> rl = class_2232.method_9442(c, "recipe");
											if(rl.method_17716() instanceof ExcavatingRecipe) {
												setVein(c.getSource(), p, rl.method_8114(), mul);
												c.getSource().method_9226(() -> class_2561.method_43469("command.coe.setvein.success", rl.method_8114()), true);
												return 1;
											}
											return 0;
										})
										)
								)
						)
				);
		l.then(class_2170.method_9247("removevein").requires(s -> s.method_9259(2)).
				then(class_2170.method_9244("pos", class_2262.method_9698()).
						executes(c -> {
							class_2338 p = class_2262.method_9696(c, "pos");
							setVein(c.getSource(), p, null, 0F);
							c.getSource().method_9226(() -> class_2561.method_43469("command.coe.setvein.success", class_2561.method_43471("chat.coe.veinFinder.nothing")), true);
							return 1;
						})
						)
				);
		l.then(class_2170.method_9247("locate").requires(s -> s.method_9259(2)).
				then(class_2170.method_9244("recipe", class_2232.method_9441()).suggests(ALL_RECIPES).
						executes(c -> {
							class_1860<?> rl = class_2232.method_9442(c, "recipe");
							if(rl instanceof VeinRecipe r) {
								class_2338 blockpos = class_2338.method_49638(c.getSource().method_9222());
								Stopwatch stopwatch = Stopwatch.createStarted(class_156.field_37250);
								class_2338 at = OreVeinGenerator.getPicker(c.getSource().method_9225()).locate(rl.method_8114(), blockpos, c.getSource().method_9225(), 100);
								stopwatch.stop();
								if(at != null) {
									int i = class_3532.method_15375(RandomSpreadGenerator.distance2d(at, blockpos));
									class_2561 component = class_2564.method_10885(class_2561.method_43469("chat.coordinates", at.method_10263(), "~", at.method_10260())).method_27694((p_214489_) -> {
										return p_214489_.method_10977(class_124.field_1060).method_10958(new class_2558(class_2558.class_2559.field_11745, "/tp @s " + at.method_10263() + " ~ " + at.method_10260())).method_10949(new class_2568(class_2568.class_5247.field_24342, class_2561.method_43471("chat.coordinates.tooltip")));
									});
									c.getSource().method_9226(() -> {
										return class_2561.method_43469("command.coe.locate.success", rl.method_8114().toString(), component, i);
									}, false);
									CreateOreExcavation.LOGGER.info("Locating element " + rl.method_8114() + " took " + stopwatch.elapsed().toMillis() + " ms");
									return i;
								} else {
									throw ERROR_VEIN_NOT_FOUND.create(rl.method_8114().toString());
								}
							} else {
								throw ERROR_VEIN_NOT_FOUND.create(rl.method_8114().toString());
							}
						})
						)
				);
		dispatcher.register(l);
	}

	private static void setVein(class_2168 css, class_2338 pos, class_2960 rl, float mul) {
		class_1923 p = new class_1923(pos);
		OreData data = OreDataCapability.getData(css.method_9225().method_8497(p.field_9181, p.field_9180));
		data.setRecipe(rl);
		data.setLoaded(true);
		data.setRandomMul(mul);
		data.setExtractedAmount(0);
	}

	public static final SuggestionProvider<class_2168> ALL_RECIPES = class_2321.method_10022(new class_2960(CreateOreExcavation.MODID, "all_recipes"), (ctx, builder) -> {
		Stream<class_2960> rl;
		class_1863 rm;
		if(ctx.getSource() instanceof class_637) {
			rm = class_310.method_1551().method_1562().method_2877();
		} else if(ctx.getSource() instanceof class_2168 css) {
			rm = css.method_9211().method_3772();
		} else {
			rm = null;
		}
		if(rm != null) {
			rl = rm.method_30027(CreateOreExcavation.VEIN_RECIPES.getRecipeType()).stream().map(VeinRecipe::method_8114);
		} else rl = Stream.empty();

		return class_2172.method_9257(rl, builder);
	});
}

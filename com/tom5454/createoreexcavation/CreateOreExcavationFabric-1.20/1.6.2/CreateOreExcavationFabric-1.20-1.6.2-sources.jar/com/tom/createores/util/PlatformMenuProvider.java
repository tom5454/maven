package com.tom.createores.util;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_2540;
import net.minecraft.class_3222;
import net.minecraft.class_3908;

public interface PlatformMenuProvider extends class_3908, ExtendedScreenHandlerFactory {
	@Override
	default void writeScreenOpeningData(class_3222 player, class_2540 buf) {
	}
}

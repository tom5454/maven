package com.tom.createores.block.entity;

import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import com.simibubi.create.content.kinetics.base.KineticBlockEntity;

import com.tom.createores.block.MultiblockPart;
import com.tom.createores.block.MultiblockPart.MultiblockGhostPart;
import com.tom.createores.block.entity.MultiblockCapHandler.Kinetic;

public class KineticInputBlockEntity extends KineticBlockEntity implements Kinetic {
	private float reqStress = 1;

	public KineticInputBlockEntity(class_2591<?> typeIn, class_2338 pos, class_2680 state) {
		super(typeIn, pos, state);
	}

	@Override
	public float calculateStressApplied() {
		this.lastStressApplied = reqStress;
		return reqStress;
	}

	@Override
	public float calculateAddedStressCapacity() {
		return 0;
	}

	@Override
	public void initialize() {
		super.initialize();

		class_2680 state = field_11863.method_8320(field_11867);
		class_2338 pos = field_11867;
		for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
			class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
			pos = pos.method_10079(d, 1);
			state = field_11863.method_8320(pos);
		}
		if (state.method_26204() instanceof MultiblockPart) {
			MultiblockPart d = (MultiblockPart) state.method_26204();
			if (!(d instanceof MultiblockGhostPart)) {
				class_2586 te = field_11863.method_8321(pos);
				if (te instanceof MultiblockCapHandler) {
					((MultiblockCapHandler)te).addKinetic(this);
				}
			}
		}
	}

	@Override
	public boolean addToGoggleTooltip(List<class_2561> tooltip, boolean isPlayerSneaking) {
		boolean added = super.addToGoggleTooltip(tooltip, isPlayerSneaking);
		class_2680 state = field_11863.method_8320(field_11867);
		class_2338 pos = field_11867;
		for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
			class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
			pos = pos.method_10079(d, 1);
			state = field_11863.method_8320(pos);
		}
		if (state.method_26204() instanceof MultiblockPart) {
			MultiblockPart d = (MultiblockPart) state.method_26204();
			if (d instanceof MultiblockGhostPart)return added;
			else {
				class_2586 te = field_11863.method_8321(pos);
				if (te instanceof MultiblockCapHandler) {
					return ((MultiblockCapHandler)te).addToGoggleTooltip(tooltip, isPlayerSneaking) || added;
				} else {
					return added;
				}
			}
		}
		return added;
	}

	@Override
	public void setStress(float stress) {
		this.reqStress = stress;
		if(lastStressApplied != stress && hasNetwork()) {
			getOrCreateNetwork().updateStressFor(this, calculateStressApplied());
			networkDirty = true;
			notifyUpdate();
		}
	}

	@Override
	protected void write(class_2487 compound, boolean clientPacket) {
		super.write(compound, clientPacket);
		compound.method_10548("reqStress", reqStress);
	}

	@Override
	protected void read(class_2487 compound, boolean clientPacket) {
		super.read(compound, clientPacket);
		reqStress = compound.method_10583("reqStress");
	}

	@Override
	public float getRotationSpeed() {
		if(overStressed || lastStressApplied != reqStress)return 0;
		return Math.abs(speed);
	}
}

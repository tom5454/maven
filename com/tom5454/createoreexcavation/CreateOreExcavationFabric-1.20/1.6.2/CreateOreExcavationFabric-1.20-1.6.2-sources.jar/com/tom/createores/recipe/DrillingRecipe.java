package com.tom.createores.recipe;

import com.simibubi.create.content.processing.recipe.ProcessingOutput;
import net.minecraft.class_1865;
import net.minecraft.class_2371;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_3956;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class DrillingRecipe extends ExcavatingRecipe {
	public class_2371<ProcessingOutput> output;

	public DrillingRecipe(class_2960 id, class_3956<?> type, class_1865<?> serializer) {
		super(id, type, serializer);
	}

	@Override
	public String method_8112() {
		return "drilling";
	}

	@Override
	protected void fromJson(JsonObject json) {
		output = class_2371.method_10211();
		for (JsonElement je : class_3518.method_15261(json, "output")) {
			output.add(ProcessingOutput.deserialize(je));
		}
	}

	@Override
	protected void toJson(JsonObject json) {
		JsonArray ar = new JsonArray();
		output.stream().map(ProcessingOutput::serialize).forEach(ar::add);
		json.add("output", ar);
	}

	@Override
	protected void fromNetwork(class_2540 buffer) {
		output = class_2371.method_10211();
		int size = buffer.method_10816();
		for (int i = 0; i < size; i++)
			output.add(ProcessingOutput.read(buffer));
	}

	@Override
	protected void toNetwork(class_2540 buffer) {
		buffer.method_10804(output.size());
		output.forEach(o -> o.write(buffer));
	}

	public class_2371<ProcessingOutput> getOutput() {
		return output;
	}
}

package com.tom.createores.client;

import net.minecraft.class_1058;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public class PlatformClient {

	public static class_1058 getBlockTexture(class_2680 pState, class_1937 level, class_2338 pos) {
		return class_310.method_1551().method_1541().method_3351().method_3339(pState);
	}
}

package com.tom.createores.rei;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.simibubi.create.compat.rei.DoubleItemIcon;
import com.simibubi.create.compat.rei.ItemIcon;
import com.simibubi.create.compat.rei.display.CreateDisplay;

import com.tom.createores.Registration;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.BiomeTooltip;

import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.api.client.gui.widgets.Tooltip;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.gui.widgets.WidgetWithBounds;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.client.registry.display.DisplayCategory;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.entry.EntryStack;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_364;

public class VeinCategory implements DisplayCategory<CreateDisplay<VeinRecipe>> {
	protected Renderer icon;
	protected Renderer biomeWIcon, biomeBIcon;

	public VeinCategory() {
		icon = new ItemIcon(() -> new class_1799(Registration.NORMAL_DRILL_ITEM.get()));
		biomeWIcon = new ItemIcon(() -> new class_1799(class_1802.field_17535));
		biomeBIcon = new DoubleItemIcon(() -> new class_1799(class_1802.field_17535), () -> new class_1799(class_1802.field_8077));
	}

	@Override
	public Renderer getIcon() {
		return icon;
	}

	@Override
	public List<Widget> setupDisplay(CreateDisplay<VeinRecipe> display, Rectangle bounds) {
		VeinRecipe recipe = display.getRecipe();
		Point origin = new Point(bounds.getX(), bounds.getY() + 4);
		List<Widget> widgets = new ArrayList<>();
		widgets.add(Widgets.createRecipeBase(bounds));
		widgets.add(Widgets.wrapRenderer(new Rectangle(origin.x + 100, origin.y + 5, 16, 16), biomeWIcon));
		widgets.add(Widgets.wrapRenderer(new Rectangle(origin.x + 100, origin.y + 25, 16, 16), biomeBIcon));
		widgets.add(new WidgetWithBounds() {

			@Override
			public List<? extends class_364> method_25396() {
				return Collections.emptyList();
			}

			@Override
			public void method_25394(class_332 poseStack, int mouseX, int mouseY, float f) {
				mouseX -= bounds.x;
				mouseY -= bounds.y;
				List<class_2561> tooltip = new ArrayList<>();
				if(mouseX > 100 && mouseX < 118) {
					if(mouseY > 5 && mouseY < 23) {
						tooltip.add(class_2561.method_43471("tooltip.coe.biome.whitelist"));
						BiomeTooltip.listBiomes(recipe.biomeWhitelist, tooltip);
					} else if(mouseY > 25 && mouseY < 43) {
						tooltip.add(class_2561.method_43471("tooltip.coe.biome.blacklist"));
						BiomeTooltip.listBiomes(recipe.biomeBlacklist, tooltip);
					} else {
						BiomeTooltip.resetPage();
					}
				}
				if(!tooltip.isEmpty())Tooltip.create(tooltip).queue();
			}

			@Override
			public Rectangle getBounds() {
				return bounds;
			}
		});
		widgets.add(Widgets.createSlot(new Point(origin.x + 50, origin.y + 25)).disableBackground().markInput().entries(Collections.singletonList(EntryStack.of(REIPlugin.VEIN_TYPE, recipe))));
		return widgets;
	}

	@Override
	public int getDisplayHeight() {
		return 120;
	}

	@Override
	public CategoryIdentifier<? extends CreateDisplay<VeinRecipe>> getCategoryIdentifier() {
		return REIPlugin.VEINS;
	}

	@Override
	public class_2561 getTitle() {
		return class_2561.method_43471("jei.coe.recipe.veins");
	}
}

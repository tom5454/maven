package com.tom.createores.block.entity;

import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public interface IDrill {
	class_1799 getDrill();
	class_2338 getBelow();
	class_2350 getFacing();
	boolean shouldRenderRubble();
	float getYOffset();
	float getDrillOffset();
	float getRotation();
	float getPrevRotation();
	boolean shouldRenderShaft();
}

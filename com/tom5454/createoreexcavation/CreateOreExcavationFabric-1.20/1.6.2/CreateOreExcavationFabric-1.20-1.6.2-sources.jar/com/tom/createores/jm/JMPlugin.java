package com.tom.createores.jm;

import com.tom.createores.CreateOreExcavation;

import journeymap.api.v2.client.IClientAPI;
import journeymap.api.v2.client.IClientPlugin;
import journeymap.api.v2.client.event.MappingEvent;
import journeymap.api.v2.common.JourneyMapPlugin;
import journeymap.api.v2.common.event.ClientEventRegistry;
import journeymap.api.v2.common.event.FullscreenEventRegistry;
import net.minecraft.class_1074;
import net.minecraft.class_2960;

@JourneyMapPlugin(apiVersion = IClientAPI.API_VERSION)
public class JMPlugin implements IClientPlugin {
	private IClientAPI api;

	@Override
	public String getModId() {
		return CreateOreExcavation.MODID;
	}

	@Override
	public void initialize(IClientAPI api) {
		this.api = api;
		OreVeinsOverlay.INSTANCE.setApi(api);
		ClientEventRegistry.MAPPING_EVENT.subscribe(getModId(), me -> {
			if (me.getStage() == MappingEvent.Stage.MAPPING_STARTED)
				OreVeinsOverlay.INSTANCE.onMappingStarted();
			else if (me.getStage() == MappingEvent.Stage.MAPPING_STOPPED)
				OreVeinsOverlay.INSTANCE.onMappingStopped();
		});
		FullscreenEventRegistry.ADDON_BUTTON_DISPLAY_EVENT.subscribe(getModId(), event -> {
			event.getThemeButtonDisplay().addThemeToggleButton(class_1074.method_4662("jm.coe.veinsOverlayToggle"), class_2960.method_43902(CreateOreExcavation.MODID, "textures/gui/jm_coe_veins.png"), OreVeinsOverlay.INSTANCE.isActivated(), OreVeinsOverlay.INSTANCE::toggle);
		});
	}
}

package com.tom.createores.block;

import static net.minecraft.class_2741.field_12481;

import com.tom.createores.block.MultiblockPart.MultiblockMainPart;
import com.tom.createores.block.entity.MultiblockCapHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2769;
import net.minecraft.class_3726;
import net.minecraft.class_3965;

public abstract class MultiblockController extends class_2248 implements MultiblockMainPart {

	public MultiblockController(class_2251 p_49795_) {
		super(p_49795_);
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		builder.method_11667(new class_2769[]{field_12481});
		super.method_9515(builder);
	}

	@Override
	public class_2680 method_9598(class_2680 state, class_2470 rot) {
		return state.method_11657(field_12481, rot.method_10503(state.method_11654(field_12481)));
	}

	@Override
	public class_2680 method_9569(class_2680 state, class_2415 mirrorIn) {
		return state.method_26186(mirrorIn.method_10345(state.method_11654(field_12481)));
	}

	@Override
	public class_2680 method_9605(class_1750 context) {
		return method_9564().method_11657(field_12481, context.method_8042());
	}

	@Override
	public class_265 method_26159(class_2680 pState, class_1922 pReader, class_2338 pPos, class_3726 pContext) {
		return class_259.method_1073();
	}

	@Override
	public float method_9575(class_2680 pState, class_1922 pLevel, class_2338 pPos) {
		return 1.0F;
	}

	@Override
	public boolean method_9579(class_2680 pState, class_1922 pReader, class_2338 pPos) {
		return true;
	}

	@Override
	public class_1269 method_9534(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer, class_1268 pHand,
			class_3965 pHit) {
		return onActivate(pState, pLevel, pPos, pPlayer, pHand, pHit);
	}

	@Override
	public void method_9536(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_2680 pNewState, boolean pIsMoving) {
		if (!pState.method_27852(pNewState.method_26204())) {
			class_2586 blockentity = pLevel.method_8321(pPos);
			if (blockentity instanceof MultiblockCapHandler) {
				((MultiblockCapHandler)blockentity).dropInv();
			}

			super.method_9536(pState, pLevel, pPos, pNewState, pIsMoving);
		}
	}

	@Override
	public class_1799 method_9574(class_1922 level, class_2338 pos, class_2680 state) {
		return pickBlock(level, pos, state);
	}

	@Override
	public class_1799 pickBlock(class_1922 level, class_2338 pos, class_2680 state) {
		return new class_1799(this);
	}
}

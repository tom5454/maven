package com.tom.createores.emi;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_1802;
import net.minecraft.class_1860;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import com.simibubi.create.compat.emi.DoubleItemIcon;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.Registration;
import com.tom.createores.recipe.DrillingRecipe;
import com.tom.createores.recipe.ExtractorRecipe;
import com.tom.createores.recipe.VeinRecipe;

import dev.emi.emi.api.EmiPlugin;
import dev.emi.emi.api.EmiRegistry;
import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.render.EmiRenderable;
import dev.emi.emi.api.stack.EmiStack;

public class EMIPlugin implements EmiPlugin {
	public static final Map<class_2960, EmiRecipeCategory> ALL = new LinkedHashMap<>();

	public static final EmiRecipeCategory
	DRILLING = register("drilling", DoubleItemIcon.of(Registration.DRILL_BLOCK.get(), Registration.NORMAL_DRILL_ITEM.get())),
	EXTRACTING = register("extracting", DoubleItemIcon.of(Registration.EXTRACTOR_BLOCK.get(), class_1802.field_8550)),
	VEINS = register("veins", EmiStack.of(Registration.NORMAL_DRILL_ITEM.get()));

	@Override
	public void register(EmiRegistry registry) {
		registry.addIngredientSerializer(VeinEmiStack.class, new VeinEmiStack.Serializer());

		ALL.forEach((id, category) -> {
			registry.addCategory(category);
		});

		registry.addWorkstation(DRILLING, EmiStack.of(Registration.DRILL_BLOCK.get()));
		registry.addWorkstation(EXTRACTING, EmiStack.of(Registration.EXTRACTOR_BLOCK.get()));
		registry.addWorkstation(VEINS, EmiStack.of(Registration.VEIN_FINDER_ITEM.get()));

		consumeAllRecipes(r -> {
			if(r instanceof ExtractorRecipe e)registry.addRecipe(new ExtractingEmiRecipe(e));
			else if(r instanceof DrillingRecipe e)registry.addRecipe(new DrillingEmiRecipe(e));
			else if(r instanceof VeinRecipe e) {
				registry.addRecipe(new VeinEmiRecipe(e));
				registry.addEmiStack(new VeinEmiStack(e));
			}
		});
	}

	public static void consumeAllRecipes(Consumer<class_1860<?>> consumer) {
		class_310.method_1551().field_1687.method_8433()
		.method_8126()
		.forEach(consumer);
	}

	private static EmiRecipeCategory register(String name, EmiRenderable icon) {
		class_2960 id = new class_2960(CreateOreExcavation.MODID, name);
		EmiRecipeCategory category = new EmiRecipeCategory(id, icon) {
			@Override
			public class_2561 getName() {
				return class_2561.method_43471("jei.coe.recipe." + name);
			}
		};
		ALL.put(id, category);
		return category;
	}
}

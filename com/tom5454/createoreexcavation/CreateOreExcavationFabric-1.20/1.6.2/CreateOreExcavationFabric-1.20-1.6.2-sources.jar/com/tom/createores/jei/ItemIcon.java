package com.tom.createores.jei;

import java.util.function.Supplier;

import net.createmod.catnip.gui.element.GuiGameElement;
import net.minecraft.class_1799;
import net.minecraft.class_332;
import com.mojang.blaze3d.systems.RenderSystem;

import mezz.jei.api.gui.drawable.IDrawable;

public class ItemIcon implements IDrawable {

	private Supplier<class_1799> primarySupplier;
	private class_1799 primaryStack;

	public ItemIcon(Supplier<class_1799> primary) {
		this.primarySupplier = primary;
	}

	@Override
	public int getWidth() {
		return 18;
	}

	@Override
	public int getHeight() {
		return 18;
	}

	@Override
	public void draw(class_332 matrixStack, int xOffset, int yOffset) {
		if (primaryStack == null) {
			primaryStack = primarySupplier.get();
		}

		RenderSystem.enableDepthTest();
		matrixStack.method_51448().method_22903();
		matrixStack.method_51448().method_46416(xOffset, yOffset, 0);

		matrixStack.method_51448().method_22903();
		matrixStack.method_51448().method_46416(1, 1, 0);
		GuiGameElement.of(primaryStack)
		.render(matrixStack);
		matrixStack.method_51448().method_22909();

		matrixStack.method_51448().method_22909();
	}
}

package com.tom.createores.block;

import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2351;
import net.minecraft.class_2382;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3619;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_4970;
import com.simibubi.create.content.equipment.wrench.IWrenchable;
import com.tterrag.registrate.util.nullness.NonNullUnaryOperator;

import com.tom.createores.Registration;
import com.tom.createores.util.IOBlockType;

public interface MultiblockPart extends IWrenchable {

	public static NonNullUnaryOperator<class_4970.class_2251> props() {
		return p -> p.method_9632(10).method_9624().method_22488();
	}

	public static NonNullUnaryOperator<class_4970.class_2251> propsGhost() {
		return props().andThen(p -> p.method_42327().method_50012(class_3619.field_15972));
	}

	class_1269 onActivate(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer, class_1268 pHand,
			class_3965 pHit);

	class_1799 pickBlock(class_1922 level, class_2338 pos, class_2680 state);

	public static interface MultiblockGhostPart extends MultiblockPart {

		public static class_1838 makeCtx(class_1838 context, class_2338 pos) {
			return new class_1838(context.method_8045(), context.method_8036(), context.method_20287(), context.method_8041(),
					new class_3965(
							new class_243(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5),
							context.method_8038(), pos, false
							)
					);
		}

		@Override
		public default class_1269 onWrenched(class_2680 state, class_1838 context) {
			class_1937 level = context.method_8045();
			class_2338 pos = context.method_8037();
			for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
				class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
				pos = pos.method_10079(d, 1);
				state = level.method_8320(pos);
			}
			if (state.method_26204() instanceof MultiblockPart) {
				MultiblockPart d = (MultiblockPart) state.method_26204();
				if (d instanceof MultiblockGhostPart)return class_1269.field_5811;
				else return d.onWrenched(state, makeCtx(context, pos));
			}
			return class_1269.field_5811;
		}

		@Override
		public default class_1269 onSneakWrenched(class_2680 state, class_1838 context) {
			class_1937 level = context.method_8045();
			class_2338 pos = context.method_8037();
			for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
				class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
				pos = pos.method_10079(d, 1);
				state = level.method_8320(pos);
			}
			if (state.method_26204() != this && state.method_26204() instanceof MultiblockPart) {
				MultiblockPart d = (MultiblockPart) state.method_26204();
				if (d instanceof MultiblockGhostPart)return class_1269.field_5811;
				else return d.onSneakWrenched(state, makeCtx(context, pos));
			}
			return class_1269.field_5811;
		}

		class_2350 getParentDir(class_2680 state);

		public default void destroyParent(class_1937 level, class_2338 pos, class_2680 state, class_1657 pPlayer) {
			for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
				class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
				pos = pos.method_10079(d, 1);
				state = level.method_8320(pos);
			}
			if (state.method_26204() instanceof MultiblockPart && !(state.method_26204() instanceof MultiblockGhostPart)) {
				level.method_22352(pos, !pPlayer.method_7337());
			}
		}

		public default boolean hasParent(class_2680 state, class_4538 level, class_2338 pos) {
			class_2680 p = level.method_8320(pos.method_10079(getParentDir(state), 1));
			return p.method_26204() instanceof MultiblockPart;
		}

		@Override
		public default class_1269 onActivate(class_2680 state, class_1937 level, class_2338 pos, class_1657 pPlayer, class_1268 pHand,
				class_3965 pHit) {
			for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
				class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
				pos = pos.method_10079(d, 1);
				state = level.method_8320(pos);
			}
			if (state.method_26204() != this && state.method_26204() instanceof MultiblockPart) {
				MultiblockPart d = (MultiblockPart) state.method_26204();
				if (d instanceof MultiblockGhostPart)return class_1269.field_5811;
				else return d.onActivate(state, level, pos, pPlayer, pHand, new class_3965(
						new class_243(pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5),
						pHit.method_17780(), pos, false
						));
			}
			return class_1269.field_5811;
		}

		@Override
		public default class_1799 pickBlock(class_1922 level, class_2338 pos, class_2680 state) {
			for (int i = 0;i<5 && state.method_26204() instanceof MultiblockGhostPart;i++) {
				class_2350 d = ((MultiblockGhostPart)state.method_26204()).getParentDir(state);
				pos = pos.method_10079(d, 1);
				state = level.method_8320(pos);
			}
			if (state.method_26204() != this && state.method_26204() instanceof MultiblockPart) {
				MultiblockPart d = (MultiblockPart) state.method_26204();
				if (d instanceof MultiblockGhostPart)return class_1799.field_8037;
				else return d.pickBlock(level, pos, state);
			}
			return class_1799.field_8037;
		}
	}

	public static interface MultiblockMainPart extends MultiblockPart {
		MultiblockPartType[][][] getMultiblockLayout();

		@Override
		public default class_1269 onWrenched(class_2680 state, class_1838 context) {
			return class_1269.field_5811;
		}

		public default class_2382 getSize(class_2350 facing) {
			MultiblockPartType[][][] layout = getMultiblockLayout();
			int x = layout[0].length;
			int y = layout.length;
			int z = layout[0][0].length;
			return facing.method_10166() == class_2351.field_11051 ? new class_2382(x, y, z) : new class_2382(z, y, x);
		}

		class_2382 getStart(class_2350 facing);

		public default MultiblockPartType getPartTypeAt(class_2350 facing, int x, int y, int z) {
			class_2382 size = getSize(facing);
			switch (facing) {
			case field_11034:
			{
				int t = x;
				x = z;
				z = size.method_10263() - t - 1;
			}
			break;

			case field_11043:
				break;

			case field_11035:
				x = size.method_10263() - x - 1;
				z = size.method_10260() - z - 1;
				break;

			case field_11039:
			{
				int t = x;
				x = size.method_10260() - z - 1;
				z = t;
			}
			break;

			case field_11033:
			case field_11036:
			default:
				return null;
			}
			MultiblockPartType[][][] layout = getMultiblockLayout();
			return layout[y][z][x];
		}

		public default class_2350 getGhostDirection(class_2350 facing, int xIn, int yIn, int zIn) {
			MultiblockPartType[][][] layout = getMultiblockLayout();
			for(int x = 0;x<layout[0][0].length;x++) {
				for(int y = 0;y<layout.length;y++) {
					for(int z = 0;z<layout[0].length;z++) {
						if(layout[y][z][x] == MultiblockPartType.MAIN) {
							if (y == yIn) {
								if(x == xIn) {
									if(z > zIn) {
										return class_2350.field_11035;
									} else {
										return class_2350.field_11043;
									}
								} else if(x > xIn) {
									return class_2350.field_11034;
								} else {
									return class_2350.field_11039;
								}
							} else if(y > yIn) {
								return class_2350.field_11036;
							} else {
								return class_2350.field_11033;
							}
						}
					}
				}
			}
			return null;
		}

		public default class_2350 getBlockRotation(class_2350 facing, MultiblockPartType part) {
			return facing;
		}

		public static enum MultiblockPartType {
			BLANK(() -> Registration.GHOST_BLOCK.get().method_9564()),
			MAIN(),
			KINETIC(f -> Registration.KINETIC_INPUT.getDefaultState().method_11657(KineticInputBlock.SHAFT_FACING, f)),
			ITEM_IN   (IOBlockType.ITEM_IN   ),
			ITEM_OUT  (IOBlockType.ITEM_OUT  ),
			FLUID_IN  (IOBlockType.FLUID_IN  ),
			FLUID_OUT (IOBlockType.FLUID_OUT ),
			;
			private final Function<class_2350, class_2680> stateSupplier;

			private MultiblockPartType() {
				this.stateSupplier = null;
			}

			private MultiblockPartType(Supplier<class_2680> place) {
				this.stateSupplier = __ -> place.get();
			}

			private MultiblockPartType(Function<class_2350, class_2680> place) {
				this.stateSupplier = place;
			}

			private MultiblockPartType(IOBlockType type) {
				this(() -> Registration.IO_BLOCK.get().method_9564().method_11657(IOBlock.TYPE, type));
			}

			public class_2680 getBlockState(class_2350 facing) {
				return stateSupplier.apply(facing);
			}
		}
	}
}

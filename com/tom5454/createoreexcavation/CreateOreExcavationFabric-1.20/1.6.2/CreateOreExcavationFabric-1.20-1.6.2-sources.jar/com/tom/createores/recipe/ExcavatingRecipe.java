package com.tom.createores.recipe;

import com.simibubi.create.foundation.fluid.FluidIngredient;
import com.simibubi.create.foundation.item.SmartInventory;

import com.google.gson.JsonObject;

import com.tom.createores.CreateOreExcavation.RecipeTypeGroup;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_3956;
import net.minecraft.class_5455;

public abstract class ExcavatingRecipe implements class_1860<SmartInventory> {
	public class_2960 id;
	public class_3956<?> type;
	public class_1865<?> serializer;
	public class_2960 veinId;
	public class_1856 drill;
	public int priority, ticks, stressMul;
	public FluidIngredient drillingFluid;
	protected boolean isNet;

	public ExcavatingRecipe(class_2960 id, class_3956<?> type, class_1865<?> serializer) {
		this.id = id;
		this.type = type;
		this.serializer = serializer;
	}

	@Override
	public boolean matches(SmartInventory pContainer, class_1937 pLevel) {
		return false;
	}

	@Override
	public class_1799 assemble(SmartInventory p_44001_, class_5455 p_267165_) {
		return method_8110(p_267165_);
	}

	@Override
	public boolean method_8113(int pWidth, int pHeight) {
		return true;
	}

	@Override
	public class_1799 method_8110(class_5455 p_267052_) {
		return class_1799.field_8037;
	}

	@Override
	public class_2960 method_8114() {
		return id;
	}

	@Override
	public class_1865<?> method_8119() {
		return serializer;
	}

	@Override
	public class_3956<?> method_17716() {
		return type;
	}

	public class_1856 getDrill() {
		return drill;
	}

	public int getTicks() {
		return ticks;
	}

	@Override
	public abstract String method_8112();

	public int getStress() {
		return stressMul;
	}

	public FluidIngredient getDrillingFluid() {
		return drillingFluid;
	}

	protected abstract void fromJson(JsonObject json);
	protected abstract void toJson(JsonObject json);
	protected abstract void fromNetwork(class_2540 buffer);
	protected abstract void toNetwork(class_2540 buffer);

	public static class Serializer<T extends ExcavatingRecipe> implements class_1865<T> {
		private final RecipeTypeGroup<?> type;
		private final RecipeFactory<T> create;

		public Serializer(RecipeTypeGroup<?> type, RecipeFactory<T> create) {
			this.type = type;
			this.create = create;
		}

		@Override
		public T method_8121(class_2960 pRecipeId, JsonObject json) {
			T r = create.create(pRecipeId, type.getRecipeType(), this);
			r.drill = class_1856.method_52177(json.get("drill"));
			r.ticks = class_3518.method_15260(json, "ticks");
			r.priority = class_3518.method_15282(json, "priority", 0);
			r.stressMul = class_3518.method_15282(json, "stress", 256);
			r.veinId = new class_2960(class_3518.method_15265(json, "vein_id"));
			r.drillingFluid = FluidIngredient.EMPTY;
			if (class_3518.method_15294(json, "fluid"))
				r.drillingFluid = FluidIngredient.deserialize(json.get("fluid"));
			r.fromJson(json);
			return r;
		}

		public void toJson(T recipe, JsonObject json) {
			json.add("drill", recipe.drill.method_8089());
			json.addProperty("ticks", recipe.ticks);
			json.addProperty("stress", recipe.stressMul);
			json.addProperty("priority", recipe.priority);
			json.addProperty("vein_id", recipe.veinId.toString());
			if(recipe.drillingFluid != FluidIngredient.EMPTY)
				json.add("fluid", recipe.drillingFluid.serialize());
			recipe.toJson(json);
		}

		@Override
		public T method_8122(class_2960 pRecipeId, class_2540 buffer) {
			T r = create.create(pRecipeId, type.getRecipeType(), this);
			r.drill = class_1856.method_8086(buffer);
			r.ticks = buffer.method_10816();
			r.stressMul = buffer.method_10816();
			r.priority = buffer.method_10816();
			r.veinId = buffer.method_10810();
			r.fromNetwork(buffer);
			if(buffer.readBoolean())
				r.drillingFluid = FluidIngredient.read(buffer);
			else
				r.drillingFluid = FluidIngredient.EMPTY;
			r.isNet = true;
			return r;
		}

		@Override
		public void toNetwork(class_2540 buffer, T recipe) {
			recipe.drill.method_8088(buffer);
			buffer.method_10804(recipe.ticks);
			buffer.method_10804(recipe.stressMul);
			buffer.method_10804(recipe.priority);
			buffer.method_10812(recipe.veinId);
			recipe.toNetwork(buffer);
			if(recipe.drillingFluid.getRequiredAmount() == 0) {
				buffer.writeBoolean(false);
			} else {
				buffer.writeBoolean(true);
				recipe.drillingFluid.write(buffer);
			}
		}
	}

	@FunctionalInterface
	public static interface RecipeFactory<T extends ExcavatingRecipe> {
		T create(class_2960 id, class_3956<?> type, class_1865<?> serializer);
	}
}

package com.tom.createores.util;

import java.util.List;
import joptsimple.internal.Strings;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3532;
import net.minecraft.class_5250;

public class TooltipUtil {
	public static void forGoggles(List<? super class_5250> tooltip, class_5250 component) {
		forGoggles(tooltip, 0, component);
	}

	public static void forGoggles(List<? super class_5250> tooltip, int indents, class_5250 component) {
		tooltip.add(class_2561.method_43470(Strings.repeat(' ', getIndents(class_310.method_1551().field_1772, 4 + indents))).method_10852(component));
	}

	public static final float DEFAULT_SPACE_WIDTH = 4.0F; // space width in vanilla's default font
	static int getIndents(class_327 font, int defaultIndents) {
		int spaceWidth = font.method_1727(" ");
		if (DEFAULT_SPACE_WIDTH == spaceWidth) {
			return defaultIndents;
		}
		return class_3532.method_15386(DEFAULT_SPACE_WIDTH * defaultIndents / spaceWidth);
	}
}

package com.tom.createores.recipe;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import com.simibubi.create.foundation.item.SmartInventory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import com.tom.createores.Config;
import com.tom.createores.CreateOreExcavation;
import com.tom.createores.CreateOreExcavation.RecipeTypeGroup;
import com.tom.createores.util.ThreeState;
import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3518;
import net.minecraft.class_3956;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_6872;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class VeinRecipe implements class_1860<SmartInventory> {
	public class_2960 id;
	public class_3956<?> type;
	public class_1865<?> serializer;
	public int priority;
	public class_2561 veinName;
	public class_6862<class_1959> biomeWhitelist, biomeBlacklist;
	public ThreeState finite;
	public float amountMultiplierMin, amountMultiplierMax;
	public class_6872 placement;
	public class_1799 icon;
	protected boolean isNet;

	public VeinRecipe(class_2960 id, class_3956<?> type, class_1865<?> serializer) {
		this.id = id;
		this.type = type;
		this.serializer = serializer;
	}

	@Override
	public boolean matches(SmartInventory pContainer, class_1937 pLevel) {
		return false;
	}

	@Override
	public class_1799 assemble(SmartInventory p_44001_, class_5455 p_267165_) {
		return method_8110(p_267165_);
	}

	@Override
	public boolean method_8113(int pWidth, int pHeight) {
		return true;
	}

	@Override
	public class_1799 method_8110(class_5455 p_267052_) {
		return class_1799.field_8037;
	}

	@Override
	public class_2960 method_8114() {
		return id;
	}

	@Override
	public class_1865<?> method_8119() {
		return serializer;
	}

	@Override
	public class_3956<?> method_17716() {
		return type;
	}

	public class_2561 getName() {
		return veinName;
	}

	@Override
	public String method_8112() {
		return "ore_vein_type";
	}

	public boolean canGenerate(class_3218 lvl, class_6880<class_1959> b) {
		if(biomeBlacklist != null && isInTag(biomeBlacklist, lvl, b))return false;
		if(biomeWhitelist != null) {
			return isInTag(biomeWhitelist, lvl, b);
		} else
			return true;
	}

	private static boolean isInTag(class_6862<class_1959> tag, class_3218 lvl, class_6880<class_1959> b) {
		return lvl.method_8503().method_30611().method_30530(class_7924.field_41236).method_40266(tag).map(t -> t.method_40241(b)).orElse(false);
	}

	public ThreeState isFinite() {
		return finite;
	}

	public float getMinAmount() {
		return amountMultiplierMin;
	}

	public float getMaxAmount() {
		return amountMultiplierMax;
	}

	public boolean isInfiniteClient() {
		return isNet ? finite == ThreeState.NEVER : finite == ThreeState.DEFAULT ? Config.defaultInfinite : finite == ThreeState.NEVER;
	}

	public long getMinAmountClient() {
		return Math.round(isNet ? (double) amountMultiplierMin : (double) amountMultiplierMin * Config.finiteAmountBase);
	}

	public long getMaxAmountClient() {
		return Math.round(isNet ? (double) amountMultiplierMax : (double) amountMultiplierMax * Config.finiteAmountBase);
	}

	public int getNegGenerationPriority() {
		return -priority;
	}

	public class_6872 getPlacement() {
		return placement;
	}

	public static class Serializer<T extends VeinRecipe> implements class_1865<T> {
		private static final class_2960 NULL = new class_2960("coe:null");
		private final RecipeTypeGroup<?> type;
		private final RecipeFactory<T> create;

		public Serializer(RecipeTypeGroup<?> type, RecipeFactory<T> create) {
			this.type = type;
			this.create = create;
		}

		@Override
		public T method_8121(class_2960 pRecipeId, JsonObject json) {
			T r = create.create(pRecipeId, type.getRecipeType(), this);
			r.veinName = class_2561.class_2562.method_10877(json.get("name").getAsString());
			r.priority = class_3518.method_15282(json, "priority", 0);
			if(json.has("biomeWhitelist")) {
				class_2960 resourcelocation = new class_2960(class_3518.method_15265(json, "biomeWhitelist"));
				r.biomeWhitelist = class_6862.method_40092(class_7924.field_41236, resourcelocation);
			}
			if(json.has("biomeBlacklist")) {
				class_2960 resourcelocation = new class_2960(class_3518.method_15265(json, "biomeBlacklist"));
				r.biomeBlacklist = class_6862.method_40092(class_7924.field_41236, resourcelocation);
			}
			r.finite = ThreeState.get(json, "Finite");
			r.amountMultiplierMin = class_3518.method_15277(json, "amountMin", 1);
			r.amountMultiplierMax = class_3518.method_15277(json, "amountMax", 2);
			DataResult<class_6872> result = class_6872.field_36420.parse(JsonOps.INSTANCE, class_3518.method_15296(json, "placement"));
			r.placement = result.getOrThrow(false, error -> CreateOreExcavation.LOGGER.error(error));
			r.icon = class_1869.method_35228(class_3518.method_15296(json, "icon"));
			return r;
		}

		public void toJson(T recipe, JsonObject json) {
			json.addProperty("name", class_2561.class_2562.method_10867(recipe.veinName));
			json.addProperty("priority", recipe.priority);
			if(recipe.biomeWhitelist != null)json.addProperty("biomeWhitelist", recipe.biomeWhitelist.comp_327().toString());
			if(recipe.biomeBlacklist != null)json.addProperty("biomeBlacklist", recipe.biomeBlacklist.comp_327().toString());
			recipe.finite.toJson(json, "Finite");
			json.addProperty("amountMin", recipe.amountMultiplierMin);
			json.addProperty("amountMax", recipe.amountMultiplierMax);
			DataResult<JsonElement> result = class_6872.field_36420.encodeStart(JsonOps.INSTANCE, recipe.placement);
			json.add("placement", result.getOrThrow(false, error -> CreateOreExcavation.LOGGER.error(error)));
			json.add("icon", serializeItem(recipe.icon));
		}

		private JsonObject serializeItem(class_1799 stack) {
			JsonObject jsonobject = new JsonObject();
			jsonobject.addProperty("item", class_7923.field_41178.method_10221(stack.method_7909()).toString());
			return jsonobject;
		}

		@Override
		public T method_8122(class_2960 pRecipeId, class_2540 buffer) {
			T r = create.create(pRecipeId, type.getRecipeType(), this);
			r.priority = buffer.method_10816();
			r.veinName = buffer.method_10808();
			r.biomeWhitelist = create(buffer);
			r.biomeBlacklist = create(buffer);
			r.finite = buffer.readBoolean() ? ThreeState.ALWAYS : ThreeState.NEVER;
			r.amountMultiplierMin = buffer.readFloat();
			r.amountMultiplierMax = buffer.readFloat();
			r.icon = buffer.method_10819();
			r.isNet = true;
			return r;
		}

		private static class_6862<class_1959> create(class_2540 buffer) {
			class_2960 rl = buffer.method_10810();
			if(NULL.equals(rl))return null;
			else return class_6862.method_40092(class_7924.field_41236, rl);
		}

		@Override
		public void toNetwork(class_2540 buffer, T recipe) {
			buffer.method_10804(recipe.priority);
			buffer.method_10805(recipe.veinName);
			write(recipe.biomeWhitelist, buffer);
			write(recipe.biomeBlacklist, buffer);
			buffer.writeBoolean(recipe.finite == ThreeState.DEFAULT ? !Config.defaultInfinite : recipe.finite == ThreeState.ALWAYS);
			buffer.writeFloat(recipe.amountMultiplierMin * Config.finiteAmountBase);
			buffer.writeFloat(recipe.amountMultiplierMax * Config.finiteAmountBase);
			buffer.method_10793(recipe.icon);
		}

		private static void write(class_6862<class_1959> tag, class_2540 buffer) {
			buffer.method_10812(tag != null ? tag.comp_327() : NULL);
		}
	}

	@FunctionalInterface
	public static interface RecipeFactory<T extends VeinRecipe> {
		T create(class_2960 id, class_3956<?> type, class_1865<?> serializer);
	}
}

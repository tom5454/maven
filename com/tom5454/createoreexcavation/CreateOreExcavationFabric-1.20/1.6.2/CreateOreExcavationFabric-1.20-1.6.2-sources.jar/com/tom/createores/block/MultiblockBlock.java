package com.tom.createores.block;

import static net.minecraft.class_2741.field_12525;

import com.simibubi.create.foundation.block.IBE;

import com.tom.createores.Registration;
import com.tom.createores.block.MultiblockPart.MultiblockGhostPart;
import com.tom.createores.block.entity.MultiblockBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2464;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689.class_2690;
import net.minecraft.class_2769;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;

public class MultiblockBlock extends class_2248 implements MultiblockGhostPart, IBE<MultiblockBlockEntity> {

	public MultiblockBlock(class_2251 pr) {
		super(pr);
	}

	@Override
	public class_2464 method_9604(class_2680 pState) {
		return class_2464.field_11455;
	}

	@Override
	protected void method_9515(class_2690<class_2248, class_2680> builder) {
		builder.method_11667(new class_2769[]{field_12525});
		super.method_9515(builder);
	}

	@Override
	public boolean method_9558(class_2680 state, class_4538 level, class_2338 pos) {
		return hasParent(state, level, pos);
	}

	@Override
	public class_2680 method_9559(class_2680 pState, class_2350 pDirection, class_2680 pNeighborState,
			class_1936 pLevel, class_2338 pCurrentPos, class_2338 pNeighborPos) {
		return !method_9558(pState, pLevel, pCurrentPos) ? class_2246.field_10124.method_9564() : pState;
	}

	@Override
	public void method_9576(class_1937 level, class_2338 pos, class_2680 state, class_1657 pPlayer) {
		super.method_9576(level, pos, state, pPlayer);
		destroyParent(level, pos, state, pPlayer);
	}

	@Override
	public class_1269 method_9534(class_2680 pState, class_1937 pLevel, class_2338 pPos, class_1657 pPlayer, class_1268 pHand,
			class_3965 pHit) {
		return onActivate(pState, pLevel, pPos, pPlayer, pHand, pHit);
	}

	@Override
	public class_265 method_26159(class_2680 pState, class_1922 pReader, class_2338 pPos, class_3726 pContext) {
		return class_259.method_1073();
	}

	@Override
	public float method_9575(class_2680 pState, class_1922 pLevel, class_2338 pPos) {
		return 1.0F;
	}

	@Override
	public boolean method_9579(class_2680 pState, class_1922 pReader, class_2338 pPos) {
		return true;
	}

	@Override
	public class_2350 getParentDir(class_2680 state) {
		return state.method_11654(field_12525);
	}

	@Override
	public Class<MultiblockBlockEntity> getBlockEntityClass() {
		return MultiblockBlockEntity.class;
	}

	@Override
	public class_2591<? extends MultiblockBlockEntity> getBlockEntityType() {
		return Registration.GHOST_TILE.get();
	}

	@Override
	public class_1799 method_9574(class_1922 level, class_2338 pos, class_2680 state) {
		return pickBlock(level, pos, state);
	}
}

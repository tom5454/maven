package com.tom.createores.jei;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.Registration;
import com.tom.createores.recipe.DrillingRecipe;
import com.tom.createores.recipe.ExtractorRecipe;
import com.tom.createores.recipe.VeinRecipe;

import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.registration.IModIngredientRegistration;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.class_1863;
import net.minecraft.class_2960;
import net.minecraft.class_310;

@JeiPlugin
public class JEIHandler implements IModPlugin {

	public static final RecipeType<DrillingRecipe> DRILLING = RecipeType.create(CreateOreExcavation.MODID, "drilling", DrillingRecipe.class);
	public static final RecipeType<ExtractorRecipe> EXTRACTING = RecipeType.create(CreateOreExcavation.MODID, "extractor", ExtractorRecipe.class);
	public static final RecipeType<VeinRecipe> VEINS = RecipeType.create(CreateOreExcavation.MODID, "veins", VeinRecipe.class);

	@Override
	public class_2960 getPluginUid() {
		return new class_2960(CreateOreExcavation.MODID, "jei");
	}

	@Override
	public void registerCategories(IRecipeCategoryRegistration registration) {
		registration.addRecipeCategories(new DrillingCategory(), new ExtractingCategory(), new VeinCategory());
	}

	@Override
	public void registerRecipes(IRecipeRegistration registration) {
		class_1863 mngr = class_310.method_1551().method_1562().method_2877();
		registration.addRecipes(DRILLING, mngr.method_30027(CreateOreExcavation.DRILLING_RECIPES.getRecipeType()));
		registration.addRecipes(EXTRACTING, mngr.method_30027(CreateOreExcavation.EXTRACTING_RECIPES.getRecipeType()));
		registration.addRecipes(VEINS, mngr.method_30027(CreateOreExcavation.VEIN_RECIPES.getRecipeType()));
	}

	@Override
	public void registerRecipeCatalysts(IRecipeCatalystRegistration registration) {
		registration.addRecipeCatalyst(Registration.DRILL_BLOCK.asStack(), DRILLING);
		registration.addRecipeCatalyst(Registration.EXTRACTOR_BLOCK.asStack(), EXTRACTING);
		registration.addRecipeCatalyst(Registration.VEIN_FINDER_ITEM.asStack(), VEINS);
	}

	@Override
	public void registerIngredients(IModIngredientRegistration registration) {
		new VeinIngredient(registration);
	}
}

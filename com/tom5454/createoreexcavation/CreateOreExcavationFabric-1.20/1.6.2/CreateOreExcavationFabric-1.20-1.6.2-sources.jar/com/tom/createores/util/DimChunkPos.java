package com.tom.createores.util;

import java.util.Objects;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_5321;

public class DimChunkPos {
	public final class_5321<class_1937> dimension;
	public final int x;
	public final int z;
	private int hash;

	public DimChunkPos(class_5321<class_1937> dimension, int x, int z) {
		this.dimension = dimension;
		this.x = x;
		this.z = z;
	}

	public DimChunkPos(class_1937 level, class_1923 p) {
		this(level.method_27983(), p.field_9181, p.field_9180);
	}

	public DimChunkPos(class_1937 level, class_2338 p) {
		this(level, new class_1923(p));
	}

	@Override
	public int hashCode() {
		if (this.hash == 0) {
			this.hash = Objects.hash(this.dimension.method_29177(), this.x, this.z);
			if (this.hash == 0) {
				this.hash = 1;
			}
		}

		return this.hash;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == this) {
			return true;
		} else if (!(obj instanceof DimChunkPos)) {
			return false;
		} else {
			DimChunkPos p = (DimChunkPos) obj;
			return this.dimension == p.dimension && this.x == p.x && this.z == p.z;
		}
	}
}

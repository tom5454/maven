package com.tom.createores.client;

import static net.minecraft.class_124.field_1080;

import java.util.List;

import net.createmod.catnip.lang.Lang;
import net.createmod.catnip.lang.LangBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import com.simibubi.create.content.equipment.goggles.GogglesItem;
import com.simibubi.create.content.kinetics.base.IRotate.StressImpact;
import com.simibubi.create.foundation.item.TooltipHelper;
import com.simibubi.create.foundation.utility.CreateLang;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.Registration;
import com.tom.createores.jm.JMEventListener;
import com.tom.createores.network.ClientNetwork;

public class CreateOreExcavationClient implements ClientModInitializer {

	@Override
	public void onInitializeClient() {
		ClientRegistration.register();
		EntityModelLayerRegistry.registerModelLayer(DrillRenderer.LAYER_LOCATION, DrillRenderer::createModel);
		ClientNetwork.init();

		ItemTooltipCallback.EVENT.register((stack, ctx, lines) -> {
			if(stack.method_7909() == Registration.DRILL_BLOCK.get().method_8389() || stack.method_7909() == Registration.EXTRACTOR_BLOCK.get().method_8389()) {
				appendVariableStress(lines);
			}
		});

		CreateOreExcavation.journeyMap = FabricLoader.getInstance().isModLoaded("journeymap");
		if (CreateOreExcavation.journeyMap)
			JMEventListener.init();
	}

	public static void appendVariableStress(List<class_2561> tooltip) {
		boolean hasGoggles = GogglesItem.isWearingGoggles(class_310.method_1551().field_1724);
		boolean hasStressImpact = StressImpact.isEnabled();
		LangBuilder rpmUnit = CreateLang.translate("generic.unit.rpm");

		if (hasStressImpact) {
			CreateLang.translate("tooltip.stressImpact")
			.style(field_1080)
			.addTo(tooltip);

			StressImpact impactId = StressImpact.HIGH;
			LangBuilder builder = CreateLang.builder()
					.add(CreateLang.text(TooltipHelper.makeProgressBar(3, impactId.ordinal() + 1))
							.style(impactId.getAbsoluteColor()));

			if (hasGoggles) {
				builder.add(CreateLang.text("1-?"))
				.text("x ")
				.add(rpmUnit)
				.add(class_2561.method_43470(" ").method_10852(class_2561.method_43471("tooltip.coe.variableImpact")))
				.addTo(tooltip);
			} else
				builder.translate("tooltip.stressImpact." + Lang.asId(impactId.name()))
				.addTo(tooltip);
		}
	}
}

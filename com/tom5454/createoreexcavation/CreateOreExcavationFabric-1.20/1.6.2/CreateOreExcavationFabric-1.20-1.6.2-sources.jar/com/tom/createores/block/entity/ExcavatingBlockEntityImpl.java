package com.tom.createores.block.entity;

import java.util.List;

import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import com.tom.createores.recipe.ExcavatingRecipe;
import com.tom.createores.util.TooltipUtil;

import io.github.fabricators_of_create.porting_lib.transfer.fluid.FluidTank;

public abstract class ExcavatingBlockEntityImpl<R extends ExcavatingRecipe> extends ExcavatingBlockEntity<R> {
	protected FluidTank fluidTank;

	protected ExcavatingBlockEntityImpl(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		fluidTank = new FluidTank(16 * FluidConstants.BUCKET) {

			@Override
			protected void onContentsChanged() {
				notifyUpdate();
			}
		};
	}

	@Override
	protected void read(class_2487 tag, boolean clientPacket) {
		super.read(tag, clientPacket);
		fluidTank.readFromNBT(tag.method_10562(getTankInName()));
	}

	@Override
	protected void write(class_2487 tag, boolean clientPacket) {
		super.write(tag, clientPacket);
		tag.method_10566(getTankInName(), fluidTank.writeToNBT(new class_2487()));
	}

	@Override
	public boolean addToGoggleTooltip(List<class_2561> tooltip, boolean isPlayerSneaking) {
		super.addToGoggleTooltip(tooltip, isPlayerSneaking);
		TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.drill.fluidInfo"));
		containedFluidTooltip(tooltip, isPlayerSneaking, fluidTank);
		return true;
	}

	@Override
	public void addToGoggleTooltip(List<class_2561> tooltip, R rec) {
		if(rec.getDrillingFluid().getRequiredAmount() != 0 && (!rec.getDrillingFluid().test(fluidTank.getFluid()) || fluidTank.getFluidAmount() < rec.getDrillingFluid().getRequiredAmount())) {
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.drill.noFluid"));
		}
	}

	@Override
	protected boolean validateRecipe(R recipe) {
		return super.validateRecipe(recipe) && (recipe.getDrillingFluid().getRequiredAmount() == 0 || recipe.getDrillingFluid().test(fluidTank.getFluid()));
	}

	@Override
	protected boolean canExtract() {
		return current.getDrillingFluid().getRequiredAmount() == 0 ||
				(current.getDrillingFluid().test(fluidTank.getFluid()) &&
						fluidTank.getFluidAmount() >= current.getDrillingFluid().getRequiredAmount());
	}

	@Override
	protected void onFinished() {
		if(current.getDrillingFluid().getRequiredAmount() != 0) {
			try(Transaction t = Transaction.openOuter()) {
				fluidTank.extract(fluidTank.variant, current.getDrillingFluid().getRequiredAmount(), t);
				t.commit();
			}
		}
	}

	protected String getTankInName() {
		return "tank";
	}
}

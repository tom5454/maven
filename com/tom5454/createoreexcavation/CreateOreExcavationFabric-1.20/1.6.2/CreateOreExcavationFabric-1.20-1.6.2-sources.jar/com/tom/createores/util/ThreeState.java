package com.tom.createores.util;

import com.google.gson.JsonObject;
import net.minecraft.class_3518;

public enum ThreeState {
	DEFAULT, ALWAYS, NEVER
	;
	public static final ThreeState[] VALUES = values();
	public static ThreeState get(JsonObject json, String name) {
		if(class_3518.method_15258(json, "always" + name, false))return ALWAYS;
		if(class_3518.method_15258(json, "never" + name, false))return NEVER;
		return DEFAULT;
	}

	public void toJson(JsonObject json, String name) {
		switch (this) {
		case ALWAYS:
			json.addProperty("always" + name, true);
			break;

		case NEVER:
			json.addProperty("never" + name, true);
			break;

		case DEFAULT:
		default:
			break;
		}
	}
}
package com.tom.createores.emi;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import com.tom.createores.recipe.ExcavatingRecipe;

import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.api.widget.Widget;

public class RecipeTooltipWidget extends Widget {
	private ExcavatingRecipe recipe;

	public RecipeTooltipWidget(ExcavatingRecipe recipe) {
		this.recipe = recipe;
	}

	@Override
	public Bounds getBounds() {
		return new Bounds(0, 0, 134, 110);
	}

	@Override
	public void method_25394(class_332 matrices, int mouseX, int mouseY, float delta) {
	}

	@Override
	public List<class_5684> getTooltip(int mouseX, int mouseY) {
		List<class_2561> tooltip = new ArrayList<>();
		if(mouseX > 40 && mouseX < 80 && mouseY > 25 && mouseY < 60) {
			tooltip.add(class_2561.method_43469("tooltip.coe.processTime", recipe.getTicks()));
		}

		return tooltip.stream().map(class_2561::method_30937).map(class_5684::method_32662).toList();
	}
}

package com.tom.createores.kubejs;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import dev.latvian.mods.kubejs.bindings.TextWrapper;
import dev.latvian.mods.kubejs.recipe.RecipeJS;
import dev.latvian.mods.kubejs.recipe.component.RecipeComponent;
import net.minecraft.class_2561;

public enum ComponentComponent implements RecipeComponent<class_2561> {
	INSTANCE
	;

	@Override
	public Class<?> componentClass() {
		return class_2561.class;
	}

	@Override
	public JsonElement write(RecipeJS recipe, class_2561 value) {
		return new JsonPrimitive(class_2561.class_2562.method_10867(value));
	}

	@Override
	public class_2561 read(RecipeJS recipe, Object comp) {
		if(comp instanceof String) {
			try {
				return class_2561.class_2562.method_10877((String) comp);
			} catch (Exception e) {
			}
		}
		return TextWrapper.of(comp);
	}

}

package com.tom.createores.client;
// Made with Blockbench 4.2.5
// Exported for Minecraft version 1.17 - 1.18 with Mojang mappings
// Paste this class into your mod and generate all required imports

import net.createmod.ponder.api.level.PonderLevel;
import net.minecraft.class_1058;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_7923;
import com.simibubi.create.foundation.blockEntity.renderer.SafeBlockEntityRenderer;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.block.entity.IDrill;

public class DrillRenderer<T extends class_2586 & IDrill> extends SafeBlockEntityRenderer<T> {
	// This layer location should be baked with EntityRendererProvider.Context in the entity renderer and passed into this model's constructor
	public static final class_5601 LAYER_LOCATION = new class_5601(new class_2960(CreateOreExcavation.MODID, "drill"), "main");
	private static final class_2960 SHAFT = new class_2960(CreateOreExcavation.MODID, "textures/entity/shaft.png");
	private final class_630 head;
	private final class_630 shaft;
	private final class_630 rubble;

	public DrillRenderer(class_5614.class_5615 dispatcher) {
		class_630 root = dispatcher.method_32140(LAYER_LOCATION);
		this.head = root.method_32086("head");
		this.shaft = root.method_32086("shaft");
		this.rubble = root.method_32086("rubble");
	}

	public static class_5607 createModel() {
		class_5609 meshdefinition = new class_5609();
		class_5610 partdefinition = meshdefinition.method_32111();

		class_5610 head = partdefinition.method_32117("head", class_5606.method_32108(), class_5603.method_32090(0.0F, 24.0F, 0.0F));

		head.method_32117("Bit4_r1", class_5606.method_32108().method_32101(20, 26).method_32098(-1.0F, 6.5F, -1.0F, 2.0F, 2.0F, 2.0F, new class_5605(0.0F))
				.method_32101(12, 16).method_32098(-1.5F, 4.5F, -1.5F, 3.0F, 2.0F, 3.0F, new class_5605(0.0F))
				.method_32101(12, 10).method_32098(-2.0F, 2.5F, -2.0F, 4.0F, 2.0F, 4.0F, new class_5605(0.0F))
				.method_32101(0, 24).method_32098(-2.5F, 0.5F, -2.5F, 5.0F, 2.0F, 5.0F, new class_5605(0.0F))
				.method_32101(0, 16).method_32098(-5.0F, -2.5F, -2.0F, 2.0F, 4.0F, 4.0F, new class_5605(0.0F))
				.method_32101(0, 16).method_32098(3.0F, -2.5F, -2.0F, 2.0F, 4.0F, 4.0F, new class_5605(0.0F))
				.method_32101(0, 10).method_32098(-2.0F, -2.5F, -5.0F, 4.0F, 4.0F, 2.0F, new class_5605(0.0F))
				.method_32101(0, 10).method_32098(-2.0F, -2.5F, 3.0F, 4.0F, 4.0F, 2.0F, new class_5605(0.0F))
				.method_32101(0, 0).method_32098(-3.0F, -2.5F, -3.0F, 6.0F, 3.0F, 6.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 2.5F, 0.0F, 0.0F, 0.7854F, 0.0F));

		partdefinition.method_32117("shaft", class_5606.method_32108().method_32101(0, 0).method_32098(-2.0F, -12.0F, -2.0F, 4.0F, 12.0F, 4.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 24.0F, 0.0F));

		class_5610 rubble  = partdefinition.method_32117("rubble", class_5606.method_32108(), class_5603.method_32090(1.0F, 24.0F, 0.0F));

		rubble.method_32117("cube_r1", class_5606.method_32108().method_32101(0, 22).method_32098(-2.2F, -2.8F, -1.0F, 8.0F, 2.0F, 8.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 13.0F, 0.0F, -0.2486F, -0.1618F, 0.1217F));

		rubble.method_32117("cube_r2", class_5606.method_32108().method_32101(0, 13).method_32098(-8.0F, -3.0F, -1.0F, 8.0F, 2.0F, 8.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 13.0F, 0.0F, -0.0598F, 0.0156F, -0.1786F));

		rubble.method_32117("cube_r3", class_5606.method_32108().method_32101(0, 6).method_32098(-9.0F, -3.0F, -7.0F, 8.0F, 2.0F, 8.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 13.0F, 0.0F, 0.3412F, 0.1265F, -0.0937F));

		rubble.method_32117("cube_r4", class_5606.method_32108().method_32101(0, 0).method_32098(-2.0F, -3.0F, -7.0F, 8.0F, 2.0F, 8.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, 13.0F, 0.0F, 0.3414F, -0.0741F, 0.2054F));

		return class_5607.method_32110(meshdefinition, 32, 32);
	}

	@Override
	public void renderSafe(T pBlockEntity, float pPartialTick, class_4587 pPoseStack, class_4597 pBufferSource,
			int pPackedLight, int pPackedOverlay) {
		pPoseStack.method_22903();
		float f = pBlockEntity.getFacing().method_10144();
		pPoseStack.method_22904(0.5D, 0.5D, 0.5D);
		pPoseStack.method_22907(class_7833.field_40716.rotationDegrees(-f));
		pPoseStack.method_46416(0, pBlockEntity.getYOffset(), 0);
		pPoseStack.method_22905(1, -1, -1);

		pPoseStack.method_22903();
		pPoseStack.method_46416(0, pBlockEntity.getDrillOffset(), 0);
		pPoseStack.method_22907(class_7833.field_40716.rotationDegrees(class_3532.method_16439(pPartialTick, pBlockEntity.getPrevRotation(), pBlockEntity.getRotation())));

		if (pBlockEntity.shouldRenderShaft())
			shaft.method_22698(pPoseStack, pBufferSource.getBuffer(class_1921.method_23578(SHAFT)), pPackedLight, pPackedOverlay);

		class_1799 drill = pBlockEntity.getDrill();
		if (!drill.method_7960()) {
			class_2960 rl = class_7923.field_41178.method_10221(drill.method_7909());
			class_2960 tex = new class_2960(rl.method_12836(), "textures/entity/drill/" + rl.method_12832() + ".png");
			head.method_22698(pPoseStack, pBufferSource.getBuffer(class_1921.method_23578(tex)), pPackedLight, pPackedOverlay);
		}

		pPoseStack.method_22909();

		class_2338 below = pBlockEntity.getBelow();
		class_2680 state = pBlockEntity.method_10997().method_8320(below);
		if(pBlockEntity.shouldRenderRubble() && !state.method_26215() && !(pBlockEntity.method_10997() instanceof PonderLevel)) {
			try {
				class_1058 particle = PlatformClient.getBlockTexture(state, pBlockEntity.method_10997(), below);
				rubble.method_22698(pPoseStack, particle.method_24108(pBufferSource.getBuffer(class_1921.method_23581())), pPackedLight, pPackedOverlay);
			} catch (Exception e) {}
		}
		pPoseStack.method_22909();
	}
}
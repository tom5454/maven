package com.tom.createores.rei;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.jetbrains.annotations.Nullable;

import net.createmod.catnip.gui.element.GuiGameElement;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_6862;
import com.mojang.blaze3d.systems.RenderSystem;

import com.tom.createores.Registration;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.NumberFormatter;

import dev.architectury.utils.Env;
import dev.architectury.utils.EnvExecutor;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.entry.renderer.EntryRenderer;
import me.shedaniel.rei.api.client.gui.widgets.Tooltip;
import me.shedaniel.rei.api.client.gui.widgets.TooltipContext;
import me.shedaniel.rei.api.common.entry.EntrySerializer;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.entry.comparison.ComparisonContext;
import me.shedaniel.rei.api.common.entry.type.EntryDefinition;
import me.shedaniel.rei.api.common.entry.type.EntryType;

public class VeinDefinition implements EntryDefinition<VeinRecipe>, EntrySerializer<VeinRecipe> {
	@Environment(EnvType.CLIENT)
	private EntryRenderer<VeinRecipe> renderer;

	public VeinDefinition() {
		EnvExecutor.runInEnv(Env.CLIENT, () -> () -> Client.init(this));
	}

	@Environment(EnvType.CLIENT)
	private static class Client {
		private static void init(VeinDefinition definition) {
			definition.renderer = definition.new VeinEntryRenderer();
		}
	}

	@Override
	public Class<VeinRecipe> getValueType() {
		return VeinRecipe.class;
	}

	@Override
	public EntryType<VeinRecipe> getType() {
		return REIPlugin.VEIN_TYPE;
	}

	@Override
	public EntryRenderer<VeinRecipe> getRenderer() {
		return renderer;
	}

	@Override
	public @Nullable class_2960 getIdentifier(EntryStack<VeinRecipe> entry, VeinRecipe value) {
		return value != null ? value.method_8114() : null;
	}

	@Override
	public boolean isEmpty(EntryStack<VeinRecipe> entry, VeinRecipe value) {
		return value == null;
	}

	@Override
	public VeinRecipe copy(EntryStack<VeinRecipe> entry, VeinRecipe value) {
		return value;
	}

	@Override
	public VeinRecipe normalize(EntryStack<VeinRecipe> entry, VeinRecipe value) {
		return value;
	}

	@Override
	public VeinRecipe wildcard(EntryStack<VeinRecipe> entry, VeinRecipe value) {
		return value;
	}

	@Override
	public long hash(EntryStack<VeinRecipe> entry, VeinRecipe value, ComparisonContext context) {
		return value.method_8114().hashCode();
	}

	@Override
	public boolean equals(VeinRecipe o1, VeinRecipe o2, ComparisonContext context) {
		return o1.method_8114().equals(o2.method_8114());
	}

	@Override
	public @Nullable EntrySerializer<VeinRecipe> getSerializer() {
		return this;
	}

	@Override
	public class_2561 asFormattedText(EntryStack<VeinRecipe> entry, VeinRecipe value) {
		return value.getName();
	}

	@Override
	public Stream<? extends class_6862<?>> getTagsFor(EntryStack<VeinRecipe> entry, VeinRecipe value) {
		return Stream.empty();
	}

	@Override
	public boolean supportSaving() {
		return true;
	}

	@Override
	public boolean supportReading() {
		return true;
	}

	@Override
	public class_2487 save(EntryStack<VeinRecipe> entry, VeinRecipe value) {
		class_2487 tag = new class_2487();
		tag.method_10582("id", value.method_8114().toString());
		return tag;
	}

	@Override
	public VeinRecipe read(class_2487 tag) {
		class_2960 r = class_2960.method_12829(tag.method_10558("id"));
		if (r == null)return null;
		return class_310.method_1551().field_1687.method_8433().method_8130(r).map(e -> e instanceof VeinRecipe v ? v : null).orElse(null);
	}

	@Environment(EnvType.CLIENT)
	public class VeinEntryRenderer implements EntryRenderer<VeinRecipe> {
		private class_1799 drill = new class_1799(Registration.NORMAL_DRILL_ITEM.get());

		@Override
		public void render(EntryStack<VeinRecipe> entry, class_332 guiGraphics, Rectangle bounds, int mouseX, int mouseY,
				float delta) {
			VeinRecipe ingredient = entry.getValue();
			RenderSystem.enableDepthTest();
			guiGraphics.method_51448().method_22903();
			guiGraphics.method_51448().method_46416(bounds.x, bounds.y, 0);

			GuiGameElement.of(ingredient.icon)
			.render(guiGraphics);

			guiGraphics.method_51448().method_22903();
			float s = 0.5f;
			guiGraphics.method_51448().method_46416(8, 8, 100);
			guiGraphics.method_51448().method_22905(s, s, s);
			GuiGameElement.of(drill)
			.render(guiGraphics);
			guiGraphics.method_51448().method_22909();

			guiGraphics.method_51448().method_22909();
		}

		@Override
		public @Nullable Tooltip getTooltip(EntryStack<VeinRecipe> entry, TooltipContext context) {
			VeinRecipe ingredient = entry.getValue();
			List<class_2561> tooltip = new ArrayList<>();
			tooltip.add(ingredient.veinName);
			if(ingredient.isInfiniteClient())tooltip.add(class_2561.method_43471("tooltip.coe.infiniteVeins"));
			else tooltip.add(class_2561.method_43469("tooltip.coe.finiteVeins", NumberFormatter.formatNumber(ingredient.getMinAmountClient()), NumberFormatter.formatNumber(ingredient.getMaxAmountClient())));
			return Tooltip.create(tooltip);
		}

	}
}

package com.tom.createores.jm;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_310;

public class JMEventListener {

	public static void init() {
		ClientTickEvents.START_CLIENT_TICK.register(JMEventListener::onStartClientTick);
	}

	private static void onStartClientTick(class_310 mc) {
		OreVeinsOverlay.INSTANCE.tick();
	}

}

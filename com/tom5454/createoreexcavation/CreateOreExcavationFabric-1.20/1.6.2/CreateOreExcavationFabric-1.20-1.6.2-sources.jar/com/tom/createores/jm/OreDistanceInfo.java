package com.tom.createores.jm;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.recipe.VeinRecipe;

import journeymap.api.v2.client.display.PolygonOverlay;
import journeymap.api.v2.client.model.MapPolygon;
import journeymap.api.v2.client.model.ShapeProperties;
import journeymap.api.v2.client.model.TextProperties;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_5321;

public class OreDistanceInfo {
	private long time;
	private PolygonOverlay overlay;

	public OreDistanceInfo(class_5321<class_1937> dim, class_2338 center, int radius, VeinRecipe vein, long time) {
		this.time = time;
		class_2338[] c = new class_2338[36];
		int x = center.method_10263();
		int z = center.method_10260();
		for (int i = 0;i<36;i++) {
			double r = Math.toRadians(i * 10);
			c[i] = new class_2338(x + (int) (Math.cos(r) * radius), 1, z + (int) (Math.sin(r) * radius));
		}
		var polygon = new MapPolygon(c);

		int color = 0xFFFF0000;
		var shapeProps = new ShapeProperties()
				.setStrokeWidth(radius > 50 ? 4 : 2)
				.setStrokeColor(color)
				.setFillColor(color)
				.setFillOpacity(0.1f);

		var textProps = new TextProperties()
				.setColor(color)
				.setOpacity(1f)
				.setFontShadow(true);

		overlay = new PolygonOverlay(CreateOreExcavation.MODID, dim, shapeProps, polygon);

		overlay.setOverlayGroupName("COE Veins")
		.setLabel(class_2561.method_43469("chat.coe.veinFinder.distance", vein.getName(), radius).getString())
		.setTextProperties(textProps);
	}

	public PolygonOverlay getOverlay() {
		return overlay;
	}

	public boolean timedOut(long time) {
		return this.time < time;
	}

}

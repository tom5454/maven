package com.tom.createores.emi;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import com.simibubi.create.compat.emi.DoubleItemIcon;

import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.BiomeTooltip;

import dev.emi.emi.api.render.EmiRenderable;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.api.widget.Widget;

public class VeinTooltipWidget extends Widget {
	private VeinRecipe recipe;
	private EmiRenderable whitelist, blacklist;

	public VeinTooltipWidget(VeinRecipe recipe) {
		this.recipe = recipe;
		whitelist = EmiStack.of(class_1802.field_17535);
		blacklist = DoubleItemIcon.of(class_1802.field_17535, class_1802.field_8077);
	}

	@Override
	public Bounds getBounds() {
		return new Bounds(0, 0, 134, 110);
	}

	@Override
	public void method_25394(class_332 matrices, int mouseX, int mouseY, float delta) {
		whitelist.render(matrices, 100, 5, delta);
		blacklist.render(matrices, 100, 25, delta);
	}

	@Override
	public List<class_5684> getTooltip(int mouseX, int mouseY) {
		List<class_2561> tooltip = new ArrayList<>();
		if(mouseX > 100 && mouseX < 118) {
			if(mouseY > 5 && mouseY < 23) {
				tooltip.add(class_2561.method_43471("tooltip.coe.biome.whitelist"));
				BiomeTooltip.listBiomes(recipe.biomeWhitelist, tooltip);
			} else if(mouseY > 25 && mouseY < 43) {
				tooltip.add(class_2561.method_43471("tooltip.coe.biome.blacklist"));
				BiomeTooltip.listBiomes(recipe.biomeBlacklist, tooltip);
			} else {
				BiomeTooltip.resetPage();
			}
		}

		return tooltip.stream().map(class_2561::method_30937).map(class_5684::method_32662).toList();
	}
}

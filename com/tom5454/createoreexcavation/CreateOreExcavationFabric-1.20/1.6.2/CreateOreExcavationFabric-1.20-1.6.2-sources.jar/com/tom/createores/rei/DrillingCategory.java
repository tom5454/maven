package com.tom.createores.rei;

import java.util.ArrayList;
import java.util.List;

import net.createmod.catnip.layout.LayoutHelper;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import com.simibubi.create.compat.rei.DoubleItemIcon;
import com.simibubi.create.compat.rei.category.WidgetUtil;
import com.simibubi.create.compat.rei.display.CreateDisplay;
import com.simibubi.create.content.processing.recipe.ProcessingOutput;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.utility.CreateLang;

import com.tom.createores.Registration;
import com.tom.createores.recipe.DrillingRecipe;

import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.gui.widgets.Widgets;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.entry.type.VanillaEntryTypes;

public class DrillingCategory extends ExcavatingCategory<DrillingRecipe> {

	public DrillingCategory() {
		icon = new DoubleItemIcon(Registration.DRILL_BLOCK::asStack, () -> new class_1799(Registration.NORMAL_DRILL_ITEM.get()));
	}

	@Override
	public CategoryIdentifier<? extends CreateDisplay<DrillingRecipe>> getCategoryIdentifier() {
		return REIPlugin.DRILLING;
	}

	@Override
	public class_2561 getTitle() {
		return class_2561.method_43471("jei.coe.recipe.drilling");
	}

	@Override
	public void setupDisplay0(CreateDisplay<DrillingRecipe> display, Rectangle bounds, List<Widget> widgets) {
		DrillingRecipe recipe = display.getRecipe();
		Point origin = new Point(bounds.getX(), bounds.getY() + 4);
		int xOffset = bounds.getWidth() / 2;
		int yOffset = 86;

		layoutOutput(recipe).forEach(layoutEntry -> {
			float c = layoutEntry.output().getChance();
			widgets.add(WidgetUtil.textured(c != 1 ? AllGuiTextures.JEI_CHANCE_SLOT : AllGuiTextures.JEI_SLOT, origin.x + xOffset + layoutEntry.posX(), origin.y + yOffset + layoutEntry.posY()));
			List<class_2561> tooltip = new ArrayList<>();
			if(c != 1) {
				CreateLang.translate("recipe.processing.chance", c < 0.01 ? "<1" : (int) (c * 100))
				.style(class_124.field_1065).addTo(tooltip);
			}
			widgets.add(
					Widgets.createSlot(new Point(origin.x + xOffset + layoutEntry.posX() + 1, origin.y + yOffset + layoutEntry.posY() + 1))
					.markOutput().disableBackground().entry(EntryStack.of(VanillaEntryTypes.ITEM, layoutEntry.output().getStack()).tooltip(tooltip))
					);
		});

		widgets.add(new AnimatedBlock(Registration.DRILL_BLOCK.getDefaultState(), 11).pos(new Point(origin.x + 48, origin.y + 35)));
	}

	private List<LayoutEntry> layoutOutput(DrillingRecipe recipe) {
		int size = recipe.getOutput().size();
		List<LayoutEntry> positions = new ArrayList<>(size);

		LayoutHelper layout = LayoutHelper.centeredHorizontal(size, 1, 18, 18, 1);
		for (ProcessingOutput result : recipe.getOutput()) {
			positions.add(new LayoutEntry(result, layout.getX(), layout.getY()));
			layout.next();
		}

		return positions;
	}

	private record LayoutEntry(
			ProcessingOutput output,
			int posX,
			int posY
			) {}
}

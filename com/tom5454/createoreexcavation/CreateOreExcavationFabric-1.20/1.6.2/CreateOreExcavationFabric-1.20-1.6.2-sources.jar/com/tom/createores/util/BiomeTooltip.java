package com.tom.createores.util;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1959;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6880.class_6882;
import net.minecraft.class_7924;

public class BiomeTooltip {
	private static long lastBiomeChangeTime;
	private static int biomePage;

	public static void listBiomes(class_6862<class_1959> tag, List<class_2561> tooltip) {
		boolean isShift = class_437.method_25442();
		class_2378<class_1959> biomeReg = class_310.method_1551().method_1562().method_29091().method_30530(class_7924.field_41236);
		biomeReg.method_40266(tag).
		map(t -> {
			Stream<class_6880<class_1959>> s = t.method_40239();
			int size = t.method_40247();
			class_2561 pg = null;
			if(size > 16) {
				if(!isShift) {
					if(System.currentTimeMillis() - lastBiomeChangeTime > 2000) {
						biomePage++;
						if(biomePage * 16 >= size)biomePage = 0;
						lastBiomeChangeTime = System.currentTimeMillis();
					}
				}
				pg = class_2561.method_43469("tooltip.coe.page", biomePage + 1, (size / 16) + 1);
				s = s.skip(biomePage * 16).limit(16);
			}
			List<class_2561> comps = s.map(b -> getBiomeId(biomeReg, b)).
					map(b -> class_2561.method_43471("biome." + b.method_12836() + "." + b.method_12832())).
					collect(Collectors.toList());
			if(pg != null)comps.add(pg);
			return comps;
		}).ifPresent(tooltip::addAll);
	}

	private static class_2960 getBiomeId(class_2378<class_1959> biomeReg, class_6880<class_1959> h) {
		try {
			if(h.method_40231() == class_6882.field_36447) {
				return biomeReg.method_10221(h.comp_349());
			} else {
				return ((class_6880.class_6883<class_1959>)h).method_40237().method_29177();
			}
		} catch (Exception e) {
			return new class_2960("null");
		}
	}

	public static void resetPage() {
		biomePage = 0;
		lastBiomeChangeTime = 0;
	}
}

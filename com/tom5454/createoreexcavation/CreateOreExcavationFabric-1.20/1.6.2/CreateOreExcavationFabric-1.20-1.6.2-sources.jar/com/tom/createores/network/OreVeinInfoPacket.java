package com.tom.createores.network;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.jm.OreVeinsOverlay;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;

public class OreVeinInfoPacket implements Packet {
	public static final class_2960 VEIN_INFO_S2C = new class_2960(CreateOreExcavation.MODID, "veins_info");
	public class_2487 tag;

	public OreVeinInfoPacket(class_2487 tag) {
		this.tag = tag;
	}

	public OreVeinInfoPacket(class_2540 pb) {
		tag = pb.method_30617();
	}

	@Override
	public void toBytes(class_2540 pb) {
		pb.method_10794(tag);
	}

	@Override
	public class_2960 getId() {
		return VEIN_INFO_S2C;
	}

	@Override
	public void handleClient() {
		if (CreateOreExcavation.journeyMap) {
			OreVeinsOverlay.addOreInfoToMap(tag);
		}
	}

	@Override
	public void handleServer(class_3222 p) {
	}
}

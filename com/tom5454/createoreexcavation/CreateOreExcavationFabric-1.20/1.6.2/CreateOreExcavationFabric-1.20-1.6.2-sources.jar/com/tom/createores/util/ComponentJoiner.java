package com.tom.createores.util;

import java.util.Collections;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collector;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class ComponentJoiner {
	static final Set<Collector.Characteristics> CH_NOID = Collections.emptySet();

	private class_5250 value;
	private class_2561 delimiter;

	public ComponentJoiner(class_2561 delimiter) {
		this.delimiter = delimiter;
	}

	public static Collector<class_2561, ComponentJoiner, class_2561> joining(class_2561 empty, class_2561 delimiter) {
		return new Collector<>() {

			@Override
			public Supplier<ComponentJoiner> supplier() {
				return () -> new ComponentJoiner(delimiter);
			}

			@Override
			public Function<ComponentJoiner, class_2561> finisher() {
				return c -> c.value != null ? c.value : empty;
			}

			@Override
			public BinaryOperator<ComponentJoiner> combiner() {
				return ComponentJoiner::merge;
			}

			@Override
			public Set<Characteristics> characteristics() {
				return CH_NOID;
			}

			@Override
			public BiConsumer<ComponentJoiner, class_2561> accumulator() {
				return ComponentJoiner::add;
			}
		};
	}

	private class_5250 prepareBuilder() {
		if (value != null) {
			value.method_10852(delimiter);
		} else {
			value = class_2561.method_43473();
		}
		return value;
	}

	public ComponentJoiner add(class_2561 newElement) {
		prepareBuilder().method_10852(newElement);
		return this;
	}

	public ComponentJoiner merge(ComponentJoiner other) {
		if (other.value != null) {
			prepareBuilder().method_10852(other.value.method_27661());
		}
		return this;
	}
}

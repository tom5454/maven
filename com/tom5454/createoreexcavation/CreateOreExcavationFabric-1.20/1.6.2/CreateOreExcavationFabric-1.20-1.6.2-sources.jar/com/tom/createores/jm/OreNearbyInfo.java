package com.tom.createores.jm;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.recipe.VeinRecipe;

import journeymap.api.v2.client.display.PolygonOverlay;
import journeymap.api.v2.client.model.MapPolygon;
import journeymap.api.v2.client.model.ShapeProperties;
import journeymap.api.v2.client.model.TextProperties;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_5321;

public class OreNearbyInfo {
	private long time;
	private PolygonOverlay overlay;

	public OreNearbyInfo(class_5321<class_1937> dim, class_1923 center, VeinRecipe vein, long time) {
		this.time = time;

		int x = center.field_9181 << 4;
		int z = center.field_9180 << 4;
		class_2338 sw = new class_2338(x - 16, 1, z + 32);
		class_2338 se = new class_2338(x + 32, 1, z + 32);
		class_2338 ne = new class_2338(x + 32, 1, z - 16);
		class_2338 nw = new class_2338(x - 16, 1, z - 16);
		var polygon = new MapPolygon(new class_2338[]{sw, se, ne, nw});

		int color = 0xFF0000FF;
		var shapeProps = new ShapeProperties()
				.setStrokeWidth(2)
				.setStrokeColor(color)
				.setFillColor(color)
				.setFillOpacity(0.1f);

		var textProps = new TextProperties()
				.setColor(color)
				.setOpacity(1f)
				.setFontShadow(true);

		overlay = new PolygonOverlay(CreateOreExcavation.MODID, dim, shapeProps, polygon);

		overlay.setOverlayGroupName("COE Veins")
		.setLabel(class_2561.method_43469("chat.coe.veinFinder.nearby", vein.getName()).getString())
		.setTextProperties(textProps);
	}

	public PolygonOverlay getOverlay() {
		return overlay;
	}

	public boolean timedOut(long time) {
		return this.time < time;
	}

}

package com.tom.createores.util;

import java.util.Iterator;

import org.spongepowered.include.com.google.common.collect.Iterators;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.fabricmc.fabric.api.transfer.v1.transaction.base.SnapshotParticipant;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;

public class QueueInventory extends SnapshotParticipant<class_2371<class_1799>> implements Storage<ItemVariant> {
	private class_2371<class_1799> content = class_2371.method_10211();

	public int getSlots() {
		return content.size();
	}

	public class_1799 getStackInSlot(int slot) {
		return content.get(slot);
	}

	public void add(class_1799 is) {
		content.add(is);
	}

	public class_2499 toTag() {
		class_2499 tag = new class_2499();
		content.stream().filter(s -> !s.method_7960()).map(s -> s.method_7953(new class_2487())).forEach(tag::add);
		return tag;
	}

	public void load(class_2499 tag) {
		content.clear();
		for (int i = 0; i < tag.size(); i++) {
			content.add(class_1799.method_7915(tag.method_10602(i)));
		}
	}

	public boolean hasSpace() {
		content.removeIf(class_1799::method_7960);
		return content.size() < 16;
	}

	@Override
	public long insert(ItemVariant resource, long maxAmount, TransactionContext transaction) {
		return 0;
	}

	@Override
	public long extract(ItemVariant resource, long maxAmount, TransactionContext transaction) {
		if (maxAmount < 1) return 0;
		updateSnapshots(transaction);
		long ext = 0;
		for (int i = 0; i < content.size(); i++) {
			class_1799 is = content.get(i);
			if(!is.method_7960() && resource.matches(is)) {
				int e = Math.min((int) (maxAmount - ext), is.method_7947());
				is.method_7934(e);
				ext += e;
				if(ext == maxAmount)break;
			}
		}
		return ext;
	}

	@Override
	public Iterator<StorageView<ItemVariant>> iterator() {
		return Iterators.transform(content.iterator(), SV::new);
	}

	private class SV implements StorageView<ItemVariant> {
		private final class_1799 s;

		public SV(class_1799 s) {
			this.s = s;
		}

		@Override
		public long extract(ItemVariant resource, long maxAmount, TransactionContext transaction) {
			return QueueInventory.this.extract(resource, maxAmount, transaction);
		}

		@Override
		public boolean isResourceBlank() {
			return s.method_7960();
		}

		@Override
		public ItemVariant getResource() {
			return ItemVariant.of(s);
		}

		@Override
		public long getAmount() {
			return s.method_7947();
		}

		@Override
		public long getCapacity() {
			return 0;
		}
	}

	@Override
	protected class_2371<class_1799> createSnapshot() {
		class_2371<class_1799> l = class_2371.method_10211();
		content.forEach(s -> {
			if(!s.method_7960())l.add(s.method_7972());
		});
		return l;
	}

	@Override
	protected void readSnapshot(class_2371<class_1799> snapshot) {
		class_2371<class_1799> l = class_2371.method_10211();
		snapshot.forEach(s -> {
			if(!s.method_7960())l.add(s.method_7972());
		});
		this.content = l;
	}
}

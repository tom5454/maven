package com.tom.createores.menu;

import com.tom.createores.Config;
import com.tom.createores.Registration;
import com.tom.createores.network.OreVeinAtlasClickPacket.Option;
import com.tom.createores.network.OreVeinAtlasClickPacket2;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_3919;

public class OreVeinAtlasMenu extends class_1703 {
	private class_1799 heldItem;
	private class_3919 sync;

	public OreVeinAtlasMenu(class_3917<?> type, int wid, class_1661 pinv) {
		this(type, wid, pinv, pinv.field_7546.method_6047());
	}

	public OreVeinAtlasMenu(class_3917<?> type, int wid, class_1661 pinv, class_1799 heldItem) {
		super(type, wid);
		this.heldItem = heldItem;
		sync = new class_3919(3);
		sync.method_17391(0, Config.finiteAmountBase & 0xFFFF);
		sync.method_17391(1, (Config.finiteAmountBase >> 16) & 0xFFFF);
		sync.method_17391(2, Config.defaultInfinite ? 1 : 0);
		method_17360(sync);
	}

	@Override
	public class_1799 method_7601(class_1657 p_38941_, int p_38942_) {
		return class_1799.field_8037;
	}

	@Override
	public boolean method_7597(class_1657 pl) {
		return pl.method_6047().method_7909() == Registration.VEIN_ATLAS_ITEM.get();
	}

	public class_1799 getHeldItem() {
		return heldItem;
	}

	public void click(Option opt, class_2960 id) {
		Registration.VEIN_ATLAS_ITEM.get().menuClicked(heldItem, opt, id);
	}

	public int getFiniteBase() {
		return (sync.method_17390(1) << 16) | sync.method_17390(0);
	}

	public boolean isDefaultInfinite() {
		return sync.method_17390(2) != 0;
	}

	public void click2(OreVeinAtlasClickPacket2.Option opt, int id) {
		Registration.VEIN_ATLAS_ITEM.get().menuClicked2(heldItem, opt, id);
	}
}

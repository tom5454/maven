package com.tom.createores.emi;

import java.util.ArrayList;
import java.util.List;

import net.createmod.catnip.gui.element.GuiGameElement;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import com.mojang.blaze3d.systems.RenderSystem;

import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import com.tom.createores.Registration;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.NumberFormatter;

import dev.emi.emi.EmiUtil;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.stack.serializer.EmiIngredientSerializer;

public class VeinEmiStack extends EmiStack {
	private static class_1799 drill = new class_1799(Registration.NORMAL_DRILL_ITEM.get());
	private VeinRecipe recipe;

	public VeinEmiStack(VeinRecipe recipe) {
		this.recipe = recipe;
	}

	@Override
	public boolean isEmpty() {
		return recipe == null;
	}

	@Override
	public void render(class_332 guiGraphics, int x, int y, float delta, int flags) {
		RenderSystem.enableDepthTest();
		guiGraphics.method_51448().method_22903();
		guiGraphics.method_51448().method_46416(x, y, 0);

		GuiGameElement.of(recipe.icon)
		.render(guiGraphics);

		guiGraphics.method_51448().method_22903();
		float s = 0.5f;
		guiGraphics.method_51448().method_46416(8, 8, 100);
		guiGraphics.method_51448().method_22905(s, s, s);
		GuiGameElement.of(drill)
		.render(guiGraphics);
		guiGraphics.method_51448().method_22909();

		guiGraphics.method_51448().method_22909();
	}

	public static class Serializer implements EmiIngredientSerializer<VeinEmiStack> {

		@Override
		public String getType() {
			return "coe:vein";
		}

		@Override
		public EmiIngredient deserialize(JsonElement element) {
			class_1863 mngr = class_310.method_1551().method_1562().method_2877();
			class_2960 r = class_2960.method_12829(element.getAsJsonObject().get("value").getAsString());
			VeinRecipe rec = mngr.method_8130(r).map(v -> v instanceof VeinRecipe e ? e : null).orElse(null);
			return rec != null ? new VeinEmiStack(rec) : null;
		}

		@Override
		public JsonElement serialize(VeinEmiStack stack) {
			JsonObject json = new JsonObject();
			json.addProperty("type", "coe:vein");
			json.addProperty("value", stack.recipe.method_8114().toString());
			return json;
		}
	}

	@Override
	public class_2487 getNbt() {
		return null;
	}

	@Override
	public Object getKey() {
		return recipe;
	}

	@Override
	public class_2960 getId() {
		return recipe.method_8114();
	}

	@Override
	public List<class_5684> getTooltip() {
		List<class_5684> list = Lists.newArrayList();
		List<class_2561> tooltip = new ArrayList<>();
		tooltip.add(getName());
		tooltip.addAll(getTooltipText());
		tooltip.add(class_2561.method_43470(EmiUtil.getModName(recipe.id.method_12836())).method_27695(class_124.field_1078, class_124.field_1056));
		tooltip.stream().map(class_2561::method_30937).map(class_5684::method_32662).forEach(list::add);
		list.addAll(super.getTooltip());
		return list;
	}

	@Override
	public List<class_2561> getTooltipText() {
		List<class_2561> tooltip = new ArrayList<>();
		if(recipe.isInfiniteClient())tooltip.add(class_2561.method_43471("tooltip.coe.infiniteVeins"));
		else tooltip.add(class_2561.method_43469("tooltip.coe.finiteVeins", NumberFormatter.formatNumber(recipe.getMinAmountClient()), NumberFormatter.formatNumber(recipe.getMaxAmountClient())));
		return tooltip;
	}

	@Override
	public class_2561 getName() {
		return recipe.veinName;
	}

	@Override
	public EmiStack copy() {
		return this;
	}
}

package com.tom.createores.block.entity;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import com.simibubi.create.api.equipment.goggles.IHaveGoggleInformation;
import com.simibubi.create.api.equipment.goggles.IHaveHoveringInformation;
import com.simibubi.create.content.equipment.armor.BacktankBlockEntity;
import com.simibubi.create.foundation.blockEntity.ComparatorUtil;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;

import com.tom.createores.OreDataCapability;
import com.tom.createores.OreDataCapability.OreData;
import com.tom.createores.Registration;
import com.tom.createores.client.ClientUtil;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.DimChunkPos;
import com.tom.createores.util.NumberFormatter;
import com.tom.createores.util.TooltipUtil;

public class SampleDrillBlockEntity extends SmartBlockEntity implements IHaveGoggleInformation, IHaveHoveringInformation, IDrill {
	public static final int DRILL_TIME = 200;
	private class_2960 veinClient;
	private long resourceRemClient;
	private VeinRecipe vein;
	private OreData data;
	private int progress = 0;
	private boolean drilling = false;
	private float airTankLevel = -1f;

	public SampleDrillBlockEntity(class_2591<?> typeIn, class_2338 pos, class_2680 state) {
		super(typeIn, pos, state);
		setLazyTickRate(20);
	}

	@Override
	public boolean addToGoggleTooltip(List<class_2561> tooltip, boolean isPlayerSneaking) {
		VeinRecipe veinR = veinClient != null ? field_11863.method_8433().method_8130(veinClient).filter(e -> e instanceof VeinRecipe).map(r -> (VeinRecipe) r).orElse(null) : null;
		class_2561 vein = veinR != null ? veinR.getName() : class_2561.method_43471("chat.coe.veinFinder.nothing");
		TooltipUtil.forGoggles(tooltip, class_2561.method_43469("chat.coe.veinFinder.found", vein));

		if(!field_11863.method_8320(field_11867.method_10074()).method_26234(field_11863, field_11867.method_10074())) {
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.drill.noGround"));
		}

		if (drilling) {
			if (progress < DRILL_TIME)
				TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.drill.progress").method_27693(": [").method_10852(ClientUtil.makeProgressBar(progress / (float) DRILL_TIME)).method_27693("]"));
			else
				TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.sample_drill.done"));
		} else if(airTankLevel > 0.2f) {
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.sample_drill.click_to_start"));
		}
		if(resourceRemClient != 0)TooltipUtil.forGoggles(tooltip, class_2561.method_43469("info.coe.drill.resourceRemaining", NumberFormatter.formatNumber(resourceRemClient)));
		if (airTankLevel < 0)
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.sample_drill.no_air"));
		else if (airTankLevel < 0.21f)
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.sample_drill.low_air"));
		else
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.sample_drill.air").method_27693(": [").method_10852(ClientUtil.makeProgressBar(airTankLevel)).method_27693("]"));
		return true;
	}

	private void updateVein() {
		class_1923 p = new class_1923(field_11867);
		data = OreDataCapability.getData(field_11863.method_8497(p.field_9181, p.field_9180));
		class_1863 m = field_11863.method_8433();
		if(data != null) {
			vein = data.getRecipe(m);
		}
	}

	@Override
	public void tick() {
		super.tick();
		if (!field_11863.field_9236 && drilling && progress < DRILL_TIME &&
				field_11863.method_8320(field_11867.method_10074()).method_26234(field_11863, field_11867.method_10074())) {
			class_2586 be = field_11863.method_8321(field_11867.method_10084());
			if (be instanceof BacktankBlockEntity t) {
				int air = t.getAirLevel();
				if (t.getComparatorOutput() > ComparatorUtil.fractionToRedstoneLevel(0.2f)) {
					int op = class_3532.method_15340(air / 80, 1, 4);
					t.setAirLevel(air - op);
					progress += op;
					notifyUpdate();
				}
			}
		}
	}

	@Override
	public void lazyTick() {
		if (field_11863.field_9236)return;
		updateVein();
		class_2586 be = field_11863.method_8321(field_11867.method_10084());
		if (be instanceof BacktankBlockEntity t) {
			airTankLevel = t.getComparatorOutput() / (float) ComparatorUtil.fractionToRedstoneLevel(1f);
		} else {
			airTankLevel = -1f;
		}
		notifyUpdate();
	}

	@Override
	protected void write(class_2487 compound, boolean clientPacket) {
		super.write(compound, clientPacket);
		compound.method_10569("progress", progress);
		compound.method_10556("drilling", drilling);
		if(clientPacket) {
			if(vein != null) {
				compound.method_10582("veinId", vein.method_8114().toString());
				compound.method_10544("resRem", data.getResourcesRemaining(vein));
			}
			compound.method_10548("air", airTankLevel);
		}
	}

	@Override
	protected void read(class_2487 compound, boolean clientPacket) {
		super.read(compound, clientPacket);
		progress = compound.method_10550("progress");
		drilling = compound.method_10577("drilling");
		if(clientPacket) {
			if(compound.method_10545("veinId")) {
				veinClient = new class_2960(compound.method_10558("veinId"));
				resourceRemClient = compound.method_10537("resRem");
			} else
				veinClient = null;
			airTankLevel = compound.method_10583("air");
		}
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
	}

	public void clicked(class_1657 player) {
		if (progress >= DRILL_TIME) {
			if (vein == null) {
				player.method_7353(class_2561.method_43469("chat.coe.veinFinder.found", class_2561.method_43471("chat.coe.veinFinder.nothing")), true);
			} else {
				class_1799 is = player.method_6047();
				if (is.method_7909() == Registration.VEIN_ATLAS_ITEM.get()) {
					Registration.VEIN_ATLAS_ITEM.get().addVein(player, is, vein, new DimChunkPos(field_11863, field_11867), data.getRandomMul());
					return;
				}
				player.method_7353(class_2561.method_43471("chat.coe.sampleDrill.noAtlas"), true);
			}
		} else if(!drilling) {
			if(airTankLevel > 0.2f) {
				progress = 0;
				drilling = true;
				player.method_7353(class_2561.method_43471("chat.coe.sampleDrill.start"), true);
			} else if(airTankLevel < 0) {
				player.method_7353(class_2561.method_43471("chat.coe.sampleDrill.noAir"), true);
			} else {
				player.method_7353(class_2561.method_43471("chat.coe.sampleDrill.lowAir"), true);
			}
		} else {
			player.method_7353(class_2561.method_43471("chat.coe.sampleDrill.running"), true);
		}
	}

	@Override
	public class_1799 getDrill() {
		return Registration.NORMAL_DRILL_ITEM.asStack();
	}

	@Override
	public class_2338 getBelow() {
		return field_11867.method_10074();
	}

	@Override
	public class_2350 getFacing() {
		return class_2350.field_11035;
	}

	@Override
	public boolean shouldRenderRubble() {
		return progress > 0;
	}

	@Override
	public float getYOffset() {
		return 1.7f;
	}

	@Override
	public float getDrillOffset() {
		return progress >= DRILL_TIME ? 0f : (progress / (float) DRILL_TIME) * 0.5f;
	}

	@Override
	public float getRotation() {
		if (progress >= DRILL_TIME)return 0f;
		if (progress > 0 && airTankLevel > 0.2f) {
			long ticks = method_10997().method_8510();
			float rot = (ticks * 20) % 360;
			return rot;
		}
		return 0f;
	}

	@Override
	public float getPrevRotation() {
		if (progress >= DRILL_TIME)return 0f;
		if (progress > 0 && airTankLevel > 0.2f) {
			long ticks = method_10997().method_8510() - 1;
			float rot = (ticks * 20) % 360;
			return rot;
		}
		return 0f;
	}

	@Override
	public boolean shouldRenderShaft() {
		return (progress / (float) DRILL_TIME) > 0.5f && progress < DRILL_TIME;
	}

	public void setDrilling(boolean drilling) {
		this.drilling = drilling;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}

	public void setAirTankLevel(float airTankLevel) {
		this.airTankLevel = airTankLevel;
	}
}

package com.tom.createores.block.entity;

import static net.minecraft.class_124.field_1065;
import static net.minecraft.class_2741.field_12481;

import java.util.Comparator;
import java.util.List;

import net.createmod.catnip.lang.FontHelper.Palette;
import net.minecraft.class_1074;
import net.minecraft.class_1264;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1863;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import com.simibubi.create.content.kinetics.base.IRotate.SpeedLevel;
import com.simibubi.create.foundation.blockEntity.SmartBlockEntity;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.item.TooltipHelper;
import com.simibubi.create.foundation.utility.CreateLang;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.OreDataCapability;
import com.tom.createores.OreDataCapability.OreData;
import com.tom.createores.Registration;
import com.tom.createores.client.ClientUtil;
import com.tom.createores.recipe.ExcavatingRecipe;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.DimChunkPos;
import com.tom.createores.util.NumberFormatter;
import com.tom.createores.util.TooltipUtil;

public abstract class ExcavatingBlockEntity<R extends ExcavatingRecipe> extends SmartBlockEntity implements MultiblockCapHandler, IDrill {
	protected int progress;
	protected Kinetic kinetic;
	protected class_2960 veinClient, recipeClient;
	protected long resourceRemClient;
	protected boolean hasRotation;
	protected class_1799 drillStack;
	protected R current;
	protected VeinRecipe vein;
	protected OreData data;
	protected ExcavatorState state = ExcavatorState.NO_VEIN;
	protected boolean completedOneCycle;

	protected ExcavatingBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
		super(type, pos, state);
		drillStack = class_1799.field_8037;
		setLazyTickRate(20);
	}

	@SuppressWarnings({ "unchecked" })
	@Override
	public boolean addToGoggleTooltip(List<class_2561> tooltip, boolean isPlayerSneaking) {
		VeinRecipe veinR = veinClient != null ? field_11863.method_8433().method_8130(veinClient).filter(e -> e instanceof VeinRecipe).map(r -> (VeinRecipe) r).orElse(null) : null;
		class_2561 vein = veinR != null ? veinR.getName() : class_2561.method_43471("chat.coe.veinFinder.nothing");
		R rec = recipeClient != null ? field_11863.method_8433().method_8130(recipeClient).filter(r -> r.method_17716() == getRecipeType()).map(r -> (R) r).orElse(null) : null;
		TooltipUtil.forGoggles(tooltip, class_2561.method_43469("chat.coe.veinFinder.found", vein));
		if(!hasRotation) {
			TooltipUtil.forGoggles(tooltip, CreateLang.translateDirect("tooltip.speedRequirement")
					.method_27692(field_1065));
			class_2561 hint =
					CreateLang.translateDirect("gui.contraptions.not_fast_enough", class_1074.method_4662(method_11010().method_26204()
							.method_9539()));
			List<class_2561> cutString = TooltipHelper.cutTextComponent(hint, Palette.GRAY_AND_WHITE);
			for (int i = 0; i < cutString.size(); i++)
				TooltipUtil.forGoggles(tooltip, cutString.get(i).method_27661());
		}
		if(drillStack.method_7960())
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.drill.noDrill"));
		else
			TooltipUtil.forGoggles(tooltip, class_2561.method_43469("info.coe.drill.installed", drillStack.method_7964()));

		if(!field_11863.method_8320(getBelow()).method_26234(field_11863, getBelow())) {
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.drill.noGround"));
		}

		if(rec != null) {
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.drill.progress").method_27693(": [").method_10852(ClientUtil.makeProgressBar(progress / (float) rec.getTicks())).method_27693("]"));
			if(resourceRemClient != 0)TooltipUtil.forGoggles(tooltip, class_2561.method_43469("info.coe.drill.resourceRemaining", NumberFormatter.formatNumber(resourceRemClient)));
			if(!rec.getDrill().method_8093(drillStack)) {
				TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.drill.badDrill"));
			}
			addToGoggleTooltip(tooltip, rec);
		}
		if(state != ExcavatorState.NO_ERROR) {
			TooltipUtil.forGoggles(tooltip, class_2561.method_43471("info.coe.drill.err_" + state.name().toLowerCase()));
		}

		return true;
	}

	public void addToGoggleTooltip(List<class_2561> tooltip, R recipe) {}

	public void updateRecipe() {
		vein = null;
		current = null;

		class_1923 p = new class_1923(field_11867);
		data = OreDataCapability.getData(field_11863.method_8497(p.field_9181, p.field_9180));
		class_1863 m = field_11863.method_8433();
		if(data != null) {
			vein = data.getRecipe(m);
			if(vein != null) {
				List<R> rec = m.method_30027(getRecipeType()).stream().filter(r -> r.veinId.equals(vein.method_8114())).sorted(Comparator.comparingInt(r -> r.priority)).toList();
				if(rec.size() == 1)current = rec.get(0);
				else if(rec.size() > 1) {
					for (R r : rec) {
						if(validateRecipe(r)) {
							current = r;
						}
					}
					if(current == null)current = rec.get(0);
				}
			}
		}
	}

	protected boolean validateRecipe(R recipe) {
		return recipe.getDrill().method_8093(drillStack);
	}

	protected abstract class_3956<R> getRecipeType();
	protected abstract boolean canExtract();
	protected abstract void onFinished();

	@Override
	public void tick() {
		super.tick();
		if(!field_11863.field_9236) {
			if(current != null && state == ExcavatorState.NO_ERROR) {
				if(kinetic != null)kinetic.setStress(current.getStress());
				if(canExtract() && kinetic != null && kinetic.getRotationSpeed() >= SpeedLevel.MEDIUM.getSpeedValue() &&
						current.getDrill().method_8093(drillStack) && field_11863.method_8320(getBelow()).method_26234(field_11863, getBelow())) {
					float prg = kinetic.getRotationSpeed() / SpeedLevel.MEDIUM.getSpeedValue();
					progress += prg;
					if(progress >= current.getTicks()) {
						updateState();
						if(state == ExcavatorState.NO_ERROR) {
							onFinished();
							data.extract(1);
							completedOneCycle = true;
							method_5431();
						}
						progress = 0;
					}
				} else if(!current.getDrill().method_8093(drillStack)) {
					R old = current;
					updateRecipe();
					if (old != current)
						progress = 0;
				}
			} else if(progress > 10) {
				progress = 0;
				updateState();
			} else {
				progress++;
			}
		}
	}

	private void updateState() {
		updateRecipe();
		if(vein == null) {
			state = ExcavatorState.NO_VEIN;
		} else if(!data.canExtract(field_11863, field_11867)) {
			state = ExcavatorState.TOO_MANY_EXCAVATORS;
		} else if(data.getResourcesRemaining(vein) == -1) {
			state = ExcavatorState.VEIN_EMPTY;
		} else if(current == null) {
			state = ExcavatorState.NO_RECIPE;
		} else {
			state = ExcavatorState.NO_ERROR;
		}
		notifyUpdate();
	}

	@Override
	public void lazyTick() {
		notifyUpdate();
	}

	@Override
	protected void read(class_2487 tag, boolean clientPacket) {
		super.read(tag, clientPacket);
		progress = tag.method_10550("progress");
		drillStack = class_1799.method_7915(tag.method_10562("drill"));
		completedOneCycle = tag.method_10577("finishedOnce");
		if(clientPacket) {
			state = ExcavatorState.VALUES[tag.method_10571("state")];
			if(tag.method_10545("veinId")) {
				veinClient = new class_2960(tag.method_10558("veinId"));
				resourceRemClient = tag.method_10537("resRem");
			} else
				veinClient = null;

			if(tag.method_10545("currentRecipeId")) {
				recipeClient = new class_2960(tag.method_10558("currentRecipeId"));
			} else
				recipeClient = null;

			hasRotation = tag.method_10577("hasRot");
		}
	}

	@Override
	protected void write(class_2487 tag, boolean clientPacket) {
		super.write(tag, clientPacket);
		tag.method_10569("progress", progress);
		tag.method_10566("drill", drillStack.method_7953(new class_2487()));
		tag.method_10556("finishedOnce", completedOneCycle);
		if(clientPacket) {
			tag.method_10567("state", (byte) state.ordinal());
			if(vein != null) {
				tag.method_10582("veinId", vein.method_8114().toString());
				tag.method_10544("resRem", data.getResourcesRemaining(vein));
			}
			if(current != null) {
				tag.method_10582("currentRecipeId", current.method_8114().toString());
			}
			tag.method_10556("hasRot", kinetic != null && kinetic.getRotationSpeed() >= SpeedLevel.MEDIUM.getSpeedValue());
		}
	}

	@Override
	public void initialize() {
		super.initialize();
		if(!field_11863.field_9236) {
			if(progress > 0 && current == null)
				updateRecipe();
			if(current == null)progress = 0;
		}
	}

	@Override
	public class_1799 getDrill() {
		return drillStack;
	}

	@Override
	public class_2338 getBelow() {
		return field_11867.method_10087(2);
	}

	@Override
	public void addKinetic(Kinetic k) {
		this.kinetic = k;
	}

	@Override
	public void dropInv() {
		dropItemStack(drillStack);
	}

	public class_1269 onClick(class_1657 player, class_1268 hand) {
		class_1799 item = player.method_5998(hand);
		if (item.method_7909() == Registration.VEIN_ATLAS_ITEM.get()) {
			if(!field_11863.field_9236) {
				if (completedOneCycle) {
					Registration.VEIN_ATLAS_ITEM.get().addVein(player, item, vein, new DimChunkPos(field_11863, field_11867), data.getRandomMul());
				} else {
					player.method_7353(class_2561.method_43471("chat.coe.sampleDrill.notDone"), true);
				}
			}
			return class_1269.field_5812;
		}
		if(!item.method_7960() && item.method_31573(CreateOreExcavation.DRILL_TAG)) {
			if(drillStack.method_7960()) {
				if(!field_11863.field_9236)drillStack = item.method_7971(1);
				notifyUpdate();
				return class_1269.field_5812;
			}
		} else if(item.method_7960()) {
			if(!drillStack.method_7960()) {
				if(!field_11863.field_9236) {
					if(player.method_7270(drillStack)) {
						drillStack = class_1799.field_8037;
						notifyUpdate();
						return class_1269.field_21466;
					}
					return class_1269.field_5812;
				} else return class_1269.field_5812;
			}
		}
		return class_1269.field_5811;
	}

	@Override
	public void addBehaviours(List<BlockEntityBehaviour> behaviours) {
	}

	protected void dropItemStack(class_1799 stackInSlot) {
		class_1264.method_5449(field_11863, field_11867.method_10263(), field_11867.method_10264(), field_11867.method_10260(), stackInSlot);
	}

	@Override
	protected class_238 createRenderBoundingBox() {
		return new class_238(field_11867.method_10069(-1, -1, -1), field_11867.method_10069(1, 0, 1));
	}

	@Override
	public class_2350 getFacing() {
		return method_11010().method_11654(field_12481);
	}

	@Override
	public boolean shouldRenderRubble() {
		return completedOneCycle || (recipeClient != null && progress > 0);
	}

	@Override
	public float getYOffset() {
		return 0.8f;
	}

	@Override
	public float getDrillOffset() {
		return isActive() ? 0.2f : 0.0f;
	}

	private boolean isActive() {
		return recipeClient != null && hasRotation;
	}

	@Override
	public float getRotation() {
		if (isActive()) {
			long ticks = method_10997().method_8510();
			float rot = (ticks * 20) % 360;
			return rot;
		}
		return 0f;
	}

	@Override
	public float getPrevRotation() {
		if (isActive()) {
			long ticks = method_10997().method_8510() - 1;
			float rot = (ticks * 20) % 360;
			return rot;
		}
		return 0f;
	}

	@Override
	public boolean shouldRenderShaft() {
		return true;
	}

	public static enum ExcavatorState {
		NO_ERROR,
		NO_VEIN,
		VEIN_EMPTY,
		TOO_MANY_EXCAVATORS,
		NO_RECIPE,
		;
		public static final ExcavatorState[] VALUES = values();
	}
}

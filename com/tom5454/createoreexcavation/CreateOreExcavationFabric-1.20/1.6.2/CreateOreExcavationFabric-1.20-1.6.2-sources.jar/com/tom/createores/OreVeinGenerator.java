package com.tom.createores;

import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.RandomSpreadGenerator;

public class OreVeinGenerator {
	private static AtomicReference<RandomSpreadGenerator> picker = new AtomicReference<>();

	public static void invalidate() {
		picker.set(null);
	}

	public static RandomSpreadGenerator getPicker(class_3218 chunk) {
		RandomSpreadGenerator v = picker.get();
		if(v != null)return v;
		synchronized (picker) {
			v = picker.get();
			if(v != null)return v;
			v = new RandomSpreadGenerator();
			v.loadAll(chunk);
			picker.set(v);
			return v;
		}
	}

	public static VeinRecipe pick(class_2818 chunk) {
		return getPicker((class_3218) chunk.method_12200()).pick(chunk);
	}

	public static class_5819 rngFromChunk(class_2818 chunk) {
		class_3218 lvl = (class_3218) chunk.method_12200();
		long seed = lvl.method_8412();
		return class_5819.method_43049(seed ^ chunk.method_12004().method_8324());
	}
}

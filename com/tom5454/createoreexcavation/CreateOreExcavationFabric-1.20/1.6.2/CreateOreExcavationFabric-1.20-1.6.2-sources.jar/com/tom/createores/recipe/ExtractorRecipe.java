package com.tom.createores.recipe;

import com.simibubi.create.foundation.fluid.FluidHelper;

import com.google.gson.JsonObject;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import net.minecraft.class_1865;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3956;

public class ExtractorRecipe extends ExcavatingRecipe {
	public FluidStack output;

	public ExtractorRecipe(class_2960 id, class_3956<?> type, class_1865<?> serializer) {
		super(id, type, serializer);
	}

	@Override
	public String method_8112() {
		return "extractor";
	}

	@Override
	protected void fromJson(JsonObject json) {
		output = FluidHelper.deserializeFluidStack(json.getAsJsonObject("output"));
	}

	@Override
	protected void fromNetwork(class_2540 buffer) {
		output = FluidStack.readFromPacket(buffer);
	}

	@Override
	protected void toNetwork(class_2540 buffer) {
		output.writeToPacket(buffer);
	}

	public FluidStack getOutput() {
		return output;
	}

	@Override
	protected void toJson(JsonObject json) {
		json.add("output", FluidHelper.serializeFluidStack(output));
	}
}

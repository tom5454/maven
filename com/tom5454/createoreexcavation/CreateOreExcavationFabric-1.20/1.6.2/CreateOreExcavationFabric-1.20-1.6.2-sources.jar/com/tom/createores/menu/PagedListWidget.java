package com.tom.createores.menu;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_474;
import net.minecraft.class_6382;

public abstract class PagedListWidget<D, T> extends class_339 {
	private class_474 forwardButton;
	private class_474 backButton;
	private int wh;
	private int page;

	protected Supplier<List<T>> list;
	protected T selected;
	private List<ListEntry> listEntries = new ArrayList<>();

	public PagedListWidget(int x, int y, int w, int h, int wh) {
		super(x, y, w, h, class_2561.method_43473());
		this.forwardButton = this.addWidgetToGUI(new class_474(x + w - 24, y + h - 12, true, p_98297_ -> this.pageForward(), true));
		this.backButton = this.addWidgetToGUI(new class_474(x + 4, y + h - 12, false, p_98287_ -> this.pageBack(), true));
		this.wh = wh;
		int wc = getLines();
		for (int i = 0;i<wc;i++) {
			listEntries.add(new ListEntry(i, makeElement(x, y + i * wh)));
		}
	}

	private void pageBack() {
		if (page > 0) {
			page--;
			updateContent();
		}
	}

	private void pageForward() {
		if ((page + 1) * getLines() < list.get().size()) {
			page++;
			updateContent();
		}
	}

	@Override
	protected void method_47399(class_6382 pNarrationElementOutput) {
	}

	@Override
	protected void method_48579(class_332 pGuiGraphics, int pMouseX, int pMouseY, float pPartialTick) {
		if (field_22764) {
			class_310 minecraft = class_310.method_1551();
			class_2561 c = class_2561.method_43470((page + 1) + " / " + (Math.max(class_3532.method_15386(list.get().size() / (float) getLines()), 1)));
			pGuiGraphics.method_51439(minecraft.field_1772, c, method_46426() + method_25368() / 2 - minecraft.field_1772.method_27525(c) / 2, method_46427() + method_25364() - 8, 4210752, false);
		}
	}

	protected abstract <W extends class_339> W addWidgetToGUI(W w);
	protected abstract D makeElement(int x, int y);
	protected abstract void updateElement(D element, T data);

	public void updateContent() {
		listEntries.forEach(ListEntry::update);
		page = class_3532.method_15340(page, 0, Math.max(class_3532.method_15386(list.get().size() / (float) getLines()), 0));
		backButton.field_22763 = page > 0;
		forwardButton.field_22763 = (page + 1) * getLines() < list.get().size();
	}

	public int getLines() {
		return (field_22759 - 16) / wh;
	}

	public void setVisible(boolean visible) {
		this.field_22764 = visible;
		backButton.field_22764 = visible;
		forwardButton.field_22764 = visible;
		listEntries.forEach(ListEntry::update);
	}

	private class ListEntry {
		private final int id;
		private final D disp;

		public ListEntry(int id, D disp) {
			this.id = id;
			this.disp = disp;
		}

		private T getId() {
			if (!field_22764)return null;
			List<T> l = list.get();
			int j = page * getLines();
			if (j < 0) {
				j = 0;
			}
			if(this.id + j < l.size()) {
				return l.get(this.id + j);
			}
			return null;
		}

		private void update() {
			updateElement(disp, getId());
		}
	}
}

package com.tom.createores.block;

import com.simibubi.create.content.equipment.armor.BacktankItem;
import com.simibubi.create.foundation.block.IBE;

import com.tom.createores.Registration;
import com.tom.createores.block.entity.SampleDrillBlockEntity;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class SampleDrillBlock extends class_2248 implements IBE<SampleDrillBlockEntity> {

	public SampleDrillBlock(class_2251 p_49224_) {
		super(p_49224_);
	}

	@Override
	public Class<SampleDrillBlockEntity> getBlockEntityClass() {
		return SampleDrillBlockEntity.class;
	}

	@Override
	public class_2591<? extends SampleDrillBlockEntity> getBlockEntityType() {
		return Registration.SAMPLE_DRILL_TILE.get();
	}

	@Override
	public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player,
			class_1268 hand, class_3965 hit) {
		if (hit.method_17780() == class_2350.field_11036 && player.method_5998(hand).method_7909() instanceof BacktankItem)
			return class_1269.field_5811;
		if (!world.field_9236 && world.method_8321(pos) instanceof SampleDrillBlockEntity be) {
			be.clicked(player);
		}
		return class_1269.field_5812;
	}
}

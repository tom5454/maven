package com.tom.createores.item;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1863;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import com.mojang.datafixers.util.Pair;

import com.tom.createores.Config;
import com.tom.createores.OreDataCapability;
import com.tom.createores.OreDataCapability.OreData;
import com.tom.createores.OreVeinGenerator;
import com.tom.createores.Registration;
import com.tom.createores.network.NetworkHandler;
import com.tom.createores.network.OreVeinInfoPacket;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.ComponentJoiner;
import com.tom.createores.util.RandomSpreadGenerator;

public class OreVeinFinderItem extends class_1792 {

	public OreVeinFinderItem(class_1793 properties) {
		super(properties);
	}

	@Override
	public class_1271<class_1799> method_7836(class_1937 level, class_1657 player, class_1268 interactionHand) {
		if(!level.field_9236)
			detect(level, player.method_24515(), player);

		return class_1271.method_22427(player.method_5998(interactionHand));
	}

	@Override
	public class_1269 method_7884(class_1838 ctx) {
		if(!ctx.method_8045().field_9236)
			detect(ctx.method_8045(), ctx.method_8037(), ctx.method_8036());

		return class_1269.field_5812;
	}

	@Override
	public void method_7851(class_1799 pStack, class_1937 pLevel, List<class_2561> pTooltipComponents,
			class_1836 pIsAdvanced) {
		if (pStack.method_7985() && pStack.method_7969().method_10577("isFiltered")) {
			pTooltipComponents.add(class_2561.method_43471("tooltip.coe.vein_finder.filtered"));
		}
	}

	@Override
	public void method_7888(class_1799 pStack, class_1937 pLevel, class_1297 pEntity, int pSlotId, boolean pIsSelected) {
		if (!pLevel.field_9236 && pEntity instanceof class_1657 player && pLevel.method_8510() % 20 == 10) {
			boolean hasAtlas = false;
			for (int i = 0;i < player.method_31548().method_5439(); i++) {
				class_1799 is = player.method_31548().method_5438(i);
				if (is.method_7909() == Registration.VEIN_ATLAS_ITEM.get()) {
					hasAtlas = true;
					break;
				}
			}
			pStack.method_7948().method_10556("isFiltered", hasAtlas);
		}
	}

	@Override
	public boolean method_7886(class_1799 pStack) {
		return (pStack.method_7985() && pStack.method_7969().method_10577("isFiltered")) || super.method_7886(pStack);
	}

	private void detect(class_1937 level, class_2338 pos, class_1657 player) {
		class_1799 atlas = class_1799.field_8037;
		for (int i = 0;i < player.method_31548().method_5439(); i++) {
			class_1799 is = player.method_31548().method_5438(i);
			if (is.method_7909() == Registration.VEIN_ATLAS_ITEM.get()) {
				atlas = is;
				break;
			}
		}
		class_2487 atlasTag = atlas.method_7969();
		Predicate<VeinRecipe> filter = atlasTag != null ? makeFilter(atlasTag) : a -> true;

		class_1923 center = new class_1923(pos);
		OreData found = null;
		List<OreData> nearby = new ArrayList<>();
		int near = Config.veinFinderNear;
		for(int x = -near;x <= near;x++) {
			for(int z = -near;z <= near;z++) {
				OreData d = OreDataCapability.getData(level.method_8497(center.field_9181 + x, center.field_9180 + z));
				if(x == 0 && z == 0)found = d;
				else nearby.add(d);
			}
		}
		player.method_7353(class_2561.method_43471("chat.coe.veinFinder.info"), false);
		player.method_7353(class_2561.method_43469("chat.coe.veinFinder.pos", center.field_9181, center.field_9180), false);
		class_1863 m = level.method_8433();
		class_2561 f;
		class_2561 nothing = class_2561.method_43471("chat.coe.veinFinder.nothing");
		class_2561 comma = class_2561.method_43470(", ");
		if(found != null && found.getRecipe(m) != null)f = found.getRecipe(m).getName();
		else f = nothing;
		player.method_7353(class_2561.method_43469("chat.coe.veinFinder.found", f), false);

		class_2487 infoTag = new class_2487();
		class_2960 id = found.getRecipeId();
		if (id != null)infoTag.method_10582("found", id.toString());
		infoTag.method_10569("x", pos.method_10263());
		infoTag.method_10569("z", pos.method_10260());

		class_2960 rl = nearby.stream().map(d -> d.getRecipe(m)).filter(r -> r != null).map(VeinRecipe::method_8114).findFirst().orElse(null);
		if (rl != null) {
			infoTag.method_10582("nearby", rl.toString());
		}

		f = nearby.stream().map(d -> d.getRecipe(m)).filter(r -> r != null).map(r -> r.getName()).collect(ComponentJoiner.joining(nothing, comma));
		player.method_7353(class_2561.method_43469("chat.coe.veinFinder.nearby", f), false);

		Pair<class_2338, VeinRecipe> nearest = OreVeinGenerator.getPicker((class_3218) level).locate(pos, (class_3218) level, 16, filter);
		if(nearest != null) {
			class_2338 at = nearest.getFirst();
			int i = Math.round(RandomSpreadGenerator.distance2d(at, pos) / Config.veinFinderFar) * Config.veinFinderFar;
			player.method_7353(class_2561.method_43469("chat.coe.veinFinder.far", class_2561.method_43469("chat.coe.veinFinder.distance", nearest.getSecond().getName(), i)), false);
			infoTag.method_10582("far", nearest.getSecond().method_8114().toString());
			infoTag.method_10569("dist", i);
		} else {
			player.method_7353(class_2561.method_43469("chat.coe.veinFinder.far", nothing), false);
		}
		NetworkHandler.sendTo((class_3222) player, new OreVeinInfoPacket(infoTag));
		player.method_7357().method_7906(this, Config.veinFinderCd);
	}

	private Predicate<VeinRecipe> makeFilter(class_2487 atlasTag) {
		String vt = atlasTag.method_10558(OreVeinAtlasItem.TARGET);
		class_2960 target = class_2960.method_12829(vt);
		if (!vt.isEmpty() && target != null) {
			return v -> target.equals(v.method_8114());
		}
		Set<class_2960> exclude = new HashSet<>();
		class_2499 ex = atlasTag.method_10554(OreVeinAtlasItem.EXCLUDE, class_2520.field_33258);
		for (int i = 0;i < ex.size(); i++) {
			class_2960 v = class_2960.method_12829(ex.method_10608(i));
			if (v != null)exclude.add(v);
		}
		if (exclude.isEmpty())return a -> true;
		return v -> {
			return !exclude.contains(v.method_8114());
		};
	}
}

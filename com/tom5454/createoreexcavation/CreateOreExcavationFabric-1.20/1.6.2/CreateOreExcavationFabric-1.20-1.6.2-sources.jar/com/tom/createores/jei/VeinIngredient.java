package com.tom.createores.jei;

import java.util.ArrayList;
import java.util.List;

import org.jetbrains.annotations.Nullable;

import net.createmod.catnip.gui.element.GuiGameElement;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1863;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import com.mojang.blaze3d.systems.RenderSystem;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.Registration;
import com.tom.createores.recipe.VeinRecipe;
import com.tom.createores.util.NumberFormatter;

import mezz.jei.api.ingredients.IIngredientHelper;
import mezz.jei.api.ingredients.IIngredientRenderer;
import mezz.jei.api.ingredients.IIngredientType;
import mezz.jei.api.ingredients.subtypes.UidContext;
import mezz.jei.api.registration.IModIngredientRegistration;

public class VeinIngredient implements IIngredientHelper<VeinRecipe>, IIngredientRenderer<VeinRecipe> {
	public static final IIngredientType<VeinRecipe> VEIN = () -> VeinRecipe.class;
	private class_1799 drill;

	public VeinIngredient(IModIngredientRegistration registration) {
		class_1863 mngr = class_310.method_1551().method_1562().method_2877();
		registration.register(VEIN, mngr.method_30027(CreateOreExcavation.VEIN_RECIPES.getRecipeType()), this, this);
		drill = new class_1799(Registration.NORMAL_DRILL_ITEM.get());
	}

	@Override
	public void render(class_332 guiGraphics, VeinRecipe ingredient) {
		RenderSystem.enableDepthTest();
		guiGraphics.method_51448().method_22903();

		GuiGameElement.of(ingredient.icon)
		.render(guiGraphics);

		guiGraphics.method_51448().method_22903();
		float s = 0.5f;
		guiGraphics.method_51448().method_46416(8, 8, 100);
		guiGraphics.method_51448().method_22905(s, s, s);
		GuiGameElement.of(drill)
		.render(guiGraphics);
		guiGraphics.method_51448().method_22909();

		guiGraphics.method_51448().method_22909();
	}

	@Override
	public List<class_2561> getTooltip(VeinRecipe ingredient, class_1836 tooltipFlag) {
		List<class_2561> tooltip = new ArrayList<>();
		tooltip.add(ingredient.veinName);
		if(ingredient.isInfiniteClient())tooltip.add(class_2561.method_43471("tooltip.coe.infiniteVeins"));
		else tooltip.add(class_2561.method_43469("tooltip.coe.finiteVeins", NumberFormatter.formatNumber(ingredient.getMinAmountClient()), NumberFormatter.formatNumber(ingredient.getMaxAmountClient())));
		return tooltip;
	}

	@Override
	public IIngredientType<VeinRecipe> getIngredientType() {
		return VEIN;
	}

	@Override
	public String getDisplayName(VeinRecipe ingredient) {
		return ingredient.veinName.getString();
	}

	@Override
	public String getUniqueId(VeinRecipe ingredient, UidContext context) {
		return ingredient.method_8114().toString();
	}

	@Override
	public class_2960 getResourceLocation(VeinRecipe ingredient) {
		return ingredient.method_8114();
	}

	@Override
	public VeinRecipe copyIngredient(VeinRecipe ingredient) {
		return ingredient;
	}

	@Override
	public String getErrorInfo(@Nullable VeinRecipe ingredient) {
		return ingredient != null && ingredient.id != null ? ingredient.id.toString() : "null";
	}
}

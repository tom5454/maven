package com.tom.createores.util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.class_1860;
import net.minecraft.class_1923;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2818;
import net.minecraft.class_2919;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_4076;
import net.minecraft.class_5742;
import net.minecraft.class_5820;
import net.minecraft.class_6872;
import net.minecraft.class_6880;
import com.mojang.datafixers.util.Pair;

import com.tom.createores.CreateOreExcavation;
import com.tom.createores.OreDataCapability;
import com.tom.createores.OreDataCapability.OreData;
import com.tom.createores.recipe.VeinRecipe;

public class RandomSpreadGenerator {
	private List<VeinRecipe> recipes = new ArrayList<>();

	public void loadAll(class_3218 level) {
		recipes.addAll(level.method_8433().method_30027(CreateOreExcavation.VEIN_RECIPES.getRecipeType()));
		recipes.sort(Comparator.comparingInt(VeinRecipe::getNegGenerationPriority).thenComparing(VeinRecipe::method_8114));
	}

	public VeinRecipe pick(class_2818 chunk) {
		int x = chunk.method_12004().field_9181;
		int z = chunk.method_12004().field_9180;
		int minY = class_5742.method_33100(chunk.method_31607());
		int maxY = minY + class_5742.method_33100(chunk.method_31605()) - 1;
		class_3218 level = (class_3218) chunk.method_12200();
		for (VeinRecipe recipe : recipes) {
			class_1923 chunkpos = recipe.getPlacement().method_40169(level.method_8412(), x, z);
			if(chunkpos.field_9181 == x && chunkpos.field_9180 == z) {
				class_2919 rng = new class_2919(new class_5820(0L));
				rng.method_12663(level.method_8412(), x, z);
				class_6880<class_1959> biome = chunk.method_16359(rng.method_43048(4), minY + rng.method_43048(maxY), rng.method_43048(4));
				if(recipe.canGenerate(level, biome)) {
					return recipe;
				}
			}
		}
		return null;
	}

	private VeinRecipe pick(class_3218 level, class_1923 chunk, VeinRecipe last) {
		int minY = class_5742.method_33100(level.method_31607());
		int maxY = minY + class_5742.method_33100(level.method_31605()) - 1;
		for (VeinRecipe recipe : recipes) {
			class_1923 chunkpos = recipe.getPlacement().method_40169(level.method_8412(), chunk.field_9181, chunk.field_9180);
			if(chunkpos.field_9181 == chunk.field_9181 && chunkpos.field_9180 == chunk.field_9180) {
				class_2919 rng = new class_2919(new class_5820(0L));
				rng.method_12663(level.method_8412(), chunk.field_9181, chunk.field_9180);
				class_6880<class_1959> biome = level.method_16359(class_5742.method_33102(chunk.field_9181) + rng.method_43048(4), minY + rng.method_43048(maxY), class_5742.method_33102(chunk.field_9180) + rng.method_43048(4));

				if (recipe.canGenerate(level, biome))
					return recipe;
			}
			if(recipe == last)break;
		}
		return null;
	}

	public class_2338 locate(class_2960 id, class_2338 pPos, class_3218 level, int radius) {
		class_1860<?> recipe = level.method_8433().method_8130(id).orElse(null);
		if(recipe instanceof VeinRecipe r) {
			int i = class_4076.method_18675(pPos.method_10263());
			int j = class_4076.method_18675(pPos.method_10260());
			for(int k = 0; k <= radius; ++k) {
				class_2338 pos = getNearestGenerated(level, i, j, k, level.method_8412(), r);
				if(pos != null) {
					if (level.method_8477(pos)) {
						OreData data = OreDataCapability.getData(level.method_8500(pos));
						VeinRecipe vr = data.getRecipe(level.method_8433());
						if (vr == null || !vr.id.equals(id))continue;
					}
					return pos;
				}
			}
		}
		return null;
	}

	public Pair<class_2338, VeinRecipe> locate(class_2338 pPos, class_3218 level, int radius, Predicate<VeinRecipe> filter) {
		int i = class_4076.method_18675(pPos.method_10263());
		int j = class_4076.method_18675(pPos.method_10260());
		for(int k = 0; k <= radius; ++k) {
			Pair<class_2338, VeinRecipe> found = null;
			float dist = Float.MAX_VALUE;
			for (int j2 = 0; j2 < recipes.size(); j2++) {
				VeinRecipe r = recipes.get(j2);
				if (!filter.test(r))continue;
				class_2338 pos = getNearestGenerated(level, i, j, k, level.method_8412(), r);
				if(pos != null) {
					float d = distance2d(pos, pPos);
					if(d < dist) {
						if (level.method_8477(pos)) {
							OreData data = OreDataCapability.getData(level.method_8500(pos));
							r = data.getRecipe(level.method_8433());
							if (r == null)continue;
							if (!filter.test(r))continue;
						}
						found = Pair.of(pos, r);
						dist = d;
					}
				}
			}
			if(found != null)
				return found;
		}
		return null;
	}

	private class_2338 getNearestGenerated(class_3218 pLevel, int pX, int pY, int pZ, long pSeed, VeinRecipe recipe) {
		class_6872 pSpreadPlacement = recipe.getPlacement();
		int i = pSpreadPlacement.method_41632();

		for(int j = -pZ; j <= pZ; ++j) {
			boolean flag = j == -pZ || j == pZ;

			for(int k = -pZ; k <= pZ; ++k) {
				boolean flag1 = k == -pZ || k == pZ;
				if (flag || flag1) {
					int l = pX + i * j;
					int i1 = pY + i * k;
					class_1923 chunkpos = pSpreadPlacement.method_40169(pSeed, l, i1);

					VeinRecipe picked = pick(pLevel, chunkpos, recipe);
					if(picked == recipe)
						return chunkpos.method_33943(0);
				}
			}
		}

		return null;
	}

	public static float distance2d(class_2338 a, class_2338 b) {
		int i = b.method_10263() - a.method_10263();
		int j = b.method_10260() - a.method_10260();
		return class_3532.method_15355(i * i + j * j);
	}
}

package com.tom.cpm.common;

import com.tom.cpl.block.Biome;
import com.tom.cpl.block.BlockState;
import com.tom.cpl.block.World;
import com.tom.cpl.util.WeakStorage;
import com.tom.cpm.shared.animation.AnimationState;
import net.minecraft.class_1297;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2378;

public class WorldImpl implements World {
	public WeakStorage<net.minecraft.class_1937> level = new WeakStorage<>();
	public class_2338 base;

	public static void setWorld(AnimationState a, class_1297 ent) {
		if(!(a.world instanceof WorldImpl))a.world = new WorldImpl();
		WorldImpl i = (WorldImpl) a.world;
		net.minecraft.class_1937 l = ent.field_6002;
		i.level.set(l);
		i.base = ent.method_5704();
		a.dayTime = l.method_8532();
		a.skyLight = l.method_8314(class_1944.field_9284, i.base);
		a.blockLight = l.method_8314(class_1944.field_9282, i.base);
	}

	@Override
	public BlockState getBlock(int x, int y, int z) {
		return level.call(l -> BlockStateHandlerImpl.impl.wrap(l.method_8320(base.method_10069(x, y, z))), BlockState.AIR);
	}

	@Override
	public boolean isCovered() {
		return level.call(l -> l.method_8311(base), false);
	}

	@Override
	public int getYHeight() {
		return base.method_10264();
	}

	@Override
	public int getMaxHeight() {
		return level.call(l -> l.method_8322(), 0);
	}

	@Override
	public int getMinHeight() {
		return 0;
	}

	@Override
	public WeatherType getWeather() {
		return level.call(l -> l.method_8546() ? WeatherType.THUNDER : l.method_8419() ? WeatherType.RAIN : WeatherType.CLEAR, WeatherType.CLEAR);
	}

	@Override
	public Biome getBiome() {
		return level.call(l -> BiomeHandlerImpl.impl.wrap(l.method_8310(base)), null);
	}

	@Override
	public String getDimension() {
		return level.call(l -> class_2378.field_11155.method_10221(l.method_8597().method_12460()).toString(), null);
	}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Desc;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.ClientBase.PlayerNameTagRenderer;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import net.minecraft.class_1007;
import net.minecraft.class_310;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_898;
import net.minecraft.class_922;

@Mixin(value = class_1007.class, priority = 900)
public abstract class PlayerRendererMixin extends class_922<class_742, class_591<class_742>> implements PlayerNameTagRenderer<class_742> {

	public PlayerRendererMixin(class_898 rendererManager,
			class_591<class_742> entityModelIn, float shadowSizeIn) {
		super(rendererManager, entityModelIn, shadowSizeIn);
	}

	@Inject(at = @At("HEAD"), method = "renderRightHand(Lnet/minecraft/client/entity/player/AbstractClientPlayerEntity;)V")
	public void onRenderRightArmPre(class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHand(method_4038());
	}

	@Inject(at = @At("HEAD"), method = "renderLeftHand(Lnet/minecraft/client/entity/player/AbstractClientPlayerEntity;)V")
	public void onRenderLeftArmPre(class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHand(method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderRightHand(Lnet/minecraft/client/entity/player/AbstractClientPlayerEntity;)V")
	public void onRenderRightArmPost(class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderLeftHand(Lnet/minecraft/client/entity/player/AbstractClientPlayerEntity;)V")
	public void onRenderLeftArmPost(class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(method_4038());
	}

	@Inject(at = @At("HEAD"), method = "renderNameTags(Lnet/minecraft/client/entity/player/AbstractClientPlayerEntity;DDDLjava/lang/String;D)V", cancellable = true)
	public void onRenderName1(class_742 entityIn, double x, double y, double z, String displayNameIn, double dst, CallbackInfo cbi) {
		if(!Player.isEnableNames())cbi.cancel();
	}

	@Inject(at = @At(value = "RETURN"), method = "renderNameTags(Lnet/minecraft/client/entity/player/AbstractClientPlayerEntity;DDDLjava/lang/String;D)V")
	public void onRenderName2(class_742 entityIn, double x, double y, double z, String displayNameIn, double dst, CallbackInfo cbi) {
		if(Player.isEnableLoadingInfo())
			CustomPlayerModelsClient.INSTANCE.renderNameTag(this, entityIn, entityIn.method_7334(), ModelDefinitionLoader.PLAYER_UNIQUE, x, y, z, dst);
	}

	@Override
	public void cpm$renderNameTag(class_742 entityIn, String displayNameIn, double x, double y, double z, double i) {
		super.method_3930(entityIn, x, y, z, displayNameIn, i);
	}

	@Override
	public class_898 cpm$entityRenderDispatcher() {
		return field_4676;
	}

	@Override
	@Unique
	public void renderModel(class_742 p_77036_1_, float p_77036_2_, float p_77036_3_,
			float p_77036_4_, float p_77036_5_, float p_77036_6_, float p_77036_7_) {
		super.method_4052(p_77036_1_, p_77036_2_, p_77036_3_, p_77036_4_, p_77036_5_, p_77036_6_, p_77036_7_);
	}

	@Inject(at = @At("HEAD"), target = {@Desc(value = "", args = {class_742.class, float.class, float.class, float.class, float.class, float.class, float.class})}, cancellable = true)
	public void onRenderModel(class_742 player, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch, float scale, CallbackInfo cbi) {
		boolean pBodyVisible = this.method_4056(player);
		boolean pTranslucent = !pBodyVisible && !player.method_5756(class_310.method_1551().field_1724);
		if(!pBodyVisible && CustomPlayerModelsClient.mc.getPlayerRenderManager().isBound(method_4038())) {
			boolean r = CustomPlayerModelsClient.mc.getPlayerRenderManager().getHolderSafe(method_4038(), null, h -> h.setInvisState(), false, false);
			if(pTranslucent)return;
			boolean pGlowing = player.method_5851();
			if(!pGlowing && !r)return;
			if (!this.method_3925(player))return;

			CustomPlayerModelsClient.mc.getPlayerRenderManager().getHolderSafe(method_4038(), null, h -> h.setInvis(false), false);
			this.field_4737.method_17088(player, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);

			cbi.cancel();
		}
	}
}

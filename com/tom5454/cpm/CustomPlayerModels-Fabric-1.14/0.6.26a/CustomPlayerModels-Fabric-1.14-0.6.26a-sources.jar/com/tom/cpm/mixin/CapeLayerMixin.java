package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.TextureSheetType;
import com.tom.cpm.shared.model.render.ModelRenderManager.BoundPlayer;
import net.minecraft.class_1304;
import net.minecraft.class_1664;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_972;

@Mixin(class_972.class)
public abstract class CapeLayerMixin extends class_3887<class_742, class_591<class_742>> {

	public CapeLayerMixin(
			class_3883<class_742, class_591<class_742>> p_i50926_1_) {
		super(p_i50926_1_);
	}

	@Inject(at = @At("HEAD"), method = "render(Lnet/minecraft/client/entity/player/AbstractClientPlayerEntity;FFFFFFF)V", cancellable = true)
	public void onRender(class_742 player, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale, CallbackInfo cbi) {
		BoundPlayer pl = CustomPlayerModelsClient.INSTANCE.manager.getPlayerFromModel(method_17165());
		if(pl != null) {
			ModelDefinition def = pl.definition;
			if(def != null && def.hasRoot(RootModelType.CAPE)) {
				class_1799 chestplate = player.method_6118(class_1304.field_6174);
				if(!player.method_5767() && player.method_7348(class_1664.field_7559) && chestplate.method_7909() != class_1802.field_8833) {
					class_591<class_742> model = method_17165();
					CustomPlayerModelsClient.mc.getPlayerRenderManager().rebindModel(model);
					CustomPlayerModelsClient.INSTANCE.manager.bindSkin(model, TextureSheetType.CAPE);
					CustomPlayerModelsClient.renderCape(player, partialTicks, model, def);
				}
				cbi.cancel();
			}
		}
	}
}

package com.tom.cpm.client;

import org.lwjgl.opengl.GL11;
import com.mojang.blaze3d.platform.GLX;
import com.mojang.blaze3d.platform.GlStateManager;

import com.tom.cpl.math.Vec4f;
import com.tom.cpl.render.DirectBuffer;
import com.tom.cpl.render.VBuffers.NativeRenderType;
import com.tom.cpl.render.VertexBuffer;
import com.tom.cpm.client.MinecraftObject.DynTexture;
import com.tom.cpm.shared.retro.RetroGLAccess;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class RetroGL implements RetroGLAccess<class_2960> {
	private static final RenderStage lines = new RenderStage(true, false, false, () -> {
		GlStateManager.disableDepthTest();
		GlStateManager.disableTexture();
	}, () -> {
		GlStateManager.enableTexture();
		GlStateManager.enableDepthTest();
	}, GL11.GL_LINES, class_290.field_1576);

	private static final RenderStage color = new RenderStage(true, false, false, () -> {
		GlStateManager.disableTexture();
	}, () -> {
		GlStateManager.enableTexture();
	}, GL11.GL_QUADS, class_290.field_1576);

	@Override
	public RenderStage texture(class_2960 rl) {
		return new RenderStage(true, true, true, () -> {
			bindTex(rl);
		}, () -> {
		}, GL11.GL_QUADS, class_290.field_1577);
	}

	private static float lx, ly;
	@Override
	public RenderStage eyes(class_2960 rl) {
		return new RenderStage(true, true, true, () -> {
			lx = Platform.lastBrightnessX();
			ly = Platform.lastBrightnessY();
			GlStateManager.enableBlend();
			GlStateManager.disableAlphaTest();
			GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
			GlStateManager.depthMask(true);
			int i = 0xF0;
			int j = i % 65536;
			int k = i / 65536;
			GLX.glMultiTexCoord2f(GLX.GL_TEXTURE1, j, k);
			class_310.method_1551().field_1773.method_3201(true);
			bindTex(rl);
		}, () -> {
			class_310.method_1551().field_1773.method_3201(false);
			GLX.glMultiTexCoord2f(GLX.GL_TEXTURE1, lx, ly);
			GlStateManager.blendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
			GlStateManager.enableAlphaTest();
		}, GL11.GL_QUADS, class_290.field_1577);
	}

	@Override
	public RenderStage linesNoDepth() {
		return lines;
	}

	@Override
	public RenderStage color() {
		return color;
	}

	private static void bindTex(class_2960 tex) {
		if(tex != null)
			class_310.method_1551().method_1531().method_4618(tex);
	}

	public static VertexBuffer buffer(NativeRenderType type) {
		RenderStage stage = type.getNativeType();
		return new RetroBuffer(class_289.method_1348(), stage);
	}

	private static class RenderStage implements RetroLayer {
		private boolean color, texture, normal;
		private Runnable begin, end;
		private int glMode;
		private class_293 format;

		public RenderStage(boolean color, boolean texture, boolean normal, Runnable begin, Runnable end, int glMode, class_293 format) {
			this.color = color;
			this.texture = texture;
			this.normal = normal;
			this.begin = begin;
			this.end = end;
			this.glMode = glMode;
			this.format = format;
		}

		public void begin(class_287 buf) {
			begin.run();
			buf.method_1328(glMode, format);
		}

		public void end() {
			end.run();
		}
	}

	private static class RetroBuffer extends DirectBuffer<class_287> {
		private RenderStage stage;
		private class_289 tes;

		public RetroBuffer(class_289 tes, RenderStage stage) {
			super(tes.method_1349());
			this.tes = tes;
			this.stage = stage;
			stage.begin(buffer);
		}

		@Override
		protected void pushVertex(float x, float y, float z, float red, float green, float blue, float alpha,
				float u, float v, float nx, float ny, float nz) {
			buffer.method_1315(x, y, z);
			if(stage.texture)buffer.method_1312(u, v);
			if(stage.color)buffer.method_1336(red, green, blue, alpha);
			if(stage.normal)buffer.method_1318(nx, ny, nz);
			buffer.method_1344();
		}

		@Override
		public void finish() {
			tes.method_1350();
			stage.end();
		}

	}

	public static Vec4f getColor() {
		GlStateManager.class_1020 c = GlStateManager.COLOR;
		return new Vec4f(val(c.field_5057), val(c.field_5056), val(c.field_5055), val(c.field_5054));
	}

	private static float val(float color) {
		return color == -1 ? 1 : color;
	}

	@Override
	public class_2960 getDynTexture() {
		return DynTexture.getBoundLoc();
	}
}

package com.tom.cpm.client;

import java.util.function.Function;
import net.minecraft.class_437;
import com.mojang.blaze3d.platform.GlStateManager;

import com.tom.cpl.gui.Frame;
import com.tom.cpl.gui.IGui;

public class GuiImpl extends GuiBase {

	public GuiImpl(Function<IGui, Frame> creator, class_437 parent) {
		super(creator, parent);
	}

	@Override
	public void render(int mouseX, int mouseY, float partialTicks) {
		super.render(mouseX, mouseY, partialTicks);
		if(minecraft.field_1724 != null && gui.enableChat()) {
			GlStateManager.pushMatrix();
			GlStateManager.translated(0.0D, minecraft.field_1704.method_4502() - 48, 800);
			minecraft.field_1705.method_1743().method_1805(minecraft.field_1705.method_1738());
			GlStateManager.popMatrix();
		}
	}
}

package com.tom.cpm.client;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_2540;
import net.minecraft.class_2658;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import net.minecraft.class_339;
import io.netty.channel.Channel;

public class Platform {
	public static final class_2960 WHITE = new class_2960("cpm:textures/white.png");
	public static float lastBrightnessX, lastBrightnessY;

	public static void initPlayerProfile() {
		if(FabricLoader.getInstance().isModLoaded("firstperson")) {
			try {
				MethodHandle h = MethodHandles.lookup().unreflectGetter(Class.forName("dev.tr7zw.firstperson.FirstPersonModelCore").getDeclaredField("isRenderingPlayer"));
				PlayerProfile.inFirstPerson = () -> {
					try {
						return (boolean) h.invoke();
					} catch (Throwable e) {
						PlayerProfile.inFirstPerson = () -> false;
						return false;
					}
				};
				PlayerProfile.inFirstPerson.getAsBoolean();
			} catch (Throwable e) {
			}
		}
	}

	public static boolean isSitting(class_1657 player) {
		return player.method_5765();
	}

	public static void setHeight(class_339 w, int h) {
		w.height = h;
	}

	public static Channel getChannel(class_2535 conn) {
		return conn.field_11651;
	}

	public static class_2960 getName(class_2658 p) {
		return p.method_11456();
	}

	public static class_2960 getName(class_2817 p) {
		return p.field_12830;
	}

	public static class_2540 getData(class_2658 p) {
		return p.method_11458();
	}

	public static class_2540 getData(class_2817 p) {
		return p.field_12832;
	}

	public static float lastBrightnessX() {
		return lastBrightnessX;
	}

	public static float lastBrightnessY() {
		return lastBrightnessY;
	}
}

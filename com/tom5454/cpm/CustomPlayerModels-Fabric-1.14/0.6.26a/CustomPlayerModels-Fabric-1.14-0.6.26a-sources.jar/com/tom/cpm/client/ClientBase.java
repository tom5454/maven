package com.tom.cpm.client;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.mojang.blaze3d.platform.GlStateManager;

import com.tom.cpl.text.FormatText;
import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.common.PlayerAnimUpdater;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.model.RenderManager;
import com.tom.cpm.shared.model.TextureSheetType;
import com.tom.cpm.shared.network.NetHandler;

import io.netty.buffer.Unpooled;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3879;
import net.minecraft.class_563;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_634;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_898;

public class ClientBase {
	public static final class_2960 DEFAULT_CAPE = new class_2960("cpm:textures/template/cape.png");
	public static MinecraftObject mc;
	public class_310 minecraft;
	public RenderManager<GameProfile, class_1657, class_3879, Void> manager;
	public NetHandler<class_2960, class_1657, class_634> netHandler;

	public void init0() {
		minecraft = class_310.method_1551();
		mc = new MinecraftObject(minecraft);
	}

	public void init1() {
		manager = new RenderManager<>(mc.getPlayerRenderManager(), mc.getDefinitionLoader(), PlayerProfile::getPlayerProfile);
		manager.setGPGetters(GameProfile::getProperties, Property::getValue);
		netHandler = new NetHandler<>(class_2960::new);
		netHandler.setExecutor(() -> minecraft);
		netHandler.setSendPacketClient(d -> new class_2540(Unpooled.wrappedBuffer(d)), (c, rl, pb) -> c.method_2883(new class_2817(rl, pb)));
		netHandler.setPlayerToLoader(class_1657::method_7334);
		netHandler.setGetPlayerById(id -> {
			class_1297 ent = class_310.method_1551().field_1687.method_8469(id);
			if(ent instanceof class_1657) {
				return (class_1657) ent;
			}
			return null;
		});
		netHandler.setGetClient(() -> minecraft.field_1724);
		netHandler.setGetNet(c -> ((class_746)c).field_3944);
		netHandler.setDisplayText(f -> minecraft.field_1724.method_7353(f.remap(), false));
		netHandler.setGetPlayerAnimGetters(new PlayerAnimUpdater());
	}

	public static void apiInit() {
		CustomPlayerModels.api.buildClient().voicePlayer(class_1657.class, class_1657::method_5667).
		renderApi(class_3879.class, GameProfile.class).
		localModelApi(GameProfile::new).init();
	}

	public void playerRenderPre(class_1657 player, class_591 model) {
		manager.bindPlayer(player, null, model);
		manager.bindSkin(model, TextureSheetType.SKIN);
	}

	public void playerRenderPost(class_591 model) {
		manager.unbindFlush(model);
	}

	public void renderHand(class_591 model) {
		manager.bindHand(class_310.method_1551().field_1724, null, model);
		manager.bindSkin(model, TextureSheetType.SKIN);
	}

	public void renderHandPost(class_572 model) {
		manager.unbindFlush(model);
	}

	public void renderSkull(class_3879 skullModel, GameProfile profile) {
		manager.bindSkull(profile, null, skullModel);
		manager.bindSkin(skullModel, TextureSheetType.SKIN);
	}

	public void renderSkullPost(class_3879 model) {
		manager.unbindFlush(model);
	}

	public void renderElytra(class_572<class_1309> player, class_563<class_1309> model) {
		manager.bindElytra(player, model);
		manager.bindSkin(model, TextureSheetType.ELYTRA);
	}

	public void renderArmor(class_572<class_1309> modelArmor, class_572<class_1309> modelLeggings,
			class_572<class_1309> player) {
		manager.bindArmor(player, modelArmor, 1);
		manager.bindArmor(player, modelLeggings, 2);
		manager.bindSkin(modelArmor, TextureSheetType.ARMOR1);
		manager.bindSkin(modelLeggings, TextureSheetType.ARMOR2);
	}

	public void updateJump() {
		if(minecraft.field_1724.field_5952 && minecraft.field_1724.field_3913.field_3904) {
			manager.jump(minecraft.field_1724);
		}
	}

	//Copy from CapeLayer
	public static void renderCape(class_742 playerIn, float partialTicks, class_591<class_742> model,
			ModelDefinition modelDefinition) {
		GlStateManager.pushMatrix();

		float f1, f2, f3;

		if(playerIn != null) {
			double d0 = class_3532.method_16436(partialTicks, playerIn.field_7524,
					playerIn.field_7500)
					- class_3532.method_16436(partialTicks, playerIn.field_6014, playerIn.field_5987);
			double d1 = class_3532.method_16436(partialTicks, playerIn.field_7502,
					playerIn.field_7521)
					- class_3532.method_16436(partialTicks, playerIn.field_6036, playerIn.field_6010);
			double d2 = class_3532.method_16436(partialTicks, playerIn.field_7522,
					playerIn.field_7499)
					- class_3532.method_16436(partialTicks, playerIn.field_5969, playerIn.field_6035);
			float f = playerIn.field_6220
					+ (playerIn.field_6283 - playerIn.field_6220);
			double d3 = class_3532.method_15374(f * 0.017453292F);
			double d4 = (-class_3532.method_15362(f * 0.017453292F));
			f1 = (float) d1 * 10.0F;
			f1 = class_3532.method_15363(f1, -6.0F, 32.0F);
			f2 = (float) (d0 * d3 + d2 * d4) * 100.0F;
			f2 = class_3532.method_15363(f2, 0.0F, 150.0F);
			f3 = (float) (d0 * d4 - d2 * d3) * 100.0F;
			f3 = class_3532.method_15363(f3, -20.0F, 20.0F);
			if (f2 < 0.0F) {
				f2 = 0.0F;
			}

			float f4 = class_3532.method_16439(partialTicks, playerIn.field_7505, playerIn.field_7483);
			f1 += class_3532.method_15374(class_3532.method_16439(partialTicks, playerIn.field_6039,
					playerIn.field_5973) * 6.0F) * 32.0F * f4;
			if (playerIn.method_20231()) {
				f1 += 25.0F;
			}
			if (playerIn.method_6118(class_1304.field_6174).method_7960()) {
				if (playerIn.method_20231()) {
					model.field_3485.field_3655 = 1.4F + 0.125F * 3;
					model.field_3485.field_3656 = 1.85F + 1 - 0.125F * 4;
				} else {
					model.field_3485.field_3655 = 0.0F + 0.125F * 16f;
					model.field_3485.field_3656 = 0.0F;
				}
			} else if (playerIn.method_20231()) {
				model.field_3485.field_3655 = 0.3F + 0.125F * 16f;
				model.field_3485.field_3656 = 0.8F + 0.3f;
			} else {
				model.field_3485.field_3655 = -1.1F + 0.125F * 32f;
				model.field_3485.field_3656 = -0.85F + 1;
			}
		} else {
			f1 = 0;
			f2 = 0;
			f3 = 0;
		}
		model.field_3485.field_3654 = (float) -Math.toRadians(6.0F + f2 / 2.0F + f1);
		model.field_3485.field_3675 = (float) Math.toRadians(180.0F - f3 / 2.0F);
		model.field_3485.field_3674 = (float) Math.toRadians(f3 / 2.0F);
		mc.getPlayerRenderManager().setModelPose(model);
		model.field_3485.field_3654 = 0;
		model.field_3485.field_3675 = 0;
		model.field_3485.field_3674 = 0;
		model.method_2823(0.0625F);
		GlStateManager.popMatrix();
	}

	public static interface PlayerNameTagRenderer<E extends class_1297> {
		void cpm$renderNameTag(E entityIn, String displayNameIn, double x, double y, double z, double i);
		class_898 cpm$entityRenderDispatcher();
	}

	public <E extends class_1297> void renderNameTag(PlayerNameTagRenderer<E> r, E entityIn, GameProfile gprofile, String unique, double x, double y, double z, double d0) {
		if (d0 < 32*32) {
			FormatText st = manager.getStatus(gprofile, unique);
			if(st != null) {
				GlStateManager.pushMatrix();
				GlStateManager.translatef(0.0F, 1.3F, 0.0F);
				GlStateManager.scalef(0.5f, 0.5f, 0.5f);
				r.cpm$renderNameTag(entityIn, st.<class_2561>remap().method_10863(), x, y, z, d0);
				GlStateManager.popMatrix();
			}
		}
	}
}

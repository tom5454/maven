package com.tom.cpm.mixin;

import java.util.Map;
import net.minecraft.class_2350;
import net.minecraft.class_2484;
import net.minecraft.class_2631;
import net.minecraft.class_607;
import net.minecraft.class_827;
import net.minecraft.class_836;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.mojang.authlib.GameProfile;

import com.tom.cpm.client.CustomPlayerModelsClient;

@Mixin(class_836.class)
public abstract class SkullTileEntityRendererMixin extends class_827<class_2631> {

	@Shadow private static @Final Map<class_2484.class_2485, class_607> MODEL_BY_TYPE;

	@Inject(at = @At("HEAD"),
			method = "renderSkull(FFFLnet/minecraft/util/Direction;FLnet/minecraft/block/SkullBlock$ISkullType;"
					+ "Lcom/mojang/authlib/GameProfile;IF)V")
	private void onRenderPre(float f1, float f2, float f3, class_2350 directionIn, float p_228879_1_, class_2484.class_2485 skullType, GameProfile gameProfileIn, int i, float animationProgress, CallbackInfo cbi) {
		if (skullType == class_2484.class_2486.field_11510 && gameProfileIn != null) {
			class_607 model = MODEL_BY_TYPE.get(skullType);
			CustomPlayerModelsClient.INSTANCE.renderSkull(model, gameProfileIn);
		}
	}

	@Inject(at = @At("RETURN"),
			method = "renderSkull(FFFLnet/minecraft/util/Direction;FLnet/minecraft/block/SkullBlock$ISkullType;"
					+ "Lcom/mojang/authlib/GameProfile;IF)V")
	private void onRenderPost(float f1, float f2, float f3, class_2350 directionIn, float p_228879_1_, class_2484.class_2485 skullType, GameProfile gameProfileIn, int i, float animationProgress, CallbackInfo cbi) {
		if (skullType == class_2484.class_2486.field_11510 && gameProfileIn != null) {
			class_607 model = MODEL_BY_TYPE.get(skullType);
			CustomPlayerModelsClient.INSTANCE.renderSkullPost(model);
		}
	}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.IBipedModel;
import com.tom.cpm.client.PlayerRenderManager;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_572;
import net.minecraft.class_970;

@Mixin(class_970.class)
public abstract class ArmorLayerMixin extends class_3887<class_1309, class_572<class_1309>> {

	public ArmorLayerMixin(class_3883<class_1309, class_572<class_1309>> p_i50926_1_) {
		super(p_i50926_1_);
	}

	private @Final @Shadow class_572<class_1309> innerModel;
	private @Final @Shadow class_572<class_1309> outerModel;

	@Inject(at = @At("HEAD"),
			method = "render(Lnet/minecraft/entity/LivingEntity;FFFFFFF)V")
	public void preRender(class_1309 entitylivingbaseIn, float f1, float f2, float f3, float f4, float f5, float f6, float f7, CallbackInfo cbi) {
		if(method_17165() instanceof class_572) {
			CustomPlayerModelsClient.INSTANCE.renderArmor(outerModel, innerModel, method_17165());
		}
	}

	@Inject(at = @At("RETURN"),
			method = "render(Lnet/minecraft/entity/LivingEntity;FFFFFFF)V")
	public void postRender(class_1309 entitylivingbaseIn, float f1, float f2, float f3, float f4, float f5, float f6, float f7, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbind(outerModel);
		CustomPlayerModelsClient.INSTANCE.manager.unbind(innerModel);
	}

	@Inject(at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/entity/layers/ArmorLayer;usesInnerModel(Lnet/minecraft/inventory/EquipmentSlotType;)Z"),
			method = "renderArmorPiece(Lnet/minecraft/entity/LivingEntity;FFFFFFFLnet/minecraft/inventory/EquipmentSlotType;)V",
			locals = LocalCapture.CAPTURE_FAILHARD)
	private void setupModel(class_1309 entityLivingBaseIn, float f1, float f2, float f3, float f4, float f5, float f6, float f7, class_1304 slotIn, CallbackInfo cbi, class_1799 itemstack, class_1738 armoritem, class_572<class_1309> armor) {
		class_572<class_1309> model = method_17165();
		((IBipedModel) armor).cpm$noSetup();
		PlayerRenderManager m = CustomPlayerModelsClient.mc.getPlayerRenderManager();
		m.copyModelForArmor(model.field_3391, armor.field_3391);
		m.copyModelForArmor(model.field_3398, armor.field_3398);
		m.copyModelForArmor(model.field_3390, armor.field_3390);
		m.copyModelForArmor(model.field_3397, armor.field_3397);
		m.copyModelForArmor(model.field_3401, armor.field_3401);
		m.copyModelForArmor(model.field_3392, armor.field_3392);
	}
}

package com.tom.cpm.client;

import java.util.function.Supplier;
import net.minecraft.class_1309;
import net.minecraft.class_3879;
import net.minecraft.class_563;
import net.minecraft.class_569;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_630;
import com.mojang.blaze3d.platform.GlStateManager;

import com.tom.cpl.math.MatrixStack;
import com.tom.cpl.math.Vec4f;
import com.tom.cpl.render.VBuffers;
import com.tom.cpm.shared.model.PlayerModelParts;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.render.ModelRenderManager;
import com.tom.cpm.shared.model.render.VanillaModelPart;
import com.tom.cpm.shared.retro.RedirectHolderRetro;

public class PlayerRenderManager extends ModelRenderManager<Void, Void, class_630, class_3879> {
	public static final float scale = 0.0625F;

	public PlayerRenderManager() {
		setFactory(new RedirectHolderFactory<Void, Void, class_630>() {

			@SuppressWarnings("unchecked")
			@Override
			public <M> RedirectHolder<?, Void, Void, class_630> create(
					M model, String arg) {
				if("api".equals(arg) && model instanceof class_572) {
					return new RedirectHolderApi(PlayerRenderManager.this, (class_572<class_1309>) model);
				} else if(model instanceof class_591) {
					return new RedirectHolderPlayer(PlayerRenderManager.this, (class_591<class_1309>) model);
				} else if(model instanceof class_569) {
					return new RedirectHolderSkull(PlayerRenderManager.this, (class_569) model);
				} else if(model instanceof class_563) {
					return new RedirectHolderElytra(PlayerRenderManager.this, (class_563<class_1309>) model);
				} else if(model instanceof class_572 && "armor1".equals(arg)) {
					return new RedirectHolderArmor1(PlayerRenderManager.this, (class_572<class_1309>) model);
				} else if(model instanceof class_572 && "armor2".equals(arg)) {
					return new RedirectHolderArmor2(PlayerRenderManager.this, (class_572<class_1309>) model);
				}
				return null;
			}
		});
		setRedirectFactory(new RedirectRendererFactory<class_3879, Void, class_630>() {

			@Override
			public RedirectRenderer<class_630> create(class_3879 model,
					RedirectHolder<class_3879, ?, Void, class_630> access,
					Supplier<class_630> modelPart, VanillaModelPart part) {
				return new RedirectModelRenderer((RDH) access, modelPart, part);
			}
		});
		setVis(m -> m.field_3665, (m, v) -> m.field_3665 = v);
		setModelPosGetters(m -> m.field_3657, m -> m.field_3656, m -> m.field_3655);
		setModelRotGetters(m -> m.field_3654, m -> m.field_3675, m -> m.field_3674);
		setModelSetters((m, x, y, z) -> {
			m.field_3657 = x;
			m.field_3656 = y;
			m.field_3655 = z;
		}, (m, x, y, z) -> {
			m.field_3654 = x;
			m.field_3675 = y;
			m.field_3674 = z;
		});
		setRenderPart(new class_630(new class_3879()));
	}

	public static abstract class RDH extends RedirectHolderRetro<class_3879, class_630> {

		public RDH(
				ModelRenderManager<Void, Void, class_630, class_3879> mngr,
				class_3879 model) {
			super(mngr, model);
		}
	}

	private static class RedirectHolderPlayer extends RDH {
		private RedirectRenderer<class_630> head;

		public RedirectHolderPlayer(PlayerRenderManager mngr, class_591<class_1309> model) {
			super(mngr, model);
			head = registerHead(new Field<>(    () -> model.field_3398    , v -> model.field_3398     = v, PlayerModelParts.HEAD));
			register(new Field<>(() -> model.field_3391    , v -> model.field_3391     = v, PlayerModelParts.BODY));
			register(new Field<>(() -> model.field_3401, v -> model.field_3401 = v, PlayerModelParts.RIGHT_ARM));
			register(new Field<>(() -> model.field_3390 , v -> model.field_3390  = v, PlayerModelParts.LEFT_ARM));
			register(new Field<>(() -> model.field_3392, v -> model.field_3392 = v, PlayerModelParts.RIGHT_LEG));
			register(new Field<>(() -> model.field_3397 , v -> model.field_3397  = v, PlayerModelParts.LEFT_LEG));

			register(new Field<>(() -> model.field_3394        , v -> model.field_3394         = v, null)).setCopyFrom(head);
			register(new Field<>(() -> model.field_3484 , v -> model.field_3484  = v, null));
			register(new Field<>(() -> model.field_3486, v -> model.field_3486 = v, null));
			register(new Field<>(() -> model.field_3482  , v -> model.field_3482   = v, null));
			register(new Field<>(() -> model.field_3479 , v -> model.field_3479  = v, null));
			register(new Field<>(() -> model.field_3483     , v -> model.field_3483      = v, null));

			register(new Field<>(() -> model.field_3485, v -> model.field_3485 = v, RootModelType.CAPE));
		}
	}

	private static class RedirectHolderApi extends RDH {
		private RedirectRenderer<class_630> head;

		public RedirectHolderApi(PlayerRenderManager mngr, class_572<class_1309> model) {
			super(mngr, model);
			head = registerHead(new Field<>(    () -> model.field_3398    , v -> model.field_3398     = v, PlayerModelParts.HEAD));
			register(new Field<>(() -> model.field_3391    , v -> model.field_3391     = v, PlayerModelParts.BODY));
			register(new Field<>(() -> model.field_3401, v -> model.field_3401 = v, PlayerModelParts.RIGHT_ARM));
			register(new Field<>(() -> model.field_3390 , v -> model.field_3390  = v, PlayerModelParts.LEFT_ARM));
			register(new Field<>(() -> model.field_3392, v -> model.field_3392 = v, PlayerModelParts.RIGHT_LEG));
			register(new Field<>(() -> model.field_3397 , v -> model.field_3397  = v, PlayerModelParts.LEFT_LEG));

			register(new Field<>(() -> model.field_3394        , v -> model.field_3394         = v, null)).setCopyFrom(head);
			if(model instanceof class_591) {
				class_591<class_1309> pm = (class_591<class_1309>) model;
				register(new Field<>(() -> pm.field_3484 , v -> pm.field_3484  = v, null));
				register(new Field<>(() -> pm.field_3486, v -> pm.field_3486 = v, null));
				register(new Field<>(() -> pm.field_3482  , v -> pm.field_3482   = v, null));
				register(new Field<>(() -> pm.field_3479 , v -> pm.field_3479  = v, null));
				register(new Field<>(() -> pm.field_3483     , v -> pm.field_3483      = v, null));

				register(new Field<>(() -> pm.field_3485, v -> pm.field_3485 = v, RootModelType.CAPE));
			}
		}

		@Override
		protected boolean isDirectMode() {
			return true;
		}
	}

	private static class RedirectHolderSkull extends RDH {

		public RedirectHolderSkull(PlayerRenderManager mngr, class_569 model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_3564, v -> model.field_3564 = v, PlayerModelParts.HEAD));
			register(new Field<>(() -> model.field_3377 , v -> model.field_3377  = v, null));
		}

	}

	private static class RedirectHolderElytra extends RDH {

		public RedirectHolderElytra(PlayerRenderManager mngr, class_563<class_1309> model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_3364, v -> model.field_3364 = v, RootModelType.ELYTRA_RIGHT));
			register(new Field<>(() -> model.field_3365,  v -> model.field_3365  = v, RootModelType.ELYTRA_LEFT));
		}

	}

	private static class RedirectHolderArmor1 extends RDH {

		public RedirectHolderArmor1(PlayerRenderManager mngr, class_572<class_1309> model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_3398,     v -> model.field_3398     = v, RootModelType.ARMOR_HELMET));
			register(new Field<>(() -> model.field_3391,     v -> model.field_3391     = v, RootModelType.ARMOR_BODY));
			register(new Field<>(() -> model.field_3401, v -> model.field_3401 = v, RootModelType.ARMOR_RIGHT_ARM));
			register(new Field<>(() -> model.field_3390,  v -> model.field_3390  = v, RootModelType.ARMOR_LEFT_ARM));
			register(new Field<>(() -> model.field_3392, v -> model.field_3392 = v, RootModelType.ARMOR_RIGHT_FOOT));
			register(new Field<>(() -> model.field_3397,  v -> model.field_3397  = v, RootModelType.ARMOR_LEFT_FOOT));

			register(new Field<>(() -> model.field_3394 , v -> model.field_3394  = v, null));
		}

	}

	private static class RedirectHolderArmor2 extends RDH {

		public RedirectHolderArmor2(PlayerRenderManager mngr, class_572<class_1309> model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_3391,     v -> model.field_3391     = v, RootModelType.ARMOR_LEGGINGS_BODY));
			register(new Field<>(() -> model.field_3392, v -> model.field_3392 = v, RootModelType.ARMOR_RIGHT_LEG));
			register(new Field<>(() -> model.field_3397,  v -> model.field_3397  = v, RootModelType.ARMOR_LEFT_LEG));
		}

	}

	public static class RedirectModelRenderer extends class_630 implements RedirectRenderer<class_630> {
		protected final RDH holder;
		protected final VanillaModelPart part;
		protected final Supplier<class_630> parentProvider;
		protected class_630 parent;
		protected VBuffers buffers;

		public RedirectModelRenderer(RDH holder, Supplier<class_630> parent, VanillaModelPart part) {
			super(holder.model);
			this.part = part;
			this.holder = holder;
			this.parentProvider = parent;
		}

		@Override
		public VBuffers getVBuffers() {
			return buffers;
		}

		@Override
		public class_630 swapIn() {
			if(parent != null)return this;
			parent = parentProvider.get();
			holder.copyModel(parent, this);
			return this;
		}

		@Override
		public class_630 swapOut() {
			if(parent == null)return parentProvider.get();
			class_630 p = parent;
			parent = null;
			return p;
		}

		@Override
		public RedirectHolder<?, ?, ?, class_630> getHolder() {
			return holder;
		}

		@Override
		public class_630 getParent() {
			return parent;
		}

		@Override
		public VanillaModelPart getPart() {
			return part;
		}

		@Override
		public Vec4f getColor() {
			return RetroGL.getColor();
		}

		@Override
		public void method_2847(float scale) {
			MatrixStack.Entry e = getPartTransform();
			if(e != null) {
				multiplyStacks(e);
			} else
				super.method_2847(scale);
		}

		@Override
		public void method_2846(float scale) {
			this.buffers = new VBuffers(RetroGL::buffer);
			render();
			buffers.finishAll();
		}

		@Override
		public void renderParent() {
			parent.method_2846(scale);
		}
	}


	public static void multiplyStacks(MatrixStack.Entry e) {
		e.getMatrix().multiplyNative(GlStateManager::multMatrix);
	}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import net.minecraft.class_1309;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_563;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_979;

@Mixin(class_979.class)
public abstract class ElytraLayerMixin extends class_3887<class_1309, class_583<class_1309>> {
	public ElytraLayerMixin(class_3883<class_1309, class_583<class_1309>> p_i50926_1_) {
		super(p_i50926_1_);
	}

	private @Shadow @Final class_563<class_1309> elytraModel;

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lcom/mojang/blaze3d/platform/GlStateManager;pushMatrix()V"),
			method = "render(Lnet/minecraft/entity/LivingEntity;FFFFFFF)V")
	public void preRender(class_1309 entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale, CallbackInfo cbi) {
		if(method_17165() instanceof class_572) {
			CustomPlayerModelsClient.INSTANCE.renderElytra((class_572<class_1309>) method_17165(), elytraModel);
		}
	}

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lcom/mojang/blaze3d/platform/GlStateManager;popMatrix()V"),
			method = "render(Lnet/minecraft/entity/LivingEntity;FFFFFFF)V")
	public void postRender(class_1309 entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbind(elytraModel);
	}
}

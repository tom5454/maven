package com.tom.cpm.client;

import java.util.function.BiConsumer;
import net.minecraft.class_1058;
import net.minecraft.class_11785;
import net.minecraft.class_1921;
import net.minecraft.class_3902;
import net.minecraft.class_4587;
import net.minecraft.class_591;
import net.minecraft.class_630;
import com.tom.cpl.render.RecordBuffer;
import com.tom.cpl.render.VBuffers.NativeRenderType;

public interface SelfRenderer {
	void submitSelf(RenderCollector collector);

	public static record RenderCollector(class_4587 pose, class_11785 collector, class_1921 defaultRt, int light, int overlay, int tint, int outline, class_1058 sprite, Object state) {

		public void submitVanilla(class_630 part) {
			collector.method_73490(new VanillaPartLayer(part, PlayerRenderManager.entity), part.method_32084(), pose, defaultRt, light, overlay, tint, sprite, outline, null);
		}

		public BiConsumer<NativeRenderType, RecordBuffer> recordBuffer() {
			return (rt, rb) -> {
				class_1921 nrt = rt.getNativeType();
				if (nrt == null)nrt = defaultRt;
				collector.method_73490(new CustomModelLayer(rb), class_3902.field_17274, pose, nrt, light, overlay, tint, sprite, outline, null);
			};
		}

		public void storeState(class_591 pm) {
			if (state instanceof PlayerRenderStateAccess prs)
				prs.cpm$storeState(pm);
		}
	}
}

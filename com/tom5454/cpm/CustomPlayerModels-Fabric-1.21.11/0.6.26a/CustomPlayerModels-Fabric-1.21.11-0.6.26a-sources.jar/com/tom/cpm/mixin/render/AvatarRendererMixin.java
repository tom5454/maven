package com.tom.cpm.mixin.render;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.mojang.authlib.GameProfile;
import com.tom.cpl.text.FormatText;
import com.tom.cpm.client.CPMOrderedSubmitNodeCollector.CPMSubmitNodeCollector;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.LivingRendererAccess;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.PlayerProfile;
import com.tom.cpm.client.PlayerRenderStateAccess;
import com.tom.cpm.shared.animation.AnimationEngine.AnimationMode;
import com.tom.cpm.shared.animation.AnimationState;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_11890;
import net.minecraft.class_11901;
import net.minecraft.class_11903;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;

@Mixin(class_1007.class)
public abstract class AvatarRendererMixin<AvatarlikeEntity extends class_11890 & class_11901>
extends class_922<AvatarlikeEntity, class_10055, class_591> implements LivingRendererAccess {
	private static @Unique final class_2960 CPM$EMPTY_TEX = class_2960.method_60654("cpm:textures/template/empty.png");

	public AvatarRendererMixin(class_5618 context, class_591 entityModel, float f) {
		super(context, entityModel, f);
	}

	@Inject(
			at = @At("RETURN"),
			method = {
					"getTextureLocation(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)Lnet/minecraft/resources/Identifier;"
			},
			cancellable = true)
	public void onGetEntityTexture(class_10055 entity, CallbackInfoReturnable<class_2960> cbi) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(method_4038(), new ModelTexture(cbi), TextureSheetType.SKIN);
	}

	@Inject(at = @At("HEAD"), method = "submitNameTag", cancellable = true)
	public void onSubmitNameTag(class_10055 avatarRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo cbi) {
		if(!Player.isEnableNames()) {
			cbi.cancel();
			return;
		}
		if (Player.isEnableLoadingInfo()) {
			PlayerRenderStateAccess sa = (PlayerRenderStateAccess) avatarRenderState;
			if (sa.cpm$getModelStatus() != null) {
				poseStack.method_22903();
				poseStack.method_22904(0.0D, 1.3F, 0.0D);
				poseStack.method_22905(0.5f, 0.5f, 0.5f);
				submitNodeCollector.method_73482(
						poseStack,
						avatarRenderState.field_53338,
						0,
						sa.cpm$getModelStatus(),
						!avatarRenderState.field_53334,
						avatarRenderState.field_61820,
						avatarRenderState.field_53332,
						cameraRenderState);
				poseStack.method_22909();
			}
		}
	}

	@Override
	public void cpm$onGetRenderType(class_10042 player, boolean pTranslucent, boolean pGlowing,
			CallbackInfoReturnable<class_1921> cbi) {
		if (CustomPlayerModelsClient.mc.getPlayerRenderManager().isBound(method_4038())) {
			boolean r = CustomPlayerModelsClient.mc.getPlayerRenderManager().getHolderSafe(method_4038(), null, h -> h.setInvisState(), false, false);
			if(pTranslucent)return;
			if(!pGlowing && !r)return;
			class_2960 tex = method_3885((class_10055) player);
			CustomPlayerModelsClient.mc.getPlayerRenderManager().getHolderSafe(method_4038(), null, h -> h.setInvis(pGlowing), false);
			cbi.setReturnValue(
					pGlowing ?
							class_12249.method_76018(tex) :
								class_12249.method_75990(CPM$EMPTY_TEX)
					);
		}
	}

	@Inject(at = @At("RETURN"), method = "extractRenderState")
	public void onExtractRenderState(final class_11890 abstractClientPlayer, final class_10055 playerRenderState, final float f, CallbackInfo cbi) {
		PlayerRenderStateAccess sa = (PlayerRenderStateAccess) playerRenderState;
		GameProfile profile = PlayerProfile.getPlayerProfile(abstractClientPlayer);
		String unique;
		if (abstractClientPlayer instanceof class_742) {
			unique = ModelDefinitionLoader.PLAYER_UNIQUE;
		} else if(abstractClientPlayer instanceof class_11903) {
			unique = "man:" + abstractClientPlayer.method_5845();
		} else {
			return;
		}
		FormatText st = CustomPlayerModelsClient.INSTANCE.manager.getStatus(profile, unique);
		sa.cpm$setModelStatus(st != null ? st.remap() : null);
		AnimationState state = new AnimationState(AnimationMode.PLAYER);
		var pl = CustomPlayerModelsClient.INSTANCE.manager.loadPlayerState(profile, abstractClientPlayer, unique, state);
		sa.cpm$setPlayer(pl);
		sa.cpm$setAnimationState(state);
		if (pl != null) {
			((PlayerProfile) pl).updateFromState(state, playerRenderState);
		}
	}

	@Inject(at = @At("HEAD"), method = "renderRightHand")
	public void onRenderRightArmPre(final class_4587 poseStack, final class_11659 vertexConsumers, final int i, final class_2960 Identifier, final boolean sleeve, CallbackInfo cbi, @Local LocalRef<class_11659> snc) {
		CPMSubmitNodeCollector.injectSNC(snc);
		CustomPlayerModelsClient.INSTANCE.renderHand(method_4038());
	}

	@Inject(at = @At("HEAD"), method = "renderLeftHand")
	public void onRenderLeftArmPre(final class_4587 poseStack, final class_11659 vertexConsumers, final int i, final class_2960 Identifier, final boolean sleeve, CallbackInfo cbi, @Local LocalRef<class_11659> snc) {
		CPMSubmitNodeCollector.injectSNC(snc);
		CustomPlayerModelsClient.INSTANCE.renderHand(method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderRightHand")
	public void onRenderRightArmPost(final class_4587 poseStack, final class_11659 vertexConsumers, final int i, final class_2960 Identifier, final boolean sleeve, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderLeftHand")
	public void onRenderLeftArmPost(final class_4587 poseStack, final class_11659 vertexConsumers, final int i, final class_2960 Identifier, final boolean sleeve, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(method_4038());
	}

	@ModifyArg(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/rendertype/RenderTypes;entityTranslucent("
					+ "Lnet/minecraft/resources/Identifier;)Lnet/minecraft/client/renderer/rendertype/RenderType;"
			), method = "renderHand")
	public class_2960 getSkinTex(class_2960 arg) {
		ModelTexture tex = new ModelTexture(arg);
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(method_4038(), tex, TextureSheetType.SKIN);
		return tex.getTexture();
	}
}

package com.tom.cpm.client;

import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_3532;
import net.minecraft.class_4588;
import net.minecraft.class_8030;

public class GuiRenderStates {
	public record Colored4RectangleRenderState(
			RenderPipeline pipeline, class_11231 textureSetup, Matrix3x2f pose,
			int x0, int y0, int x1, int y1,
			class_8030 bounds,
			int topLeft, int topRight, int bottomLeft, int bottomRight, @Nullable class_8030 scissorArea
			) implements class_11244 {

		public Colored4RectangleRenderState(
				RenderPipeline pipeline, class_11231 textureSetup, Matrix3x2f pose,
				int x0, int y0,int x1, int y1,
				int topLeft, int topRight, int bottomLeft, int bottomRight, @Nullable class_8030 scissorArea
				) {
			this(pipeline, textureSetup, pose, x0, y0, x1, y1,
					getBounds(x0, y0, x1, y1, pose, scissorArea),
					topLeft, topRight, bottomLeft, bottomRight, scissorArea);
		}

		@Override
		public void method_70917(class_4588 vertexConsumer) {
			vertexConsumer.method_70815(this.pose(), this.x0(), this.y0()).method_39415(this.topLeft());
			vertexConsumer.method_70815(this.pose(), this.x0(), this.y1()).method_39415(this.bottomLeft());
			vertexConsumer.method_70815(this.pose(), this.x1(), this.y1()).method_39415(this.bottomRight());
			vertexConsumer.method_70815(this.pose(), this.x1(), this.y0()).method_39415(this.topRight());
		}
	}

	public record ColoredRectangleFRenderState(
			RenderPipeline pipeline, class_11231 textureSetup, Matrix3x2f pose, float x0, float y0, float x1, float y1, class_8030 bounds,
			int color, @Nullable class_8030 scissorArea
			) implements class_11244 {

		public ColoredRectangleFRenderState(RenderPipeline pipeline, class_11231 textureSetup, Matrix3x2f pose,
				float x0, float y0, float x1, float y1,
				int color, @Nullable class_8030 scissorArea) {
			this(pipeline, textureSetup, pose, x0, y0, x1, y1,
					getBounds(class_3532.method_15375(x0), class_3532.method_15375(y0), class_3532.method_15386(x1), class_3532.method_15386(y1), pose, scissorArea),
					color, scissorArea);
		}

		@Override
		public void method_70917(class_4588 vertexConsumer) {
			vertexConsumer.method_70815(this.pose(), this.x0(), this.y0()).method_39415(this.color());
			vertexConsumer.method_70815(this.pose(), this.x0(), this.y1()).method_39415(this.color());
			vertexConsumer.method_70815(this.pose(), this.x1(), this.y1()).method_39415(this.color());
			vertexConsumer.method_70815(this.pose(), this.x1(), this.y0()).method_39415(this.color());
		}
	}

	public static class_8030 getBounds(int x0, int y0, int x1, int y1, Matrix3x2f matrix3x2f, @Nullable class_8030 scissor) {
		class_8030 screenRectangle2 = new class_8030(x0, y0, x1 - x0, y1 - y0).method_71523(matrix3x2f);
		return scissor != null ? scissor.method_49701(screenRectangle2) : screenRectangle2;
	}
}

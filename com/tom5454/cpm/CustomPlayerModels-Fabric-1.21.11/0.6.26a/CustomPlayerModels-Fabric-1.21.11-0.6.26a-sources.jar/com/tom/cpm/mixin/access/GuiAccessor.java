package com.tom.cpm.mixin.access;

import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_329.class)
public interface GuiAccessor {

	@Invoker
	void callRenderChat(class_332 p_329202_, class_9779 p_328014_);
}

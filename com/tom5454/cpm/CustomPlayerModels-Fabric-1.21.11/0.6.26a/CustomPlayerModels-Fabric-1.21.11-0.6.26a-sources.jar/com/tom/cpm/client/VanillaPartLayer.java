package com.tom.cpm.client;

import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_5603;
import net.minecraft.class_630;

public class VanillaPartLayer extends class_3879<class_5603> {

	public VanillaPartLayer(class_630 p_368583_, Function<class_2960, class_1921> p_103110_) {
		super(p_368583_, p_103110_);
	}

	@Override
	public void setupAnim(class_5603 p_435637_) {
		super.method_2819(p_435637_);
		method_63512().method_32085(p_435637_);
	}
}

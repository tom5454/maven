package com.tom.cpm.client;

import java.util.Collections;
import net.minecraft.class_3879;
import net.minecraft.class_3902;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;
import com.tom.cpl.render.RecordBuffer;

public class CustomModelLayer extends class_3879<class_3902> {

	public CustomModelLayer(RecordBuffer buffer) {
		super(new ModelLayerPart(buffer), null);
	}

	private static class ModelLayerPart extends class_630 {
		private RecordBuffer buffer;

		public ModelLayerPart(RecordBuffer buffer) {
			super(Collections.emptyList(), Collections.emptyMap());
			this.buffer = buffer;
		}

		@Override
		public void method_22699(class_4587 p, class_4588 c, int light, int overlay, int tint) {
			buffer.replay(new VBuffer(c, light, overlay, 0f, p));
		}
	}
}

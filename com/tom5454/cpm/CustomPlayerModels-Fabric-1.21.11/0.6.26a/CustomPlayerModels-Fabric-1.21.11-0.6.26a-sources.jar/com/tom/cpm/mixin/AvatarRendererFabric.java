package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.tom.cpm.client.CPMOrderedSubmitNodeCollector.CPMSubmitNodeCollector;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.PlayerRenderStateAccess;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_11890;
import net.minecraft.class_11901;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_591;
import net.minecraft.class_922;

@Mixin(class_1007.class)
public abstract class AvatarRendererFabric<AvatarlikeEntity extends class_11890 & class_11901>
extends class_922<AvatarlikeEntity, class_10055, class_591>
implements com.tom.cpm.client.EntityRenderer<class_10055> {

	public AvatarRendererFabric(class_5618 context, class_591 entityModel, float f) {
		super(context, entityModel, f);
	}

	@Override
	public void cpm$onSubmitPre(class_10055 livingEntityRenderState, class_4587 poseStack,
			class_11659 submitNodeCollector, class_12075 cameraRenderState,
			LocalRef<class_11659> snc) {
		snc.set(new CPMSubmitNodeCollector(submitNodeCollector));
		CustomPlayerModelsClient.INSTANCE.playerRenderPre((PlayerRenderStateAccess) livingEntityRenderState, field_4737, livingEntityRenderState);
	}

	@Override
	public void cpm$onSubmitPost(class_10055 livingEntityRenderState, class_4587 poseStack,
			class_11659 submitNodeCollector, class_12075 cameraRenderState) {
		CustomPlayerModelsClient.INSTANCE.playerRenderPost(field_4737);
	}
}

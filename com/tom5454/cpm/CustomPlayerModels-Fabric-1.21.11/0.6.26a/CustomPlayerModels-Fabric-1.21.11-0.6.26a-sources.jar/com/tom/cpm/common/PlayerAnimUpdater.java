package com.tom.cpm.common;

import java.util.function.BiConsumer;
import net.minecraft.class_11890;
import net.minecraft.class_1657;
import com.tom.cpm.shared.animation.ServerAnimationState;

public class PlayerAnimUpdater implements BiConsumer<class_11890, ServerAnimationState> {

	@Override
	public void accept(class_11890 t, ServerAnimationState u) {
		u.updated = true;
		u.falling = (float) t.field_6017;
		u.health = t.method_6032() / t.method_6063();
		u.air = Math.max(t.method_5669() / (float) t.method_5748(), 0);
		if (t instanceof class_1657 p) {
			u.creativeFlying = p.method_31549().field_7479;
			u.hunger = p.method_7344().method_7586() / 20f;
			u.inMenu = p.field_7512 != p.field_7498;
		} else {
			u.creativeFlying = false;
			u.hunger = 1f;
			u.inMenu = false;
		}
	}

}

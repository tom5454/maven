package com.tom.cpm.mixin.render;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.tom.cpm.client.CPMOrderedSubmitNodeCollector.CPMSubmitNodeCollector;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_11533;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11786;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_4587;
import net.minecraft.class_5598;
import net.minecraft.class_811;

@Mixin(class_11533.class)
public class PlayerHeadSpecialRendererMixin {
	private @Shadow @Final class_5598 modelBase;

	@WrapOperation(at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/blockentity/SkullBlockRenderer;submitSkull("
					+ "Lnet/minecraft/core/Direction;FFLcom/mojang/blaze3d/vertex/PoseStack;"
					+ "Lnet/minecraft/client/renderer/SubmitNodeCollector;I"
					+ "Lnet/minecraft/client/model/object/skull/SkullModelBase;"
					+ "Lnet/minecraft/client/renderer/rendertype/RenderType;I"
					+ "Lnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V"), method = "submit")
	public void submitPre(
			@Nullable class_2350 p1,
			float p2,
			float p3,
			class_4587 p4,
			class_11659 collector,
			int p6,
			class_5598 p7,
			class_1921 renderType,
			int p9,
			@Nullable class_11683.class_11792 p10,
			Operation<Void> op,
			@Local class_11786.class_11787 info
			) {
		if (info != null) {
			if (!(collector instanceof CPMSubmitNodeCollector))
				collector = new CPMSubmitNodeCollector(collector);
			CustomPlayerModelsClient.INSTANCE.manager.bindSkull(info.method_73502(), null, modelBase);
			ModelTexture mt = new ModelTexture(info.method_73503().comp_1626().comp_3627());
			CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(modelBase, mt, TextureSheetType.SKIN);
			renderType = mt.getRenderType();
		}
		op.call(p1, p2, p3, p4, collector, p6, p7, renderType, p9, p10);
	}

	@Inject(at = @At("RETURN"), method = "submit")
	public void submitPost(
			@Nullable class_11786.class_11787 p_451691_,
			class_811 p_439036_,
			class_4587 p_439012_,
			class_11659 p_439704_,
			int p_439598_,
			int p_440685_,
			boolean p_439388_,
			int p_451687_,
			CallbackInfo cbi
			) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().unbindModel(modelBase);
	}
}

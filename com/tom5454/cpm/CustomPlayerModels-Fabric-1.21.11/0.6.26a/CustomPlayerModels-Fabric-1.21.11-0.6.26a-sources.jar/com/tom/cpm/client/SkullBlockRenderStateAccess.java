package com.tom.cpm.client;

import com.tom.cpm.shared.config.Player;
import net.minecraft.class_11890;
import net.minecraft.class_8685;

public interface SkullBlockRenderStateAccess {
	void cpm$setPlayer(Player<class_11890> player);
	Player<class_11890> cpm$getPlayer();
	void cpm$setSkin(class_8685 tex);
	class_8685 cpm$getSkin();
}

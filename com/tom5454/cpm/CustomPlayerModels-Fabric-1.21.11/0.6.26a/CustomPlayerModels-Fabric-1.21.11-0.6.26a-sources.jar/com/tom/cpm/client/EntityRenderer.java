package com.tom.cpm.client;

import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;

public interface EntityRenderer<S extends class_10042> {
	default void cpm$onSubmitPre(S livingEntityRenderState, class_4587 poseStack,
			class_11659 submitNodeCollector, class_12075 cameraRenderState,
			LocalRef<class_11659> snc) {}
	default void cpm$onSubmitPost(S livingEntityRenderState, class_4587 poseStack,
			class_11659 submitNodeCollector, class_12075 cameraRenderState) {}
}

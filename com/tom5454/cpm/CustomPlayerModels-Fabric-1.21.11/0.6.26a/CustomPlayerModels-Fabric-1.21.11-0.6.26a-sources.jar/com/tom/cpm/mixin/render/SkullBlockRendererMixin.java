package com.tom.cpm.mixin.render;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.tom.cpm.client.CPMOrderedSubmitNodeCollector.CPMSubmitNodeCollector;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.SkullBlockRenderStateAccess;
import com.tom.cpm.shared.animation.AnimationEngine.AnimationMode;
import com.tom.cpm.shared.animation.AnimationState;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_11659;
import net.minecraft.class_11683;
import net.minecraft.class_11786;
import net.minecraft.class_11972;
import net.minecraft.class_12075;
import net.minecraft.class_243;
import net.minecraft.class_2631;
import net.minecraft.class_4587;
import net.minecraft.class_5598;
import net.minecraft.class_827;
import net.minecraft.class_836;
import net.minecraft.class_9296;

@Mixin(class_836.class)
public abstract class SkullBlockRendererMixin implements class_827<class_2631, class_11972> {
	private @Shadow @Final class_11786 playerSkinRenderCache;

	@Inject(at = @At("RETURN"), method = "extractRenderState")
	public void onExtractRenderState(
			class_2631 be, class_11972 stateIn, float p_447371_, class_243 p_445526_,
			@Nullable class_11683.class_11792 p_446270_, CallbackInfo cbi
			) {
		class_9296 resolvableprofile = be.method_11334();
		if (resolvableprofile != null) {
			var info = this.playerSkinRenderCache.method_73495(resolvableprofile);
			var pl = CustomPlayerModelsClient.INSTANCE.manager.loadSkull(info.method_73502());
			((SkullBlockRenderStateAccess) stateIn).cpm$setPlayer(pl);
			((SkullBlockRenderStateAccess) stateIn).cpm$setSkin(info.method_73503());
		}
	}

	@Inject(at = @At(value = "INVOKE_ASSIGN", target = "Ljava/util/function/Function;apply(Ljava/lang/Object;)Ljava/lang/Object;", shift = Shift.BY, by = 2), method = "submit(Lnet/minecraft/client/renderer/blockentity/state/SkullBlockRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V")
	public void onSubmitPre(class_11972 state, class_4587 pose, class_11659 collector, class_12075 cam, CallbackInfo cbi, @Local LocalRef<class_11659> snc, @Local class_5598 model) {
		SkullBlockRenderStateAccess sa = (SkullBlockRenderStateAccess) state;
		if (sa.cpm$getPlayer() != null) {
			CPMSubmitNodeCollector.injectSNC(snc);

			ModelTexture mt = new ModelTexture(sa.cpm$getSkin().comp_1626().comp_3627());
			CustomPlayerModelsClient.INSTANCE.manager.bindPlayerState(sa.cpm$getPlayer(), null, model, null, new AnimationState(AnimationMode.SKULL));
			CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.SKIN);
			state.field_62749 = mt.getRenderType();
		}
	}

	@Inject(at = @At(value = "RETURN"), method = "submit(Lnet/minecraft/client/renderer/blockentity/state/SkullBlockRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V")
	public void onSubmitPost(class_11972 state, class_4587 pose, class_11659 collector, class_12075 cam, CallbackInfo cbi, @Local class_5598 model) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().unbindModel(model);
	}
}

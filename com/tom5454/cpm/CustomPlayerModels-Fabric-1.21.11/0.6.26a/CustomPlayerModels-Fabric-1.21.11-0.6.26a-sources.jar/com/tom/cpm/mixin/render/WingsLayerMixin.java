package com.tom.cpm.mixin.render;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import net.minecraft.class_10034;
import net.minecraft.class_11659;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_563;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_979;

@Mixin(class_979.class)
public abstract class WingsLayerMixin<S extends class_10034, M extends class_583<S>> extends class_3887<S, M> {
	private @Shadow @Final class_563 elytraModel;

	public WingsLayerMixin(class_3883<S, M> p_117346_) {
		super(p_117346_);
	}

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V"),
			method = "submit")
	public void preRender(class_4587 p_435137_, class_11659 p_434138_, int p_434689_, S p_434317_, float p_433309_, float p_432928_, CallbackInfo cbi) {
		if(method_17165() instanceof class_572) {
			CustomPlayerModelsClient.INSTANCE.renderElytra((class_572<class_10034>) method_17165(), elytraModel);
		}
	}

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V"),
			method = "submit")
	public void postRender(class_4587 p_435137_, class_11659 p_434138_, int p_434689_, S p_434317_, float p_433309_, float p_432928_, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbind(elytraModel);
	}
}

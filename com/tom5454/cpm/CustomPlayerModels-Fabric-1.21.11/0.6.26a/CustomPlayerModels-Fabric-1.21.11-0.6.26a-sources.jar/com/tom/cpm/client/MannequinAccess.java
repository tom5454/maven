package com.tom.cpm.client;

import net.minecraft.class_11786;

public interface MannequinAccess {
	class_11786.class_11787 cpm$getInfo();
}

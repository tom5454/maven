package com.tom.cpm.mixin.render;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CapeTransformUtil;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.PlayerRenderStateAccess;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_10055;
import net.minecraft.class_10186;
import net.minecraft.class_11659;
import net.minecraft.class_11890;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_972;

@Mixin(class_972.class)
public abstract class CapeLayerMixin extends class_3887<class_10055, class_591> {
	public CapeLayerMixin(class_3883<class_10055, class_591> p_117346_) {
		super(p_117346_);
	}

	private @Shadow @Final class_572<class_10055> model;
	@Shadow abstract boolean hasLayer(class_1799 p_372809_, class_10186.class_10190 p_388089_);

	@Inject(at =
			@At("HEAD"),
			method = "submit("
					+ "Lcom/mojang/blaze3d/vertex/PoseStack;"
					+ "Lnet/minecraft/client/renderer/SubmitNodeCollector;I"
					+ "Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;FF"
					+ ")V", cancellable = true)
	private void submitCape(class_4587 poseStack, class_11659 collector, int light, class_10055 state, float p_433069_, float p_435707_,
			CallbackInfo cbi) {
		Player<class_11890> pl = ((PlayerRenderStateAccess) state).cpm$getPlayer();
		if (pl != null) {
			ModelDefinition def = pl.getModelDefinition();
			if (def != null && def.hasRoot(RootModelType.CAPE)) {
				if (!this.hasLayer(state.field_53418, class_10186.class_10190.field_54127)) {
					poseStack.method_22903();
					if (this.hasLayer(state.field_53418, class_10186.class_10190.field_54125)) {
						poseStack.method_46416(0.0F, -0.053125F, 0.06875F);
					}

					var cape = state.field_53520.comp_1627();
					class_2960 defLoc = cape != null ? cape.comp_3627() : CustomPlayerModelsClient.DEFAULT_CAPE;
					ModelTexture mt = new ModelTexture(defLoc);
					CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSubModel(method_17165(), model, null);
					CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.CAPE);
					if(mt.getTexture() != null) {
						this.model.method_17087(state);
						CapeTransformUtil.applyTransform(model);
						CustomPlayerModelsClient.mc.getPlayerRenderManager().setModelPose(model);

						collector.method_73489(
								this.model,
								state,
								poseStack,
								mt.getRenderType(),
								light,
								class_4608.field_21444,
								state.field_61821,
								null
								);
					}
					CustomPlayerModelsClient.mc.getPlayerRenderManager().unbindModel(model);
					poseStack.method_22909();
				}
				cbi.cancel();
			}
		}
	}
}

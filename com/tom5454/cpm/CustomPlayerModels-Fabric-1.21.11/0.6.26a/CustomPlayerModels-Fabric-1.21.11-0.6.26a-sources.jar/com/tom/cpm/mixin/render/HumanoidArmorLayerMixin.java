package com.tom.cpm.mixin.render;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import net.minecraft.class_10034;
import net.minecraft.class_11659;
import net.minecraft.class_11677;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_970;

@Mixin(class_970.class)
public abstract class HumanoidArmorLayerMixin extends class_3887<class_10034, class_572<class_10034>> {

	public HumanoidArmorLayerMixin(
			class_3883<class_10034, class_572<class_10034>> renderLayerParent) {
		super(renderLayerParent);
	}

	private @Final @Shadow class_11677<class_572<class_10034>> modelSet;

	@Inject(at = @At("HEAD"), method = "submit")
	public void preRender(class_4587 p_435921_, class_11659 p_434130_, int p_434678_, class_10034 p_435902_, float p_435802_, float p_434554_, CallbackInfo cbi) {
		if(method_17165() instanceof class_572) {
			CustomPlayerModelsClient.INSTANCE.renderArmor(modelSet, method_17165());
		}
	}

	@Inject(at = @At("RETURN"), method = "submit")
	public void postRender(class_4587 p_435921_, class_11659 p_434130_, int p_434678_, class_10034 p_435902_, float p_435802_, float p_434554_, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbind(modelSet.comp_4542());
		CustomPlayerModelsClient.INSTANCE.manager.unbind(modelSet.comp_4543());
		CustomPlayerModelsClient.INSTANCE.manager.unbind(modelSet.comp_4544());
		CustomPlayerModelsClient.INSTANCE.manager.unbind(modelSet.comp_4545());
	}
}

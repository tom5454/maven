package com.tom.cpm.mixin;

import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_10455;
import net.minecraft.class_11566;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_638;
import net.minecraft.class_811;
import net.minecraft.class_9296;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_10455.class)
public class SpecialModelWrapperMixin {

	@Inject(at = @At("RETURN"), method = "update")
	public void onUpdate(
			class_10444 itemStackRenderState,
			class_1799 itemStack,
			class_10442 itemModelResolver,
			class_811 itemDisplayContext,
			@Nullable class_638 clientLevel,
			@Nullable class_11566 itemOwner,
			int i,
			CallbackInfo cbi
			) {
		if (itemStack.method_7909() == class_1802.field_8575) {
			class_9296 resolvableProfile = itemStack.method_58694(class_9334.field_49617);
			if (resolvableProfile != null) {
				itemStackRenderState.method_70947();
			}
		}
	}
}

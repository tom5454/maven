package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import com.tom.cpm.client.SkullBlockRenderStateAccess;
import com.tom.cpm.shared.config.Player;
import net.minecraft.class_11890;
import net.minecraft.class_11972;
import net.minecraft.class_8685;

@Mixin(class_11972.class)
public class SkullBlockRenderStateMixin implements SkullBlockRenderStateAccess {
	private Player<class_11890> cpm$player;
	private class_8685 cpm$skin;

	@Override
	public void cpm$setPlayer(Player<class_11890> player) {
		cpm$player = player;
	}

	@Override
	public Player<class_11890> cpm$getPlayer() {
		return cpm$player;
	}

	@Override
	public void cpm$setSkin(class_8685 tex) {
		cpm$skin = tex;
	}

	@Override
	public class_8685 cpm$getSkin() {
		return cpm$skin;
	}
}

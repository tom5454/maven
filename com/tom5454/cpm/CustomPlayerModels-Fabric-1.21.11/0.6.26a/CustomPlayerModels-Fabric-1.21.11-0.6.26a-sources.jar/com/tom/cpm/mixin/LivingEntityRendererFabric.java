package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1309;
import net.minecraft.class_3883;
import net.minecraft.class_4587;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;

@Mixin(value = class_922.class, priority = 100000)
public abstract class LivingEntityRendererFabric<T extends class_1309, S extends class_10042, M extends class_583<? super S>>
extends class_897<T, S>
implements class_3883<S, M>, com.tom.cpm.client.EntityRenderer<S> {

	protected LivingEntityRendererFabric(class_5618 context) {
		super(context);
	}

	@Inject(at = @At("HEAD"), method = "submit("
			+ "Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;"
			+ "Lnet/minecraft/client/renderer/SubmitNodeCollector;"
			+ "Lnet/minecraft/client/renderer/state/CameraRenderState;"
			+ ")V")
	public void onSubmitPre(S livingEntityRenderState, class_4587 poseStack,
			class_11659 submitNodeCollector, class_12075 cameraRenderState,
			CallbackInfo cbi, @Local LocalRef<class_11659> snc) {
		cpm$onSubmitPre(livingEntityRenderState, poseStack, submitNodeCollector, cameraRenderState, snc);
	}

	@Inject(at = @At("RETURN"), method = "submit("
			+ "Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;"
			+ "Lnet/minecraft/client/renderer/SubmitNodeCollector;"
			+ "Lnet/minecraft/client/renderer/state/CameraRenderState;"
			+ ")V")
	public void onSubmitPost(S livingEntityRenderState, class_4587 poseStack,
			class_11659 submitNodeCollector, class_12075 cameraRenderState,
			CallbackInfo cbi) {
		cpm$onSubmitPost(livingEntityRenderState, poseStack, submitNodeCollector, cameraRenderState);
	}
}

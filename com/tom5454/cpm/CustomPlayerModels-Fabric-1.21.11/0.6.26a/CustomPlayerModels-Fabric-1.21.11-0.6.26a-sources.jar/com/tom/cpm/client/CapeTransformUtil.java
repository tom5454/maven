package com.tom.cpm.client;

import net.minecraft.class_10055;
import net.minecraft.class_5603;
import net.minecraft.class_572;
import net.minecraft.class_9950;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class CapeTransformUtil {

	public static void applyTransform(class_572<class_10055> model) {
		if (model instanceof class_9950 m) {
			m.field_52927.method_32085(CapeTransformUtil.combine(model.field_3391.method_32084(), m.field_52927.method_32084()));
		}
	}

	public static class_5603 combine(class_5603 first, class_5603 second) {
		// Create the first transformation matrix
		Matrix4f transformA = new Matrix4f()
				.translate(first.comp_2997(), first.comp_2998(), first.comp_2999())
				.rotateZYX(first.comp_3002(), first.comp_3001(), first.comp_3000())
				.scale(first.comp_3003(), first.comp_3004(), first.comp_3005());

		// Create the second transformation matrix
		Matrix4f transformB = new Matrix4f()
				.translate(second.comp_2997(), second.comp_2998(), second.comp_2999())
				.rotateZYX(second.comp_3002(), second.comp_3001(), second.comp_3000())
				.scale(second.comp_3003(), second.comp_3004(), second.comp_3005());

		// Multiply them to get the final transformation
		transformA.mul(transformB);

		// Extract final translation
		Vector3f translation = transformA.getTranslation(new Vector3f());

		// Extract final scale
		Vector3f scale = transformA.getScale(new Vector3f());

		// Extract final rotation
		Quaternionf rotation = transformA.getUnnormalizedRotation(new Quaternionf());
		Vector3f eulerAngles = rotation.getEulerAnglesZYX(new Vector3f());

		// Return the combined PartPose
		return new class_5603(
				translation.x, translation.y, translation.z,
				eulerAngles.x, eulerAngles.y, eulerAngles.z,
				scale.x, scale.y, scale.z
				);
	}
}

package com.tom.cpm.mixin.access;

import java.io.IOException;
import java.nio.channels.WritableByteChannel;
import net.minecraft.class_1011;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1011.class)
public interface NativeImageAccessor {

	@Invoker
	boolean callWriteToChannel(final WritableByteChannel writableByteChannel) throws IOException;
}

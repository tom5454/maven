package com.tom.cpm.client;

import java.nio.FloatBuffer;
import net.minecraft.class_11239;
import net.minecraft.class_11256;
import net.minecraft.class_2960;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_8030;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import com.tom.cpl.math.Box;
import com.tom.cpl.math.Mat4f;
import com.tom.cpl.math.Vec2i;
import com.tom.cpl.render.RenderTypes;
import com.tom.cpl.render.VBuffers;
import com.tom.cpl.util.Image;
import com.tom.cpm.client.MinecraftObject.DynTexture;
import com.tom.cpm.shared.gui.ViewportCamera;
import com.tom.cpm.shared.gui.panel.Panel3d;
import com.tom.cpm.shared.gui.panel.Panel3d.Panel3dNative;
import com.tom.cpm.shared.model.render.RenderMode;

public class Panel3dImpl extends Panel3dNative {
	private class_310 mc;
	private Vec2i mouse;
	private Mat4f view, proj;

	public Panel3dImpl(Panel3d panel) {
		super(panel);
		mc = class_310.method_1551();
	}

	@Override
	public void render(float partialTicks) {
		GuiImpl gui = panel.getGui().getNativeGui();
		Vec2i mouse = super.getMouse();
		Vec2i off = panel.getGui().getOffset();
		this.mouse = new Vec2i(mouse.x - off.x, mouse.y - off.y);

		Box bounds = getBounds();
		gui.drawPip(this, bounds.w, bounds.h, State::new);
	}

	public static record State(Panel3dImpl impl, int x0, int y0, int x1, int y1, class_8030 bounds, class_8030 scissorArea) implements class_11256 {

		public State(Panel3dImpl impl, int x0, int y0, int x1, int y1, class_8030 scissorArea) {
			this(impl, x0, y0, x1, y1, class_11256.method_71535(x0, y0, x1, y1, scissorArea), scissorArea);
		}

		@Override
		public float comp_4133() {
			return 1;
		}
	}

	public static class Renderer extends class_11239<State> {

		public Renderer(class_4598 bufferSource) {
			super(bufferSource);
		}

		@Override
		public Class<State> method_70903() {
			return State.class;
		}

		@Override
		protected void renderToTexture(State pipState, class_4587 poseStack) {
			float partialTicks = 0f;
			var mc = class_310.method_1551();
			mc.field_1773.method_71114().method_71034(class_308.class_11274.field_60028);
			var panel = pipState.impl().panel;
			GuiImpl gui = panel.getGui().getNativeGui();

			ViewportCamera cam = panel.getCamera();
			float pitch = (float) Math.asin(-cam.look.y);
			float yaw = cam.look.getYaw();

			float size = cam.camDist;

			Quaternionf quaternion = class_7833.field_40718.rotationDegrees(180.0F);
			Quaternionf quaternion1 = class_7833.field_40714.rotation(pitch);
			quaternion.mul(quaternion1);

			int i = mc.method_22683().method_4495();
			int j = (pipState.comp_4124() - pipState.comp_4122()) * i;
			int k = (pipState.comp_4125() - pipState.comp_4123()) * i;
			var proj = new Matrix4f().setOrtho(0.0F, j, k, 0.0F, 1000.0F, 11000.0F);
			pipState.impl().proj = Mat4f.map(proj, Matrix4f::get);

			try {
				poseStack.method_22903();
				poseStack.method_34425(new Matrix4f().scaling(size, size, size));
				poseStack.method_22907(quaternion);

				poseStack.method_22907(class_7833.field_40716.rotation((float) (yaw + Math.PI)));
				poseStack.method_46416(-cam.position.x, -cam.position.y, -cam.position.z);

				pipState.impl().view = Mat4f.map(poseStack.method_23760().method_23761(), Matrix4f::get);

				int light = class_765.method_23687(15, 15);
				float lw = mc.method_22683().method_75291();
				panel.render(new com.tom.cpl.math.MatrixStack(), new VBuffers(rt -> new VBuffer(field_59933.method_73477(rt.getNativeType()), light, class_4608.field_21444, lw, poseStack)), partialTicks);
			} catch (Exception e) {
				gui.onGuiException("Error drawing gui", e, true);
			} finally {
				poseStack.method_22909();
			}
		}

		@Override
		protected float method_70907(int i, int j) {
			return i / 2.0F;
		}

		@Override
		protected String method_70906() {
			return "cpm:panel3d";
		}
	}

	@Override
	public Vec2i get3dSize() {
		return new Vec2i(panel.getBounds().w, panel.getBounds().h);
	}

	@Override
	public Vec2i getMouse() {
		return mouse;
	}

	@Override
	public void draw3dOverlay() {
		Box bounds = getBounds();
		Vec2i ws = get3dSize();
		panel.getGui().drawTexture(bounds.x, bounds.y, bounds.w, bounds.h, 0, 0, 1, 1);
	}

	@Override
	public RenderTypes<RenderMode> getRenderTypes() {
		return getRenderTypes0(DynTexture.getBoundLoc());
	}

	@Override
	public RenderTypes<RenderMode> getRenderTypes(String texture) {
		return getRenderTypes0(class_2960.method_43902("cpm", "textures/gui/" + texture + ".png"));
	}

	@Override
	public Image takeScreenshot(Vec2i size) {
		GuiImpl gui = panel.getGui().getNativeGui();
		int dw = mc.method_22683().method_4489();
		int dh = mc.method_22683().method_4506();
		float multiplierX = dw / (float)gui.field_22789;
		float multiplierY = dh / (float)gui.field_22790;
		int width = (int) (multiplierX * size.x);
		int height = (int) (multiplierY * size.y);
		FloatBuffer buffer = BufferUtils.createFloatBuffer(width * height * 3);
		GL11.glReadPixels((int) (multiplierX * renderPos.x), mc.method_22683().method_4506() - height - (int) (multiplierY * renderPos.y), width, height, GL11.GL_RGB, GL11.GL_FLOAT, buffer);
		Image img = new Image(width, height);
		for(int y = 0;y<height;y++) {
			for(int x = 0;x<width;x++) {
				float r = buffer.get((x + y * width) * 3);
				float g = buffer.get((x + y * width) * 3 + 1);
				float b = buffer.get((x + y * width) * 3 + 2);
				int color = 0xff000000 | (((int)(r * 255)) << 16) | (((int)(g * 255)) << 8) | ((int)(b * 255));
				img.setRGB(x, height - y - 1, color);
			}
		}
		Image rImg = new Image(size.x, size.y);
		rImg.draw(img, 0, 0, size.x, size.y);
		return rImg;
	}

	@Override
	public Mat4f getView() {
		return view;
	}

	@Override
	public Mat4f getProjection() {
		return proj;
	}
}

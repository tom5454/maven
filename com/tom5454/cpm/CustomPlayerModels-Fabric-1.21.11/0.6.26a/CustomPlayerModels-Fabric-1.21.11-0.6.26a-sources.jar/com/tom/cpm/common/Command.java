package com.tom.cpm.common;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import com.tom.cpl.command.BrigadierCommandHandler;
import com.tom.cpl.text.IText;
import net.minecraft.class_12099;
import net.minecraft.class_1657;
import net.minecraft.class_2168;
import net.minecraft.class_2186;

public class Command extends BrigadierCommandHandler<class_2168> {

	public Command(CommandDispatcher<class_2168> dispatcher, boolean client) {
		super(dispatcher, client);
	}

	@Override
	public String toStringPlayer(Object pl) {
		return ((class_1657)pl).method_5820();
	}

	@Override
	protected boolean hasOPPermission(class_2168 source) {
		return source.method_75037().hasPermission(class_12099.field_63210);
	}

	@Override
	protected ArgumentType<?> player() {
		return class_2186.method_9305();
	}

	@Override
	protected Object getPlayer(CommandContext<class_2168> ctx, String id) throws CommandSyntaxException {
		return class_2186.method_9315(ctx, id);
	}

	@Override
	public void sendSuccess(class_2168 sender, IText text) {
		sender.method_9226(() -> text.remap(), true);
	}
}

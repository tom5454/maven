package com.tom.cpm.mixin.render;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.PlayerRenderStateAccess;
import net.minecraft.class_10055;
import net.minecraft.class_591;

@Mixin(value = class_591.class, priority = 999999)
public class PlayerModelMixin {

	@Inject(at = @At("RETURN"), method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/AvatarRenderState;)V")
	public void onSetupAnim(class_10055 state, CallbackInfo cbi) {
		((PlayerRenderStateAccess) state).cpm$loadState((class_591) (Object) this);
	}
}

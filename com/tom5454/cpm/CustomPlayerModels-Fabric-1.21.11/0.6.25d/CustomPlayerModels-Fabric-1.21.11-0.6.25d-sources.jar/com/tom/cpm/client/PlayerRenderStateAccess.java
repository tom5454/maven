package com.tom.cpm.client;

import com.tom.cpm.shared.config.Player;
import net.minecraft.class_11890;
import net.minecraft.class_2561;
import net.minecraft.class_591;

public interface PlayerRenderStateAccess {
	void cpm$setPlayer(Player<class_11890> player);
	Player<class_11890> cpm$getPlayer();
	void cpm$setModelStatus(class_2561 status);
	class_2561 cpm$getModelStatus();
	void cpm$storeState(class_591 model);
	void cpm$loadState(class_591 model);
}

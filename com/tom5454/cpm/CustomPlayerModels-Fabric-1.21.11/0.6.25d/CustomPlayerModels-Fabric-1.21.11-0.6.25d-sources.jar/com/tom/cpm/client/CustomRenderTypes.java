package com.tom.cpm.client;


import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_12249;
import net.minecraft.class_156;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;

public class CustomRenderTypes {
	public static final Supplier<RenderPipeline> EYES = Platform.registerPipeline(() -> {
		return RenderPipeline.builder(class_10799.field_60127)
				.withLocation(class_2960.method_43902("cpm", "pipeline/eyes"))
				.withVertexShader("core/entity")
				.withFragmentShader("core/entity")
				.withShaderDefine("EMISSIVE")
				.withShaderDefine("NO_OVERLAY")
				.withShaderDefine("NO_CARDINAL_LIGHTING")
				.withSampler("Sampler0")
				.withBlend(BlendFunction.ADDITIVE)
				.withDepthWrite(false)
				.withVertexFormat(class_290.field_1580, class_5596.field_27382)
				.build();
	});

	public static final Supplier<RenderPipeline> LINES = Platform.registerPipeline(() -> {
		return RenderPipeline.builder(class_10799.field_56859)
				.withLocation(class_2960.method_43902("cpm", "pipeline/lines"))
				.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
				.build();
	});

	private static final class_1921 LINES_NO_DEPTH = class_1921.method_75940("cpm:lines_no_depth",
			class_12247.method_75927(LINES.get()).method_75930(class_12245.field_63976)
			.method_75931(class_12246.field_63983).method_75938());

	private static final Function<class_2960, class_1921> GLOWING_EYES = class_156.method_34866(identifier -> {
		final class_12247 renderSetup9 = class_12247.method_75927(EYES.get())
				.method_75934("Sampler0", identifier)
				.method_75937()
				.method_75938();
		return class_1921.method_75940("eyes", renderSetup9);
	});

	public static final class_1921 ENTITY_COLOR = class_12249.method_76000(class_2960.method_60654("cpm:textures/white.png"));

	public static final class_1921 ENTITY_COLOR_EYES = glowingEyes(class_2960.method_60654("cpm:textures/white.png"));


	public static class_1921 entityColorTranslucent() {
		return ENTITY_COLOR;
	}

	public static class_1921 entityColorEyes() {
		return ENTITY_COLOR_EYES;
	}

	public static class_1921 linesNoDepth() {
		return LINES_NO_DEPTH;
	}

	public static class_1921 glowingEyes(class_2960 rl) {
		return GLOWING_EYES.apply(rl);
	}
}

package com.tom.cpm.client;

import java.util.function.Function;
import net.minecraft.class_10034;
import net.minecraft.class_10055;
import net.minecraft.class_11677;
import net.minecraft.class_11890;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3879;
import net.minecraft.class_563;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_634;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_8710;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.common.ByteArrayPayload;
import com.tom.cpm.common.PlayerAnimUpdater;
import com.tom.cpm.mixinplugin.IrisDetector;
import com.tom.cpm.mixinplugin.OFDetector;
import com.tom.cpm.shared.model.RenderManager;
import com.tom.cpm.shared.network.NetHandler;
import com.tom.cpm.shared.util.Log;

public abstract class ClientBase {
	public static final class_2960 DEFAULT_CAPE = class_2960.method_60654("cpm:textures/template/cape.png");
	public static boolean optifineLoaded, irisLoaded, vrLoaded;
	public static MinecraftObject mc;
	public RenderManager<GameProfile, class_11890, class_3879, Void> manager;
	public NetHandler<class_8710.class_9154<ByteArrayPayload>, class_11890, class_634> netHandler;

	public void init0() {
		mc = new MinecraftObject();
		optifineLoaded = OFDetector.doApply();
		vrLoaded = Platform.isModLoaded("vivecraft");
		irisLoaded = IrisDetector.doApply();
		if(optifineLoaded)Log.info("Optifine detected, enabling optifine compatibility");
		if(vrLoaded)Log.info("ViveCraft detected, enabling ViveCraft compatibility");
		if(irisLoaded)Log.info("Iris detected, enabling iris compatibility");
	}

	public void init1() {
		manager = new RenderManager<>(mc.getPlayerRenderManager(), mc.getDefinitionLoader(), PlayerProfile::getPlayerProfile);
		manager.setGPGetters(GameProfile::properties, Property::value);
		netHandler = new NetHandler<>((k, v) -> new class_8710.class_9154<>(class_2960.method_43902(k, v)));
		netHandler.setExecutor(class_310::method_1551);
		netHandler.setSendPacketClient(Function.identity(), (c, rl, pb) -> c.method_52787(new class_2817(new ByteArrayPayload(rl, pb))));
		netHandler.setPlayerToLoader(PlayerProfile::getPlayerProfile);
		netHandler.setGetPlayerById(id -> {
			class_1297 ent = class_310.method_1551().field_1687.method_8469(id);
			if(ent instanceof class_11890 a) {
				return a;
			}
			return null;
		});
		netHandler.setGetClient(() -> class_310.method_1551().field_1724);
		netHandler.setGetNet(c -> ((class_746)c).field_3944);
		netHandler.setDisplayText(t -> class_310.method_1551().field_1724.method_7353(t.remap(), false));
		netHandler.setGetPlayerAnimGetters(new PlayerAnimUpdater());
		if (irisLoaded)IrisPipelineSetup.setup();
	}

	public static void apiInit() {
		CustomPlayerModels.api.buildClient().voicePlayer(class_11890.class, class_11890::method_5667).
		renderApi(class_3879.class, class_2960.class, class_1921.class, Void.class, GameProfile.class, ModelTexture::new).
		localModelApi(GameProfile::new).init();
	}

	public void playerRenderPre(PlayerRenderStateAccess sa, class_591 model, class_10055 renderState) {
		CustomPlayerModelsClient.INSTANCE.manager.bindPlayerState(sa.cpm$getPlayer(), null, model, null);
		model.method_62110(renderState);
		mc.getPlayerRenderManager().setModelPose(model);
	}

	public void playerRenderPost(class_591 model) {
		manager.unbindClear(model);
	}

	public void renderHand(class_591 model) {
		renderHand(class_310.method_1551().field_1724, model);
	}

	public void renderHand(class_742 pl, class_591 model) {
		manager.bindHand(pl, null, model);
	}

	public void renderHandPost(class_572 model) {
		manager.unbindClear(model);
	}

	public void renderElytra(class_572<class_10034> player, class_563 model) {
		manager.bindElytra(player, model);
	}

	public void renderArmor(class_11677<class_572<class_10034>> modelSet,
			class_572<class_10034> player) {
		manager.bindArmor(player, modelSet.comp_4542(), 1);
		manager.bindArmor(player, modelSet.comp_4544(), 2);
		manager.bindArmor(player, modelSet.comp_4543(), 3);
		manager.bindArmor(player, modelSet.comp_4545(), 4);
	}

	public void updateJump() {
		var minecraft = class_310.method_1551();
		if(minecraft.field_1724.method_24828() && minecraft.field_1724.field_3913.field_54155.comp_3163()) {
			manager.jump(minecraft.field_1724);
		}
	}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import com.tom.cpm.client.PlayerRenderStateAccess;
import com.tom.cpm.shared.config.Player;
import net.minecraft.class_10055;
import net.minecraft.class_11890;
import net.minecraft.class_2561;
import net.minecraft.class_5603;
import net.minecraft.class_591;

@Mixin(class_10055.class)
public class AvatarRenderStateMixin implements PlayerRenderStateAccess {
	private @Unique Player<class_11890> cpm$player;
	private @Unique class_2561 cpm$modelStatus;
	private @Unique class_5603 cpm$head;
	private @Unique class_5603 cpm$body;
	private @Unique class_5603 cpm$rightArm;
	private @Unique class_5603 cpm$leftArm;
	private @Unique class_5603 cpm$rightLeg;
	private @Unique class_5603 cpm$leftLeg;

	@Override
	public void cpm$setPlayer(Player<class_11890> player) {
		this.cpm$player = player;
	}

	@Override
	public Player<class_11890> cpm$getPlayer() {
		return cpm$player;
	}

	@Override
	public void cpm$setModelStatus(class_2561 status) {
		cpm$modelStatus = status;
	}

	@Override
	public class_2561 cpm$getModelStatus() {
		return cpm$modelStatus;
	}

	@Override
	public void cpm$storeState(class_591 model) {
		cpm$head     = model.field_3398    .method_32084();
		cpm$body     = model.field_3391    .method_32084();
		cpm$rightArm = model.field_3401.method_32084();
		cpm$leftArm  = model.field_27433 .method_32084();
		cpm$rightLeg = model.field_3392.method_32084();
		cpm$leftLeg  = model.field_3397 .method_32084();
	}

	@Override
	public void cpm$loadState(class_591 model) {
		if (cpm$head == null)return;
		model.field_3398    .method_32085(cpm$head    );
		model.field_3391    .method_32085(cpm$body    );
		model.field_3401.method_32085(cpm$rightArm);
		model.field_27433 .method_32085(cpm$leftArm );
		model.field_3392.method_32085(cpm$rightLeg);
		model.field_3397 .method_32085(cpm$leftLeg );
	}
}

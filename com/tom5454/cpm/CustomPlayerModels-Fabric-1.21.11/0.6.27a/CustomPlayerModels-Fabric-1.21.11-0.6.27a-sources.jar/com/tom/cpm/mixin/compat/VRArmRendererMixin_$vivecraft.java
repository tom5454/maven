package com.tom.cpm.mixin.compat;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.vivecraft.client_vr.render.VRArmRenderer;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.tom.cpm.client.CPMOrderedSubmitNodeCollector.CPMSubmitNodeCollector;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_1007;
import net.minecraft.class_11659;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_742;

@Mixin(VRArmRenderer.class)
public class VRArmRendererMixin_$vivecraft extends class_1007<class_742> {

	public vivecraft(class_5618 p_445612_, boolean p_445726_) {
		super(p_445612_, p_445726_);
	}

	@Inject(at = @At("HEAD"), method = "renderRightHand")
	public void onRenderRightArmPre(final class_4587 poseStack, final class_11659 vertexConsumers, final int i, final class_2960 Identifier, final boolean sleeve, CallbackInfo cbi, @Local LocalRef<class_11659> snc) {
		CPMSubmitNodeCollector.injectSNC(snc);
		CustomPlayerModelsClient.INSTANCE.renderHand(method_4038());
	}

	@Inject(at = @At("HEAD"), method = "renderLeftHand")
	public void onRenderLeftArmPre(final class_4587 poseStack, final class_11659 vertexConsumers, final int i, final class_2960 Identifier, final boolean sleeve, CallbackInfo cbi, @Local LocalRef<class_11659> snc) {
		CPMSubmitNodeCollector.injectSNC(snc);
		CustomPlayerModelsClient.INSTANCE.renderHand(method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderRightHand")
	public void onRenderRightArmPost(final class_4587 poseStack, final class_11659 vertexConsumers, final int i, final class_2960 Identifier, final boolean sleeve, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderLeftHand")
	public void onRenderLeftArmPost(final class_4587 poseStack, final class_11659 vertexConsumers, final int i, final class_2960 Identifier, final boolean sleeve, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(method_4038());
	}

	@ModifyArg(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/rendertype/RenderTypes;entityTranslucent("
					+ "Lnet/minecraft/resources/Identifier;)Lnet/minecraft/client/renderer/rendertype/RenderType;"
			), method = "renderHand")
	public class_2960 getSkinTex(class_2960 arg) {
		ModelTexture tex = new ModelTexture(arg);
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(method_4038(), tex, TextureSheetType.SKIN);
		return tex.getTexture();
	}
}

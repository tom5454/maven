package com.tom.cpm.client.vr;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_630;
import net.minecraft.class_742;
import org.vivecraft.client.render.VRPlayerModel;
import org.vivecraft.client.render.VRPlayerModel_WithArms;
import com.tom.cpl.math.MatrixStack;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.client.PlayerRenderManager.RDH;
import com.tom.cpm.shared.model.PlayerModelParts;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.render.ModelRenderManager.Field;
import com.tom.cpm.shared.model.render.ModelRenderManager.RedirectRenderer;
import com.tom.cpm.shared.util.Log;

public class RedirectHolderVRPlayer extends RDH {
	private RedirectRenderer<class_630> head;
	private RedirectRenderer<class_630> leftArm;
	private RedirectRenderer<class_630> rightArm;
	private boolean seated;
	private static boolean VC120;
	private static java.lang.reflect.Field[] OLD_FIELDS;
	static {
		try {
			OLD_FIELDS = new java.lang.reflect.Field[] {
					VRPlayerModel_WithArms.class.getDeclaredField("leftShoulder"),
					VRPlayerModel_WithArms.class.getDeclaredField("rightShoulder"),
					VRPlayerModel_WithArms.class.getDeclaredField("leftShoulder_sleeve"),
					VRPlayerModel_WithArms.class.getDeclaredField("rightShoulder_sleeve"),
			};
			VC120 = false;
		} catch (Throwable e) {
			VC120 = true;
		}
	}

	public RedirectHolderVRPlayer(PlayerRenderManager mngr, VRPlayerModel<class_742> model) {
		super(mngr, model);

		seated = !(model instanceof VRPlayerModel_WithArms);

		head = registerHead(new Field<>(    () -> model.field_3398     , v -> model.field_3398      = v, PlayerModelParts.HEAD));
		register(new Field<>(           () -> model.field_3391     , v -> model.field_3391      = v, PlayerModelParts.BODY));
		if(seated) {
			rightArm = register(new Field<>(() -> model.field_3401, v -> model.field_3401 = v, PlayerModelParts.RIGHT_ARM));
			leftArm = register(new Field<>( () -> model.field_27433 , v -> model.field_27433  = v, PlayerModelParts.LEFT_ARM));
		} else {
			VRPlayerModel_WithArms<class_742> w = (VRPlayerModel_WithArms<class_742>) model;
			rightArm = register(new Field<>(() -> w.rightHand, v -> w.rightHand = v, PlayerModelParts.RIGHT_ARM));
			leftArm = register(new Field<>( () -> w.leftHand , v -> w.leftHand  = v, PlayerModelParts.LEFT_ARM));
		}
		register(new Field<>(           () -> model.field_3392 , v -> model.field_3392  = v, PlayerModelParts.RIGHT_LEG));
		register(new Field<>(           () -> model.field_3397  , v -> model.field_3397   = v, PlayerModelParts.LEFT_LEG));

		register(new Field<>(() -> model.field_3394        , v -> model.field_3394         = v, null)).setCopyFrom(head);
		register(new Field<>(() -> model.field_3484 , v -> model.field_3484  = v, null));
		register(new Field<>(() -> model.field_3486, v -> model.field_3486 = v, null));
		register(new Field<>(() -> model.field_3482  , v -> model.field_3482   = v, null));
		register(new Field<>(() -> model.field_3479 , v -> model.field_3479  = v, null));
		register(new Field<>(() -> model.field_3483     , v -> model.field_3483      = v, null));

		register(new Field<>(() -> model.vrHMD, v -> model.vrHMD = v, null));//disable
		if(!seated) {
			VRPlayerModel_WithArms<class_742> w = (VRPlayerModel_WithArms<class_742>) model;
			if (VC120) {
				register(new Field<>(() -> w.field_27433 , v -> w.field_27433  = v, null));//disable
				register(new Field<>(() -> w.field_3401, v -> w.field_3401 = v, null));//disable

				register(new Field<>(() -> w.leftHandSleeve , v -> w.leftHandSleeve  = v, null));//disable
				register(new Field<>(() -> w.rightHandSleeve, v -> w.rightHandSleeve = v, null));//disable
			} else {
				try {
					var lookup = MethodHandles.lookup();
					for (int i = 0; i < OLD_FIELDS.length; i++) {
						var field = OLD_FIELDS[i];
						MethodHandle get = lookup.unreflectGetter(field).bindTo(w);
						MethodHandle set = lookup.unreflectSetter(field).bindTo(w);

						register(new Field<>(() -> {
							try {
								return (class_630) get.invoke();
							} catch (Throwable e) {
								return model.vrHMD;//Fallback nonull
							}
						}, v -> {
							try {
								set.invoke(v);
							} catch (Throwable e) {
								// Do nothing
							}
						}, null));//disable
					}
				} catch (Throwable e) {
					Log.warn("Failed to bind legacy field accessors for VRPlayerModel_WithArms class", e);
				}
			}
		}

		register(new Field<>(() -> model.field_3485, v -> model.field_3485 = v, RootModelType.CAPE));
	}

	@Override
	protected void setupTransform(MatrixStack stack, RedirectRenderer<class_630> part, boolean pre) {
		if (VC120)return;
		if(!pre && (leftArm == part || rightArm == part) && !seated) {
			stack.translate(0, -8 / 16f, 0);
		}
	}

	public static interface GetOld extends Function<VRPlayerModel_WithArms<class_742>, class_630> {
		@Override
		class_630 apply(VRPlayerModel_WithArms<class_742> t);

		default Supplier<class_630> bind(VRPlayerModel_WithArms<class_742> v) {
			return () -> apply(v);
		}
	}

	public static interface SetOld extends BiConsumer<VRPlayerModel_WithArms<class_742>, class_630> {
		@Override
		void accept(VRPlayerModel_WithArms<class_742> t, class_630 part);

		default Consumer<class_630> bind(VRPlayerModel_WithArms<class_742> v) {
			return e -> accept(v, e);
		}
	}
}

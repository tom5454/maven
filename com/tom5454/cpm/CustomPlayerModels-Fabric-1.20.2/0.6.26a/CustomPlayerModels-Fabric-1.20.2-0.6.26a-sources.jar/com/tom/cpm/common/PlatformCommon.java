package com.tom.cpm.common;

import java.util.List;
import net.minecraft.class_1320;
import net.minecraft.class_1959;
import com.jamieswhiteshirt.reachentityattributes.ReachEntityAttributes;

import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.shared.util.Log;

public class PlatformCommon {

	public static class_1959.class_5482 getClimateSettings(class_1959 b) {
		return b.field_26393;
	}

	public static List<class_1320> getReachAttr() {
		if (CustomPlayerModels.isModLoaded("reach-entity-attributes")) {
			Log.info("Loaded Reach Entity Attributes scaler");
			return List.of(ReachEntityAttributes.REACH, ReachEntityAttributes.ATTACK_RANGE);
		}
		return null;
	}

	public static List<class_1320> getStepHeightAttr() {
		return null;
	}
}

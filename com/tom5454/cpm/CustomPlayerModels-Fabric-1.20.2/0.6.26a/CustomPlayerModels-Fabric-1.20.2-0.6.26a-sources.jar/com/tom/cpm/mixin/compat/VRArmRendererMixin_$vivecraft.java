package com.tom.cpm.mixin.compat;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.vivecraft.client_vr.provider.ControllerType;
import org.vivecraft.client_vr.render.VRArmRenderer;
import com.tom.cpm.client.CustomPlayerModelsClient;
import net.minecraft.class_1007;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_630;
import net.minecraft.class_742;
import net.minecraft.class_8685;

@Mixin(VRArmRenderer.class)
public class VRArmRendererMixin_$vivecraft extends class_1007 {

	public vivecraft(class_5618 pContext, boolean pUseSlimModel) {
		super(pContext, pUseSlimModel);
	}

	@Inject(at = @At("HEAD"), method = "renderRightHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V")
	public void onRenderRightArmPre(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.bindHand(player, vertexConsumers, method_4038());
	}

	@Inject(at = @At("HEAD"), method = "renderLeftHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V")
	public void onRenderLeftArmPre(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.bindHand(player, vertexConsumers, method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderRightHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V")
	public void onRenderRightArmPost(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbindFlush(method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderLeftHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V")
	public void onRenderLeftArmPost(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbindFlush(method_4038());
	}

	@Redirect(at =
			@At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/resources/PlayerSkin;"
							+ "texture()Lnet/minecraft/resources/ResourceLocation;"
					),
			method = "renderItem("
					+ "Lorg/vivecraft/client_vr/provider/ControllerType;"
					+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;"
					+ "ILnet/minecraft/client/player/AbstractClientPlayer;"
					+ "Lnet/minecraft/client/model/geom/ModelPart;Lnet/minecraft/client/model/geom/ModelPart;)V"
			)
	public class_2960 getSkinTex(class_8685 skin, ControllerType side, class_4587 matrixStackIn, class_4597 bufferIn,
			int combinedLightIn, class_742 player, class_630 rendererArmIn, class_630 rendererArmwearIn) {
		return method_4216(player);
	}
}

package com.tom.cpm.client.vr;

import org.vivecraft.client.render.VRPlayerModel;
import org.vivecraft.client.render.VRPlayerModel_WithArms;
import com.tom.cpl.math.MatrixStack;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.client.PlayerRenderManager.RDH;
import com.tom.cpm.shared.model.PlayerModelParts;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.render.ModelRenderManager.Field;
import com.tom.cpm.shared.model.render.ModelRenderManager.RedirectRenderer;
import net.minecraft.class_630;
import net.minecraft.class_742;

public class RedirectHolderVRPlayer extends RDH {
	private RedirectRenderer<class_630> head;
	private RedirectRenderer<class_630> leftArm;
	private RedirectRenderer<class_630> rightArm;
	private boolean seated;

	public RedirectHolderVRPlayer(PlayerRenderManager mngr, VRPlayerModel<class_742> model) {
		super(mngr, model);

		seated = !(model instanceof VRPlayerModel_WithArms);

		head = registerHead(new Field<>(    () -> model.field_3398     , v -> model.field_3398      = v, PlayerModelParts.HEAD));
		register(new Field<>(           () -> model.field_3391     , v -> model.field_3391      = v, PlayerModelParts.BODY));
		if(seated) {
			rightArm = register(new Field<>(() -> model.field_3401, v -> model.field_3401 = v, PlayerModelParts.RIGHT_ARM));
			leftArm = register(new Field<>( () -> model.field_27433 , v -> model.field_27433  = v, PlayerModelParts.LEFT_ARM));
		} else {
			VRPlayerModel_WithArms<class_742> w = (VRPlayerModel_WithArms<class_742>) model;
			rightArm = register(new Field<>(() -> w.rightHand, v -> w.rightHand = v, PlayerModelParts.RIGHT_ARM));
			leftArm = register(new Field<>( () -> w.leftHand , v -> w.leftHand  = v, PlayerModelParts.LEFT_ARM));
		}
		register(new Field<>(           () -> model.field_3392 , v -> model.field_3392  = v, PlayerModelParts.RIGHT_LEG));
		register(new Field<>(           () -> model.field_3397  , v -> model.field_3397   = v, PlayerModelParts.LEFT_LEG));

		register(new Field<>(() -> model.field_3394        , v -> model.field_3394         = v, null)).setCopyFrom(head);
		register(new Field<>(() -> model.field_3484 , v -> model.field_3484  = v, null));
		register(new Field<>(() -> model.field_3486, v -> model.field_3486 = v, null));
		register(new Field<>(() -> model.field_3482  , v -> model.field_3482   = v, null));
		register(new Field<>(() -> model.field_3479 , v -> model.field_3479  = v, null));
		register(new Field<>(() -> model.field_3483     , v -> model.field_3483      = v, null));

		register(new Field<>(() -> model.vrHMD, v -> model.vrHMD = v, null));//disable
		if(!seated) {
			VRPlayerModel_WithArms<class_742> w = (VRPlayerModel_WithArms<class_742>) model;
			register(new Field<>(() -> w.leftShoulder , v -> w.leftShoulder  = v, null));//disable
			register(new Field<>(() -> w.rightShoulder, v -> w.rightShoulder = v, null));//disable

			register(new Field<>(() -> w.leftShoulder_sleeve , v -> w.leftShoulder_sleeve  = v, null));//disable
			register(new Field<>(() -> w.rightShoulder_sleeve, v -> w.rightShoulder_sleeve = v, null));//disable
		}

		register(new Field<>(() -> model.field_3485, v -> model.field_3485 = v, RootModelType.CAPE));
	}

	@Override
	protected void setupTransform(MatrixStack stack, RedirectRenderer<class_630> part, boolean pre) {
		if(!pre && (leftArm == part || rightArm == part) && !seated) {
			stack.translate(0, -8 / 16f, 0);
		}
	}
}

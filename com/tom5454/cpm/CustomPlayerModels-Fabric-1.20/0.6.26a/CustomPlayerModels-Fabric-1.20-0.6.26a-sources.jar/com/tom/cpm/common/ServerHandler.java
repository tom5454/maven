package com.tom.cpm.common;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.MinecraftServerObject;
import com.tom.cpm.shared.MinecraftServerAccess;
import com.tom.cpm.shared.network.NetH;
import com.tom.cpm.shared.network.NetHandler;

public class ServerHandler extends ServerHandlerBase {
	public static NetHandler<class_2960, class_3222, class_3244> netHandler;

	public static MinecraftServer getServer() {
		return ((MinecraftServerObject)MinecraftServerAccess.get()).getServer();
	}

	static {
		netHandler = init();
		netHandler.setGetOnlinePlayers(() -> getServer().method_3760().method_14571());
		netHandler.setExecutor(n -> n.field_14148);
		if(CustomPlayerModels.isModLoaded("pehkui")) {
			netHandler.addScaler(new PehkuiInterface());
		}
	}

	public static void onPlayerJoin(class_3222 spe) {
		netHandler.onJoin(spe);
	}

	public static void onTrackingStart(class_1297 target, class_3222 spe) {
		class_3244 handler = spe.field_13987;
		NetH h = (NetH) handler;
		if(h.cpm$hasMod()) {
			if(target instanceof class_1657) {
				netHandler.sendPlayerData((class_3222) target, spe);
			}
		}
	}

	public static void jump(Object player) {
		if(player instanceof class_3222) {
			netHandler.onJump((class_3222) player);
		}
	}
}

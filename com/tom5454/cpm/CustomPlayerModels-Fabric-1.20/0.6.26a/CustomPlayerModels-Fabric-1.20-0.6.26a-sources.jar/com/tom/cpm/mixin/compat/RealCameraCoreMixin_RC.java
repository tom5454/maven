package com.tom.cpm.mixin.compat;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.xtracr.realcamera.RealCameraCore;
import net.minecraft.class_310;
import net.minecraft.class_4597;
import com.tom.cpm.client.RealCameraDetector;

@Mixin(RealCameraCore.class)
public class RealCameraCoreMixin_RC {

	@Inject(at = @At("HEAD"), method = "renderCameraEntity", remap = false)
	private static void onUpdateModelPre(final class_310 client, final float tickDelta, class_4597 buf, CallbackInfo cbi) {
		RealCameraDetector.realCameraRendering = true;
	}

	@Inject(at = @At("RETURN"), method = "renderCameraEntity", remap = false)
	private static void onUpdateModelPost(final class_310 client, final float tickDelta, class_4597 buf, CallbackInfo cbi) {
		RealCameraDetector.realCameraRendering = false;
	}
}

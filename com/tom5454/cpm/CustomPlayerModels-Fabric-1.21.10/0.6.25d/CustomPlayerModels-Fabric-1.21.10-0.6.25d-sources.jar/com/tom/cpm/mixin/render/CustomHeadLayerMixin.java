package com.tom.cpm.mixin.render;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.tom.cpm.client.CPMOrderedSubmitNodeCollector.CPMSubmitNodeCollector;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_11786;
import net.minecraft.class_1921;
import net.minecraft.class_2484;
import net.minecraft.class_3882;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_5598;
import net.minecraft.class_583;
import net.minecraft.class_9296;
import net.minecraft.class_976;

@Mixin(class_976.class)
public abstract class CustomHeadLayerMixin<S extends class_10042, M extends class_583<S> & class_3882> extends class_3887<S, M> {
	private @Shadow @Final class_11786 playerSkinRenderCache;

	public CustomHeadLayerMixin(class_3883<S, M> p_117346_) {
		super(p_117346_);
	}

	@Inject(at = @At(value = "INVOKE_ASSIGN", target = "Lnet/minecraft/client/renderer/entity/layers/CustomHeadLayer;resolveSkullRenderType(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lnet/minecraft/world/level/block/SkullBlock$Type;)Lnet/minecraft/client/renderer/RenderType;"), method = "submit")
	public void onSubmitPre(class_4587 p_433907_, class_11659 p_433246_, int p_435428_, S state,
			float p_434590_, float p_433023_, CallbackInfo cbi, @Local class_5598 model,
			@Local LocalRef<class_11659> snc, @Local LocalRef<class_1921> rt) {
		if (state.field_55315 != class_2484.class_2486.field_11510)return;
		class_9296 resolvableprofile = state.field_55316;
		if (resolvableprofile != null) {
			CPMSubmitNodeCollector.injectSNC(snc);
			var info = this.playerSkinRenderCache.method_73495(resolvableprofile);
			CustomPlayerModelsClient.INSTANCE.manager.bindSkull(info.method_73502(), null, model);
			ModelTexture mt = new ModelTexture(info.method_73503().comp_1626().comp_3627());
			CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.SKIN);
			rt.set(mt.getRenderType());
		}
	}

	@Inject(at =
			@At(value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/blockentity/SkullBlockRenderer;submitSkull("
					+ "Lnet/minecraft/core/Direction;FFLcom/mojang/blaze3d/vertex/PoseStack;"
					+ "Lnet/minecraft/client/renderer/SubmitNodeCollector;I"
					+ "Lnet/minecraft/client/model/SkullModelBase;Lnet/minecraft/client/renderer/RenderType;I"
					+ "Lnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;)V",
					shift = Shift.AFTER),
			method = "submit")
	public void onSubmitPost(class_4587 p_433907_, class_11659 p_433246_, int p_435428_, S state,
			float p_434590_, float p_433023_, CallbackInfo cbi, @Local class_5598 model) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().unbindModel(model);
	}
}

package com.tom.cpm.mixin.render;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_10186;
import net.minecraft.class_10186.class_10190;
import net.minecraft.class_10197;
import net.minecraft.class_10394;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4722;
import net.minecraft.class_5321;

@Mixin(class_10197.class)
public class EquipmentLayerRendererMixin {
	private static final String CPMRENDERLAYERSMETHOD = "renderLayers("
			+ "Lnet/minecraft/client/resources/model/EquipmentClientInfo$LayerType;"
			+ "Lnet/minecraft/resources/ResourceKey;Lnet/minecraft/client/model/Model;"
			+ "Ljava/lang/Object;Lnet/minecraft/world/item/ItemStack;"
			+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;"
			+ "ILnet/minecraft/resources/ResourceLocation;II)V";

	@Inject(at =
			@At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/renderer/OrderedSubmitNodeCollector;submitModel("
							+ "Lnet/minecraft/client/model/Model;Ljava/lang/Object;"
							+ "Lcom/mojang/blaze3d/vertex/PoseStack;"
							+ "Lnet/minecraft/client/renderer/RenderType;III"
							+ "Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;I"
							+ "Lnet/minecraft/client/renderer/feature/ModelFeatureRenderer$CrumblingOverlay;"
							+ ")V",
							shift = Shift.BEFORE,
							ordinal = 2
					),
			method = CPMRENDERLAYERSMETHOD)
	private <S> void onSumbitArmorTrim(
			class_10186.class_10190 layerType,
			class_5321<class_10394> p_387603_,
			class_3879<? super S> model,
			S p_435806_,
			class_1799 p_371670_,
			class_4587 p_371767_,
			class_11659 p_435795_,
			int p_371309_,
			@Nullable class_2960 p_371639_,
			int p_435821_,
			int p_436591_,
			CallbackInfo cbi
			) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, new ModelTexture(class_4722.field_42071, PlayerRenderManager.armor), layerType == class_10190.field_54126 ? TextureSheetType.ARMOR2 : TextureSheetType.ARMOR1);
	}

	@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/RenderType;armorCutoutNoCull(Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;", shift = Shift.BEFORE), method = CPMRENDERLAYERSMETHOD)
	public void grabTexture(
			class_10186.class_10190 layerType,
			class_5321<class_10394> p_387603_,
			class_3879<Object> model,
			Object p_435806_,
			class_1799 p_371670_,
			class_4587 p_371767_,
			class_11659 p_435795_,
			int p_371309_,
			@Nullable class_2960 p_371639_,
			int p_435821_,
			int p_436591_,
			CallbackInfo cbi,
			@Local(ordinal = 1) LocalRef<class_2960> resourceLocation2) {
		if (layerType == class_10190.field_54125 || layerType == class_10190.field_54126) {
			CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, new ModelTexture(resourceLocation2.get(), PlayerRenderManager.armor), layerType == class_10190.field_54126 ? TextureSheetType.ARMOR2 : TextureSheetType.ARMOR1);
		} else if (layerType == class_10190.field_54127) {
			ModelTexture mt = new ModelTexture(resourceLocation2.get());
			CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.ELYTRA);
			resourceLocation2.set(mt.getTexture());
		}
	}
}

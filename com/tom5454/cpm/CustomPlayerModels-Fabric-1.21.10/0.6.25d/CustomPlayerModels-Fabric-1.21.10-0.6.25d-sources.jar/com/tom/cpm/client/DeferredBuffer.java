package com.tom.cpm.client;

import java.util.function.BiFunction;
import net.minecraft.class_11659;
import net.minecraft.class_1921;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

// TODO move into main source
public class DeferredBuffer implements BiFunction<class_11659, class_1921, class_4588> {
	private class_4587 dummy = new class_4587();

	@Override
	public class_4588 apply(class_11659 t, class_1921 u) {
		t.method_73483(dummy, u, (__, vc) -> {

		});
		return null;
	}

}

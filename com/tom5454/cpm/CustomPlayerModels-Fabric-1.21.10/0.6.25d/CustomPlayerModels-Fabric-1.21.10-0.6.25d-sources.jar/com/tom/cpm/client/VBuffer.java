package com.tom.cpm.client;

import com.tom.cpl.render.DirectBuffer;
import net.minecraft.class_4587;
import net.minecraft.class_4587.class_4665;
import net.minecraft.class_4588;

public class VBuffer extends DirectBuffer<class_4588> {
	private int light, overlay;
	private class_4665 pose;

	public VBuffer(class_4588 buffer, int light, int overlay, class_4587 matrixStackIn) {
		super(buffer);
		this.light = light;
		this.overlay = overlay;
		pose = matrixStackIn.method_23760().method_56822();
	}

	public VBuffer(class_4588 buffer, int light, int overlay, class_4665 poseIn) {
		super(buffer);
		this.light = light;
		this.overlay = overlay;
		this.pose = poseIn;
	}

	@Override
	protected void pushVertex(float x, float y, float z, float red, float green,
			float blue, float alpha, float u, float v, float nx, float ny, float nz) {
		buffer.method_56824(pose, x, y, z);
		buffer.method_22915(red, green, blue, alpha);
		buffer.method_22913(u, v);
		buffer.method_22922(overlay);
		buffer.method_60803(light);
		buffer.method_60831(pose, nx, ny, nz);
	}

	@Override
	public void finish() {}
}

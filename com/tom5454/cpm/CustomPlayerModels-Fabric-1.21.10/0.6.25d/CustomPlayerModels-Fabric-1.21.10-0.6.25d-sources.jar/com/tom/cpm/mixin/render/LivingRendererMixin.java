package com.tom.cpm.mixin.render;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.tom.cpm.client.LivingRendererAccess;
import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;

@Mixin(class_922.class)
public abstract class LivingRendererMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>> extends class_897<T, S> implements LivingRendererAccess {

	protected LivingRendererMixin(class_5618 p_174008_) {
		super(p_174008_);
	}

	@Inject(at = @At("HEAD"), method = "getRenderType(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/renderer/RenderType;", cancellable = true)
	public void onGetRenderType(class_10042 player, boolean pBodyVisible, boolean pTranslucent, boolean pGlowing, CallbackInfoReturnable<class_1921> cbi) {
		if(!pBodyVisible) {
			cpm$onGetRenderType(player, pTranslucent, pGlowing, cbi);
		}
	}
}

package com.tom.cpm.client;

import java.util.List;
import net.minecraft.class_10017;
import net.minecraft.class_10017.class_10018;
import net.minecraft.class_10017.class_11680;
import net.minecraft.class_10444.class_10445;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_10933;
import net.minecraft.class_11659;
import net.minecraft.class_11659.class_11660;
import net.minecraft.class_11659.class_11947;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_11785;
import net.minecraft.class_11791;
import net.minecraft.class_12075;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_327.class_6415;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_5481;
import net.minecraft.class_630;
import net.minecraft.class_777;
import net.minecraft.class_811;
import org.joml.Quaternionf;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.tom.cpm.client.SelfRenderer.RenderCollector;

public class CPMOrderedSubmitNodeCollector implements class_11785 {
	private final class_11785 collector;

	public CPMOrderedSubmitNodeCollector(class_11785 collector) {
		this.collector = collector;
	}

	@Override
	public void method_73487(class_4587 p_438906_, class_10017 p_439622_, class_10933 p_439768_) {
		collector.method_73487(p_438906_, p_439622_, p_439768_);
	}

	@Override
	public void method_73479(class_4587 p_439112_, float p_439891_, List<class_11680> p_439759_) {
		collector.method_73479(p_439112_, p_439891_, p_439759_);
	}

	@Override
	public void method_73482(class_4587 p_439537_, class_243 p_439628_, int p_439109_, class_2561 p_439200_,
			boolean p_439687_, int p_451645_, double p_440364_, class_12075 p_451474_) {
		collector.method_73482(p_439537_, p_439628_, p_439109_, p_439200_, p_439687_, p_451645_, p_440364_, p_451474_);
	}

	@Override
	public void method_73478(class_4587 p_440112_, float p_439364_, float p_439156_, class_5481 p_438924_,
			boolean p_440612_, class_6415 p_439113_, int p_440164_, int p_439316_, int p_440620_, int p_440227_) {
		collector.method_73478(p_440112_, p_439364_, p_439156_, p_438924_, p_440612_, p_439113_, p_440164_, p_439316_,
				p_440620_, p_440227_);
	}

	@Override
	public void method_73488(class_4587 p_440539_, class_10017 p_440393_, Quaternionf p_439403_) {
		collector.method_73488(p_440539_, p_440393_, p_439403_);
	}

	@Override
	public void method_73486(class_4587 p_440528_, class_10018 p_440576_) {
		collector.method_73486(p_440528_, p_440576_);
	}

	@Override
	public <S> void method_73490(class_3879<? super S> model, S state, class_4587 pose, class_1921 type,
			int light, int overlay, int tint, class_1058 sprite, int outline,
			class_11792 p_439871_) {
		if (model.method_63512() instanceof SelfRenderer sr) {
			model.method_2819(state);
			sr.submitSelf(new RenderCollector(pose, collector, type, light, overlay, tint, outline, sprite, state));
		} else
			collector.method_73490(model, state, pose, type, light, overlay, tint, sprite,
					outline, p_439871_);
	}

	@Override
	public <S> void method_73489(class_3879<? super S> model, S state, class_4587 pose, class_1921 type,
			int light, int overlay, int outline, class_11792 p_439732_) {
		if (model.method_63512() instanceof SelfRenderer sr) {
			model.method_2819(state);
			sr.submitSelf(new RenderCollector(pose, collector, type, light, overlay, -1, outline, null, state));
		} else
			collector.method_73489(model, state, pose, type, light, overlay, outline, p_439732_);
	}

	@Override
	public void method_73491(class_630 part, class_4587 pose, class_1921 type, int light,
			int overlay, class_1058 sprite) {
		if (part instanceof SelfRenderer sr) {
			sr.submitSelf(new RenderCollector(pose, collector, type, light, overlay, -1, 0, sprite, null));
		} else
			collector.method_73491(part, pose, type, light, overlay, sprite);
	}

	@Override
	public void method_73492(class_630 part, class_4587 pose, class_1921 type, int light,
			int overlay, class_1058 sprite, int tint, class_11792 p_442691_) {
		if (part instanceof SelfRenderer sr) {
			sr.submitSelf(new RenderCollector(pose, collector, type, light, overlay, tint, 0, sprite, null));
		} else
			collector.method_73492(part, pose, type, light, overlay, sprite, tint,
					p_442691_);
	}

	@Override
	public void method_73493(class_630 part, class_4587 pose, class_1921 type, int light,
			int overlay, class_1058 sprite, boolean p_438944_, boolean p_440215_) {
		if (part instanceof SelfRenderer sr) {
			sr.submitSelf(new RenderCollector(pose, collector, type, light, overlay, -1, 0, sprite, null));
		} else
			collector.method_73493(part, pose, type, light, overlay, sprite, p_438944_,
					p_440215_);
	}

	@Override
	public void method_73494(class_630 part, class_4587 pose, class_1921 type, int light,
			int overlay, class_1058 sprite, boolean p_439080_, boolean p_438989_, int tint,
			class_11792 p_442896_, int outline) {
		if (part instanceof SelfRenderer sr) {
			sr.submitSelf(new RenderCollector(pose, collector, type, light, overlay, tint, outline, sprite, null));
		} else
			collector.method_73494(part, pose, type, light, overlay, sprite, p_439080_,
					p_438989_, tint, p_442896_, outline);
	}

	@Override
	public void method_73481(class_4587 p_438936_, class_2680 p_439547_, int p_440601_, int p_440032_, int p_440736_) {
		collector.method_73481(p_438936_, p_439547_, p_440601_, p_440032_, p_440736_);
	}

	@Override
	public void method_73485(class_4587 p_439854_, class_11791 p_440284_) {
		collector.method_73485(p_439854_, p_440284_);
	}

	@Override
	public void method_73484(class_4587 p_439157_, class_1921 p_440628_, class_1087 p_439853_, float p_440368_,
			float p_440148_, float p_440307_, int p_440602_, int p_440529_, int p_440743_) {
		collector.method_73484(p_439157_, p_440628_, p_439853_, p_440368_, p_440148_, p_440307_, p_440602_,
				p_440529_, p_440743_);
	}

	@Override
	public void method_73480(class_4587 p_439086_, class_811 p_439900_, int p_439678_, int p_440575_,
			int p_440740_, int[] p_440087_, List<class_777> p_440405_, class_1921 p_440525_, class_10445 p_438984_) {
		collector.method_73480(p_439086_, p_439900_, p_439678_, p_440575_, p_440740_, p_440087_, p_440405_, p_440525_,
				p_438984_);
	}

	@Override
	public void method_73483(class_4587 p_440145_, class_1921 p_440184_, class_11660 p_439967_) {
		collector.method_73483(p_440145_, p_440184_, p_439967_);
	}

	@Override
	public void method_74315(class_11947 p_445517_) {
		collector.method_74315(p_445517_);
	}

	public static class CPMSubmitNodeCollector extends CPMOrderedSubmitNodeCollector implements class_11659 {
		private final class_11659 collector;

		public CPMSubmitNodeCollector(class_11659 collector) {
			super(collector);
			this.collector = collector;
		}

		@Override
		public class_11785 method_73529(int order) {
			return new CPMOrderedSubmitNodeCollector(collector.method_73529(order));
		}

		public static void injectSNC(LocalRef<class_11659> snc) {
			var collector = snc.get();
			if (collector instanceof CPMSubmitNodeCollector)return;
			snc.set(new CPMSubmitNodeCollector(collector));
		}
	}
}

package com.tom.cpm.client;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.BooleanSupplier;
import net.minecraft.class_10055;
import net.minecraft.class_1068;
import net.minecraft.class_11890;
import net.minecraft.class_1304;
import net.minecraft.class_156;
import net.minecraft.class_1747;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_2190;
import net.minecraft.class_310;
import net.minecraft.class_4050;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTextures;
import com.mojang.authlib.properties.PropertyMap;

import com.tom.cpl.block.entity.ActiveEffect;
import com.tom.cpl.math.MathHelper;
import com.tom.cpl.util.Hand;
import com.tom.cpl.util.HandAnimation;
import com.tom.cpm.client.vr.VRPlayerRenderer;
import com.tom.cpm.common.EntityTypeHandlerImpl;
import com.tom.cpm.common.PlayerInventory;
import com.tom.cpm.common.WorldImpl;
import com.tom.cpm.mixinplugin.FPMDetector;
import com.tom.cpm.shared.animation.AnimationState;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.model.SkinType;
import com.tom.cpm.shared.model.render.PlayerModelSetup.ArmPose;
import com.tom.cpm.shared.skin.PlayerTextureLoader;
import com.tom.cpm.shared.skin.TextureType;

public class PlayerProfile extends Player<class_11890> {
	public static boolean inGui;
	public static BooleanSupplier inFirstPerson;
	static {
		inFirstPerson = () -> false;
		if (FPMDetector.doApply()) {
			FirstPersonDetector.init();
		}
	}

	private final GameProfile profile;
	private String skinType;

	public static GameProfile getPlayerProfile(class_11890 avatar) {
		if (avatar == null)return null;
		if (avatar instanceof class_742 player) {
			var profile = player.method_7334();
			if (profile.properties().isEmpty()) {
				var conn = class_310.method_1551().method_1562();
				if (conn != null) {
					var info = conn.method_2871(profile.id());
					if(info != null)profile = info.method_2966();
				}
			}
			return profile;
		} else if (avatar instanceof MannequinAccess man) {
			var info = man.cpm$getInfo();
			if (info != null)
				return info.method_73502();
		}

		return new GameProfile(avatar.method_5667(), avatar.method_5820());
	}

	public PlayerProfile(GameProfile profile) {
		this.profile = new GameProfile(profile.id(), profile.name(), new PropertyMap(cloneProperties(profile.properties())));

		if(profile.id() != null)
			this.skinType = class_1068.method_4648(profile.id()).comp_1629().method_15434();
	}

	@Override
	public SkinType getSkinType() {
		return SkinType.get(skinType);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((profile == null) ? 0 : profile.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		PlayerProfile other = (PlayerProfile) obj;
		if (profile == null) {
			if (other.profile != null) return false;
		} else if (!profile.equals(other.profile)) return false;
		return true;
	}

	@Override
	public UUID getUUID() {
		return profile.id();
	}

	@Override
	public void updateFromPlayer(AnimationState animState, class_11890 player) {
		class_4050 p = player.method_18376();
		animState.resetPlayer();
		switch (p) {
		case field_18077:
			animState.elytraFlying = true;
			break;
		case field_18078:
			animState.sleeping = true;
			break;
		case field_18080:
			animState.tridentSpin = true;
			break;
		default:
			break;
		}
		animState.sneaking = player.method_18276();
		animState.crawling = player.method_20448();
		animState.swimming = player.method_20232();
		if(!player.method_5805())animState.dying = true;
		if(Platform.isSitting(player))animState.riding = true;
		if(player.method_5624())animState.sprinting = true;
		if(player.method_6115()) {
			animState.usingAnimation = HandAnimation.of(player.method_6030().method_7976());
		}
		if(player.method_5799())animState.retroSwimming = true;
		animState.moveAmountX = (float) (player.method_23317() - player.field_6014);
		animState.moveAmountY = (float) (player.method_23318() - player.field_6036);
		animState.moveAmountZ = (float) (player.method_23321() - player.field_5969);
		animState.yaw = player.method_36454();
		animState.pitch = player.method_36455();
		animState.bodyYaw = player.field_6283;

		animState.encodedState = MinecraftObject.LAYER_CODEC.getValue(player::method_74091);

		class_1799 is = player.method_6118(class_1304.field_6169);
		animState.hasSkullOnHead = is.method_7909() instanceof class_1747 && ((class_1747)is.method_7909()).method_7711() instanceof class_2190;
		animState.wearingHelm = !is.method_7960();
		is = player.method_6118(class_1304.field_6174);
		animState.wearingElytra = is.method_58694(class_9334.field_54197) != null;
		animState.wearingBody = !is.method_7960();
		animState.wearingLegs = !player.method_6118(class_1304.field_6172).method_7960();
		animState.wearingBoots = !player.method_6118(class_1304.field_6166).method_7960();
		animState.mainHand = Hand.of(player.method_6068());
		animState.activeHand = Hand.of(animState.mainHand, player.method_6058());
		animState.swingingHand = Hand.of(animState.mainHand, player.field_6266);
		animState.hurtTime = player.field_6235;
		animState.isOnLadder = player.method_6101();
		animState.isBurning = player.method_5862();
		animState.isFreezing = player.method_32312() > 0;
		animState.inGui = inGui;
		animState.firstPersonMod = inFirstPerson.getAsBoolean();
		if (player instanceof class_742 pl) {
			PlayerInventory.setInv(animState, pl.method_31548());
		} else {
			// Emulate equipment
		}
		WorldImpl.setWorld(animState, player);
		if (player.method_5854() != null)animState.vehicle = EntityTypeHandlerImpl.impl.wrap(player.method_5854().method_5864());
		player.method_6026().forEach(e -> animState.allEffects.add(new ActiveEffect(class_7923.field_41174.method_10221(e.method_5579().comp_349()).toString(), e.method_5578(), e.method_5584(), !e.method_5581())));

		if(player.method_6030().method_7909() instanceof class_1764) {
			float f = class_1764.method_7775(player.method_6030(), player);
			float f1 = MathHelper.clamp(player.method_6048(), 0.0F, f);
			animState.crossbowPullback = f1 / f;
		}

		if(player.method_6030().method_7909() instanceof class_1753) {
			float f = 20F;
			float f1 = MathHelper.clamp(player.method_6048(), 0.0F, f);
			animState.bowPullback = f1 / f;
		}
	}

	@Override
	public void updateFromModel(AnimationState animState, Object model) {
		if(model instanceof class_591) {
			if(CustomPlayerModelsClient.vrLoaded)
				animState.vrState = VRPlayerRenderer.getVRState(animState.animationMode, model);
			else
				animState.vrState = null;
		}
	}

	public void updateFromState(AnimationState animState, class_10055 state) {
		animState.resetModel();
		animState.attackTime = state.field_53404;
		animState.swimAmount = state.field_53403;
		animState.leftArm = ArmPose.of(state.field_55306);
		animState.rightArm = ArmPose.of(state.field_55304);
		animState.parrotLeft = state.field_53526 != null;
		animState.parrotRight = state.field_53527 != null;
	}

	@Override
	protected PlayerTextureLoader initTextures() {
		var cache = class_310.method_1551().method_1582().field_45635.field_45640.toFile();
		return new PlayerTextureLoader(cache) {

			@Override
			protected CompletableFuture<Void> load0() {
				return CompletableFuture.supplyAsync(() -> {
					class_310 mc = class_310.method_1551();
					var mss = mc.method_73361().comp_837();
					var pt = mss.getPackedTextures(profile);
					if (pt == null)return MinecraftProfileTextures.EMPTY;
					var mpts = mss.unpackTextures(pt);
					return mpts;
				}, class_156.method_18349().method_64116("CPM:unpackSkinTextures")).thenAcceptAsync(mpts -> {
					var skin = mpts.skin();
					var cape = mpts.cape();
					var elytra = mpts.elytra();
					if (skin != null) {
						skinType = skin.getMetadata("model");
						defineTexture(TextureType.SKIN, skin.getUrl(), skin.getHash());
					}
					if (cape != null) {
						defineTexture(TextureType.CAPE, cape.getUrl(), cape.getHash());
					}
					if (elytra != null) {
						defineTexture(TextureType.ELYTRA, elytra.getUrl(), elytra.getHash());
					}
				}, t -> class_310.method_1551().method_63588(t::run));
			}
		};
	}

	@Override
	public String getName() {
		return profile.name();
	}

	@Override
	public Object getGameProfile() {
		return profile;
	}
}

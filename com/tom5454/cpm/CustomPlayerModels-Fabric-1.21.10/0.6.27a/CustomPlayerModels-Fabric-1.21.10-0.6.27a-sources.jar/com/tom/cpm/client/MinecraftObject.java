package com.tom.cpm.client;

import java.io.File;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1068;
import net.minecraft.class_1664;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_526;
import net.minecraft.class_634;
import net.minecraft.class_640;
import com.mojang.authlib.GameProfile;
import com.tom.cpl.block.BiomeHandler;
import com.tom.cpl.gui.Frame;
import com.tom.cpl.gui.IGui;
import com.tom.cpl.gui.IKeybind;
import com.tom.cpl.render.RenderTypeBuilder;
import com.tom.cpl.tag.AllTagManagers;
import com.tom.cpl.util.DynamicTexture.ITexture;
import com.tom.cpl.util.Image;
import com.tom.cpl.util.ImageIO.IImageIO;
import com.tom.cpm.common.BiomeHandlerImpl;
import com.tom.cpm.shared.MinecraftClientAccess;
import com.tom.cpm.shared.MinecraftObjectHolder;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import com.tom.cpm.shared.model.SkinType;
import com.tom.cpm.shared.model.render.RenderMode;
import com.tom.cpm.shared.network.ModelEventType;
import com.tom.cpm.shared.network.NetH;
import com.tom.cpm.shared.network.NetHandler;
import com.tom.cpm.shared.util.MojangAPI;
import com.tom.cpm.shared.util.SkinLayerCodec;

public class MinecraftObject implements MinecraftClientAccess {
	private final ModelDefinitionLoader<GameProfile> loader;
	private final PlayerRenderManager prm;
	private AllTagManagers tags;
	public RenderTypeBuilder<class_2960, class_1921> renderBuilder;

	public static final SkinLayerCodec<class_1664> LAYER_CODEC = new SkinLayerCodec<>(new class_1664[] {
			class_1664.field_7563,
			class_1664.field_7564,
			class_1664.field_7566,
			class_1664.field_7565,
			class_1664.field_7568,
			class_1664.field_7570,
	});

	public MinecraftObject() {
		MinecraftObjectHolder.setClientObject(this);
		loader = new ModelDefinitionLoader<>(PlayerProfile::new, GameProfile::id, GameProfile::name);
		prm = new PlayerRenderManager();
		renderBuilder = new RenderTypeBuilder<>();
		renderBuilder.register(RenderMode.DEFAULT, class_1921::method_23580, 0);
		renderBuilder.register(RenderMode.GLOW, CustomRenderTypes::glowingEyes, 1);
		renderBuilder.register(RenderMode.COLOR, CustomRenderTypes::entityColorTranslucent, 0);
		renderBuilder.register(RenderMode.COLOR_GLOW, CustomRenderTypes::entityColorEyes, 1);
		renderBuilder.register(RenderMode.OUTLINE, CustomRenderTypes::linesNoDepth, 2);
	}

	public void setTags(AllTagManagers tags) {
		this.tags = tags;
	}

	@Override
	public PlayerRenderManager getPlayerRenderManager() {
		return prm;
	}

	@Override
	public ITexture createTexture() {
		return new DynTexture();
	}

	public static class DynTexture implements ITexture {
		private static int ID = 0;
		private class_1043 dynTex;
		private class_2960 loc;
		private static class_2960 bound_loc;
		private class_310 mc = class_310.method_1551();

		@Override
		public void bind() {
			if (loc == null)return;//No data
			bound_loc = loc;
			if(mc.method_1531().method_4619(loc) == null)
				mc.method_1531().method_4616(loc, dynTex);
		}

		@Override
		public void load(Image texture) {
			if (loc == null || dynTex.method_68004().getWidth(0) != texture.getWidth() || dynTex.method_68004().getHeight(0) != texture.getHeight()) {
				if (loc != null) {
					mc.method_1531().method_4615(loc);
				}

				int id = ID++;
				dynTex = new class_1043("CPM Dynamic Texture #" + id, texture.getWidth(), texture.getHeight(), true);
				loc = class_2960.method_60655("cpm", "dyn_" + id);
				mc.method_1531().method_4616(loc, dynTex);
			}

			class_1011 ni = NativeImageIO.createFromBufferedImage(texture);
			dynTex.method_4526(ni);
			dynTex.method_4524();
		}

		public static class_2960 getBoundLoc() {
			return bound_loc;
		}

		@Override
		public void free() {
			if (loc != null)
				mc.method_1531().method_4615(loc);
		}
	}

	@Override
	public void executeOnGameThread(Runnable r) {
		class_310.method_1551().execute(r);
	}

	@Override
	public void executeNextFrame(Runnable r) {
		class_310.method_1551().method_63588(r);
	}

	@Override
	public ModelDefinitionLoader<GameProfile> getDefinitionLoader() {
		return loader;
	}

	@Override
	public SkinType getSkinType() {
		return SkinType.get(class_1068.method_4648(class_310.method_1551().method_1548().method_44717()).comp_1629().method_15434());
	}

	@Override
	public int getEncodedGesture() {
		Set<class_1664> s = class_310.method_1551().field_1690.field_1892;
		return LAYER_CODEC.getValue(s::contains);
	}

	@Override
	public void setEncodedGesture(int value) {
		Set<class_1664> s = class_310.method_1551().field_1690.field_1892;
		LAYER_CODEC.setValue(value, s);
		class_310.method_1551().field_1690.method_1643();
	}

	@Override
	public boolean isInGame() {
		return class_310.method_1551().field_1724 != null;
	}

	@Override
	public Object getPlayerIDObject() {
		return class_310.method_1551().method_53462();
	}

	@Override
	public Object getCurrentPlayerIDObject() {
		var mc = class_310.method_1551();
		return PlayerProfile.getPlayerProfile(mc.field_1724);
	}

	@Override
	public List<IKeybind> getKeybinds() {
		return KeyBindings.kbs;
	}

	@Override
	public ServerStatus getServerSideStatus() {
		var mc = class_310.method_1551();
		class_634 conn = mc.method_1562();
		return mc.field_1724 != null ? conn instanceof NetH && ((NetH)conn).cpm$hasMod() ? ServerStatus.INSTALLED : ServerStatus.SKIN_LAYERS_ONLY : ServerStatus.OFFLINE;
	}

	@Override
	public File getGameDir() {
		return class_310.method_1551().field_1697;
	}

	@Override
	public void openGui(Function<IGui, Frame> creator) {
		var mc = class_310.method_1551();
		mc.method_1507(new GuiImpl(creator, mc.field_1755));
	}

	@Override
	public Runnable openSingleplayer() {
		var mc = class_310.method_1551();
		return () -> mc.method_1507(new class_526(mc.field_1755));
	}

	@Override
	public NetHandler<?, ?, ?> getNetHandler() {
		return CustomPlayerModelsClient.INSTANCE.netHandler;
	}

	@Override
	public IImageIO getImageIO() {
		return new NativeImageIO();
	}

	@Override
	public MojangAPI getMojangAPI() {
		var mc = class_310.method_1551();
		return new MojangAPI(mc.method_1548().method_1676(), mc.method_1548().method_44717(), mc.method_1548().method_1674());
	}

	@Override
	public void clearSkinCache() {
		MojangAPI.clearYggdrasilCache(class_310.method_1551().method_73361().comp_837());
		//mc.getGameProfile().clear();
		//mc.getGameProfile();//refresh TODO
	}

	@Override
	public String getConnectedServer() {
		if(class_310.method_1551().method_1562() == null)return null;
		SocketAddress sa = Platform.getChannel(class_310.method_1551().method_1562().method_48296()).remoteAddress();
		if(sa instanceof InetSocketAddress)
			return ((InetSocketAddress)sa).getHostString();
		return null;
	}

	@Override
	public List<Object> getPlayers() {
		if(class_310.method_1551().method_1562() == null)return Collections.emptyList();
		return class_310.method_1551().method_1562().method_2880().stream().map(class_640::method_2966).collect(Collectors.toList());
	}

	@Override
	public Proxy getProxy() {
		return class_310.method_1551().method_1487();
	}

	@Override
	public RenderTypeBuilder<?, ?> getRenderBuilder() {
		return renderBuilder;
	}

	@Override
	public AllTagManagers getBuiltinTags() {
		return tags;
	}

	@Override
	public BiomeHandler<?> getBiomeHandler() {
		return BiomeHandlerImpl.clientImpl;
	}

	@Override
	public boolean requiresSelfEventForAnimation(ModelEventType type) {
		return type == ModelEventType.FALLING;
	}
}

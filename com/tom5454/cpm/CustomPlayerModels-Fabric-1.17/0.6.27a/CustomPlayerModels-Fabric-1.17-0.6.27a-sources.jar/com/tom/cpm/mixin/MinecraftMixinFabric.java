package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.GuiImpl;
import com.tom.cpm.shared.editor.gui.EditorGui;
import net.minecraft.class_310;
import net.minecraft.class_317;
import net.minecraft.class_437;
import net.minecraft.class_442;

@Mixin(class_310.class)
public abstract class MinecraftMixinFabric {

	@Shadow private boolean pause;
	@Shadow private float pausePartialTick;
	@Shadow private class_317 timer;
	@Shadow public class_437 screen;
	@Shadow public abstract void setScreen(class_437 screen);

	@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/util/profiling/ProfilerFiller;popPush(Ljava/lang/String;)V"), method = "runTick(Z)V")
	public void onRenderTick(boolean v, CallbackInfo cbi) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().getAnimationEngine().update(this.pause ? this.pausePartialTick : this.timer.field_1970);
	}

	@Inject(at = @At("HEAD"), method = "setScreen(Lnet/minecraft/client/gui/screens/Screen;)V", cancellable = true)
	public void onSetScreen(class_437 screen, CallbackInfo cbi) {
		if(screen == null && this.screen instanceof GuiImpl.Overlay) {
			cbi.cancel();
			setScreen(((GuiImpl.Overlay)this.screen).getGui());
		}
		if(screen instanceof class_442 && EditorGui.doOpenEditor()) {
			cbi.cancel();
			setScreen(new GuiImpl(EditorGui::new, screen));
		}
		if(screen instanceof GuiImpl i)i.onOpened();
	}

	@Inject(at = @At("HEAD"), method = "clearLevel(Lnet/minecraft/client/gui/screens/Screen;)V")
	public void onDisconnect(class_437 screen, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.onLogout();
	}
}

package com.tom.cpm.client;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4080;
import com.tom.cpl.tag.TagManager;
import com.tom.cpm.shared.MinecraftObjectHolder;
import com.tom.cpm.shared.util.ErrorLog;
import com.tom.cpm.shared.util.ErrorLog.LogLevel;

public class CPMTagLoader extends class_4080<Map<String, List<Map<String, Object>>>> {
	private final TagManager<?> tags;
	protected final String prefix;
	protected final class_2960 id;

	public CPMTagLoader(Consumer<CPMTagLoader> mc, TagManager<?> tags, String prefix) {
		this.tags = tags;
		this.prefix = prefix;
		this.id = new class_2960("cpm", "tags_" + prefix);
		mc.accept(this);
	}

	@Override
	protected Map<String, List<Map<String, Object>>> method_18789(class_3300 mngr, class_3695 profiler) {
		return load(mngr);
	}

	@Override
	protected void apply(Map<String, List<Map<String, Object>>> tagMap, class_3300 mngr, class_3695 profiler) {
		tags.applyBuiltin(tagMap, prefix);
	}

	@SuppressWarnings("unchecked")
	private Map<String, List<Map<String, Object>>> load(class_3300 mngr) {
		Map<String, List<Map<String, Object>>> el = new HashMap<>();
		mngr.method_14488("cpm_tags/" + prefix, l -> l.endsWith(".json")).forEach(rl -> {
			List<Map<String, Object>> res = new ArrayList<>();
			el.put(rl.method_12836() + ":" + rl.method_12832().substring(9, rl.method_12832().length() - 5), res);
			try {
				for (class_3298 r : mngr.method_14489(rl)) {
					try (
							class_3298 iresource = r;
							InputStream inputstream = iresource.method_14482();
							Reader rd = new BufferedReader(new InputStreamReader(inputstream, StandardCharsets.UTF_8))
							) {
						Map<String, Object> tag = (Map<String, Object>) MinecraftObjectHolder.gson.fromJson(rd, Object.class);
						res.add(tag);
					}
				}
			} catch (Exception e) {
				ErrorLog.addLog(LogLevel.WARNING, "Failed to load cpm builtin tag: " + rl, e);
			}
		});
		return el;
	}
}

package com.tom.cpm.client;

import com.tom.cpm.shared.model.render.BatchedBuffers.BufferOutput;
import net.minecraft.class_1159;
import net.minecraft.class_4581;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

public class VBufferOut implements BufferOutput<class_4588> {
	private int light, overlay;
	private class_1159 mat4;
	private class_4581 mat3;

	public VBufferOut(int light, int overlay, class_4587 matrixStackIn) {
		this.light = light;
		this.overlay = overlay;
		mat4 = new class_1159(matrixStackIn.method_23760().method_23761());
		mat3 = new class_4581(matrixStackIn.method_23760().method_23762());
	}

	@Override
	public void push(class_4588 buffer, float x, float y, float z, float red, float green,
			float blue, float alpha, float u, float v, float nx, float ny, float nz) {
		buffer.method_22918(mat4, x, y, z);
		buffer.method_22915(red, green, blue, alpha);
		buffer.method_22913(u, v);
		buffer.method_22922(overlay);
		buffer.method_22916(light);
		buffer.method_23763(mat3, nx, ny, nz);
		buffer.method_1344();
	}
}

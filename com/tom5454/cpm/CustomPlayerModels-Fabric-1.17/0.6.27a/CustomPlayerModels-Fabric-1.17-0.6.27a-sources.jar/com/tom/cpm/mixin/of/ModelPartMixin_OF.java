package com.tom.cpm.mixin.of;

import java.util.List;
import java.util.Map;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import com.tom.cpm.client.optifine.proxy.ModelPartOF;

@Mixin(class_630.class)
public class ModelPartMixin_OF implements ModelPartOF {

	@Shadow(remap = false)
	public List<class_630> childModelsList;

	@Shadow
	public @Final Map<String, class_630> children;

	@Override
	public void cpm$updateChildModelsList() {
		childModelsList.clear();
		childModelsList.addAll(children.values());
	}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpl.util.NettyByteBufInputStream;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.shared.MinecraftObjectHolder;
import com.tom.cpm.shared.network.NetH;
import net.minecraft.class_2658;
import net.minecraft.class_634;

@Mixin(class_634.class)
public class ClientPacketListenerMixin implements NetH {
	private boolean cpm$hasMod;

	@Override
	public boolean cpm$hasMod() {
		return cpm$hasMod;
	}

	@Override
	public void cpm$setHasMod(boolean v) {
		this.cpm$hasMod = v;
	}

	@Inject(at = @At("HEAD"), method = "handleCustomPayload(Lnet/minecraft/network/protocol/game/ClientboundCustomPayloadPacket;)V", cancellable = true)
	public void onHandleCustomPayload(class_2658 packet, CallbackInfo cbi) {
		if(packet.method_11456().method_12836().equals(MinecraftObjectHolder.NETWORK_ID)) {
			CustomPlayerModelsClient.INSTANCE.netHandler.receiveClient(packet.method_11456(), new NettyByteBufInputStream(packet.method_11458()), this);
			cbi.cancel();
		}
	}
}

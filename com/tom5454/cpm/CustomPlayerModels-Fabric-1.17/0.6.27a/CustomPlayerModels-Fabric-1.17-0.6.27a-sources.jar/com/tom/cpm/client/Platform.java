package com.tom.cpm.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1159;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_339;
import io.netty.channel.Channel;

public class Platform {

	public static void initPlayerProfile() {
		if (FabricLoader.getInstance().isModLoaded("firstperson"))
			FirstPersonDetector.init();
	}

	public static class_1159 createMatrix(float[] array) {
		return Mat4Access.load(array);
	}

	public static interface Mat4Access {
		void cpm$loadValue(float[] data);

		static class_1159 load(float[] data) {
			class_1159 m = new class_1159();
			((Mat4Access) (Object) m).cpm$loadValue(data);
			return m;
		}
	}

	public static boolean isSitting(class_1657 player) {
		return player.method_5765();
	}

	public static void setHeight(class_339 w, int h) {
		w.field_22759 = h;
	}

	public static Channel getChannel(class_2535 conn) {
		return conn.field_11651;
	}
}

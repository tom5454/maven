package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.TextureSheetType;
import com.tom.cpm.shared.model.render.ModelRenderManager.BoundPlayer;
import net.minecraft.class_1304;
import net.minecraft.class_1664;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_972;

@Mixin(class_972.class)
public abstract class CapeLayerMixin extends class_3887<class_742, class_591<class_742>> {

	public CapeLayerMixin(class_3883<class_742, class_591<class_742>> p_116602_) {
		super(p_116602_);
	}

	@Inject(at = @At("HEAD"), method = "render"
			+ "(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I"
			+ "Lnet/minecraft/client/player/AbstractClientPlayer;FFFFFF)V", cancellable = true)
	public void onRender(class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn,
			class_742 entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks,
			float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo cbi) {
		BoundPlayer pl = CustomPlayerModelsClient.INSTANCE.manager.getPlayerFromModel(method_17165());
		if(pl != null) {
			ModelDefinition def = pl.definition;
			if(def != null && def.hasRoot(RootModelType.CAPE)) {
				class_1799 chestplate = entitylivingbaseIn.method_6118(class_1304.field_6174);
				if(!entitylivingbaseIn.method_5767() && entitylivingbaseIn.method_7348(class_1664.field_7559) && chestplate.method_7909() != class_1802.field_8833) {
					class_2960 defLoc = entitylivingbaseIn.method_3119();
					if(defLoc == null)defLoc = CustomPlayerModelsClient.DEFAULT_CAPE;
					ModelTexture mt = new ModelTexture(defLoc);
					CustomPlayerModelsClient.mc.getPlayerRenderManager().rebindModel(method_17165());
					CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(method_17165(), mt, TextureSheetType.CAPE);
					if(mt.getTexture() != null) {
						class_4588 buffer = bufferIn.getBuffer(mt.getRenderType());
						CustomPlayerModelsClient.renderCape(matrixStackIn, buffer, packedLightIn, entitylivingbaseIn, partialTicks, method_17165(), def);
					}
				}
				cbi.cancel();
			}
		}
	}
}

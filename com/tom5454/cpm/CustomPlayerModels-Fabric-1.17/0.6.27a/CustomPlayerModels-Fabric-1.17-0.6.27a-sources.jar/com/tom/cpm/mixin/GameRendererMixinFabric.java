package com.tom.cpm.mixin;

import java.io.IOException;
import java.util.function.Consumer;
import net.minecraft.class_293;
import net.minecraft.class_3300;
import net.minecraft.class_5912;
import net.minecraft.class_5944;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.ClientBase.ShaderLoader;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.shared.util.Log;

@Mixin(class_757.class)
public abstract class GameRendererMixinFabric implements ShaderLoader {

	@Shadow
	abstract class_5944 preloadShader(class_5912 arg, String string, class_293 vertexFormat) throws IOException;

	private class_3300 cpm$tmpRmngr;

	@Inject(at = @At("TAIL"), method = "reloadShaders(Lnet/minecraft/server/packs/resources/ResourceManager;)V")
	public void onShadersLoading(class_3300 resourceManager, CallbackInfo cbi) {
		try {
			cpm$tmpRmngr = resourceManager;
			CustomPlayerModelsClient.INSTANCE.registerShaders(this);
		} finally {
			cpm$tmpRmngr = null;
		}
	}

	@Override
	public void cpm$registerShader(String name, class_293 vertexFormat, Consumer<class_5944> finish) {
		try {
			finish.accept(preloadShader(cpm$tmpRmngr, name, vertexFormat));
		} catch (IOException e) {
			Log.error("Failed to load cpm '" + name + "' shader", e);
			finish.accept(null);
		}
	}
}

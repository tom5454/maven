package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpl.util.ItemSlot;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.model.render.ItemTransform;
import com.tom.cpm.shared.model.render.ModelRenderManager.BoundPlayer;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_591;
import net.minecraft.class_983;

@Mixin(value = class_983.class, priority = 2000)
public abstract class ParrotOnShoulderLayerMixin extends class_3887<net.minecraft.class_1657, class_591<net.minecraft.class_1657>> {

	public ParrotOnShoulderLayerMixin(class_3883<net.minecraft.class_1657, class_591<net.minecraft.class_1657>> p_117346_) {
		super(p_117346_);
	}

	@Inject(at = @At("HEAD"),
			method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/player/Player;FFFFZ)V")
	public void onRenderPre(class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, net.minecraft.class_1657 entitylivingbaseIn, float limbSwing, float limbSwingAmount, float netHeadYaw, float headPitch, boolean leftShoulderIn, CallbackInfo cbi) {
		matrixStackIn.method_22903();
		BoundPlayer pl = CustomPlayerModelsClient.INSTANCE.manager.getPlayerFromModel(method_17165());
		if(pl != null) {
			ModelDefinition def = pl.definition;
			if(def != null) {
				ItemTransform tr = def.getTransform(leftShoulderIn ? ItemSlot.LEFT_SHOULDER : ItemSlot.RIGHT_SHOULDER);
				if(tr != null) {
					PlayerRenderManager.multiplyStacks(tr.getMatrix(), matrixStackIn);
					if(entitylivingbaseIn.method_18276())
						matrixStackIn.method_22904(0, -0.2f, 0);
				}
			}
		}
	}

	@Inject(at = @At("RETURN"),
			method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/world/entity/player/Player;FFFFZ)V")
	public void onRenderPost(class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, net.minecraft.class_1657 entitylivingbaseIn, float limbSwing, float limbSwingAmount, float netHeadYaw, float headPitch, boolean leftShoulderIn, CallbackInfo cbi) {
		matrixStackIn.method_22909();
	}
}

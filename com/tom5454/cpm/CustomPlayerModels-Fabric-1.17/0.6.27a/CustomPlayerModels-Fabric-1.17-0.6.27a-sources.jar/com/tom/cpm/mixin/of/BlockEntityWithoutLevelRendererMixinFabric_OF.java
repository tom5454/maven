package com.tom.cpm.mixin.of;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2190;
import net.minecraft.class_2248;
import net.minecraft.class_2484;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2631;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5598;
import net.minecraft.class_756;
import org.apache.commons.lang3.StringUtils;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.mojang.authlib.GameProfile;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.RefHolder;

@Mixin(class_756.class)
public class BlockEntityWithoutLevelRendererMixinFabric_OF {
	private @Shadow Map<class_2484.class_2485, class_5598> skullModels;

	@Inject(at = @At("HEAD"), method = "renderRaw", require = 0, remap = false)
	//Optifine
	public void onRenderOF(class_1799 itemStack, class_4587 matrices, class_4597 multiBufferSource, int light, int arg5, CallbackInfo ci) {
		class_1792 item = itemStack.method_7909();
		if (item instanceof class_1747) {
			class_2248 block = ((class_1747)item).method_7711();
			if (block instanceof class_2190) {
				GameProfile gameProfile = null;
				if (itemStack.method_7985()) {
					class_2487 compoundTag = itemStack.method_7969();
					if (compoundTag.method_10573("SkullOwner", 10)) {
						gameProfile = class_2512.method_10683(compoundTag.method_10562("SkullOwner"));
					} else if (compoundTag.method_10573("SkullOwner", 8)
							&& !StringUtils.isBlank(compoundTag.method_10558("SkullOwner"))) {
						gameProfile = new GameProfile((UUID) null, compoundTag.method_10558("SkullOwner"));
						compoundTag.method_10551("SkullOwner");
						class_2631.method_11335(gameProfile, (p_172560_) -> {
							compoundTag.method_10566("SkullOwner", class_2512.method_10684(new class_2487(), p_172560_));
						});
					}
				}
				class_2484.class_2485 skullType = ((class_2190)block).method_9327();
				class_5598 skullmodelbase = this.skullModels.get(skullType);
				RefHolder.CPM_MODELS = skullModels;
				if(skullType == class_2484.class_2486.field_11510 && gameProfile != null) {
					CustomPlayerModelsClient.INSTANCE.renderSkull(skullmodelbase, gameProfile, multiBufferSource);
				}
			}
		}
	}
}

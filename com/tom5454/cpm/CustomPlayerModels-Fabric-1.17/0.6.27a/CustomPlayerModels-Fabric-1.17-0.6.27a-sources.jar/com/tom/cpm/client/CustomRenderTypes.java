package com.tom.cpm.client;

import java.util.OptionalDouble;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_2960;
import net.minecraft.class_4668;

public class CustomRenderTypes extends class_1921 {
	private static final class_1921 LINES_NO_DEPTH = method_24049("cpm:lines_no_depth", class_290.field_29337, class_293.class_5596.field_27377, 256, false, false, class_1921.class_4688.method_23598().method_34578(field_29433).method_23609(new class_4668.class_4677(OptionalDouble.empty())).method_23607(field_22241).method_23615(field_21370).method_23610(field_25643).method_23616(field_21349).method_23603(field_21345).method_23604(field_21346).method_23617(false));
	private static final class_2960 WHITE = new class_2960("textures/misc/white.png");

	private CustomRenderTypes(String nameIn, class_293 formatIn, class_5596 drawModeIn, int bufferSizeIn,
			boolean useDelegateIn, boolean needsSortingIn, Runnable setupTaskIn, Runnable clearTaskIn) {
		super(nameIn, formatIn, drawModeIn, bufferSizeIn, useDelegateIn, needsSortingIn, setupTaskIn, clearTaskIn);
	}

	public static class_1921 entityColorTranslucent() {
		return method_23580(WHITE);
	}

	public static class_1921 entityColorEyes() {
		return method_23026(WHITE);
	}

	public static class_1921 linesNoDepth() {
		return LINES_NO_DEPTH;
	}
}

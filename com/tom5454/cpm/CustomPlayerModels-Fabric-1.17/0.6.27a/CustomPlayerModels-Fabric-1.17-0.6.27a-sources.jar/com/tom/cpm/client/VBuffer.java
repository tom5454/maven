package com.tom.cpm.client;

import com.tom.cpl.render.DirectBuffer;
import net.minecraft.class_1159;
import net.minecraft.class_4581;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

public class VBuffer extends DirectBuffer<class_4588> {
	private int light, overlay;
	private class_1159 mat4;
	private class_4581 mat3;

	public VBuffer(class_4588 buffer, int light, int overlay, class_4587 matrixStackIn) {
		super(buffer);
		this.light = light;
		this.overlay = overlay;
		mat4 = matrixStackIn.method_23760().method_23761();
		mat3 = matrixStackIn.method_23760().method_23762();
	}

	@Override
	protected void pushVertex(float x, float y, float z, float red, float green,
			float blue, float alpha, float u, float v, float nx, float ny, float nz) {
		buffer.method_22918(mat4, x, y, z);
		buffer.method_22915(red, green, blue, alpha);
		buffer.method_22913(u, v);
		buffer.method_22922(overlay);
		buffer.method_22916(light);
		buffer.method_23763(mat3, nx, ny, nz);
		buffer.method_1344();
	}

	@Override
	public void finish() {}
}

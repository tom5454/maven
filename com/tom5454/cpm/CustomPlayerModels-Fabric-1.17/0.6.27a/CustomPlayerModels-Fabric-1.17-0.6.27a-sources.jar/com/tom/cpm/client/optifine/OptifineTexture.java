package com.tom.cpm.client.optifine;

import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.MinecraftObject.DynTexture;
import com.tom.cpm.client.optifine.proxy.TextureOF;
import com.tom.cpm.shared.skin.TextureProvider;
import net.minecraft.class_1044;
import net.minecraft.class_2960;
import net.minecraft.class_310;

public class OptifineTexture {

	public static void applyOptifineTexture(class_2960 loc, TextureProvider skin) {
		if(CustomPlayerModelsClient.optifineLoaded) {
			class_1044 tex = class_310.method_1551().method_1531().method_4619(loc);
			DynTexture dt = (DynTexture) skin.texture.getNative();
			if(dt != null && tex != null)
				((TextureOF)dt.getDynTex()).cpm$copyMultiTex(((TextureOF) tex).cpm$multiTex());
		}
	}
}

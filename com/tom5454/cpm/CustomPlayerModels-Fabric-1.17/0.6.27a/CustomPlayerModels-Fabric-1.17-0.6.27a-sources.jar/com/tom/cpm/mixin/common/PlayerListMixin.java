package com.tom.cpm.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.common.ServerHandler;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;

@Mixin(class_3324.class)
public class PlayerListMixin {

	@Inject(at = @At("RETURN"), method = "placeNewPlayer(Lnet/minecraft/network/Connection;Lnet/minecraft/server/level/ServerPlayer;)V")
	public void onOnPlayerConnect(class_2535 connection, class_3222 player, CallbackInfo cbi) {
		ServerHandler.onPlayerJoin(player);
	}
}

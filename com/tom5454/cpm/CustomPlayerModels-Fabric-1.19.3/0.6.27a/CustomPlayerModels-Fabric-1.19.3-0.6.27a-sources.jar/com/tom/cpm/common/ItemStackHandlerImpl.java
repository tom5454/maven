package com.tom.cpm.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2479;
import net.minecraft.class_2487;
import net.minecraft.class_2495;
import net.minecraft.class_2499;
import net.minecraft.class_2501;
import net.minecraft.class_2514;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import com.tom.cpl.item.ItemStackHandler;
import com.tom.cpl.item.NbtMapper;
import com.tom.cpl.item.Stack;
import com.tom.cpl.nbt.NBTTagCompound;

public class ItemStackHandlerImpl extends ItemStackHandler<class_1799> {
	public static final ItemStackHandlerImpl impl = new ItemStackHandlerImpl();
	public static final NBT nbt = new NBT();

	@Override
	public int getCount(class_1799 stack) {
		return stack.method_7947();
	}

	@Override
	public int getMaxCount(class_1799 stack) {
		return stack.method_7914();
	}

	@Override
	public int getDamage(class_1799 stack) {
		return stack.method_7919();
	}

	@Override
	public int getMaxDamage(class_1799 stack) {
		return stack.method_7936();
	}

	@Override
	public boolean itemEquals(class_1799 a, class_1799 b) {
		return class_1799.method_7984(a, b);
	}

	@Override
	public boolean itemEqualsFull(class_1799 a, class_1799 b) {
		return class_1799.method_31577(a, b);
	}

	@Override
	public List<String> listNativeTags() {
		return class_7923.field_41178.method_40273().map(k -> "#" + k.comp_327()).toList();
	}

	@Override
	public List<Stack> getAllElements() {
		return class_7706.method_47344().method_45414().stream().map(this::wrap).collect(Collectors.toList());
	}

	public static class NBT extends NbtMapper<class_2520, class_2487, class_2499, class_2514> {

		@Override
		public long getLong(class_2514 t) {
			return t.method_10699();
		}

		@Override
		public int getInt(class_2514 t) {
			return t.method_10701();
		}

		@Override
		public short getShort(class_2514 t) {
			return t.method_10696();
		}

		@Override
		public byte getByte(class_2514 t) {
			return t.method_10698();
		}

		@Override
		public double getDouble(class_2514 t) {
			return t.method_10697();
		}

		@Override
		public float getFloat(class_2514 t) {
			return t.method_10700();
		}

		@Override
		public class_2514 asNumber(class_2520 t) {
			return t instanceof class_2514 ? (class_2514) t : null;
		}

		@Override
		public String getString(class_2520 t) {
			return t.method_10714();
		}

		@Override
		public class_2520 getTag(class_2487 t, String name) {
			return t.method_10580(name);
		}

		@Override
		public class_2499 asList(class_2520 t) {
			return t instanceof class_2499 ? (class_2499) t : null;
		}

		@Override
		public class_2487 asCompound(class_2520 t) {
			return t instanceof class_2487 ? (class_2487) t : null;
		}

		@Override
		public int listSize(class_2499 t) {
			return t.size();
		}

		@Override
		public class_2520 getAt(class_2499 t, int i) {
			return t.method_10534(i);
		}

		@Override
		public boolean contains(class_2487 t, String name, int type) {
			return t.method_10573(name, type);
		}

		@Override
		public class_2487 newCompound() {
			return new class_2487();
		}

		@Override
		public class_2499 newList() {
			return new class_2499();
		}

		@Override
		public Iterable<String> keys(class_2487 t) {
			return t.method_10541();
		}

		@Override
		public int getId(class_2520 t) {
			return t.method_10711();
		}

		@Override
		public byte[] getByteArray(class_2520 t) {
			return t instanceof class_2479 ? ((class_2479) t).method_10521() : new byte[0];
		}

		@Override
		public int[] getIntArray(class_2520 t) {
			return t instanceof class_2495 ? ((class_2495) t).method_10588() : new int[0];
		}

		@Override
		public long[] getLongArray(class_2520 t) {
			return t instanceof class_2501 ? ((class_2501) t).method_10615() : new long[0];
		}
	}

	@Override
	public NBTTagCompound getTag(class_1799 stack) {
		return stack.method_7985() ? nbt.wrap(stack.method_7969()) : null;
	}

	@SuppressWarnings("deprecation")
	@Override
	public List<Stack> listNativeEntries(String tag) {
		List<Stack> stacks = new ArrayList<>();
		if (tag.charAt(0) == '#') {
			class_2960 rl = class_2960.method_12829(tag.substring(1));
			if (rl != null) {
				class_6862<class_1792> i = class_6862.method_40092(class_7924.field_41197, rl);
				class_7923.field_41178.method_40266(i).map(t -> {
					return t.method_40239().map(h -> h.method_40229().right()).filter(Optional::isPresent)
							.map(o -> wrap(new class_1799(o.get()))).toList();
				}).ifPresent(stacks::addAll);
			}
		} else {
			class_2960 rl = class_2960.method_12829(tag);
			class_1792 item = class_7923.field_41178.method_10223(rl);
			if (item != null) {
				stacks.add(wrap(new class_1799(item)));
			}
		}
		return stacks;
	}

	@Override
	public boolean isInTag(String tag, class_1799 stack) {
		if (tag.charAt(0) == '#') {
			class_2960 rl = class_2960.method_12829(tag.substring(1));
			if (rl != null) {
				class_6862<class_1792> i = class_6862.method_40092(class_7924.field_41197, rl);
				return stack.method_31573(i);
			}
		} else {
			return getItemId(stack).equals(tag);
		}
		return false;
	}

	@Override
	public List<String> listTags(class_1799 stack) {
		return stack.method_40133().map(k -> "#" + k.comp_327()).toList();
	}

	@Override
	public String getItemId(class_1799 stack) {
		return class_7923.field_41178.method_10221(stack.method_7909()).toString();
	}

	@Override
	public Stack emptyObject() {
		return wrap(class_1799.field_8037);
	}

	@Override
	public String getItemDisplayName(class_1799 stack) {
		return stack.method_7954().getString();
	}
}

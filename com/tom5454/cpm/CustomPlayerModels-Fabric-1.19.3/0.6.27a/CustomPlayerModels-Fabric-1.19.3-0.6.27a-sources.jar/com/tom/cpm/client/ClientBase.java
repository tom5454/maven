package com.tom.cpm.client;

import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2817;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_563;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_5944;
import net.minecraft.class_634;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_898;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.tom.cpl.text.FormatText;
import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.common.PlayerAnimUpdater;
import com.tom.cpm.mixinplugin.IrisDetector;
import com.tom.cpm.mixinplugin.OFDetector;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.model.RenderManager;
import com.tom.cpm.shared.network.NetHandler;
import com.tom.cpm.shared.util.Log;

import io.netty.buffer.Unpooled;

public abstract class ClientBase {
	public static final class_2960 DEFAULT_CAPE = new class_2960("cpm:textures/template/cape.png");
	public static boolean optifineLoaded, irisLoaded, vrLoaded;
	public static MinecraftObject mc;
	protected class_310 minecraft;
	public RenderManager<GameProfile, net.minecraft.class_1657, class_3879, class_4597> manager;
	public NetHandler<class_2960, net.minecraft.class_1657, class_634> netHandler;

	public void init0() {
		minecraft = class_310.method_1551();
		mc = new MinecraftObject(minecraft);
		optifineLoaded = OFDetector.doApply();
		vrLoaded = Platform.isModLoaded("vivecraft");
		irisLoaded = IrisDetector.doApply();
		if(optifineLoaded)Log.info("Optifine detected, enabling optifine compatibility");
		if(vrLoaded)Log.info("ViveCraft detected, enabling ViveCraft compatibility");
		if(irisLoaded)Log.info("Iris detected, enabling iris compatibility");
	}

	public void init1() {
		manager = new RenderManager<>(mc.getPlayerRenderManager(), mc.getDefinitionLoader(), PlayerProfile::getPlayerProfile);
		manager.setGPGetters(GameProfile::getProperties, Property::getValue);
		netHandler = new NetHandler<>(class_2960::new);
		netHandler.setExecutor(() -> minecraft);
		netHandler.setSendPacketClient(d -> new class_2540(Unpooled.wrappedBuffer(d)), (c, rl, pb) -> c.method_2883(new class_2817(rl, pb)));
		netHandler.setPlayerToLoader(net.minecraft.class_1657::method_7334);
		netHandler.setGetPlayerById(id -> {
			class_1297 ent = class_310.method_1551().field_1687.method_8469(id);
			if(ent instanceof net.minecraft.class_1657) {
				return (net.minecraft.class_1657) ent;
			}
			return null;
		});
		netHandler.setGetClient(() -> minecraft.field_1724);
		netHandler.setGetNet(c -> ((class_746)c).field_3944);
		netHandler.setDisplayText(t -> minecraft.field_1724.method_7353(t.remap(), false));
		netHandler.setGetPlayerAnimGetters(new PlayerAnimUpdater());
	}

	public static void apiInit() {
		CustomPlayerModels.api.buildClient().voicePlayer(net.minecraft.class_1657.class, net.minecraft.class_1657::method_5667).
		renderApi(class_3879.class, class_2960.class, class_1921.class, class_4597.class, GameProfile.class, ModelTexture::new).
		localModelApi(GameProfile::new).init();
	}

	//Copy from CapeFeatureRenderer
	public static void renderCape(class_4587 matrixStack, class_4588 buffer, int packedLightIn,
			class_742 abstractClientPlayerEntity, float partialTicks, class_591<class_742> model,
			ModelDefinition modelDefinition) {
		matrixStack.method_22903();

		float r, q, s;

		if(abstractClientPlayerEntity != null) {
			double d = class_3532.method_16436(partialTicks, abstractClientPlayerEntity.field_7524,
					abstractClientPlayerEntity.field_7500)
					- class_3532.method_16436(partialTicks, abstractClientPlayerEntity.field_6014,
							abstractClientPlayerEntity.method_23317());
			double e = class_3532.method_16436(partialTicks, abstractClientPlayerEntity.field_7502,
					abstractClientPlayerEntity.field_7521)
					- class_3532.method_16436(partialTicks, abstractClientPlayerEntity.field_6036,
							abstractClientPlayerEntity.method_23318());
			double m = class_3532.method_16436(partialTicks, abstractClientPlayerEntity.field_7522,
					abstractClientPlayerEntity.field_7499)
					- class_3532.method_16436(partialTicks, abstractClientPlayerEntity.field_5969,
							abstractClientPlayerEntity.method_23321());
			float n = abstractClientPlayerEntity.field_6220
					+ (abstractClientPlayerEntity.field_6283 - abstractClientPlayerEntity.field_6220);
			double o = class_3532.method_15374(n * 0.017453292F);
			double p = (-class_3532.method_15362(n * 0.017453292F));
			q = (float) e * 10.0F;
			q = class_3532.method_15363(q, -6.0F, 32.0F);
			r = (float) (d * o + m * p) * 100.0F;
			r = class_3532.method_15363(r, 0.0F, 150.0F);
			s = (float) (d * p - m * o) * 100.0F;
			s = class_3532.method_15363(s, -20.0F, 20.0F);
			if (r < 0.0F) {
				r = 0.0F;
			}

			float t = class_3532.method_16439(partialTicks, abstractClientPlayerEntity.field_7505,
					abstractClientPlayerEntity.field_7483);
			q += class_3532.method_15374(class_3532.method_16439(partialTicks, abstractClientPlayerEntity.field_6039,
					abstractClientPlayerEntity.field_5973) * 6.0F) * 32.0F * t;
			if (abstractClientPlayerEntity.method_18276()) {
				q += 50.0F;
			}
			if (abstractClientPlayerEntity.method_6118(class_1304.field_6174).method_7960()) {
				if (abstractClientPlayerEntity.method_18276()) {
					model.field_3485.field_3655 = 1.4F + 0.125F * 3;
					model.field_3485.field_3656 = 1.85F + 1 - 0.125F * 4;
				} else {
					model.field_3485.field_3655 = 0.0F + 0.125F * 16f;
					model.field_3485.field_3656 = 0.0F;
				}
			} else if (abstractClientPlayerEntity.method_18276()) {
				model.field_3485.field_3655 = 0.3F + 0.125F * 16f;
				model.field_3485.field_3656 = 0.8F + 0.3f;
			} else {
				model.field_3485.field_3655 = -1.1F + 0.125F * 32f;
				model.field_3485.field_3656 = -0.85F + 1;
			}
		} else {
			r = 0;
			q = 0;
			s = 0;
		}

		model.field_3485.field_3654 = (float) -Math.toRadians(6.0F + q / 2.0F + r);
		model.field_3485.field_3675 = (float) Math.toRadians(180.0F - s / 2.0F);
		model.field_3485.field_3674 = (float) Math.toRadians(s / 2.0F);
		mc.getPlayerRenderManager().setModelPose(model);
		model.field_3485.field_3654 = 0;
		model.field_3485.field_3675 = 0;
		model.field_3485.field_3674 = 0;
		model.method_2823(matrixStack, buffer, packedLightIn, class_4608.field_21444);
		matrixStack.method_22909();
	}

	public static interface PlayerNameTagRenderer<E extends class_1297> {
		void cpm$renderNameTag(E entityIn, class_2561 displayNameIn, class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn);
		class_898 cpm$entityRenderDispatcher();
	}

	public <E extends class_1297> void renderNameTag(PlayerNameTagRenderer<E> r, E entityIn, GameProfile gprofile, String unique, class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn) {
		double d0 = r.cpm$entityRenderDispatcher().method_23168(entityIn);
		if (d0 < 100.0D) {
			FormatText st = manager.getStatus(gprofile, unique);
			if(st != null) {
				matrixStackIn.method_22903();
				matrixStackIn.method_22904(0.0D, 1.3F, 0.0D);
				matrixStackIn.method_22905(0.5f, 0.5f, 0.5f);
				r.cpm$renderNameTag(entityIn, st.remap(), matrixStackIn, bufferIn, packedLightIn);
				matrixStackIn.method_22909();
			}
		}
	}

	public void playerRenderPre(class_1657 player, class_4597 buffer, class_591 model) {
		manager.bindPlayer(player, buffer, model);
	}

	public void playerRenderPost(class_4597 buffer, class_591 model) {
		manager.unbindFlush(model);
	}

	public void renderHand(class_4597 buffer, class_591 model) {
		manager.bindHand(minecraft.field_1724, buffer, model);
	}

	public void renderHandPost(class_4597 buffer, class_572 model) {
		manager.unbindFlush(model);
	}

	public void renderSkull(class_3879 skullModel, GameProfile profile, class_4597 buffer) {
		manager.bindSkull(profile, buffer, skullModel);
	}

	public void renderSkullPost(class_4597 buffer, class_3879 model) {
		manager.unbindFlush(model);
	}

	public void renderElytra(class_572<class_1309> player, class_563<class_1309> model) {
		manager.bindElytra(player, model);
	}

	public void renderArmor(class_572<class_1309> modelArmor, class_572<class_1309> modelLeggings,
			class_572<class_1309> player) {
		manager.bindArmor(player, modelArmor, 1);
		manager.bindArmor(player, modelLeggings, 2);
	}

	public void updateJump() {
		if(minecraft.field_1724.method_24828() && minecraft.field_1724.field_3913.field_3904) {
			manager.jump(minecraft.field_1724);
		}
	}

	public static interface ShaderLoader {
		void cpm$registerShader(String name, class_293 vertexFormat, Consumer<class_5944> finish);
	}

	public void registerShaders(ShaderLoader loader) {
	}
}

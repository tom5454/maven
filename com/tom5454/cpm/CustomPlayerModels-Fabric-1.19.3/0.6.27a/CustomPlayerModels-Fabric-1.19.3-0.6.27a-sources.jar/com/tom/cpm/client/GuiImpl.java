package com.tom.cpm.client;

import java.util.function.Function;
import net.minecraft.class_437;
import net.minecraft.class_4587;
import com.tom.cpl.gui.Frame;
import com.tom.cpl.gui.IGui;

public class GuiImpl extends GuiBase {

	public GuiImpl(Function<IGui, Frame> creator, class_437 parent) {
		super(creator, parent);
	}

	@Override
	public void method_25394(class_4587 matrixStack, int mouseX, int mouseY, float partialTicks) {
		super.method_25394(matrixStack, mouseX, mouseY, partialTicks);
		if(field_22787.field_1724 != null && gui.enableChat()) {
			matrixStack.method_22903();
			matrixStack.method_22904(0.0D, field_22787.method_22683().method_4502() - 48, 800);
			field_22787.field_1705.method_1743().method_1805(matrixStack, field_22787.field_1705.method_1738(), mouseX, mouseY);
			matrixStack.method_22909();
		}
	}
}

package com.tom.cpm.mixin;

import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2484;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5598;
import net.minecraft.class_756;
import net.minecraft.class_809;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import com.mojang.authlib.GameProfile;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.RefHolder;

@Mixin(class_756.class)
public class BlockEntityWithoutLevelRendererMixin {
	private @Shadow Map<class_2484.class_2485, class_5598> skullModels;

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/blockentity/SkullBlockRenderer;"
					+ "getRenderType(Lnet/minecraft/world/level/block/SkullBlock$Type;Lcom/mojang/authlib/GameProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;",
					remap = true
			),
			method = "renderByItem(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/client/renderer/block/model/ItemTransforms$TransformType;"
					+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)V",
					locals = LocalCapture.CAPTURE_FAILHARD,
					require = 0)//Optifine
	public void onRender(class_1799 stack, class_809.class_811 arg1, class_4587 matrices, class_4597 vertexConsumers, int light, int arg5, CallbackInfo ci, class_1792 item, class_2248 block, GameProfile gameProfile, class_2484.class_2485 skullType, class_5598 model) {
		RefHolder.CPM_MODELS = skullModels;
		if(skullType == class_2484.class_2486.field_11510 && gameProfile != null) {
			CustomPlayerModelsClient.INSTANCE.renderSkull(model, gameProfile, vertexConsumers);
		}
	}
}

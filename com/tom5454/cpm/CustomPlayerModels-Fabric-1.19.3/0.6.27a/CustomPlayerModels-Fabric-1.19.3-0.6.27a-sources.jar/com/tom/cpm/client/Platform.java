package com.tom.cpm.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_339;
import io.netty.channel.Channel;

public class Platform {

	public static boolean isSitting(class_1657 player) {
		return player.method_5765();
	}

	public static void setHeight(class_339 w, int h) {
		w.field_22759 = h;
	}

	public static Channel getChannel(class_2535 conn) {
		return conn.field_11651;
	}

	public static boolean isModLoaded(String id) {
		return FabricLoader.getInstance().isModLoaded(id);
	}
}

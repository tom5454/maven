package com.tom.cpm.client;

import java.util.function.Function;
import net.minecraft.class_10799;
import net.minecraft.class_11231;
import net.minecraft.class_11239;
import net.minecraft.class_11256;
import net.minecraft.class_4597;
import net.minecraft.class_8030;
import com.mojang.blaze3d.pipeline.RenderPipeline;

public interface GuiGraphicsEx {
	void cpm$fillGradient(RenderPipeline renderPipeline, class_11231 textureSetup, int x0, int y0, int x1, int y1,
			int topLeft, int topRight, int bottomLeft, int bottomRight);

	default void cpm$fillGradient(int x0, int y0, int x1, int y1,
			int topLeft, int topRight, int bottomLeft, int bottomRight) {
		cpm$fillGradient(class_10799.field_56879, class_11231.method_70899(), x0, y0, x1, y1, topLeft, topRight, bottomLeft, bottomRight);
	}

	void cpm$fill(RenderPipeline renderPipeline, class_11231 textureSetup, float x0, float y0, float x1, float y1, int color);

	default void cpm$fill(float x0, float y0, float x1, float y1, int color) {
		cpm$fill(class_10799.field_56879, class_11231.method_70899(), x0, y0, x1, y1, color);
	}

	<I, S extends class_11256> void cpm$drawPip(I instance, int x0, int y0, int x1, int y1, StateFactory<I, S> sf);

	@FunctionalInterface
	public static interface StateFactory<I, S extends class_11256> {
		S create(I instance, int x0, int y0, int x1, int y1, class_8030 scissorArea);
	}

	public static void registerPictureInPictureRenderers(RegistrationHandler handler) {
		handler.register(Panel3dImpl.State.class, Panel3dImpl.Renderer::new);
	}

	@FunctionalInterface
	public static interface RegistrationHandler {
		<T extends class_11256> void register(Class<T> stateClass, Function<class_4597.class_4598, class_11239<T>> factory);
	}
}
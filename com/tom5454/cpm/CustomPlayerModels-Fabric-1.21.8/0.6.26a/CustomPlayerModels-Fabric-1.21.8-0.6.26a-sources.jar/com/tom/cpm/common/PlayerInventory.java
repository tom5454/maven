package com.tom.cpm.common;

import com.tom.cpl.item.Inventory;
import com.tom.cpl.item.NamedSlot;
import com.tom.cpl.item.Stack;
import com.tom.cpm.shared.animation.AnimationState;
import net.minecraft.class_1304;

public class PlayerInventory implements Inventory {
	private net.minecraft.class_1661 inv;

	public static void setInv(AnimationState a, net.minecraft.class_1661 inv) {
		if(!(a.playerInventory instanceof PlayerInventory))a.playerInventory = new PlayerInventory();
		((PlayerInventory) a.playerInventory).inv = inv;
	}

	@Override
	public int size() {
		return inv == null ? 0 : inv.method_5439();
	}

	@Override
	public Stack getInSlot(int i) {
		return ItemStackHandlerImpl.impl.wrap(inv.method_5438(i));
	}

	@Override
	public void reset() {
		inv = null;
	}

	@Override
	public int getNamedSlotId(NamedSlot slot) {
		return switch (slot) {
		case MAIN_HAND -> inv.method_67532();
		case ARMOR_BOOTS -> class_1304.field_6166.method_32320(inv.method_67533().size());
		case ARMOR_CHESTPLATE -> class_1304.field_6174.method_32320(inv.method_67533().size());
		case ARMOR_HELMET -> class_1304.field_6169.method_32320(inv.method_67533().size());
		case ARMOR_LEGGINGS -> class_1304.field_6172.method_32320(inv.method_67533().size());
		case OFF_HAND -> inv.method_67533().size() + 4;
		default -> throw new IllegalArgumentException("Unexpected value: " + slot);
		};
	}
}

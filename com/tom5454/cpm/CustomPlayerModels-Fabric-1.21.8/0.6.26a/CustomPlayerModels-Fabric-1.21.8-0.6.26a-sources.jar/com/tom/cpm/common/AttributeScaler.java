package com.tom.cpm.common;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1322.class_1323;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5134;
import net.minecraft.class_6880;
import com.tom.cpm.shared.network.NetHandler.ScalerInterface;
import com.tom.cpm.shared.util.ScalingOptions;

public class AttributeScaler implements ScalerInterface<class_3222, List<class_6880<class_1320>>> {
	private static final class_2960 CPM_ATTR_ID = class_2960.method_43902("cpm", "24bba381-9615-4530-8fcf-4fc42393a4b5");

	@Override
	public void setScale(List<class_6880<class_1320>> key, class_3222 player, float value) {
		key.forEach(a -> {
			class_1324 ai = player.method_6127().method_45329(a);
			if (ai != null) {
				ai.method_6200(CPM_ATTR_ID);
				if (Math.abs(value - 1) > 0.01f)
					ai.method_26835(new class_1322(CPM_ATTR_ID, value - 1, class_1323.field_6330));
			}
		});
	}

	@Override
	public List<class_6880<class_1320>> toKey(ScalingOptions opt) {
		switch (opt) {
		case ENTITY: return Collections.singletonList(class_5134.field_47760);
		case HEALTH: return Collections.singletonList(class_5134.field_23716);
		case STEP_HEIGHT: return Collections.singletonList(class_5134.field_47761);
		case ATTACK_DMG: return Collections.singletonList(class_5134.field_23721);
		case ATTACK_KNOCKBACK: return Collections.singletonList(class_5134.field_23722);
		case ATTACK_SPEED: return Collections.singletonList(class_5134.field_23723);
		case DEFENSE: return Collections.singletonList(class_5134.field_23724);
		case REACH: return List.of(class_5134.field_47758, class_5134.field_47759);
		case MOB_VISIBILITY: return Collections.singletonList(class_5134.field_23717);
		case MOTION: return Collections.singletonList(class_5134.field_23719);
		case KNOCKBACK_RESIST: return Collections.singletonList(class_5134.field_23718);
		case JUMP_HEIGHT: return Collections.singletonList(class_5134.field_23728);
		case FALL_DAMAGE: return Collections.singletonList(class_5134.field_49077);
		case MINING_SPEED: return Collections.singletonList(class_5134.field_49076);
		case SAFE_FALL_DISTANCE: return Collections.singletonList(class_5134.field_49079);
		case THIRD_PERSON: return Collections.singletonList(class_5134.field_59674);
		default: return null;
		}
	}

	@Override
	public String getMethodName() {
		return ATTRIBUTE;
	}
}

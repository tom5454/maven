package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import com.tom.cpm.client.PlayerHeadRenderInfoAccess;
import net.minecraft.class_11533.class_11534;
import net.minecraft.class_9296;

@Mixin(class_11534.class)
public class PlayerHeadRenderInfoMixin implements PlayerHeadRenderInfoAccess {
	private class_9296 cpm$profile;

	@Override
	public class_9296 cpm$getProfile() {
		return cpm$profile;
	}

	@Override
	public void cpm$setProfile(class_9296 cpm$profile) {
		this.cpm$profile = cpm$profile;
	}
}

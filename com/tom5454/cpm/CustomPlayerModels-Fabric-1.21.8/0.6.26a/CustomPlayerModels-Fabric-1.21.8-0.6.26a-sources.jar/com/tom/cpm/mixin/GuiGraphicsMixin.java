package com.tom.cpm.mixin;

import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import com.mojang.blaze3d.pipeline.RenderPipeline;

import com.tom.cpm.client.GuiGraphicsEx;
import com.tom.cpm.client.GuiRenderStates.Colored4RectangleRenderState;
import com.tom.cpm.client.GuiRenderStates.ColoredRectangleFRenderState;
import net.minecraft.class_11231;
import net.minecraft.class_11246;
import net.minecraft.class_11256;
import net.minecraft.class_332;

@Mixin(class_332.class)
public class GuiGraphicsMixin implements GuiGraphicsEx {
	private @Shadow @Final class_332.class_8214 scissorStack;
	private @Shadow @Final class_11246 guiRenderState;
	private @Shadow @Final Matrix3x2fStack pose;

	@Override
	public void cpm$fillGradient(RenderPipeline renderPipeline, class_11231 textureSetup, int x0, int y0, int x1, int y1,
			int topLeft, int topRight, int bottomLeft, int bottomRight) {
		this.guiRenderState.method_70919(
				new Colored4RectangleRenderState(
						renderPipeline, textureSetup, new Matrix3x2f(this.pose), x0, y0, x1, y1, topLeft, topRight, bottomLeft, bottomRight, this.scissorStack.method_70863()
						)
				);
	}

	@Override
	public void cpm$fill(RenderPipeline renderPipeline, class_11231 textureSetup, float x0, float y0, float x1, float y1,
			int color) {
		this.guiRenderState.method_70919(
				new ColoredRectangleFRenderState(
						renderPipeline, textureSetup, new Matrix3x2f(this.pose), x0, y0, x1, y1, color, this.scissorStack.method_70863()
						)
				);
	}

	@Override
	public <I, S extends class_11256> void cpm$drawPip(I instance, int x0, int y0, int x1, int y1,
			StateFactory<I, S> sf) {
		this.guiRenderState.method_70922(sf.create(instance, x0, y0, x1, y1, this.scissorStack.method_70863()));
	}
}

package com.tom.cpm.mixin.compat;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.irisshaders.batchedentityrendering.impl.Groupable;
import net.irisshaders.iris.layer.EntityRenderStateShard;
import net.irisshaders.iris.layer.OuterWrappedRenderType;
import net.irisshaders.iris.shaderpack.materialmap.NamespacedId;
import net.irisshaders.iris.shaderpack.materialmap.WorldRenderingSettings;
import net.irisshaders.iris.uniforms.CapturedRenderingState;
import net.minecraft.class_1299;
import net.minecraft.class_2586;
import net.minecraft.class_2631;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7923;
import net.minecraft.class_824;
import it.unimi.dsi.fastutil.objects.Object2IntFunction;

@Mixin(value = class_824.class, priority = 900)
public class BlockEntityRenderDispatcherMixin_Iris {

	@ModifyVariable(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/entity/BlockEntityType;isValid(Lnet/minecraft/world/level/block/state/BlockState;)Z"), allow = 1, require = 1)
	private class_4597 prewrapBufferSource(class_4597 bufferSource, class_2586 blockEntity) {
		if (!(bufferSource instanceof Groupable) || !(blockEntity instanceof class_2631)) {
			return bufferSource;
		} else {
			Object2IntFunction<NamespacedId> entityIds = WorldRenderingSettings.INSTANCE.getEntityIds();
			if (entityIds == null)
				return bufferSource;

			// Fake rendering an armor stand instead of a block entity for skulls
			// Fixes glowing effect not working
			class_2960 entityId = class_7923.field_41177.method_10221(class_1299.field_6131);
			int intId = entityIds.applyAsInt(new NamespacedId(entityId.method_12836(), entityId.method_12832()));
			CapturedRenderingState.INSTANCE.setCurrentEntity(intId);
			return type -> bufferSource.getBuffer(OuterWrappedRenderType.wrapExactlyOnce("iris:is_entity", type, EntityRenderStateShard.INSTANCE));
		}
	}

	@Inject(method = {
	"render(Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;)V"}, at = {
			@At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/blockentity/BlockEntityRenderDispatcher;setupAndRender(Lnet/minecraft/client/renderer/blockentity/BlockEntityRenderer;Lnet/minecraft/world/level/block/entity/BlockEntity;FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/world/phys/Vec3;)V", shift = At.Shift.AFTER)})
	private void postRender(class_2586 blockEntity, float tickDelta, class_4587 matrix, class_4597 bufferSource, CallbackInfo ci) {
		CapturedRenderingState.INSTANCE.setCurrentEntity(0);
	}
}


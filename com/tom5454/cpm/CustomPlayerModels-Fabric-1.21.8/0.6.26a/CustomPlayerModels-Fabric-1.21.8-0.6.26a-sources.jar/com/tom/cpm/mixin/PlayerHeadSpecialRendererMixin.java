package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import com.mojang.authlib.GameProfile;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.PlayerHeadRenderInfoAccess;
import com.tom.cpm.client.RefHolder;
import net.minecraft.class_11533;
import net.minecraft.class_11533.class_11534;
import net.minecraft.class_2484;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5598;
import net.minecraft.class_811;
import net.minecraft.class_836;
import net.minecraft.class_9296;

@Mixin(class_11533.class)
public class PlayerHeadSpecialRendererMixin {
	private @Shadow @Final class_5598 modelBase;

	@Inject(at = @At("HEAD"), method = "render")
	public void onRender(
			class_11534 info,
			final class_811 itemDisplayContext, final class_4587 poseStack,
			final class_4597 multiBufferSource, final int i, final int j, final boolean bl,
			CallbackInfo cbi, @Local final LocalRef<class_11534> playerHeadRenderInfo
			) {
		Object b = playerHeadRenderInfo.get();
		if (b instanceof PlayerHeadRenderInfoAccess a) {
			class_9296 resolvableProfile = a.cpm$getProfile();
			GameProfile gameProfile = resolvableProfile != null ? resolvableProfile.comp_2413() : null;
			if (gameProfile != null) {
				RefHolder.CPM_MODELS = t -> t == class_2484.class_2486.field_11510 ? modelBase : null;
				CustomPlayerModelsClient.INSTANCE.renderSkull(modelBase, gameProfile, multiBufferSource);
				playerHeadRenderInfo.set(new class_11534(class_836.method_65832(class_2484.class_2486.field_11510, resolvableProfile)));
			}
		}
	}

	@Inject(at = @At("RETURN"), method = "createAndCacheIfTextureIsUnpacked(Lnet/minecraft/world/item/component/ResolvableProfile;)Lnet/minecraft/client/renderer/special/PlayerHeadSpecialRenderer$PlayerHeadRenderInfo;")
	private void onCreateAndCacheIfTextureIsUnpacked(class_9296 resolvableProfile, CallbackInfoReturnable<class_11534> cbi) {
		Object b = cbi.getReturnValue();
		if (b instanceof PlayerHeadRenderInfoAccess a) {
			a.cpm$setProfile(resolvableProfile);
		}
	}
}

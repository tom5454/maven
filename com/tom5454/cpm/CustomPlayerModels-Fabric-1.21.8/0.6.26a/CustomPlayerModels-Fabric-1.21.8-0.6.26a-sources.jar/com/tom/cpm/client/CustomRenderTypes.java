package com.tom.cpm.client;

import static net.minecraft.class_4668.*;
import static net.minecraft.class_1921.*;

import java.util.OptionalDouble;
import java.util.function.Supplier;

import net.irisshaders.batchedentityrendering.impl.BlendingStateHolder;
import net.irisshaders.batchedentityrendering.impl.TransparencyType;
import net.minecraft.class_10799;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_4668;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat.class_5596;

public class CustomRenderTypes {
	public static final Supplier<RenderPipeline> EYES = Platform.registerPipeline(() -> {
		return RenderPipeline.builder(class_10799.field_60127)
				.withLocation(class_2960.method_43902("cpm", "pipeline/eyes"))
				.withVertexShader("core/entity")
				.withFragmentShader("core/entity")
				.withShaderDefine("EMISSIVE")
				.withShaderDefine("NO_OVERLAY")
				.withShaderDefine("NO_CARDINAL_LIGHTING")
				.withSampler("Sampler0")
				.withBlend(BlendFunction.ADDITIVE)
				.withDepthWrite(false)
				.withVertexFormat(class_290.field_1580, class_5596.field_27382)
				.build();
	});

	public static final Supplier<RenderPipeline> LINES = Platform.registerPipeline(() -> {
		return RenderPipeline.builder(class_10799.field_56859)
				.withLocation(class_2960.method_43902("cpm", "pipeline/lines"))
				.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
				.build();
	});

	public static final class_1921 ENTITY_COLOR = method_23580(class_2960.method_60654("textures/misc/white.png"));

	public static final class_1921 ENTITY_COLOR_EYES = glowingEyes(class_2960.method_60654("textures/misc/white.png"));

	public static class_1921 entityColorTranslucent() {
		return ENTITY_COLOR;
	}

	public static class_1921 entityColorEyes() {
		return ENTITY_COLOR_EYES;
	}

	public static class_1921 linesNoDepth() {
		return method_24049(
				"cpm:lines_no_depth",
				1536,
				false, true,
				LINES.get(),
				class_1921.class_4688.method_23598().
				method_23609(new class_4668.class_4677(OptionalDouble.empty())).
				method_23607(field_22241).
				method_23610(field_25643).
				method_23617(false));
	}

	public static class_1921 glowingEyes(class_2960 rl) {
		class_4668.class_4683 textureStateShard = new class_4668.class_4683(rl, false);
		class_1921 rt = method_24049(
				"eyes", 1536, false, true, EYES.get(), class_1921.class_4688.method_23598().method_34577(textureStateShard).method_23617(false)
				);
		if (ClientBase.irisLoaded)
			((BlendingStateHolder) rt).setTransparencyType(TransparencyType.DECAL);
		return rt;
	}
}

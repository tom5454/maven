package com.tom.cpm.client;

import net.minecraft.class_9296;

public interface PlayerHeadRenderInfoAccess {
	class_9296 cpm$getProfile();
	void cpm$setProfile(class_9296 cpm$profile);
}

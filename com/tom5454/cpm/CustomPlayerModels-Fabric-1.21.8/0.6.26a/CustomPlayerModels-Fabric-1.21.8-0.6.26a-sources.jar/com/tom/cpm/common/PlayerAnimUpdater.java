package com.tom.cpm.common;

import java.util.function.BiConsumer;
import net.minecraft.class_1657;
import com.tom.cpm.shared.animation.ServerAnimationState;

public class PlayerAnimUpdater implements BiConsumer<class_1657, ServerAnimationState> {

	@Override
	public void accept(class_1657 t, ServerAnimationState u) {
		u.updated = true;
		u.creativeFlying = t.method_31549().field_7479;
		u.falling = (float) t.field_6017;
		u.health = t.method_6032() / t.method_6063();
		u.air = Math.max(t.method_5669() / (float) t.method_5748(), 0);
		u.hunger = t.method_7344().method_7586() / 20f;
		u.inMenu = t.field_7512 != t.field_7498;
	}

}

package com.tom.cpm.mixin;

import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2484;
import net.minecraft.class_2631;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5598;
import net.minecraft.class_836;
import net.minecraft.class_9296;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.RefHolder;
import com.tom.cpm.shared.model.TextureSheetType;

@Mixin(class_836.class)
public class SkullBlockRendererMixin {
	@Shadow private @Final Function<class_2484.class_2485, class_5598> modelByType;

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/blockentity/SkullBlockRenderer;"
					+ "getRenderType(Lnet/minecraft/world/level/block/SkullBlock$Type;Lnet/minecraft/world/item/component/ResolvableProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;"
			),
			method = "render(Lnet/minecraft/world/level/block/entity/SkullBlockEntity;F"
					+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II"
					+ "Lnet/minecraft/world/phys/Vec3;)V",
					locals = LocalCapture.CAPTURE_FAILHARD)
	public void onRender(final class_2631 skullBlockEntity, final float f, final class_4587 poseStack,
			final class_4597 buffer, final int i, final int j, final class_243 vec3, CallbackInfo ci, float g, class_2680 blockState, boolean bl, class_2350 direction, int k, float h, class_2484.class_2485 skullType, class_5598 model) {
		RefHolder.CPM_MODELS = modelByType;
		class_9296 gameProfile = skullBlockEntity.method_11334();
		if(skullType == class_2484.class_2486.field_11510 && gameProfile != null) {
			CustomPlayerModelsClient.INSTANCE.renderSkull(model, gameProfile.comp_2413(), buffer);
		}
	}

	@Inject(at = @At("HEAD"),
			method = "getRenderType(Lnet/minecraft/world/level/block/SkullBlock$Type;Lnet/minecraft/world/item/component/ResolvableProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;", cancellable = true)
	private static void onGetRenderType(class_2484.class_2485 type, class_9296 resolvableProfile, CallbackInfoReturnable<class_1921> cbi) {
		if (RefHolder.CPM_MODELS == null)return;
		class_5598 model = RefHolder.CPM_MODELS.apply(type);
		RefHolder.CPM_MODELS = null;
		if (type != class_2484.class_2486.field_11510 || resolvableProfile == null)return;
		ModelTexture mt = new ModelTexture(class_310.method_1551().method_1582().method_52862(resolvableProfile.comp_2413()).comp_1626());
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.SKIN);
		if (mt.getTexture() != null)
			cbi.setReturnValue(mt.getRenderType());
	}

	@Inject(at = @At("RETURN"),
			method = "renderSkull(Lnet/minecraft/core/Direction;FF"
					+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I"
					+ "Lnet/minecraft/client/model/SkullModelBase;Lnet/minecraft/client/renderer/RenderType;)V")
	private static void renderSkullPost(class_2350 direction, float yaw, float animationProgress, class_4587 matrices, class_4597 vertexConsumers, int light, class_5598 model, class_1921 renderLayer, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderSkullPost(vertexConsumers, model);
	}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import net.minecraft.class_1007;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;

@Mixin(value = class_1007.class, priority = 900)
public abstract class PlayerRendererMixinFabric extends class_922<class_742, class_591<class_742>> {

	public PlayerRendererMixinFabric(class_5618 ctx, class_591<class_742> model, float shadowRadius) {
		super(ctx, model, shadowRadius);
	}

	@Inject(at = @At("HEAD"), method = "render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V")
	public void onRenderPre(class_742 abstractClientPlayerEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.playerRenderPre(abstractClientPlayerEntity, vertexConsumerProvider, method_4038());
	}

	@Inject(at = @At("RETURN"), method = "render(Lnet/minecraft/client/player/AbstractClientPlayer;FFLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I)V")
	public void onRenderPost(class_742 abstractClientPlayerEntity, float f, float g, class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.playerRenderPost(vertexConsumerProvider, method_4038());
	}
}

package com.tom.cpm.mixin;

import java.util.Map;
import net.minecraft.class_1309;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2190;
import net.minecraft.class_2484;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5598;
import net.minecraft.class_9296;
import net.minecraft.class_9334;
import net.minecraft.class_976;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import com.mojang.authlib.GameProfile;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.RefHolder;

@Mixin(class_976.class)
public class CustomHeadLayerMixin {
	private @Shadow @Final Map<class_2484.class_2485, class_5598> skullModels;

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/blockentity/SkullBlockRenderer;"
					+ "getRenderType(Lnet/minecraft/world/level/block/SkullBlock$Type;Lnet/minecraft/world/item/component/ResolvableProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;"
			),
			method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I"
					+ "Lnet/minecraft/world/entity/LivingEntity;FFFFFF)V",
					locals = LocalCapture.CAPTURE_FAILHARD)
	public void onRender(class_4587 matrixStack, class_4597 vertexConsumerProvider, int i, class_1309 livingEntity, float f, float g, float h, float j, float k, float l, CallbackInfo ci, class_1799 itemstack) {
		class_1792 item = itemstack.method_7909();
		class_2484.class_2485 skullType = ((class_2190)((class_1747)item).method_7711()).method_9327();
		if(skullType == class_2484.class_2486.field_11510) {
			RefHolder.CPM_MODELS = skullModels;
			class_9296 resolvableProfile = itemstack.method_57824(class_9334.field_49617);
			GameProfile gameProfile = resolvableProfile != null ? resolvableProfile.comp_2413() : null;
			if(gameProfile != null) {
				class_5598 model = this.skullModels.get(skullType);
				CustomPlayerModelsClient.INSTANCE.renderSkull(model, gameProfile, vertexConsumerProvider);
			}
		}
	}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.tom.cpm.client.ClientBase.PlayerNameTagRenderer;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.LivingRendererAccess;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_1007;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_591;
import net.minecraft.class_630;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import net.minecraft.class_898;
import net.minecraft.class_922;

@Mixin(value = class_1007.class, priority = 900)
public abstract class PlayerRendererMixin extends class_922<class_742, class_591<class_742>> implements PlayerNameTagRenderer<class_742>, LivingRendererAccess {

	public PlayerRendererMixin(class_5618 p_174289_, class_591<class_742> p_174290_, float p_174291_) {
		super(p_174289_, p_174290_, p_174291_);
	}

	@Inject(
			at = @At("RETURN"),
			method = {
					"getTextureLocation(Lnet/minecraft/client/player/AbstractClientPlayer;)Lnet/minecraft/resources/ResourceLocation;"
			},
			cancellable = true)
	public void onGetEntityTexture(class_742 entity, CallbackInfoReturnable<class_2960> cbi) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(method_4038(), new ModelTexture(cbi), TextureSheetType.SKIN);
	}

	@Redirect(at =
			@At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/resources/PlayerSkin;"
							+ "texture()Lnet/minecraft/resources/ResourceLocation;"
					),
			method = "renderHand("
					+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;"
					+ "ILnet/minecraft/client/player/AbstractClientPlayer;"
					+ "Lnet/minecraft/client/model/geom/ModelPart;Lnet/minecraft/client/model/geom/ModelPart;)V"
			)
	public class_2960 getSkinTex(class_8685 skin, class_4587 poseStack, class_4597 multiBufferSource, int i, class_742 player, class_630 modelPart, class_630 modelPart2) {
		return method_3931(player);
	}

	@Inject(at = @At("HEAD"), method = "renderRightHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V")
	public void onRenderRightArmPre(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHand(vertexConsumers, method_4038());
	}

	@Inject(at = @At("HEAD"), method = "renderLeftHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V")
	public void onRenderLeftArmPre(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHand(vertexConsumers, method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderRightHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V")
	public void onRenderRightArmPost(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(vertexConsumers, method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderLeftHand(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;ILnet/minecraft/client/player/AbstractClientPlayer;)V")
	public void onRenderLeftArmPost(class_4587 matrices, class_4597 vertexConsumers, int light, class_742 player, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(vertexConsumers, method_4038());
	}

	@Inject(at = @At("HEAD"), method = "renderNameTag(Lnet/minecraft/client/player/AbstractClientPlayer;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IF)V", cancellable = true)
	public void onRenderName1(class_742 entityIn, class_2561 displayNameIn, class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, float f0, CallbackInfo cbi) {
		if(!Player.isEnableNames())cbi.cancel();
	}

	@Inject(at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/entity/LivingEntityRenderer;renderNameTag(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IF)V",
			ordinal = 1),
			method = "renderNameTag(Lnet/minecraft/client/player/AbstractClientPlayer;Lnet/minecraft/network/chat/Component;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;IF)V")
	public void onRenderName2(class_742 entityIn, class_2561 displayNameIn, class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, float f0, CallbackInfo cbi) {
		if(Player.isEnableLoadingInfo())
			CustomPlayerModelsClient.INSTANCE.renderNameTag(this, entityIn, entityIn.method_7334(), ModelDefinitionLoader.PLAYER_UNIQUE, matrixStackIn, bufferIn, packedLightIn, f0);
	}

	@Redirect(at =
			@At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/renderer/RenderType;entitySolid("
							+ "Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"
					),
			method = "renderHand("
					+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;"
					+ "ILnet/minecraft/client/player/AbstractClientPlayer;"
					+ "Lnet/minecraft/client/model/geom/ModelPart;Lnet/minecraft/client/model/geom/ModelPart;)V",
					require = 0
			)
	public class_1921 getArmLayer(class_2960 loc, class_4587 matrixStackIn, class_4597 bufferIn, int combinedLightIn, class_742 playerIn, class_630 rendererArmIn, class_630 rendererArmwearIn) {
		return CustomPlayerModelsClient.mc.getPlayerRenderManager().isBound(method_4038()) ? class_1921.method_23580(method_3931(playerIn)) : class_1921.method_23572(method_3931(playerIn));
	}

	@Override
	public void cpm$renderNameTag(class_742 entityIn, class_2561 displayNameIn, class_4587 matrixStackIn,
			class_4597 bufferIn, int packedLightIn, float f0) {
		super.method_3926(entityIn, displayNameIn, matrixStackIn, bufferIn, packedLightIn, f0);
	}

	@Override
	public class_898 cpm$entityRenderDispatcher() {
		return field_4676;
	}

	@Override
	public void cpm$onGetRenderType(class_1309 player, boolean pTranslucent, boolean pGlowing,
			CallbackInfoReturnable<class_1921> cbi) {
		if(CustomPlayerModelsClient.mc.getPlayerRenderManager().isBound(method_4038())) {
			boolean r = CustomPlayerModelsClient.mc.getPlayerRenderManager().getHolderSafe(method_4038(), null, h -> h.setInvisState(), false, false);
			if(pTranslucent)return;
			if(!pGlowing && !r)return;
			class_2960 tex = method_3931((class_742) player);
			CustomPlayerModelsClient.mc.getPlayerRenderManager().getHolderSafe(method_4038(), null, h -> h.setInvis(pGlowing), false);
			cbi.setReturnValue(
					pGlowing ?
							class_1921.method_23287(tex) :
								class_1921.method_23576(new class_2960("cpm:textures/template/empty.png"))
					);
		}
	}
}

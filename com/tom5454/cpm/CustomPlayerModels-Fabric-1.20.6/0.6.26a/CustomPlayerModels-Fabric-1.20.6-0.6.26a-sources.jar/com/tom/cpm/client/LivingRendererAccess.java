package com.tom.cpm.client;

import net.minecraft.class_1309;
import net.minecraft.class_1921;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public interface LivingRendererAccess {
	void cpm$onGetRenderType(class_1309 player, boolean pTranslucent, boolean pGlowing, CallbackInfoReturnable<class_1921> cbi);
}

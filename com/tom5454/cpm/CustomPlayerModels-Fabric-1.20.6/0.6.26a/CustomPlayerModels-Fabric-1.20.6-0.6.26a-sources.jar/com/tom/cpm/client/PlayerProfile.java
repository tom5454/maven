package com.tom.cpm.client;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.BooleanSupplier;
import net.minecraft.class_1044;
import net.minecraft.class_1046;
import net.minecraft.class_1068;
import net.minecraft.class_1304;
import net.minecraft.class_1747;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1770;
import net.minecraft.class_1799;
import net.minecraft.class_2190;
import net.minecraft.class_310;
import net.minecraft.class_4050;
import net.minecraft.class_591;
import net.minecraft.class_634;
import net.minecraft.class_640;
import net.minecraft.class_7923;
import com.mojang.authlib.GameProfile;
import com.mojang.blaze3d.systems.RenderSystem;

import com.tom.cpl.block.entity.ActiveEffect;
import com.tom.cpl.math.MathHelper;
import com.tom.cpl.util.Hand;
import com.tom.cpl.util.HandAnimation;
import com.tom.cpm.client.vr.VRPlayerRenderer;
import com.tom.cpm.common.EntityTypeHandlerImpl;
import com.tom.cpm.common.PlayerInventory;
import com.tom.cpm.common.WorldImpl;
import com.tom.cpm.mixinplugin.FPMDetector;
import com.tom.cpm.shared.animation.AnimationState;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.model.SkinType;
import com.tom.cpm.shared.model.render.PlayerModelSetup.ArmPose;
import com.tom.cpm.shared.skin.PlayerTextureLoader;
import com.tom.cpm.shared.skin.TextureType;

public class PlayerProfile extends Player<net.minecraft.class_1657> {
	public static boolean inGui;
	public static BooleanSupplier inFirstPerson;
	static {
		inFirstPerson = () -> false;
		if (FPMDetector.doApply()) {
			FirstPersonDetector.init();
		}
	}

	private final GameProfile profile;
	private String skinType;

	public static GameProfile getPlayerProfile(net.minecraft.class_1657 player) {
		if (player == null)return null;
		var profile = player.method_7334();
		if (profile.getProperties().isEmpty()) {
			var conn = class_310.method_1551().method_1562();
			if (conn != null) {
				var info = conn.method_2871(profile.getId());
				if(info != null)profile = info.method_2966();
			}
		}
		return profile;
	}

	public PlayerProfile(GameProfile profile) {
		this.profile = new GameProfile(profile.getId(), profile.getName());
		cloneProperties(profile.getProperties(), this.profile.getProperties());

		if(profile.getId() != null)
			this.skinType = class_1068.method_4648(profile.getId()).comp_1629().method_52856();
	}

	@Override
	public SkinType getSkinType() {
		return SkinType.get(skinType);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((profile == null) ? 0 : profile.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		PlayerProfile other = (PlayerProfile) obj;
		if (profile == null) {
			if (other.profile != null) return false;
		} else if (!profile.equals(other.profile)) return false;
		return true;
	}

	@Override
	public UUID getUUID() {
		return profile.getId();
	}

	@Override
	public void updateFromPlayer(AnimationState animState, net.minecraft.class_1657 player) {
		class_4050 p = player.method_18376();
		animState.resetPlayer();
		switch (p) {
		case field_18077:
			animState.elytraFlying = true;
			break;
		case field_18078:
			animState.sleeping = true;
			break;
		case field_18080:
			animState.tridentSpin = true;
			break;
		default:
			break;
		}
		animState.sneaking = player.method_18276();
		animState.crawling = player.method_20448();
		animState.swimming = player.method_20232();
		if(!player.method_5805())animState.dying = true;
		if(Platform.isSitting(player))animState.riding = true;
		if(player.method_5624())animState.sprinting = true;
		if(player.method_6115()) {
			animState.usingAnimation = HandAnimation.of(player.method_6030().method_7976());
		}
		if(player.method_5799())animState.retroSwimming = true;
		animState.moveAmountX = (float) (player.method_23317() - player.field_6014);
		animState.moveAmountY = (float) (player.method_23318() - player.field_6036);
		animState.moveAmountZ = (float) (player.method_23321() - player.field_5969);
		animState.yaw = player.method_36454();
		animState.pitch = player.method_36455();
		animState.bodyYaw = player.field_6283;

		animState.encodedState = MinecraftObject.LAYER_CODEC.getValue(player::method_7348);

		class_1799 is = player.method_6118(class_1304.field_6169);
		animState.hasSkullOnHead = is.method_7909() instanceof class_1747 && ((class_1747)is.method_7909()).method_7711() instanceof class_2190;
		animState.wearingHelm = !is.method_7960();
		is = player.method_6118(class_1304.field_6174);
		animState.wearingElytra = is.method_7909() instanceof class_1770;
		animState.wearingBody = !is.method_7960();
		animState.wearingLegs = !player.method_6118(class_1304.field_6172).method_7960();
		animState.wearingBoots = !player.method_6118(class_1304.field_6166).method_7960();
		animState.mainHand = Hand.of(player.method_6068());
		animState.activeHand = Hand.of(animState.mainHand, player.method_6058());
		animState.swingingHand = Hand.of(animState.mainHand, player.field_6266);
		animState.hurtTime = player.field_6235;
		animState.isOnLadder = player.method_6101();
		animState.isBurning = player.method_5862();
		animState.isFreezing = player.method_32312() > 0;
		animState.inGui = inGui;
		animState.firstPersonMod = inFirstPerson.getAsBoolean();
		PlayerInventory.setInv(animState, player.method_31548());
		WorldImpl.setWorld(animState, player);
		if (player.method_5854() != null)animState.vehicle = EntityTypeHandlerImpl.impl.wrap(player.method_5854().method_5864());
		player.method_6026().forEach(e -> animState.allEffects.add(new ActiveEffect(class_7923.field_41174.method_10221(e.method_5579().comp_349()).toString(), e.method_5578(), e.method_5584(), !e.method_5581())));

		if(player.method_6030().method_7909() instanceof class_1764) {
			float f = class_1764.method_7775(player.method_6030());
			float f1 = MathHelper.clamp(player.method_6048(), 0.0F, f);
			animState.crossbowPullback = f1 / f;
		}

		if(player.method_6030().method_7909() instanceof class_1753) {
			float f = 20F;
			float f1 = MathHelper.clamp(player.method_6048(), 0.0F, f);
			animState.bowPullback = f1 / f;
		}

		animState.parrotLeft = !player.method_7356().method_10558("id").isEmpty();
		animState.parrotRight = !player.method_7308().method_10558("id").isEmpty();
	}

	@Override
	public void updateFromModel(AnimationState animState, Object model) {
		if(model instanceof class_591) {
			class_591 m = (class_591) model;
			animState.resetModel();
			animState.attackTime = m.field_3447;
			animState.swimAmount = m.field_3396;
			animState.leftArm = ArmPose.of(m.field_3399);
			animState.rightArm = ArmPose.of(m.field_3395);
			if(CustomPlayerModelsClient.vrLoaded)
				animState.vrState = VRPlayerRenderer.getVRState(animState.animationMode, model);
		}
	}

	@Override
	protected PlayerTextureLoader initTextures() {
		return new PlayerTextureLoader() {

			@Override
			protected CompletableFuture<Void> load0() {
				class_310 mc = class_310.method_1551();
				return mc.method_1582().method_52863(profile).thenAcceptAsync(skin -> {
					class_1044 s = mc.method_1531().method_34590(skin.comp_1626(), null);
					class_1044 c = mc.method_1531().method_34590(skin.comp_1627(), null);
					class_1044 e = mc.method_1531().method_34590(skin.comp_1628(), null);
					if (s instanceof class_1046 h)defineTexture(TextureType.SKIN, h.field_5214, h.field_5210);
					if (c instanceof class_1046 h)defineTexture(TextureType.CAPE, h.field_5214, h.field_5210);
					if (e instanceof class_1046 h)defineTexture(TextureType.ELYTRA, h.field_5214, h.field_5210);
					skinType = skin.comp_1629().method_52856();
				}, t -> RenderSystem.recordRenderCall(t::run));
			}
		};
	}

	@Override
	public String getName() {
		return profile.getName();
	}

	@Override
	public Object getGameProfile() {
		return profile;
	}
}

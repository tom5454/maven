package com.tom.cpm.client.vr;

import org.vivecraft.client.render.VRPlayerModel;
import org.vivecraft.client.render.VRPlayerModel_WithArms;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.shared.animation.AnimationEngine.AnimationMode;
import com.tom.cpm.shared.animation.AnimationState.VRState;
import com.tom.cpm.shared.model.render.ModelRenderManager.RedirectHolder;
import net.minecraft.class_4597;
import net.minecraft.class_630;
import net.minecraft.class_742;

public class VRPlayerRenderer {

	public static boolean isVRPlayer(Object model) {
		return model instanceof VRPlayerModel;
	}

	public static RedirectHolder<?, class_4597, ModelTexture, class_630> createVRPlayer(PlayerRenderManager mngr, Object model) {
		return new RedirectHolderVRPlayer(mngr, (VRPlayerModel<class_742>) model);
	}

	public static VRState getVRState(AnimationMode mode, Object model) {
		if(mode == AnimationMode.HAND)return VRState.FIRST_PERSON;
		if(model instanceof VRPlayerModel_WithArms)return VRState.THIRD_PERSON_STANDING;
		if(model instanceof VRPlayerModel)return VRState.THIRD_PERSON_SITTING;
		return null;
	}
}

package com.tom.cpm.client;

import com.tom.cpm.shared.animation.AnimationState;
import com.tom.cpm.shared.config.Player;
import net.minecraft.class_2561;

public interface PlayerRenderStateAccess {
	void cpm$setPlayer(Player<net.minecraft.class_1657> player);
	Player<net.minecraft.class_1657> cpm$getPlayer();
	void cpm$setAnimationState(AnimationState state);
	AnimationState cpm$getAnimationState();
	void cpm$setModelStatus(class_2561 status);
	class_2561 cpm$getModelStatus();
}

package com.tom.cpm.client.vr;

import org.vivecraft.client.render.VRPlayerModel;
import org.vivecraft.client.render.VRPlayerModel_WithArms;
import com.tom.cpl.math.MatrixStack;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.client.PlayerRenderManager.RDH;
import com.tom.cpm.shared.model.PlayerModelParts;
import com.tom.cpm.shared.model.render.ModelRenderManager.Field;
import com.tom.cpm.shared.model.render.ModelRenderManager.RedirectRenderer;
import net.minecraft.class_630;

public class RedirectHolderVRPlayer extends RDH<VRPlayerModel> {
	private RedirectRenderer<class_630> head;
	private boolean seated;

	public RedirectHolderVRPlayer(PlayerRenderManager mngr, VRPlayerModel model) {
		super(mngr, model);

		seated = !(model instanceof VRPlayerModel_WithArms);

		head = registerHead(createRendered(    () -> model.field_3398     , v -> model.field_3398      = v, PlayerModelParts.HEAD));
		register(createRendered(           () -> model.field_3391     , v -> model.field_3391      = v, PlayerModelParts.BODY));
		if(seated) {
			register(createRendered(() -> model.field_3401, v -> model.field_3401 = v, PlayerModelParts.RIGHT_ARM));
			register(createRendered( () -> model.field_27433 , v -> model.field_27433  = v, PlayerModelParts.LEFT_ARM));
		} else {
			VRPlayerModel_WithArms w = (VRPlayerModel_WithArms) model;
			register(createRendered(() -> w.rightHand, v -> w.rightHand = v, PlayerModelParts.RIGHT_ARM));
			register(createRendered( () -> w.leftHand , v -> w.leftHand  = v, PlayerModelParts.LEFT_ARM));
		}
		register(createRendered(           () -> model.field_3392 , v -> model.field_3392  = v, PlayerModelParts.RIGHT_LEG));
		register(createRendered(           () -> model.field_3397  , v -> model.field_3397   = v, PlayerModelParts.LEFT_LEG));

		register(create2ndLayer(() -> model.field_3394        , v -> model.field_3394         = v, null)).setCopyFrom(head);
		register(create2ndLayer(() -> model.field_3484 , v -> model.field_3484  = v, null));
		register(create2ndLayer(() -> model.field_3486, v -> model.field_3486 = v, null));
		register(create2ndLayer(() -> model.field_3482  , v -> model.field_3482   = v, null));
		register(create2ndLayer(() -> model.field_3479 , v -> model.field_3479  = v, null));
		register(create2ndLayer(() -> model.field_3483     , v -> model.field_3483      = v, null));

		//register(new Field<>(() -> model.vrHMD, v -> model.vrHMD = v, null));//disable
		if(!seated) {
			VRPlayerModel_WithArms w = (VRPlayerModel_WithArms) model;
			register(new Field<>(() -> w.field_27433 , v -> w.field_27433  = v, null));//disable
			register(new Field<>(() -> w.field_3401, v -> w.field_3401 = v, null));//disable

			register(new Field<>(() -> w.leftHandSleeve , v -> w.leftHandSleeve  = v, null));//disable
			register(new Field<>(() -> w.rightHandSleeve, v -> w.rightHandSleeve = v, null));//disable
		}
		//register(new Field<>(() -> model.cloak, v -> model.cloak = v, RootModelType.CAPE));
	}

	@Override
	protected void setupTransform(MatrixStack stack, RedirectRenderer<class_630> part, boolean pre) {
	}
}

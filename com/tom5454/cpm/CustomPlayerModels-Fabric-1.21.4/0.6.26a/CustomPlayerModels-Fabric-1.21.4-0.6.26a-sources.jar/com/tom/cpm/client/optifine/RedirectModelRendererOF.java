package com.tom.cpm.client.optifine;

import java.util.function.Supplier;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;
import com.tom.cpm.client.PlayerRenderManager.RDH;
import com.tom.cpm.client.PlayerRenderManager.RedirectModelRendererVanilla;
import com.tom.cpm.shared.model.render.VanillaModelPart;

public class RedirectModelRendererOF extends RedirectModelRendererVanilla {

	public RedirectModelRendererOF(RDH holder, Supplier<class_630> parent, VanillaModelPart part) {
		super(holder, parent, part);
	}

	public void render(class_4587 matrixStackIn, class_4588 bufferIn, int packedLightIn, int packedOverlayIn, int color, boolean updateModel) {
		method_22699(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, color);
	}
}

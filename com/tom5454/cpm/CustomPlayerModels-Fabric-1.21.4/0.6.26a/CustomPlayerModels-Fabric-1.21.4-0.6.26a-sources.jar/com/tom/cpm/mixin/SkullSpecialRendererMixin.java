package com.tom.cpm.mixin;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.mojang.authlib.GameProfile;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.RefHolder;
import net.minecraft.class_10513;
import net.minecraft.class_2484;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5598;
import net.minecraft.class_811;
import net.minecraft.class_9296;

@Mixin(class_10513.class)
public class SkullSpecialRendererMixin {
	private @Shadow @Final class_2484.class_2485 skullType;
	private @Shadow @Final class_5598 model;

	@Inject(at = @At("HEAD"), method = "render")
	public void onRender(
			@Nullable class_9296 resolvableProfile,
			class_811 itemDisplayContext,
			class_4587 poseStack,
			class_4597 multiBufferSource,
			int i,
			int j,
			boolean bl,
			CallbackInfo cbi
			) {
		if (skullType == class_2484.class_2486.field_11510) {
			RefHolder.CPM_MODELS = t -> t == skullType ? model : null;
			GameProfile gameProfile = resolvableProfile != null ? resolvableProfile.comp_2413() : null;
			if (gameProfile != null) {
				CustomPlayerModelsClient.INSTANCE.renderSkull(model, gameProfile, multiBufferSource);
			}
		}
	}
}

package com.tom.cpm.client;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4080;
import com.tom.cpl.tag.TagManager;
import com.tom.cpm.shared.MinecraftObjectHolder;
import com.tom.cpm.shared.util.ErrorLog;
import com.tom.cpm.shared.util.ErrorLog.LogLevel;

public class CPMTagLoader extends class_4080<Map<String, List<Map<String, Object>>>> {
	private final TagManager<?> tags;
	protected final String prefix;
	protected final class_2960 id;

	public CPMTagLoader(Consumer<CPMTagLoader> mc, TagManager<?> tags, String prefix) {
		this.tags = tags;
		this.prefix = prefix;
		this.id = class_2960.method_43902("cpm", "tags_" + prefix);
		mc.accept(this);
	}

	@Override
	protected Map<String, List<Map<String, Object>>> method_18789(class_3300 mngr, class_3695 profiler) {
		return load(mngr);
	}

	@Override
	protected void apply(Map<String, List<Map<String, Object>>> tagMap, class_3300 mngr, class_3695 profiler) {
		tags.applyBuiltin(tagMap, prefix);
	}

	@SuppressWarnings("unchecked")
	private Map<String, List<Map<String, Object>>> load(class_3300 mngr) {
		Map<String, List<Map<String, Object>>> el = new HashMap<>();
		mngr.method_41265("cpm_tags/" + prefix, l -> l.method_12832().endsWith(".json")).forEach((rl, rs) -> {
			List<Map<String, Object>> res = new ArrayList<>();
			el.put(rl.method_12836() + ":" + rl.method_12832().substring(9, rl.method_12832().length() - 5), res);
			rs.forEach(r -> {
				try (BufferedReader rd = r.method_43039()) {
					Map<String, Object> tag = (Map<String, Object>) MinecraftObjectHolder.gson.fromJson(rd, Object.class);
					res.add(tag);
				} catch (Exception e) {
					ErrorLog.addLog(LogLevel.WARNING, "Failed to load cpm builtin tag: " + rl, e);
				}
			});
		});
		return el;
	}
}

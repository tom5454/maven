package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.LivingRendererAccessFabric;
import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;

@Mixin(class_922.class)
public abstract class LivingRendererMixinFabric<T extends class_1309, S extends class_10042, M extends class_583<? super S>> extends class_897<T, S> implements LivingRendererAccessFabric {

	protected LivingRendererMixinFabric(class_5618 p_174008_) {
		super(p_174008_);
	}

	@Inject(at = @At("HEAD"), method = "render")
	public void onRenderPre(class_10042 state, final class_4587 poseStack, final class_4597 multiBufferSource, final int i, CallbackInfo cbi) {
		cpm$renderPre(state, poseStack, multiBufferSource, i);
	}

	@Inject(at = @At("RETURN"), method = "render")
	public void onRenderPost(class_10042 state, final class_4587 poseStack, final class_4597 multiBufferSource, final int i, CallbackInfo cbi) {
		cpm$renderPost(state, poseStack, multiBufferSource, i);
	}
}

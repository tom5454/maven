package com.tom.cpm.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.common.ServerHandler;
import net.minecraft.class_3222;

@Mixin(class_3222.class)
public class PlayerMixin {

	@Inject(at = @At("HEAD"), method = "jumpFromGround()V")
	public void onJump(CallbackInfo cbi) {
		ServerHandler.jump(this);
	}
}

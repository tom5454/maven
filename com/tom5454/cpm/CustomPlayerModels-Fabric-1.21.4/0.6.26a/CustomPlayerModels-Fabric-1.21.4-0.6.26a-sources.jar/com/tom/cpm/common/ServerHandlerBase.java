package com.tom.cpm.common;

import java.util.Collections;
import java.util.function.Function;
import net.minecraft.class_1657;
import net.minecraft.class_2658;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3898;
import net.minecraft.class_5629;
import net.minecraft.class_8710;
import net.minecraft.class_9812;
import com.tom.cpm.shared.network.NetHandler;

public class ServerHandlerBase {

	public static NetHandler<class_8710.class_9154<ByteArrayPayload>, class_3222, class_3244> init() {
		NetHandler<class_8710.class_9154<ByteArrayPayload>, class_3222, class_3244> netHandler = new NetHandler<>((k, v) -> new class_8710.class_9154<>(class_2960.method_43902(k, v)));
		netHandler.setGetPlayerUUID(class_3222::method_5667);
		netHandler.setSendPacketServer(Function.identity(), (c, rl, pb) -> c.method_14364(new class_2658(new ByteArrayPayload(rl, pb))), ent -> {
			class_3898.class_3208 tr = ((class_3218)ent.method_37908()).method_14178().field_17254.field_18242.get(ent.method_5628());
			if(tr != null) {
				return tr.field_18250;
			}
			return Collections.emptyList();
		}, class_5629::method_32311);
		netHandler.setFindTracking((p, f) -> {
			for(class_3898.class_3208 tr : ((class_3218)p.method_37908()).method_14178().field_17254.field_18242.values()) {
				if(tr.field_18247 instanceof class_1657 && tr.field_18250.contains(p.field_13987)) {
					f.accept((class_3222) tr.field_18247);
				}
			}
		});
		netHandler.setSendChat((p, m) -> p.method_7353(m.remap(), false));
		netHandler.setGetNet(spe -> spe.field_13987);
		netHandler.setGetPlayer(net -> net.field_14140);
		netHandler.setGetPlayerId(class_3222::method_5628);
		netHandler.setKickPlayer((p, m) -> p.field_13987.method_60673(new class_9812(m.remap())));
		netHandler.setGetPlayerAnimGetters(new PlayerAnimUpdater());
		netHandler.addScaler(new AttributeScaler());
		return netHandler;
	}
}

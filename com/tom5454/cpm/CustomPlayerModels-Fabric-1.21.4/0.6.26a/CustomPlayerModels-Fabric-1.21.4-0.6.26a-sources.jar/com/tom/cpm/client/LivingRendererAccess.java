package com.tom.cpm.client;

import net.minecraft.class_10042;
import net.minecraft.class_1921;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public interface LivingRendererAccess {
	default void cpm$onGetRenderType(class_10042 player, boolean pTranslucent, boolean pGlowing, CallbackInfoReturnable<class_1921> cbi) {}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import net.minecraft.class_10034;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_563;
import net.minecraft.class_572;
import net.minecraft.class_583;
import net.minecraft.class_979;

@Mixin(class_979.class)
public abstract class WingsLayerMixin extends class_3887<class_10034, class_583<class_10034>> {

	public WingsLayerMixin(
			class_3883<class_10034, class_583<class_10034>> renderLayerParent) {
		super(renderLayerParent);
	}

	private @Shadow @Final class_563 elytraModel;

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V"),
			method = "render")
	public void preRender(final class_4587 poseStack, final class_4597 multiBufferSource, final int i,
			final class_10034 humanoidRenderState, final float f, final float g, CallbackInfo cbi) {
		if(method_17165() instanceof class_572) {
			CustomPlayerModelsClient.INSTANCE.renderElytra((class_572<class_10034>) method_17165(), elytraModel);
		}
	}

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V"),
			method = "render")
	public void postRender(final class_4587 poseStack, final class_4597 multiBufferSource, final int i,
			final class_10034 humanoidRenderState, final float f, final float g, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbind(elytraModel);
	}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import net.minecraft.class_10034;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;

@Mixin(class_970.class)
public abstract class HumanoidArmorLayerMixin extends class_3887<class_10034, class_572<class_10034>> {

	public HumanoidArmorLayerMixin(
			class_3883<class_10034, class_572<class_10034>> renderLayerParent) {
		super(renderLayerParent);
	}

	private @Final @Shadow class_572<class_10034> innerModel;
	private @Final @Shadow class_572<class_10034> outerModel;

	@Inject(at = @At("HEAD"), method = "render")
	public void preRender(class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, class_10034 entitylivingbaseIn, float a, float b, CallbackInfo cbi) {
		if(method_17165() instanceof class_572) {
			CustomPlayerModelsClient.INSTANCE.renderArmor(outerModel, innerModel, method_17165());
		}
	}

	@Inject(at = @At("RETURN"), method = "render")
	public void postRender(class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, class_10034 entitylivingbaseIn, float a, float b, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbind(outerModel);
		CustomPlayerModelsClient.INSTANCE.manager.unbind(innerModel);
	}
}

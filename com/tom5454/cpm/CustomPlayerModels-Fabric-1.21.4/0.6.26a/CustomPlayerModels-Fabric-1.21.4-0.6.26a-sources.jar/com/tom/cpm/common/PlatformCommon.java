package com.tom.cpm.common;

import net.minecraft.class_1959;

public class PlatformCommon {

	public static class_1959.class_5482 getClimateSettings(class_1959 b) {
		return b.field_26393;
	}
}

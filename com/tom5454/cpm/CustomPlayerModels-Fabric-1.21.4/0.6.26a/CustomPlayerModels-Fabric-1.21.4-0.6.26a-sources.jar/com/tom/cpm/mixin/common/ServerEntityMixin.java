package com.tom.cpm.mixin.common;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.common.ServerHandler;
import net.minecraft.class_1297;
import net.minecraft.class_3222;
import net.minecraft.class_3231;

@Mixin(class_3231.class)
public class ServerEntityMixin {

	private @Shadow @Final class_1297 entity;

	@Inject(method = "addPairing(Lnet/minecraft/server/level/ServerPlayer;)V", at = @At("RETURN"))
	private void onStartTracking(class_3222 player, CallbackInfo ci) {
		ServerHandler.onTrackingStart(entity, player);
	}
}

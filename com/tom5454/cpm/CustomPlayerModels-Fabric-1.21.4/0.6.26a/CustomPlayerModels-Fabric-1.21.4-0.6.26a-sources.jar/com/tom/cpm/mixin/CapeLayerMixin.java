package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CapeTransformUtil;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.PlayerRenderStateAccess;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_10055;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_972;

@Mixin(class_972.class)
public abstract class CapeLayerMixin extends class_3887<class_10055, class_591> {
	private @Shadow @Final class_572<class_10055> model;

	public CapeLayerMixin(class_3883<class_10055, class_591> renderLayerParent) {
		super(renderLayerParent);
	}

	@Inject(at = @At("HEAD"), method = "render"
			+ "(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I"
			+ "Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;FF)V", cancellable = true)
	public void onRender(final class_4587 poseStack, final class_4597 bufferIn, final int i,
			final class_10055 state, final float f, final float g, CallbackInfo cbi) {
		Player<?> pl = ((PlayerRenderStateAccess) state).cpm$getPlayer();
		if (pl != null) {
			ModelDefinition def = pl.getModelDefinition();
			if (def != null && def.hasRoot(RootModelType.CAPE)) {
				class_1799 chestplate = state.field_53418;

				if (!state.field_53333 && state.field_53532 && chestplate.method_7909() != class_1802.field_8833) {
					class_2960 defLoc = state.field_53520.comp_1627();
					if(defLoc == null)defLoc = CustomPlayerModelsClient.DEFAULT_CAPE;
					ModelTexture mt = new ModelTexture(defLoc);
					CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSubModel(method_17165(), model, null);
					CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.CAPE);
					if(mt.getTexture() != null) {
						class_4588 buffer = bufferIn.getBuffer(mt.getRenderType());
						this.model.method_17087(state);
						CapeTransformUtil.applyTransform(model);
						CustomPlayerModelsClient.mc.getPlayerRenderManager().setModelPose(model);
						this.model.method_60879(poseStack, buffer, i, class_4608.field_21444);
					}
					CustomPlayerModelsClient.mc.getPlayerRenderManager().unbindModel(model);
				}
				cbi.cancel();
			}
		}
	}
}

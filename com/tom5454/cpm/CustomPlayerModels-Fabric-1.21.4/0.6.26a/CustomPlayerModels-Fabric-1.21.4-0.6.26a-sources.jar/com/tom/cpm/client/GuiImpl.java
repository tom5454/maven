package com.tom.cpm.client;

import java.io.File;
import java.nio.file.Path;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;
import net.minecraft.class_1074;
import net.minecraft.class_155;
import net.minecraft.class_156;
import net.minecraft.class_1659;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4588;
import net.minecraft.class_5244;
import net.minecraft.client.ClientBrandRetriever;
import com.mojang.blaze3d.systems.RenderSystem;
import com.tom.cpl.gui.Frame;
import com.tom.cpl.gui.IGui;
import com.tom.cpl.gui.KeyCodes;
import com.tom.cpl.gui.KeyboardEvent;
import com.tom.cpl.gui.MouseEvent;
import com.tom.cpl.gui.NativeGuiComponents;
import com.tom.cpl.gui.NativeGuiComponents.NativeConstructor;
import com.tom.cpl.gui.UIColors;
import com.tom.cpl.gui.elements.FileChooserPopup;
import com.tom.cpl.gui.elements.TextField;
import com.tom.cpl.gui.elements.TextField.ITextField;
import com.tom.cpl.item.Stack;
import com.tom.cpl.math.Box;
import com.tom.cpl.math.Vec2i;
import com.tom.cpl.text.IText;
import com.tom.cpm.client.MinecraftObject.DynTexture;
import com.tom.cpm.common.ItemStackHandlerImpl;
import com.tom.cpm.mixin.GuiAccessor;
import com.tom.cpm.shared.MinecraftCommonAccess;
import com.tom.cpm.shared.gui.panel.Panel3d;

public class GuiImpl extends class_437 implements IGui {
	protected static final KeyCodes CODES = new GLFWKeyCodes();
	protected static final NativeGuiComponents nativeComponents = new NativeGuiComponents();
	protected Frame gui;
	protected class_437 parent;
	protected CtxStack stack;
	protected UIColors colors;
	protected Consumer<Runnable> closeListener;
	protected int keyModif;
	protected class_332 graphics;
	protected boolean noScissorTest;
	protected int vanillaScale = -1;

	static {
		nativeComponents.register(TextField.class, local(GuiImpl::createTextField));
		nativeComponents.register(FileChooserPopup.class, TinyFDChooser::new);
		nativeComponents.register(Panel3d.class, Panel3dImpl::new);
	}

	public GuiImpl(Function<IGui, Frame> creator, class_437 parent) {
		super(class_2561.method_43470(""));
		this.colors = new UIColors();
		this.parent = parent;
		try {
			this.gui = creator.apply(this);
		} catch (Throwable e) {
			onGuiException("Error creating gui", e, true);
		}
		noScissorTest = isCtrlDown();
	}

	private static <G extends Supplier<IGui>, N> NativeConstructor<G, N> local(Function<GuiImpl, N> fac) {
		return f -> fac.apply((GuiImpl) f.get());
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		method_25420(graphics, mouseX, mouseY, partialTicks);
		try {
			this.graphics = graphics;
			graphics.method_51448().method_22903();
			stack = new CtxStack(field_22789, field_22790);
			RenderSystem.disableDepthTest();
			float pt = field_22787.method_61966().method_60638();
			this.gui.draw(mouseX, mouseY, pt);
		} catch (Throwable e) {
			onGuiException("Error drawing gui", e, true);
		} finally {
			if(!noScissorTest)
				RenderSystem.disableScissor();
			String modVer = MinecraftCommonAccess.get().getModVersion();
			String s = "Minecraft " + class_155.method_16673().method_48019() + " (" + field_22787.method_1515() + "/" + ClientBrandRetriever.getClientModName() + ("release".equalsIgnoreCase(field_22787.method_1547()) ? "" : "/" + field_22787.method_1547()) + ") " + modVer;
			graphics.method_51433(field_22793, s, field_22789 - field_22793.method_1727(s) - 4, 2, 0xff000000, false);
			s = field_22787.field_1770;
			if(noScissorTest)s += " No Scissor";
			graphics.method_51433(field_22793, s, field_22789 - field_22793.method_1727(s) - 4, 11, 0xff000000, false);
			this.graphics = null;
			graphics.method_51448().method_22909();
		}
		if(field_22787.field_1724 != null && gui.enableChat()) {
			graphics.method_51448().method_22903();
			graphics.method_51448().method_46416(0, 0, 800);
			((GuiAccessor) field_22787.field_1705).callRenderChat(graphics, field_22787.method_61966());
			graphics.method_51448().method_22909();
		}
	}

	@Override
	public void method_25432() {
		if(vanillaScale >= 0 && vanillaScale != field_22787.field_1690.method_42474().method_41753()) {
			int v = vanillaScale;
			vanillaScale = -999;
			field_22787.field_1690.method_42474().method_41748(v);
		}
	}

	@Override
	public void method_25419() {
		class_437 p = parent;
		parent = null;
		field_22787.method_1507(p);
	}

	@Override
	public void drawBox(int x, int y, int w, int h, int color) {
		x += getOffset().x;
		y += getOffset().y;
		graphics.method_48196(class_1921.method_51785(), x, y, x+w, y+h, 0, color);
	}

	@Override
	public void drawBox(float xI, float yI, float w, float h, int color) {
		graphics.method_64039(b -> {
			float x = xI + getOffset().x;
			float y = yI + getOffset().y;

			float minX = x;
			float minY = y;
			float maxX = x+w;
			float maxY = y+h;

			if (minX < maxX) {
				float i = minX;
				minX = maxX;
				maxX = i;
			}

			if (minY < maxY) {
				float j = minY;
				minY = maxY;
				maxY = j;
			}
			Matrix4f matrix = graphics.method_51448().method_23760().method_23761();
			float f3 = (color >> 24 & 255) / 255.0F;
			float f = (color >> 16 & 255) / 255.0F;
			float f1 = (color >> 8 & 255) / 255.0F;
			float f2 = (color & 255) / 255.0F;
			class_4588 bufferbuilder = b.getBuffer(class_1921.method_51785());
			bufferbuilder.method_22918(matrix, minX, maxY, 0.0F).method_22915(f, f1, f2, f3);
			bufferbuilder.method_22918(matrix, maxX, maxY, 0.0F).method_22915(f, f1, f2, f3);
			bufferbuilder.method_22918(matrix, maxX, minY, 0.0F).method_22915(f, f1, f2, f3);
			bufferbuilder.method_22918(matrix, minX, minY, 0.0F).method_22915(f, f1, f2, f3);
			graphics.method_51452();
		});
	}

	@Override
	protected void method_25426() {
		try {
			gui.init(field_22789, field_22790);
		} catch (Throwable e) {
			onGuiException("Error in init gui", e, true);
		}
	}
	@Override
	public void drawText(int x, int y, String text, int color) {
		x += getOffset().x;
		y += getOffset().y;
		graphics.method_51448().method_22903();
		graphics.method_51448().method_46416(0, 0, 500);
		graphics.method_51433(field_22793, text, x, y, color, false);
		graphics.method_51448().method_22909();
	}

	@Override
	public boolean method_25404(int keyCode, int scanCode, int modifiers) {
		try {
			this.keyModif = modifiers;
			KeyboardEvent evt = new KeyboardEvent(keyCode, scanCode, (char) -1, GLFW.glfwGetKeyName(keyCode, scanCode));
			gui.keyPressed(evt);
			if(!evt.isConsumed()) {
				if(field_22787.field_1724 != null && field_22787.field_1690.field_1890.method_1417(keyCode, scanCode) && field_22787.field_1690.method_42539().method_41753() != class_1659.field_7536) {
					RenderSystem.recordRenderCall(() -> {
						int scale = vanillaScale;
						vanillaScale = -1;
						field_22787.method_1507(new Overlay(scale));
						vanillaScale = scale;
					});
					return true;
				}
			}
			return true;
		} catch (Throwable e) {
			onGuiException("Error processing key event", e, false);
			return true;
		}
	}

	@Override
	public boolean method_25400(char codePoint, int modifiers) {
		try {
			this.keyModif = modifiers;
			KeyboardEvent evt = new KeyboardEvent(-1, -1, codePoint, null);
			gui.keyPressed(evt);
			return evt.isConsumed();
		} catch (Throwable e) {
			onGuiException("Error processing key event", e, false);
			return true;
		}
	}

	@Override
	public boolean method_25402(double mouseX, double mouseY, int button) {
		try {
			MouseEvent evt = new MouseEvent((int) mouseX, (int) mouseY, button);
			gui.mouseClick(evt);
			return evt.isConsumed();
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
			return true;
		}
	}

	@Override
	public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
		try {
			MouseEvent evt = new MouseEvent((int) mouseX, (int) mouseY, button);
			gui.mouseDrag(evt);
			return evt.isConsumed();
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
			return true;
		}
	}

	@Override
	public boolean method_25406(double mouseX, double mouseY, int button) {
		try {
			MouseEvent evt = new MouseEvent((int) mouseX, (int) mouseY, button);
			gui.mouseRelease(evt);
			return evt.isConsumed();
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
			return true;
		}
	}

	@Override
	public boolean method_25401(double mouseX, double mouseY, double xdelta, double ydelta) {
		if(ydelta != 0) {
			try {
				MouseEvent evt = new MouseEvent((int) mouseX, (int) mouseY, (int) ydelta);
				gui.mouseWheel(evt);
				return evt.isConsumed();
			} catch (Throwable e) {
				onGuiException("Error processing mouse event", e, false);
				return true;
			}
		}
		return false;
	}

	@Override
	public void method_29638(List<Path> filesIn) {
		try {
			gui.filesDropped(filesIn.stream().map(Path::toFile).filter(File::exists).collect(Collectors.toList()));
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
		}
	}

	@Override
	public void displayError(String e) {
		class_437 p = parent;
		parent = null;
		class_310.method_1551().method_1507(new CrashScreen(e, p));
	}

	private static class CrashScreen extends class_437 {
		private String error;
		private class_437 parent;

		public CrashScreen(String error, class_437 p) {
			super(class_2561.method_43470("Error"));
			this.error = error;
			parent = p;
		}

		@Override
		public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
			super.method_25394(graphics, mouseX, mouseY, partialTicks);
			String[] txt = class_1074.method_4662("error.cpm.crash", error).split("\\\\");
			for (int i = 0; i < txt.length; i++) {
				graphics.method_25300(this.field_22793, txt[i], this.field_22789 / 2, 15 + i * 10, 16777215);
			}
		}

		@Override
		protected void method_25426() {
			super.method_25426();
			this.method_37063(class_4185.method_46430(class_5244.field_24339, (p_213034_1_) -> {
				this.field_22787.method_1507((class_437)null);
			}).method_46434(this.field_22789 / 2 - 100, 140, 200, 20).method_46431());
		}

		@Override
		public void method_25419() {
			if(parent != null) {
				class_437 p = parent;
				parent = null;
				field_22787.method_1507(p);
			}
		}
	}

	@Override
	public void closeGui() {
		if(closeListener != null) {
			closeListener.accept(this::method_25419);
		} else
			method_25419();
	}

	@Override
	public void drawTexture(int x, int y, int w, int h, int u, int v, String texture) {
		x += getOffset().x;
		y += getOffset().y;
		graphics.method_25290(class_1921::method_62277, class_2960.method_43902("cpm", "textures/gui/" + texture + ".png"), x, y, u, v, w, h, 256, 256);
	}

	@Override
	public void drawTexture(int x, int y, int w, int h, int u, int v, String texture, int color) {
		x += getOffset().x;
		y += getOffset().y;
		graphics.method_25291(class_1921::method_62277, class_2960.method_43902("cpm", "textures/gui/" + texture + ".png"), x, y, u, v, w, h, 256, 256, color);
	}

	@Override
	public void drawTexture(int xI, int yI, int width, int height, float u1, float v1, float u2, float v2) {
		graphics.method_64039(b -> {
			int x = xI + getOffset().x;
			int y = yI + getOffset().y;
			class_2960 rl = DynTexture.getBoundLoc();
			final class_4588 vertexConsumer = b.getBuffer(class_1921.method_62277(rl));
			float bo = 0;
			Matrix4f matrix = graphics.method_51448().method_23760().method_23761();
			vertexConsumer.method_22918(matrix, x, y + height, bo).method_22913(u1, v2).method_39415(-1);
			vertexConsumer.method_22918(matrix, x + width, y + height, bo).method_22913(u2, v2).method_39415(-1);
			vertexConsumer.method_22918(matrix, x + width, y, bo).method_22913(u2, v1).method_39415(-1);
			vertexConsumer.method_22918(matrix, x, y, bo).method_22913(u1, v1).method_39415(-1);
		});
	}

	@Override
	public String i18nFormat(String key, Object... obj) {
		return class_1074.method_4662(key, obj);
	}

	@Override
	public void setupCut() {
		if(!noScissorTest) {
			graphics.method_51452();
			int dw = field_22787.method_22683().method_4489();
			int dh = field_22787.method_22683().method_4506();
			float multiplierX = dw / (float)field_22789;
			float multiplierY = dh / (float)field_22790;
			Box box = getContext().cutBox;
			RenderSystem.enableScissor((int) (box.x * multiplierX), dh - (int) ((box.y + box.h) * multiplierY),
					(int) (box.w * multiplierX), (int) (box.h * multiplierY));
		}
	}

	@Override
	public int textWidth(String text) {
		return field_22793.method_1727(text);
	}

	private ITextField createTextField() {
		return new TxtField();
	}

	private class TxtField implements ITextField, Consumer<String> {
		private class_342 field;
		private Runnable eventListener;
		private Vec2i currentOff = new Vec2i(0, 0);
		private Box bounds = new Box(0, 0, 0, 0);
		private boolean settingText, updateField, enabled;
		public TxtField() {
			this.field = new class_342(field_22793, 0, 0, 0, 0, class_2561.method_43471("narrator.cpm.field"));
			this.field.method_1880(1024*1024);
			this.field.method_1858(false);
			this.field.method_1862(true);
			this.field.method_1868(colors.label_text_color);
			this.field.method_1863(this);
			this.enabled = true;
		}

		@Override
		public void draw(int mouseX, int mouseY, float partialTicks, Box bounds) {
			Vec2i off = getOffset();
			field.method_46421(bounds.x + off.x + 4);
			field.method_46419(bounds.y + off.y + 6);
			currentOff.x = off.x;
			currentOff.y = off.y;
			this.bounds.x = bounds.x;
			this.bounds.y = bounds.y;
			this.bounds.w = bounds.w;
			this.bounds.h = bounds.h;
			field.method_25358(bounds.w - 5);
			Platform.setHeight(field, bounds.h - 12);
			if(updateField) {
				settingText = true;
				field.method_1872(false);
				settingText = false;
				updateField = false;
			}
			graphics.method_51448().method_22903();
			graphics.method_51448().method_46416(0, 0, 400);
			field.method_25394(graphics, mouseX, mouseY, partialTicks);
			graphics.method_51448().method_22909();
		}

		@Override
		public void keyPressed(KeyboardEvent evt) {
			if(evt.isConsumed())return;
			if(evt.keyCode == -1) {
				if(field.method_25400(evt.charTyped, keyModif))
					evt.consume();
			} else {
				if(field.method_25404(evt.keyCode, evt.scancode, keyModif) || field.method_20315())
					evt.consume();
			}
		}

		@Override
		public void mouseClick(MouseEvent evt) {
			if(evt.isConsumed() || !enabled) {
				field.method_25365(false);
				field.method_1884(field.method_1881());
				return;
			}
			field.method_46421(bounds.x + currentOff.x);
			field.method_46419(bounds.y + currentOff.y);
			field.method_25358(bounds.w);
			Platform.setHeight(field, bounds.h);
			if(field.method_25402(evt.x + currentOff.x, evt.y + currentOff.y, evt.btn)) {
				field.method_25365(true);
				evt.consume();
			} else {
				field.method_25365(false);
				field.method_1884(field.method_1881());
			}
		}

		@Override
		public String getText() {
			return field.method_1882();
		}

		@Override
		public void setText(String txt) {
			this.settingText = true;
			field.method_1852(txt);
			this.settingText = false;
			this.updateField = true;
		}

		@Override
		public void setEventListener(Runnable eventListener) {
			this.eventListener = eventListener;
		}

		@Override
		public void accept(String value) {
			if(eventListener != null && !settingText && enabled)eventListener.run();
		}

		@Override
		public void setEnabled(boolean enabled) {
			field.method_1888(enabled);
			this.enabled = enabled;
		}

		@Override
		public boolean isFocused() {
			return field.method_25370();
		}

		@Override
		public void setFocused(boolean focused) {
			field.method_25365(focused);
		}

		@Override
		public int getCursorPos() {
			return field.method_1881();
		}

		@Override
		public void setCursorPos(int pos) {
			field.method_1875(pos);
		}

		@Override
		public void setSelectionPos(int pos) {
			field.method_1884(pos);
		}

		@Override
		public int getSelectionPos() {
			return field.field_2101;
		}
	}

	@Override
	public UIColors getColors() {
		return colors;
	}

	@Override
	public void setCloseListener(Consumer<Runnable> listener) {
		this.closeListener = listener;
	}

	@Override
	public boolean isShiftDown() {
		return method_25442();
	}

	@Override
	public boolean isCtrlDown() {
		return method_25441();
	}

	@Override
	public boolean isAltDown() {
		return method_25443();
	}

	public class Overlay extends class_408 {
		private int vanillaScaleReset;

		public Overlay(int vanillaScaleReset) {
			super("");
			this.vanillaScaleReset = vanillaScaleReset;
		}

		@Override
		public void method_25394(class_332 gr, int mouseX, int mouseY, float partialTicks) {
			gr.method_51448().method_22903();
			gr.method_51448().method_46416(0, 0, -50);
			GuiImpl.this.method_25394(gr, Integer.MIN_VALUE, Integer.MIN_VALUE, partialTicks);
			gr.method_51448().method_22909();
			gr.method_51448().method_22903();
			gr.method_51448().method_46416(0, 0, 500);
			super.method_25394(gr, mouseX, mouseY, partialTicks);
			gr.method_51448().method_22909();
		}

		@Override
		public void method_25432() {
			super.method_25432();
			field_22787.method_63588(() -> {
				field_22787.method_1507(GuiImpl.this);
				vanillaScale = vanillaScaleReset;
			});
		}
	}

	@Override
	public KeyCodes getKeyCodes() {
		return CODES;
	}

	@Override
	public void drawGradientBox(int xI, int yI, int w, int h, int topLeft, int topRight, int bottomLeft,
			int bottomRight) {
		graphics.method_64039(b -> {
			int x = xI + getOffset().x;
			int y = yI + getOffset().y;
			int left = x;
			int top = y;
			int right = x + w;
			int bottom = y + h;
			float atr = (topRight >> 24 & 255) / 255.0F;
			float rtr = (topRight >> 16 & 255) / 255.0F;
			float gtr = (topRight >> 8 & 255) / 255.0F;
			float btr = (topRight & 255) / 255.0F;
			float atl = (topLeft >> 24 & 255) / 255.0F;
			float rtl = (topLeft >> 16 & 255) / 255.0F;
			float gtl = (topLeft >> 8 & 255) / 255.0F;
			float btl = (topLeft & 255) / 255.0F;
			float abl = (bottomLeft >> 24 & 255) / 255.0F;
			float rbl = (bottomLeft >> 16 & 255) / 255.0F;
			float gbl = (bottomLeft >> 8 & 255) / 255.0F;
			float bbl = (bottomLeft & 255) / 255.0F;
			float abr = (bottomRight >> 24 & 255) / 255.0F;
			float rbr = (bottomRight >> 16 & 255) / 255.0F;
			float gbr = (bottomRight >> 8 & 255) / 255.0F;
			float bbr = (bottomRight & 255) / 255.0F;
			class_4588 bufferbuilder = b.getBuffer(class_1921.method_51785());
			Matrix4f mat = graphics.method_51448().method_23760().method_23761();
			float bo = 0;
			bufferbuilder.method_22918(mat, right, top, bo).method_22915(rtr, gtr, btr, atr);
			bufferbuilder.method_22918(mat, left, top, bo).method_22915(rtl, gtl, btl, atl);
			bufferbuilder.method_22918(mat, left, bottom, bo).method_22915(rbl, gbl, bbl, abl);
			bufferbuilder.method_22918(mat, right, bottom, bo).method_22915(rbr, gbr, bbr, abr);
		});
	}

	@Override
	public NativeGuiComponents getNative() {
		return nativeComponents;
	}

	@Override
	public void setClipboardText(String text) {
		field_22787.field_1774.method_1455(text);
	}

	@Override
	public Frame getFrame() {
		return gui;
	}

	@Override
	public String getClipboardText() {
		return field_22787.field_1774.method_1460();
	}

	@Override
	public void setScale(int value) {
		if(vanillaScale == -999)return;
		if(value != field_22787.field_1690.method_42474().method_41753()) {
			if(vanillaScale == -1)vanillaScale = field_22787.field_1690.method_42474().method_41753();
			if(value == -1) {
				if(field_22787.field_1690.method_42474().method_41753() != vanillaScale) {
					field_22787.field_1690.method_42474().method_41748(vanillaScale);
					vanillaScale = -1;
				}
			} else {
				field_22787.field_1690.method_42474().method_41748(value);
			}
		}
	}

	@Override
	public int getScale() {
		return field_22787.field_1690.method_42474().method_41753();
	}

	@Override
	public int getMaxScale() {
		return field_22787.method_22683().method_4476(0, field_22787.method_1573()) + 1;
	}

	@Override
	public CtxStack getStack() {
		return stack;
	}

	@Override
	public void method_25393() {
		try {
			gui.tick();
		} catch (Throwable e) {
			onGuiException("Error in tick gui", e, true);
		}
	}

	@Override
	public void drawFormattedText(float x, float y, IText text, int color, float scale) {
		x += getOffset().x;
		y += getOffset().y;
		graphics.method_51448().method_22903();
		graphics.method_51448().method_46416(x, y, 500);
		graphics.method_51448().method_22905(scale, scale, scale);
		graphics.method_51439(field_22793, text.<class_2561>remap(), 0, 0, color, false);
		graphics.method_51448().method_22909();
	}

	@Override
	public int textWidthFormatted(IText text) {
		return field_22793.method_30880(text.<class_2561>remap().method_30937());
	}

	@Override
	public void openURL0(String url) {
		class_156.method_668().method_670(url);
	}

	public class_332 getMCGraphics() {
		return graphics;
	}

	@Override
	public void method_49589() {
		vanillaScale = -1;
	}

	@Override
	public void drawStack(int x, int y, Stack stack) {
		x += getOffset().x;
		y += getOffset().y;
		class_1799 s = ItemStackHandlerImpl.impl.unwrap(stack);
		graphics.method_51427(s, x, y);
		graphics.method_51431(field_22793, s, x, y);
	}

	@Override
	public void drawStackTooltip(int mx, int my, Stack stack) {
		graphics.method_51448().method_22903();
		graphics.method_51448().method_46416(0, 0, 100);
		class_1799 s = ItemStackHandlerImpl.impl.unwrap(stack);
		graphics.method_51446(field_22793, s, mx, my);
		graphics.method_51448().method_22909();
	}
}
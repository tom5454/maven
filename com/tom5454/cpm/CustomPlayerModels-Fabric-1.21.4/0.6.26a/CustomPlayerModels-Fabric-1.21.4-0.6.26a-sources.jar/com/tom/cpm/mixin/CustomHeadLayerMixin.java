package com.tom.cpm.mixin;

import java.util.function.Function;
import net.minecraft.class_10042;
import net.minecraft.class_2484;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5598;
import net.minecraft.class_9296;
import net.minecraft.class_976;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.mojang.authlib.GameProfile;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.RefHolder;

@Mixin(class_976.class)
public class CustomHeadLayerMixin {
	private @Shadow @Final Function<class_2484.class_2485, class_5598> skullModels;

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/blockentity/SkullBlockRenderer;"
					+ "getRenderType(Lnet/minecraft/world/level/block/SkullBlock$Type;Lnet/minecraft/world/item/component/ResolvableProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;"
			),
			method = "render")
	public void onRender(final class_4587 poseStack, final class_4597 multiBufferSource, final int i,
			final class_10042 livingEntityRenderState, final float f, final float g, CallbackInfo ci) {
		if(livingEntityRenderState.field_55315 == class_2484.class_2486.field_11510) {
			RefHolder.CPM_MODELS = skullModels;
			class_9296 resolvableProfile = livingEntityRenderState.field_55316;
			GameProfile gameProfile = resolvableProfile != null ? resolvableProfile.comp_2413() : null;
			if(gameProfile != null) {
				class_5598 model = this.skullModels.apply(class_2484.class_2486.field_11510);
				CustomPlayerModelsClient.INSTANCE.renderSkull(model, gameProfile, multiBufferSource);
			}
		}
	}
}

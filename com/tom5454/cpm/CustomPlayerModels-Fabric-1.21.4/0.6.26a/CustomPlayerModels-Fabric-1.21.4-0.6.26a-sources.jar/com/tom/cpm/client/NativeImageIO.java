package com.tom.cpm.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import net.minecraft.class_1011;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;
import org.lwjgl.system.MemoryUtil;
import com.mojang.blaze3d.platform.TextureUtil;

import com.tom.cpl.math.Vec2i;
import com.tom.cpl.util.Image;
import com.tom.cpl.util.ImageIO.IImageIO;
import com.tom.cpm.mixin.NativeImageAccessor;

public class NativeImageIO implements IImageIO {

	@Override
	public Image read(File f) throws IOException {
		try (FileInputStream fi = new FileInputStream(f)){
			return read(fi);
		}
	}

	@Override
	public Image read(InputStream f) throws IOException {
		try (class_1011 ni = class_1011.method_4309(f)) {
			Image i = new Image(ni.method_4307(), ni.method_4323());
			for(int y = 0;y<ni.method_4323();y++) {
				for(int x = 0;x<ni.method_4307();x++) {
					int rgb = ni.method_61940(x, y);
					i.setRGB(x, y, rgb);
				}
			}
			return i;
		}
	}

	@Override
	public void write(Image img, File f) throws IOException {
		try (class_1011 i = createFromBufferedImage(img)) {
			i.method_4325(f);
		}
	}

	@Override
	public void write(Image img, OutputStream f) throws IOException {
		try (class_1011 i = createFromBufferedImage(img); WritableByteChannel writablebytechannel = Channels.newChannel(f)) {
			if (!((NativeImageAccessor) (Object) i).callWriteToChannel(writablebytechannel)) {
				throw new IOException("Could not write image to byte array: " + STBImage.stbi_failure_reason());
			}
		}
	}

	@Override
	public Vec2i getSize(InputStream din) throws IOException {
		ByteBuffer byteBufferIn = null;
		try (MemoryStack memorystack = MemoryStack.stackPush()) {
			byteBufferIn = TextureUtil.readResource(din);
			((Buffer)byteBufferIn).rewind();
			IntBuffer intbuffer = memorystack.mallocInt(1);
			IntBuffer intbuffer1 = memorystack.mallocInt(1);
			IntBuffer intbuffer2 = memorystack.mallocInt(1);
			if(!STBImage.stbi_info_from_memory(byteBufferIn, intbuffer, intbuffer1, intbuffer2)) {
				throw new IOException("Could not load image: " + STBImage.stbi_failure_reason());
			}
			return new Vec2i(intbuffer.get(0), intbuffer1.get(0));
		} finally {
			MemoryUtil.memFree(byteBufferIn);
		}
	}

	public static class_1011 createFromBufferedImage(Image texture) {
		class_1011 ni = new class_1011(texture.getWidth(), texture.getHeight(), false);
		for(int y = 0;y<texture.getHeight();y++) {
			for(int x = 0;x<texture.getWidth();x++) {
				int rgb = texture.getRGB(x, y);
				ni.method_61941(x, y, rgb);
			}
		}
		return ni;
	}
}

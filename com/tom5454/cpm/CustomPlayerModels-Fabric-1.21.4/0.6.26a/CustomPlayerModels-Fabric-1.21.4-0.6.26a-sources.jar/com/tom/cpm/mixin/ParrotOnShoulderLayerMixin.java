package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpl.util.ItemSlot;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.client.PlayerRenderStateAccess;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.model.render.ItemTransform;
import net.minecraft.class_10055;
import net.minecraft.class_1453;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_983;

@Mixin(value = class_983.class, priority = 2000)
public class ParrotOnShoulderLayerMixin {

	@Inject(at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;translate(FFF)V", shift = Shift.AFTER), method = "renderOnShoulder")
	public void onRender(final class_4587 poseStack, final class_4597 multiBufferSource, final int i,
			final class_10055 playerRenderState, final class_1453.class_7989 variant, final float f, final float g,
			final boolean leftShoulderIn, CallbackInfo cbi) {
		Player<?> pl = ((PlayerRenderStateAccess) playerRenderState).cpm$getPlayer();
		if(pl != null) {
			ModelDefinition def = pl.getModelDefinition();
			if(def != null) {
				ItemTransform tr = def.getTransform(leftShoulderIn ? ItemSlot.LEFT_SHOULDER : ItemSlot.RIGHT_SHOULDER);
				if(tr != null) {
					PlayerRenderManager.multiplyStacks(tr.getMatrix(), poseStack);
					if(playerRenderState.field_53410)
						poseStack.method_46416(0, -0.2f, 0);
				}
			}
		}
	}
}

package com.tom.cpm.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.apache.commons.lang3.stream.Streams;
import com.tom.cpl.block.BlockStateHandler;
import com.tom.cpl.item.Stack;

public class BlockStateHandlerImpl extends BlockStateHandler<class_2680> {
	public static final BlockStateHandlerImpl impl = new BlockStateHandlerImpl();

	@Override
	public String getBlockId(class_2680 stack) {
		return class_7923.field_41175.method_10221(stack.method_26204()).toString();
	}

	@Override
	public List<String> getBlockStates(class_2680 stack) {
		return stack.method_28501().stream().map(p -> p.method_11899()).toList();
	}

	private Stream<Map.Entry<class_2769<?>, Comparable<?>>> getProp(class_2680 state, String property) {
		return state.method_11656().entrySet().stream().filter(e -> e.getKey().method_11899().equals(property));
	}

	@Override
	public String getPropertyValue(class_2680 state, String property) {
		return getProp(state, property).map(this::propValue).findFirst().orElse(null);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private String propValue(Map.Entry<class_2769<?>, Comparable<?>> e) {
		class_2769 p = e.getKey();
		return p.method_11901(e.getValue());
	}

	@Override
	public int getPropertyValueInt(class_2680 state, String property) {
		return getProp(state, property).mapToInt(e -> state.method_11654(e.getKey()) instanceof Number n ? n.intValue() : -1).findFirst().orElse(-1);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getAllValuesFor(class_2680 state, String property) {
		return getProp(state, property).flatMap(e -> e.getKey().method_11898().stream().map(v -> {
			class_2769 p = e.getKey();
			return p.method_11901(v);
		})).toList();
	}

	@Override
	public List<String> listTags(class_2680 stack) {
		return stack.method_41520().method_40228().map(k -> "#" + k.comp_327()).toList();
	}

	@Override
	public List<com.tom.cpl.block.BlockState> listNativeEntries(String tag) {
		List<com.tom.cpl.block.BlockState> stacks = new ArrayList<>();
		if (tag.charAt(0) == '#') {
			class_2960 rl = class_2960.method_12829(tag.substring(1));
			if (rl != null) {
				class_6862<class_2248> i = class_6862.method_40092(class_7924.field_41254, rl);
				Streams.of(class_7923.field_41175.method_40286(i)).map(t -> t.method_40229().right()).
				filter(Optional::isPresent).map(o -> wrap(o.get().method_9564())).forEach(stacks::add);
			}
		} else {
			class_2960 rl = class_2960.method_12829(tag);
			class_2248 item = class_7923.field_41175.method_63535(rl);
			if (item != null) {
				stacks.add(wrap(item.method_9564()));
			}
		}
		return stacks;
	}

	@Override
	public List<String> listNativeTags() {
		return class_7923.field_41175.method_40272().map(k -> k.method_40251().comp_327().toString()).toList();
	}

	@Override
	public List<com.tom.cpl.block.BlockState> getAllElements() {
		return class_7923.field_41175.method_10220().map(b -> wrap(b.method_9564())).toList();
	}

	@Override
	public boolean isInTag(String tag, class_2680 stack) {
		if (tag.charAt(0) == '#') {
			class_2960 rl = class_2960.method_12829(tag.substring(1));
			if (rl != null) {
				class_6862<class_2248> i = class_6862.method_40092(class_7924.field_41254, rl);
				return stack.method_26164(i);
			}
		} else {
			return getBlockId(stack).equals(tag);
		}
		return false;
	}

	@Override
	public boolean equals(class_2680 a, class_2680 b) {
		return a.method_26204() == b.method_26204();
	}

	@Override
	public Stack getStackFromState(class_2680 state) {
		return ItemStackHandlerImpl.impl.wrap(new class_1799(state.method_26204()));
	}

	@Override
	public boolean equalsFull(class_2680 a, class_2680 b) {
		return a.equals(b);
	}

	@Override
	public com.tom.cpl.block.BlockState emptyObject() {
		return wrap(class_2246.field_10124.method_9564());
	}
}

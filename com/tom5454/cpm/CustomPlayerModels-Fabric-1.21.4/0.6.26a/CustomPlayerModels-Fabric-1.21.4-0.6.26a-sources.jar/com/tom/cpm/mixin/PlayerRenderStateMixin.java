package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import com.tom.cpm.client.PlayerRenderStateAccess;
import com.tom.cpm.shared.animation.AnimationState;
import com.tom.cpm.shared.config.Player;
import net.minecraft.class_10055;
import net.minecraft.class_2561;

@Mixin(class_10055.class)
public class PlayerRenderStateMixin implements PlayerRenderStateAccess {
	private @Unique Player<net.minecraft.class_1657> cpm$player;
	private @Unique AnimationState cpm$animState;
	private @Unique class_2561 cpm$modelStatus;

	@Override
	public void cpm$setPlayer(Player<net.minecraft.class_1657> player) {
		this.cpm$player = player;
	}

	@Override
	public Player<net.minecraft.class_1657> cpm$getPlayer() {
		return cpm$player;
	}

	@Override
	public void cpm$setAnimationState(AnimationState state) {
		cpm$animState = state;
	}

	@Override
	public AnimationState cpm$getAnimationState() {
		return cpm$animState;
	}

	@Override
	public void cpm$setModelStatus(class_2561 status) {
		cpm$modelStatus = status;
	}

	@Override
	public class_2561 cpm$getModelStatus() {
		return cpm$modelStatus;
	}
}

package com.tom.cpm.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking.PlayPayloadHandler;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_4185;
import net.minecraft.class_440;
import net.minecraft.class_442;
import com.tom.cpl.tag.AllTagManagers;
import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.common.ByteArrayPayload;
import com.tom.cpm.shared.config.ConfigKeys;
import com.tom.cpm.shared.config.ModConfig;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.editor.gui.EditorGui;
import com.tom.cpm.shared.gui.GestureGui;
import com.tom.cpm.shared.io.FastByteArrayInputStream;
import com.tom.cpm.shared.network.NetH;

public class CustomPlayerModelsClient extends ClientBase implements ClientModInitializer {
	public static CustomPlayerModelsClient INSTANCE;

	@Override
	public void onInitializeClient() {
		CustomPlayerModels.LOG.info("Customizable Player Models Client Init started");
		INSTANCE = this;
		init0();
		mc.setTags(new AllTagManagers(ResourceManagerHelper.get(class_3264.field_14188), CPMTagLoaderFabric::new));
		ClientTickEvents.START_CLIENT_TICK.register(cl -> {
			if(!cl.method_1493())
				mc.getPlayerRenderManager().getAnimationEngine().tick();
		});
		KeyBindings.init();
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.field_1724 == null)
				return;

			if(KeyBindings.gestureMenuBinding.method_1436()) {
				client.method_1507(new GuiImpl(GestureGui::new, null));
			}

			if(KeyBindings.renderToggleBinding.method_1436()) {
				Player.setEnableRendering(!Player.isEnableRendering());
			}

			mc.getPlayerRenderManager().getAnimationEngine().updateKeys(KeyBindings.quickAccess);

			CustomPlayerModels.api.clientApi().tickListeners(minecraft.method_1493());
		});
		ScreenEvents.AFTER_INIT.register((mc, screen, sw, sh) -> {
			ScreenEvents.beforeRender(screen).register((_1, _2, _3, _4, _5) -> PlayerProfile.inGui = true);
			ScreenEvents.afterRender(screen).register((_1, _2, _3, _4, _5) -> PlayerProfile.inGui = false);
			if((screen instanceof class_442 && ModConfig.getCommonConfig().getSetBoolean(ConfigKeys.TITLE_SCREEN_BUTTON, true)) ||
					screen instanceof class_440) {
				Screens.getButtons(screen).add(
						class_4185.method_46430(class_2561.method_43471("button.cpm.open_editor"), b -> class_310.method_1551().method_1507(new GuiImpl(EditorGui::new, screen))).
						method_46434(0, 0, 100, 20).method_46431());
			}
		});
		init1();
		ClientCommandRegistrationCallback.EVENT.register((d, r) -> new ClientCommand(d));
		PlayPayloadHandler<ByteArrayPayload> h = (p, c) -> {
			netHandler.receiveClient(p.id(), new FastByteArrayInputStream(p.data()), (NetH) c.player().field_3944);
		};
		CustomPlayerModels.clientPackets.forEach(p -> ClientPlayNetworking.registerGlobalReceiver(p, h));
		CustomPlayerModels.LOG.info("Customizable Player Models Client Initialized");
		apiInit();
	}

	public void onLogout() {
		mc.onLogOut();
	}
}

package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.LivingRendererAccessFabric;
import com.tom.cpm.client.PlayerRenderStateAccess;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;

@Mixin(value = class_1007.class, priority = 900)
public abstract class PlayerRendererMixinFabric extends class_922<class_742, class_10055, class_591> implements LivingRendererAccessFabric {

	public PlayerRendererMixinFabric(class_5618 context, class_591 entityModel, float f) {
		super(context, entityModel, f);
	}

	@Override
	public void cpm$renderPre(class_10042 state, class_4587 poseStack, class_4597 multiBufferSource, int i) {
		PlayerRenderStateAccess sa = (PlayerRenderStateAccess) state;
		if (sa.cpm$getPlayer() != null) {
			CustomPlayerModelsClient.INSTANCE.manager.bindPlayerState(sa.cpm$getPlayer(), multiBufferSource, method_4038(), null, sa.cpm$getAnimationState());
		}
	}

	@Override
	public void cpm$renderPost(class_10042 state, class_4587 poseStack, class_4597 multiBufferSource,
			int i) {
		CustomPlayerModelsClient.INSTANCE.playerRenderPost(multiBufferSource, method_4038());
	}
}

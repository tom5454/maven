package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.tom.cpl.text.FormatText;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.LivingRendererAccess;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.PlayerProfile;
import com.tom.cpm.client.PlayerRenderStateAccess;
import com.tom.cpm.shared.animation.AnimationEngine.AnimationMode;
import com.tom.cpm.shared.animation.AnimationState;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617.class_5618;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;

@Mixin(value = class_1007.class, priority = 900)
public abstract class PlayerRendererMixin extends class_922<class_742, class_10055, class_591> implements LivingRendererAccess {
	private static @Unique final class_2960 CPM$EMPTY_TEX = class_2960.method_60654("cpm:textures/template/empty.png");

	public PlayerRendererMixin(class_5618 context, class_591 entityModel, float f) {
		super(context, entityModel, f);
	}

	@Inject(
			at = @At("RETURN"),
			method = {
					"getTextureLocation(Lnet/minecraft/client/renderer/entity/state/PlayerRenderState;)Lnet/minecraft/resources/ResourceLocation;"
			},
			cancellable = true)
	public void onGetEntityTexture(class_10055 entity, CallbackInfoReturnable<class_2960> cbi) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(method_4038(), new ModelTexture(cbi), TextureSheetType.SKIN);
	}

	@ModifyArg(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/RenderType;entityTranslucent("
					+ "Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"
			), method = "renderHand")
	public class_2960 getSkinTex(class_2960 arg) {
		ModelTexture tex = new ModelTexture(arg);
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(method_4038(), tex, TextureSheetType.SKIN);
		return tex.getTexture();
	}

	@Inject(at = @At("HEAD"), method = "renderRightHand")
	public void onRenderRightArmPre(final class_4587 poseStack, final class_4597 vertexConsumers, final int i, final class_2960 resourceLocation, final boolean sleeve, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHand(vertexConsumers, method_4038());
	}

	@Inject(at = @At("HEAD"), method = "renderLeftHand")
	public void onRenderLeftArmPre(final class_4587 poseStack, final class_4597 vertexConsumers, final int i, final class_2960 resourceLocation, final boolean sleeve, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHand(vertexConsumers, method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderRightHand")
	public void onRenderRightArmPost(final class_4587 poseStack, final class_4597 vertexConsumers, final int i, final class_2960 resourceLocation, final boolean sleeve, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(vertexConsumers, method_4038());
	}

	@Inject(at = @At("RETURN"), method = "renderLeftHand")
	public void onRenderLeftArmPost(final class_4587 poseStack, final class_4597 vertexConsumers, final int i, final class_2960 resourceLocation, final boolean sleeve, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderHandPost(vertexConsumers, method_4038());
	}

	@Inject(at = @At("HEAD"), method = "renderNameTag", cancellable = true)
	public void onRenderName1(final class_10055 playerRenderState, final class_2561 component,
			final class_4587 poseStack, final class_4597 multiBufferSource, final int packedLightIn, CallbackInfo cbi) {
		if(!Player.isEnableNames()) {
			cbi.cancel();
			return;
		}
		if (Player.isEnableLoadingInfo()) {
			PlayerRenderStateAccess sa = (PlayerRenderStateAccess) playerRenderState;
			if (sa.cpm$getModelStatus() != null) {
				poseStack.method_22903();
				poseStack.method_22904(0.0D, 1.3F, 0.0D);
				poseStack.method_22905(0.5f, 0.5f, 0.5f);
				super.method_3926(playerRenderState, sa.cpm$getModelStatus(), poseStack, multiBufferSource, packedLightIn);
				poseStack.method_22909();
			}
		}
	}

	@Override
	public void cpm$onGetRenderType(class_10042 player, boolean pTranslucent, boolean pGlowing,
			CallbackInfoReturnable<class_1921> cbi) {
		if (CustomPlayerModelsClient.mc.getPlayerRenderManager().isBound(method_4038())) {
			boolean r = CustomPlayerModelsClient.mc.getPlayerRenderManager().getHolderSafe(method_4038(), null, h -> h.setInvisState(), false, false);
			if(pTranslucent)return;
			if(!pGlowing && !r)return;
			class_2960 tex = method_3885((class_10055) player);
			CustomPlayerModelsClient.mc.getPlayerRenderManager().getHolderSafe(method_4038(), null, h -> h.setInvis(pGlowing), false);
			cbi.setReturnValue(
					pGlowing ?
							class_1921.method_23287(tex) :
								class_1921.method_23576(CPM$EMPTY_TEX)
					);
		}
	}

	@Inject(at = @At("RETURN"), method = "extractRenderState")
	public void onExtractRenderState(final class_742 abstractClientPlayer, final class_10055 playerRenderState, final float f, CallbackInfo cbi) {
		PlayerRenderStateAccess sa = (PlayerRenderStateAccess) playerRenderState;
		FormatText st = CustomPlayerModelsClient.INSTANCE.manager.getStatus(abstractClientPlayer.method_7334(), ModelDefinitionLoader.PLAYER_UNIQUE);
		sa.cpm$setModelStatus(st != null ? st.remap() : null);
		AnimationState state = new AnimationState(AnimationMode.PLAYER);
		var pl = CustomPlayerModelsClient.INSTANCE.manager.loadPlayerState(abstractClientPlayer.method_7334(), abstractClientPlayer, ModelDefinitionLoader.PLAYER_UNIQUE, state);
		sa.cpm$setPlayer(pl);
		sa.cpm$setAnimationState(state);
		if (pl != null) {
			((PlayerProfile) pl).updateFromState(state, method_4038(), playerRenderState);
		}
	}
}

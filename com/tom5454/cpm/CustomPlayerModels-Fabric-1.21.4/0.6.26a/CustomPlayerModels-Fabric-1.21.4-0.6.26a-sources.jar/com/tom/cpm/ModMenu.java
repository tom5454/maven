package com.tom.cpm;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import com.terraformersmc.modmenu.api.UpdateChannel;
import com.terraformersmc.modmenu.api.UpdateChecker;
import com.terraformersmc.modmenu.api.UpdateInfo;

import com.tom.cpm.client.GuiImpl;
import com.tom.cpm.shared.MinecraftCommonAccess;
import com.tom.cpm.shared.gui.SettingsGui;
import com.tom.cpm.shared.util.IVersionCheck;
import net.minecraft.class_5250;

public class ModMenu implements ModMenuApi {

	@Override
	public ConfigScreenFactory<?> getModConfigScreenFactory() {
		return screen -> new GuiImpl(SettingsGui::new, screen);
	}

	@Override
	public UpdateChecker getUpdateChecker() {
		return () -> {
			IVersionCheck vc = MinecraftCommonAccess.get().getVersionCheck();
			return new UpdateInfo() {

				@Override
				public boolean isUpdateAvailable() {
					return vc.isOutdated();
				}

				@Override
				public UpdateChannel getUpdateChannel() {
					return UpdateChannel.RELEASE;
				}

				@Override
				public String getDownloadLink() {
					return "https://modrinth.com/plugin/custom-player-models";
				}

				@Override
				public class_5250 getUpdateMessage() {
					return null;
				}
			};
		};
	}
}

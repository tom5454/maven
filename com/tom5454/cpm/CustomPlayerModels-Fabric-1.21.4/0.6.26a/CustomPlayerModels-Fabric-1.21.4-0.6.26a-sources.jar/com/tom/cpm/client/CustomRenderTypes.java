package com.tom.cpm.client;

import java.util.OptionalDouble;

import net.irisshaders.batchedentityrendering.impl.BlendingStateHolder;
import net.irisshaders.batchedentityrendering.impl.TransparencyType;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_2960;
import net.minecraft.class_4668;

public class CustomRenderTypes extends class_1921 {
	public static final class_1921 ENTITY_COLOR = method_23580(class_2960.method_60654("textures/misc/white.png"));
	public static final class_1921 LINES_NO_DEPTH = method_24049("cpm:lines_no_depth", class_290.field_29337, class_293.class_5596.field_27377, 256, false, true, class_1921.class_4688.method_23598().method_34578(field_29433).method_23609(new class_4668.class_4677(OptionalDouble.empty())).method_23607(field_22241).method_23615(field_21370).method_23610(field_25643).method_23616(field_21349).method_23603(field_21345).method_23604(field_21346).method_23617(false));
	public static final class_1921 ENTITY_COLOR_EYES = glowingEyes(class_2960.method_60654("textures/misc/white.png"));

	public CustomRenderTypes(String nameIn, class_293 formatIn, class_5596 drawModeIn, int bufferSizeIn,
			boolean useDelegateIn, boolean needsSortingIn, Runnable setupTaskIn, Runnable clearTaskIn) {
		super(nameIn, formatIn, drawModeIn, bufferSizeIn, useDelegateIn, needsSortingIn, setupTaskIn, clearTaskIn);
	}

	public static class_1921 entityColorTranslucent() {
		return ENTITY_COLOR;
	}

	public static class_1921 entityColorEyes() {
		return ENTITY_COLOR_EYES;
	}

	public static class_1921 linesNoDepth() {
		return LINES_NO_DEPTH;
	}

	public static class_1921 glowingEyes(class_2960 rl) {
		class_1921 rt = class_1921.field_29636.apply(rl, field_21366);
		if (ClientBase.irisLoaded)
			((BlendingStateHolder) rt).setTransparencyType(TransparencyType.DECAL);
		return rt;
	}
}

package com.tom.cpm.client;

import net.minecraft.class_10042;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

public interface LivingRendererAccessFabric {
	default void cpm$renderPre(class_10042 state, final class_4587 poseStack, final class_4597 multiBufferSource, final int i) {}
	default void cpm$renderPost(class_10042 state, final class_4587 poseStack, final class_4597 multiBufferSource, final int i) {}
}

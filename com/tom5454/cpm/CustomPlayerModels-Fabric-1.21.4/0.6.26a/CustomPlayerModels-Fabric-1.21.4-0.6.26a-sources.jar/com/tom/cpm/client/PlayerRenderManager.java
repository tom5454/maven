package com.tom.cpm.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_10034;
import net.minecraft.class_10055;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_563;
import net.minecraft.class_572;
import net.minecraft.class_5819;
import net.minecraft.class_591;
import net.minecraft.class_607;
import net.minecraft.class_630;
import net.minecraft.class_9848;
import net.minecraft.class_9950;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import com.tom.cpl.math.MatrixStack;
import com.tom.cpl.math.Vec4f;
import com.tom.cpl.render.VBuffers;
import com.tom.cpm.client.MinecraftObject.DynTexture;
import com.tom.cpm.client.optifine.OptifineTexture;
import com.tom.cpm.client.optifine.RedirectModelRendererOF;
import com.tom.cpm.client.vr.VRPlayerRenderer;
import com.tom.cpm.shared.model.PlayerModelParts;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.TextureSheetType;
import com.tom.cpm.shared.model.render.BatchedBuffers;
import com.tom.cpm.shared.model.render.ModelRenderManager;
import com.tom.cpm.shared.model.render.VanillaModelPart;
import com.tom.cpm.shared.skin.TextureProvider;

public class PlayerRenderManager extends ModelRenderManager<class_4597, ModelTexture, class_630, class_3879> {
	public static final Function<class_2960, class_1921> armor = class_1921::method_25448;
	public static final Function<class_2960, class_1921> entity = class_1921::method_23580;

	public PlayerRenderManager() {
		setFactory(new RedirectHolderFactory<class_4597, ModelTexture, class_630>() {

			@SuppressWarnings("unchecked")
			@Override
			public <M> RedirectHolder<?, class_4597, ModelTexture, class_630> create(
					M model, String arg) {
				if ("api".equals(arg) && model instanceof class_572) {
					return new RedirectHolderApi(PlayerRenderManager.this, (class_572<class_10034>) model);
				} else if(CustomPlayerModelsClient.vrLoaded && VRPlayerRenderer.isVRPlayer(model)) {
					return VRPlayerRenderer.createVRPlayer(PlayerRenderManager.this, model);
				} else if(model instanceof class_591) {
					return new RedirectHolderPlayer(PlayerRenderManager.this, (class_591) model);
				} else if(model instanceof class_607) {
					return new RedirectHolderSkull(PlayerRenderManager.this, (class_607) model);
				} else if(model instanceof class_9950) {
					return new RedirectHolderCape(PlayerRenderManager.this, (class_9950<class_10055>) model);
				} else if(model instanceof class_563) {
					return new RedirectHolderElytra(PlayerRenderManager.this, (class_563) model);
				} else if(model instanceof class_572 && "armor1".equals(arg)) {
					return new RedirectHolderArmor1(PlayerRenderManager.this, (class_572<class_10034>) model);
				} else if(model instanceof class_572 && "armor2".equals(arg)) {
					return new RedirectHolderArmor2(PlayerRenderManager.this, (class_572<class_10034>) model);
				}
				return null;
			}
		});
		setRedirectFactory(new RedirectRendererFactory<class_3879, ModelTexture, class_630>() {

			@Override
			public RedirectRenderer<class_630> create(class_3879 model,
					RedirectHolder<class_3879, ?, ModelTexture, class_630> access,
					Supplier<class_630> modelPart, VanillaModelPart part) {
				return CustomPlayerModelsClient.optifineLoaded ?
						new RedirectModelRendererOF((RDH<?>) access, modelPart, part) :
							new RedirectModelRendererVanilla((RDH<?>) access, modelPart, part);
			}
		});
		setVis(m -> m.field_3665, (m, v) -> m.field_3665 = v);
		setModelPosGetters(m -> m.field_3657, m -> m.field_3656, m -> m.field_3655);
		setModelRotGetters(m -> m.field_3654, m -> m.field_3675, m -> m.field_3674);
		setModelSetters((m, x, y, z) -> {
			m.field_3657 = x;
			m.field_3656 = y;
			m.field_3655 = z;
		}, (m, x, y, z) -> {
			m.field_3654 = x;
			m.field_3675 = y;
			m.field_3674 = z;
		});
		setRenderPart(new class_630(Collections.emptyList(), Collections.emptyMap()));
	}

	public static abstract class RDH<M extends class_3879> extends ModelRenderManager.RedirectHolder<class_3879, class_4597, ModelTexture, class_630> {
		public List<Supplier<class_630>> renderedParts = new ArrayList<>();
		private class_630 rootPart;
		private RootModelPart rootRenderer;

		public RDH(
				ModelRenderManager<class_4597, ModelTexture, class_630, class_3879> mngr,
				M model) {
			super(mngr, model);
			batch = new BatchedBuffers<>(this, class_4597::getBuffer);
			rootPart = getRoot();
			rootRenderer = new RootModelPart(this);
		}

		@Override
		public void setupRenderSystem(ModelTexture cbi, TextureSheetType tex) {
			CustomPlayerModelsClient.mc.renderBuilder.build(renderTypes, cbi);
		}

		@Override
		protected void bindTexture(ModelTexture cbi, TextureProvider skin) {
			skin.bind();
			OptifineTexture.applyOptifineTexture(cbi.getTexture(), skin);
			cbi.setTexture(DynTexture.getBoundLoc());
		}

		@Override
		public void swapOut0() {
			setRoot(rootPart);
		}

		@Override
		public void swapIn0() {
			setRoot(rootRenderer);
		}

		protected Field<class_630> createRendered(Supplier<class_630> get, Consumer<class_630> set, VanillaModelPart part) {
			renderedParts.add(get);
			return new Field<>(get, set, part);
		}

		protected Field<class_630> create2ndLayer(Supplier<class_630> get, Consumer<class_630> set, RedirectRenderer<class_630> layer2) {
			if (layer2 instanceof RedirectModelRendererBase r) {
				r.layer2 = get.get();
			}
			return new Field<>(get, set, null);
		}

		protected class_630 getRoot() {
			return model().field_54014;
		}

		protected void setRoot(class_630 part) {
			model().field_54014 = part;
		}

		@SuppressWarnings("unchecked")
		protected M model() {
			return (M) model;
		}
	}

	private static class RedirectHolderPlayer extends RDH<class_591> {
		private RedirectRenderer<class_630> head;
		private RedirectRenderer<class_630> body;
		private RedirectRenderer<class_630> leftArm;
		private RedirectRenderer<class_630> rightArm;
		private RedirectRenderer<class_630> leftLeg;
		private RedirectRenderer<class_630> rightLeg;

		public RedirectHolderPlayer(PlayerRenderManager mngr, class_591 model) {
			super(mngr, model);
			head = registerHead(createRendered(() -> model.field_3398, v -> model.field_3398 = v, PlayerModelParts.HEAD));
			body = register(createRendered(() -> model.field_3391    , v -> model.field_3391     = v, PlayerModelParts.BODY));
			rightArm = register(createRendered(() -> model.field_3401, v -> model.field_3401 = v, PlayerModelParts.RIGHT_ARM));
			leftArm = register(createRendered(() -> model.field_27433 , v -> model.field_27433  = v, PlayerModelParts.LEFT_ARM));
			rightLeg = register(createRendered(() -> model.field_3392, v -> model.field_3392 = v, PlayerModelParts.RIGHT_LEG));
			leftLeg = register(createRendered(() -> model.field_3397 , v -> model.field_3397  = v, PlayerModelParts.LEFT_LEG));

			register(create2ndLayer(() -> model.field_3394        , v -> model.field_3394         = v, head));
			register(create2ndLayer(() -> model.field_3484 , v -> model.field_3484  = v, leftArm));
			register(create2ndLayer(() -> model.field_3486, v -> model.field_3486 = v, rightArm));
			register(create2ndLayer(() -> model.field_3482  , v -> model.field_3482   = v, leftLeg));
			register(create2ndLayer(() -> model.field_3479 , v -> model.field_3479  = v, rightLeg));
			register(create2ndLayer(() -> model.field_3483     , v -> model.field_3483      = v, body));
		}
	}

	private static class RedirectHolderApi extends RDH<class_572<? extends class_10034>> {
		private RedirectRenderer<class_630> head;

		public RedirectHolderApi(PlayerRenderManager mngr, class_572<? extends class_10034> model) {
			super(mngr, model);
			head = registerHead(createRendered(() -> model.field_3398, v -> model.field_3398 = v, PlayerModelParts.HEAD));
			register(createRendered(() -> model.field_3391    , v -> model.field_3391     = v, PlayerModelParts.BODY));
			register(createRendered(() -> model.field_3401, v -> model.field_3401 = v, PlayerModelParts.RIGHT_ARM));
			register(createRendered(() -> model.field_27433 , v -> model.field_27433  = v, PlayerModelParts.LEFT_ARM));
			register(createRendered(() -> model.field_3392, v -> model.field_3392 = v, PlayerModelParts.RIGHT_LEG));
			register(createRendered(() -> model.field_3397 , v -> model.field_3397  = v, PlayerModelParts.LEFT_LEG));

			register(new Field<>(() -> model.field_3394        , v -> model.field_3394         = v, null)).setCopyFrom(head);

			if(model instanceof class_591) {
				class_591 mp = (class_591) model;
				register(new Field<>(() -> mp.field_3484 , v -> mp.field_3484  = v, null));
				register(new Field<>(() -> mp.field_3486, v -> mp.field_3486 = v, null));
				register(new Field<>(() -> mp.field_3482  , v -> mp.field_3482   = v, null));
				register(new Field<>(() -> mp.field_3479 , v -> mp.field_3479  = v, null));
				register(new Field<>(() -> mp.field_3483     , v -> mp.field_3483      = v, null));
			}
		}
	}

	private static class RedirectHolderSkull extends RDH<class_607> {

		public RedirectHolderSkull(PlayerRenderManager mngr, class_607 model) {
			super(mngr, model);

			register(createRendered(() -> model.field_3564, v -> model.field_3564 = v, PlayerModelParts.HEAD));
		}
	}

	private static class RedirectHolderElytra extends RDH<class_563> {

		public RedirectHolderElytra(PlayerRenderManager mngr, class_563 model) {
			super(mngr, model);

			register(createRendered(() -> model.field_27412, v -> model.field_27412 = v, RootModelType.ELYTRA_RIGHT));
			register(createRendered(() -> model.field_3365,  v -> model.field_3365  = v, RootModelType.ELYTRA_LEFT));
		}
	}

	private static class RedirectHolderArmor1 extends RDH<class_572<class_10034>> {

		public RedirectHolderArmor1(PlayerRenderManager mngr, class_572<class_10034> model) {
			super(mngr, model);

			register(createRendered(() -> model.field_3398,     v -> model.field_3398     = v, RootModelType.ARMOR_HELMET));
			register(createRendered(() -> model.field_3391,     v -> model.field_3391     = v, RootModelType.ARMOR_BODY));
			register(createRendered(() -> model.field_3401, v -> model.field_3401 = v, RootModelType.ARMOR_RIGHT_ARM));
			register(createRendered(() -> model.field_27433,  v -> model.field_27433  = v, RootModelType.ARMOR_LEFT_ARM));
			register(createRendered(() -> model.field_3392, v -> model.field_3392 = v, RootModelType.ARMOR_RIGHT_FOOT));
			register(createRendered(() -> model.field_3397,  v -> model.field_3397  = v, RootModelType.ARMOR_LEFT_FOOT));

			register(new Field<>(() -> model.field_3394 , v -> model.field_3394  = v, null));
		}
	}

	private static class RedirectHolderArmor2 extends RDH<class_572<class_10034>> {

		public RedirectHolderArmor2(PlayerRenderManager mngr, class_572<class_10034> model) {
			super(mngr, model);

			register(createRendered(() -> model.field_3391,     v -> model.field_3391     = v, RootModelType.ARMOR_LEGGINGS_BODY));
			register(createRendered(() -> model.field_3392, v -> model.field_3392 = v, RootModelType.ARMOR_RIGHT_LEG));
			register(createRendered(() -> model.field_3397,  v -> model.field_3397  = v, RootModelType.ARMOR_LEFT_LEG));
		}
	}

	private static class RedirectHolderCape extends RDH<class_9950<class_10055>> {

		public RedirectHolderCape(PlayerRenderManager mngr, class_9950<class_10055> model) {
			super(mngr, model);

			register(createRendered(() -> model.field_52927,     v -> model.field_52927     = v, RootModelType.CAPE));
		}
	}

	public static class RootModelPart extends class_630 {
		private RDH<?> holder;

		public RootModelPart(RDH<?> holder) {
			super(Collections.emptyList(), Collections.emptyMap());
			this.holder = holder;
		}

		@Override
		public void method_22699(class_4587 poseStack, class_4588 vertexConsumer, int i, int j, int k) {
			poseStack.method_22903();
			this.method_22703(poseStack);
			for (final Supplier<class_630> modelPart : holder.renderedParts) {
				modelPart.get().method_22699(poseStack, vertexConsumer, i, j, k);
			}
			poseStack.method_22909();
		}
	}

	public static abstract class RedirectModelRendererBase extends class_630 implements RedirectRenderer<class_630> {
		protected final RDH<?> holder;
		protected final VanillaModelPart part;
		protected final Supplier<class_630> parentProvider;
		protected class_630 parent;
		protected VBuffers buffers;
		protected class_630 layer2;

		public RedirectModelRendererBase(RDH<?> holder, Supplier<class_630> parent, VanillaModelPart part) {
			super(Collections.emptyList(), Collections.emptyMap());
			this.part = part;
			this.holder = holder;
			this.parentProvider = parent;
		}

		@Override
		public VBuffers getVBuffers() {
			return buffers;
		}

		@Override
		public class_630 swapIn() {
			if(parent != null)return this;
			parent = parentProvider.get();
			holder.copyModel(parent, this);
			method_41918(parent.method_41921());
			method_41923();
			return this;
		}

		@Override
		public class_630 swapOut() {
			if(parent == null)return parentProvider.get();
			class_630 p = parent;
			parent = null;
			return p;
		}

		@Override
		public RedirectHolder<?, ?, ?, class_630> getHolder() {
			return holder;
		}

		@Override
		public class_630 getParent() {
			return parent;
		}

		@Override
		public VanillaModelPart getPart() {
			return part;
		}

		protected int color;

		@Override
		public Vec4f getColor() {
			return new Vec4f(class_9848.method_61327(color) / 255f, class_9848.method_61329(color) / 255f, class_9848.method_61331(color) / 255f,
					class_9848.method_61320(color) / 255f);
		}

		@Override
		public void method_22703(class_4587 stack) {
			MatrixStack.Entry e = getPartTransform();
			if(e != null) {
				multiplyStacks(e, stack);
			} else
				super.method_22703(stack);
		}

		@Override
		public class_628 method_22700(class_5819 pRandom) {
			if(parent != null)return parent.method_22700(pRandom);
			return super.method_22700(pRandom);
		}
	}

	public static class RedirectModelRendererVanilla extends RedirectModelRendererBase {

		public RedirectModelRendererVanilla(RDH<?> holder, Supplier<class_630> parent, VanillaModelPart part) {
			super(holder, parent, part);
		}

		private class_4587 matrixStackIn;
		private class_4588 bufferIn;
		private int packedLightIn, packedOverlayIn;

		@Override
		public void method_22699(class_4587 matrixStackIn, class_4588 bufferIn, int packedLightIn, int packedOverlayIn, int color) {
			if(!holder.renderTypes.isInitialized()) {
				holder.copyModel(this, parent);
				parent.method_22699(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, color);
				holder.logWarning();
				return;
			}
			this.matrixStackIn   = matrixStackIn  ;
			this.bufferIn        = bufferIn       ;
			this.packedLightIn   = packedLightIn  ;
			this.packedOverlayIn = packedOverlayIn;
			this.color = color;
			this.buffers = holder.nextBatch(() -> new VBufferOut(packedLightIn, packedOverlayIn, matrixStackIn), bufferIn);
			render();
			this.matrixStackIn = null;
			this.bufferIn = null;
		}

		@Override
		public void renderParent() {
			boolean lv = false;
			if (layer2 != null) {
				lv = layer2.field_3665;
				layer2.field_3665 = false;
			}
			parent.method_22699(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, color);
			if (layer2 != null) {
				layer2.field_3665 = lv;
			}
		}
	}

	public static void multiplyStacks(MatrixStack.Entry e, class_4587 stack) {
		stack.method_23760().method_23761().mul(new Matrix4f().setTransposed(e.getMatrixArray()));
		stack.method_23760().method_23762().mul(new Matrix3f().set(e.getNormalArray3()).transpose());
	}
}

package com.tom.cpm.client.optifine;

import com.tom.cpm.shared.skin.TextureProvider;
import net.minecraft.class_2960;

public class OptifineTexture {

	public static void applyOptifineTexture(class_2960 loc, TextureProvider skin) {
		/*if(CustomPlayerModelsClient.optifineLoaded) {
			AbstractTexture tex = Minecraft.getInstance().getTextureManager().getTexture(loc);
			DynTexture dt = (DynTexture) skin.texture.getNative();
			if(dt != null && tex != null)
				((TextureOF)dt.getDynTex()).cpm$copyMultiTex(((TextureOF) tex).cpm$multiTex());
		}*/
	}
}

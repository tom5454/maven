package com.tom.cpm.common;

import com.tom.cpl.block.Biome;
import com.tom.cpl.block.BlockState;
import com.tom.cpl.block.World;
import com.tom.cpl.util.WeakStorage;
import com.tom.cpm.shared.animation.AnimationState;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_6880;

public class WorldImpl implements World {
	public WeakStorage<class_1937> level = new WeakStorage<>();
	public class_2338 base;

	public static void setWorld(AnimationState a, class_1297 ent) {
		if(!(a.world instanceof WorldImpl))a.world = new WorldImpl();
		WorldImpl i = (WorldImpl) a.world;
		class_1937 l = ent.method_37908();
		i.level.set(l);
		i.base = ent.method_24515();
		a.dayTime = l.method_30271();
		a.skyLight = l.method_8314(class_1944.field_9284, i.base);
		a.blockLight = l.method_8314(class_1944.field_9282, i.base);
	}

	@Override
	public BlockState getBlock(int x, int y, int z) {
		return level.call(l -> BlockStateHandlerImpl.impl.wrap(l.method_8320(base.method_10069(x, y, z))), BlockState.AIR);
	}

	@Override
	public boolean isCovered() {
		return level.call(l -> l.method_8311(base), false);
	}

	@Override
	public int getYHeight() {
		return base.method_10264();
	}

	@Override
	public int getMaxHeight() {
		return level.call(l -> l.method_31600(), 0);
	}

	@Override
	public int getMinHeight() {
		return level.call(l -> l.method_31607(), 0);
	}

	@Override
	public WeatherType getWeather() {
		return level.call(l -> l.method_8546() ? WeatherType.THUNDER : l.method_8419() ? WeatherType.RAIN : WeatherType.CLEAR, WeatherType.CLEAR);
	}

	@Override
	public Biome getBiome() {
		return level.call(l -> BiomeHandlerImpl.getImpl(l).wrap(new BiomeInfo(l.method_23753(base), base)), null);
	}

	@Override
	public String getDimension() {
		return level.call(l -> l.method_27983().method_29177().toString(), null);
	}

	public static record BiomeInfo(class_6880<net.minecraft.class_1959> biome, class_2338 at) {

		public net.minecraft.class_1959 value() {
			return biome.comp_349();
		}

	}
}

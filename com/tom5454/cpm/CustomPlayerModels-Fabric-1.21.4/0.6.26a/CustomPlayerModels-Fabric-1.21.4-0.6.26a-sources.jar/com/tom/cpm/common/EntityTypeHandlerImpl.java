package com.tom.cpm.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import net.minecraft.class_1299;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import org.apache.commons.lang3.stream.Streams;
import com.tom.cpl.block.entity.EntityTypeHandler;

public class EntityTypeHandlerImpl extends EntityTypeHandler<class_1299<?>> {
	public static final EntityTypeHandlerImpl impl = new EntityTypeHandlerImpl();

	@Override
	public List<com.tom.cpl.block.entity.EntityType> listNativeEntries(String tag) {
		List<com.tom.cpl.block.entity.EntityType> stacks = new ArrayList<>();
		if (tag.charAt(0) == '#') {
			class_2960 rl = class_2960.method_12829(tag.substring(1));
			if (rl != null) {
				class_6862<class_1299<?>> i = class_6862.method_40092(class_7924.field_41266, rl);
				Streams.of(class_7923.field_41177.method_40286(i)).map(h -> h.method_40229().right()).
				filter(Optional::isPresent).map(o -> wrap(o.get())).forEach(stacks::add);
			}
		} else {
			class_2960 rl = class_2960.method_12829(tag);
			class_1299<?> item = class_7923.field_41177.method_63535(rl);
			if (item != null) {
				stacks.add(wrap(item));
			}
		}
		return stacks;
	}

	@Override
	public List<String> listNativeTags() {
		return class_7923.field_41177.method_40272().map(k -> k.method_40251().comp_327().toString()).toList();
	}

	@Override
	public com.tom.cpl.block.entity.EntityType emptyObject() {
		return null;
	}

	@Override
	public boolean isInTag(String tag, class_1299<?> state) {
		if (tag.charAt(0) == '#') {
			class_2960 rl = class_2960.method_12829(tag.substring(1));
			if (rl != null) {
				class_6862<class_1299<?>> i = class_6862.method_40092(class_7924.field_41266, rl);
				return state.method_20210(i);
			}
		} else {
			return getEntityId(state).equals(tag);
		}
		return false;
	}

	@Override
	public List<String> listTags(class_1299<?> state) {
		return state.method_40124().method_40228().map(k -> "#" + k.comp_327()).toList();
	}

	@Override
	public List<com.tom.cpl.block.entity.EntityType> getAllElements() {
		return class_7923.field_41177.method_10220().map(this::wrap).collect(Collectors.toList());
	}

	@Override
	public boolean equals(class_1299<?> a, class_1299<?> b) {
		return a == b;
	}

	@Override
	public String getEntityId(class_1299<?> state) {
		return class_7923.field_41177.method_10221(state).toString();
	}

	@Override
	public List<String> listAllActiveEffectTypes() {
		return class_7923.field_41179.method_10235().stream().map(class_2960::toString).collect(Collectors.toList());
	}
}

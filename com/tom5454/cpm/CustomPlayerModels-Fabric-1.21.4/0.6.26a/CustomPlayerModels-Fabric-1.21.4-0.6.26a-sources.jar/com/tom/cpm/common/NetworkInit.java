package com.tom.cpm.common;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_8710.class_9154;
import net.minecraft.class_9139;

public class NetworkInit {

	public static void registerToClient(PacketRegistry toClient) {
		ServerHandler.netHandler.registerOut(id -> makeCodec(id, toClient));
	}

	public static void registerToServer(PacketRegistry toServer) {
		ServerHandler.netHandler.registerIn(id -> makeCodec(id, toServer));
	}

	public static void register(PacketRegistry toClient, PacketRegistry toServer, PacketRegistry bidirectional) {
		Map<class_8710.class_9154<ByteArrayPayload>, class_9139<? super class_2540, ByteArrayPayload>> cl = new HashMap<>();
		Map<class_8710.class_9154<ByteArrayPayload>, class_9139<? super class_2540, ByteArrayPayload>> se = new HashMap<>();
		Map<class_8710.class_9154<ByteArrayPayload>, class_9139<? super class_2540, ByteArrayPayload>> bi = new HashMap<>();

		registerToClient((a, b) -> {
			if (se.containsKey(a)) {
				se.remove(a);
				bi.put(a, b);
			} else {
				cl.put(a, b);
			}
		});
		registerToServer((a, b) -> {
			if (cl.containsKey(a)) {
				cl.remove(a);
				bi.put(a, b);
			} else {
				se.put(a, b);
			}
		});
		cl.forEach(toClient);
		se.forEach(toServer);
		bi.forEach(bidirectional);
	}

	private static void makeCodec(class_8710.class_9154<ByteArrayPayload> type, PacketRegistry c) {
		class_9139<class_2540, ByteArrayPayload> codec = class_8710.method_56484(ByteArrayPayload::write, d -> new ByteArrayPayload(type, d));
		c.accept(type, codec);
	}

	@FunctionalInterface
	public static interface PacketRegistry extends BiConsumer<class_8710.class_9154<ByteArrayPayload>, class_9139<? super class_2540, ByteArrayPayload>> {
		@Override
		void accept(class_9154<ByteArrayPayload> t, class_9139<? super class_2540, ByteArrayPayload> u);
	}
}

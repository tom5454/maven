package com.tom.cpm.common;

import net.minecraft.class_2540;
import net.minecraft.class_8710;

public record ByteArrayPayload(class_8710.class_9154<ByteArrayPayload> id, byte[] data) implements class_8710 {

	public ByteArrayPayload(class_8710.class_9154<ByteArrayPayload> id, class_2540 b) {
		this(id, toArray(b));
	}

	public void write(class_2540 b) {
		b.method_52983(data);
	}

	private static byte[] toArray(class_2540 b) {
		byte[] d = new byte[b.readableBytes()];
		b.method_52979(d);
		return d;
	}

	@Override
	public class_8710.class_9154<ByteArrayPayload> method_56479() {
		return id;
	}
}

/*
 * Copyright (C) 2015-2017, C. Ramakrishnan / Illposed Software.
 * All rights reserved.
 *
 * This code is licensed under the BSD 3-Clause license.
 * SPDX-License-Identifier: BSD-3-Clause
 * See file LICENSE.md for more information.
 */

/**
 * Provides means to send and receive OSC content over a network.
 */
package com.tom.cpmoscc.external.com.illposed.osc.transport;

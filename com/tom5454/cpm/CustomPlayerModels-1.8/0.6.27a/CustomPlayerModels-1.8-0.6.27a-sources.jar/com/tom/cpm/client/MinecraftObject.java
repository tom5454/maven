package com.tom.cpm.client;

import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.client.renderer.texture.TextureUtil;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.player.EnumPlayerModelParts;
import net.minecraft.util.ResourceLocation;

import net.minecraftforge.fml.common.ObfuscationReflectionHelper;

import com.mojang.authlib.GameProfile;

import com.tom.cpl.block.BiomeHandler;
import com.tom.cpl.gui.Frame;
import com.tom.cpl.gui.IGui;
import com.tom.cpl.gui.IKeybind;
import com.tom.cpl.render.RenderTypeBuilder;
import com.tom.cpl.tag.AllTagManagers;
import com.tom.cpl.util.AWTImageIO;
import com.tom.cpl.util.DynamicTexture.ITexture;
import com.tom.cpl.util.Image;
import com.tom.cpl.util.ImageIO.IImageIO;
import com.tom.cpm.common.BiomeHandlerImpl;
import com.tom.cpm.shared.MinecraftClientAccess;
import com.tom.cpm.shared.MinecraftObjectHolder;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import com.tom.cpm.shared.model.SkinType;
import com.tom.cpm.shared.network.NetHandler;
import com.tom.cpm.shared.retro.RetroGLAccess.RetroLayer;
import com.tom.cpm.shared.util.MojangAPI;
import com.tom.cpm.shared.util.SkinLayerCodec;

public class MinecraftObject implements MinecraftClientAccess {
	private final Minecraft mc;
	private final PlayerRenderManager prm;
	private final AllTagManagers tags;
	private final ModelDefinitionLoader<GameProfile> loader;
	private final RenderTypeBuilder<ResourceLocation, RetroLayer> renderBuilder = RenderTypeBuilder.setupRetro(new RetroGL());

	public static final SkinLayerCodec<EnumPlayerModelParts> LAYER_CODEC = new SkinLayerCodec<>(new EnumPlayerModelParts[] {
			EnumPlayerModelParts.HAT,
			EnumPlayerModelParts.JACKET,
			EnumPlayerModelParts.LEFT_PANTS_LEG,
			EnumPlayerModelParts.RIGHT_PANTS_LEG,
			EnumPlayerModelParts.LEFT_SLEEVE,
			EnumPlayerModelParts.RIGHT_SLEEVE,
	});

	public MinecraftObject(Minecraft mc) {
		this.mc = mc;
		MinecraftObjectHolder.setClientObject(this);
		loader = new ModelDefinitionLoader<>(PlayerProfile::new, GameProfile::getId, GameProfile::getName);
		prm = new PlayerRenderManager();
		tags = new AllTagManagers(mc.func_110442_L(), CPMTagLoader::new);
	}

	@Override
	public PlayerRenderManager getPlayerRenderManager() {
		return prm;
	}

	@Override
	public ITexture createTexture() {
		return new DynTexture(mc);
	}

	public static class DynTexture extends DynamicTexture implements ITexture {
		private final ResourceLocation loc;
		private final Minecraft mc;

		public DynTexture(Minecraft mc) {
			super(1, 1);
			loc = mc.func_110434_K().func_110578_a("cpm", this);
			this.mc = mc;
		}

		private static ResourceLocation bound_loc;

		@Override
		public void bind() {
			GlStateManager.func_179144_i(func_110552_b());
			bound_loc = loc;
			if(mc.func_110434_K().func_110581_b(loc) == null)
				mc.func_110434_K().func_110579_a(loc, this);
		}

		@Override
		public void load(Image image) {
			this.func_147631_c();
			TextureUtil.func_110989_a(this.func_110552_b(), AWTImageIO.toBufferedImage(image), false, false);
		}

		@Override
		public void free() {
			this.func_147631_c();
			mc.func_110434_K().func_147645_c(loc);
		}

		@Override
		public void func_110551_a(IResourceManager resourceManager) throws IOException {}

		public static ResourceLocation getBoundLoc() {
			return bound_loc;
		}
	}

	@Override
	public void executeOnGameThread(Runnable r) {
		mc.func_152344_a(r);
	}

	@Override
	public ModelDefinitionLoader<GameProfile> getDefinitionLoader() {
		return loader;
	}

	@Override
	public SkinType getSkinType() {
		return SkinType.get(DefaultPlayerSkin.func_177332_b(mc.func_110432_I().func_148256_e().getId()));
	}

	@Override
	public int getEncodedGesture() {
		Set<EnumPlayerModelParts> s = ObfuscationReflectionHelper.getPrivateValue(GameSettings.class, mc.field_71474_y, "field_178882_aU");
		return LAYER_CODEC.getValue(s::contains);
	}

	@Override
	public void setEncodedGesture(int value) {
		Set<EnumPlayerModelParts> s = ObfuscationReflectionHelper.getPrivateValue(GameSettings.class, mc.field_71474_y, "field_178882_aU");
		LAYER_CODEC.setValue(value, s);
		mc.field_71474_y.func_82879_c();
	}

	@Override
	public boolean isInGame() {
		return mc.field_71439_g != null;
	}

	@Override
	public Object getPlayerIDObject() {
		return mc.func_110432_I().func_148256_e();
	}

	@Override
	public Object getCurrentPlayerIDObject() {
		return PlayerProfile.getPlayerProfile(mc.field_71439_g);
	}

	@Override
	public List<IKeybind> getKeybinds() {
		return KeyBindings.kbs;
	}

	@Override
	public File getGameDir() {
		return mc.field_71412_D;
	}

	@Override
	public void openGui(Function<IGui, Frame> creator) {
		mc.func_147108_a(new GuiImpl(creator, mc.field_71462_r));
	}

	@Override
	public Runnable openSingleplayer() {
		return () -> mc.displayGuiScreen(new GuiSelectWorld(mc.currentScreen));
	}

	@Override
	public NetHandler<?, ?, ?> getNetHandler() {
		return ClientProxy.INSTANCE.netHandler;
	}

	@Override
	public IImageIO getImageIO() {
		return new AWTImageIO();
	}
	@Override
	public MojangAPI getMojangAPI() {
		return new MojangAPI(mc.func_110432_I().func_148256_e().getName(), mc.func_110432_I().func_148256_e().getId(), mc.func_110432_I().func_148254_d());
	}

	@Override
	public void clearSkinCache() {
		MojangAPI.clearYggdrasilCache(mc.func_152347_ac());
		mc.func_181037_M().clear();
		mc.func_181037_M();//refresh
	}

	@Override
	public String getConnectedServer() {
		if(mc.func_147114_u() == null)return null;
		SocketAddress sa = mc.func_147114_u().func_147298_b().channel().remoteAddress();
		if(sa instanceof InetSocketAddress)
			return ((InetSocketAddress)sa).getHostString();
		return null;
	}

	@Override
	public List<Object> getPlayers() {
		if(mc.func_147114_u() == null)return Collections.emptyList();
		return mc.func_147114_u().func_175106_d().stream().map(NetworkPlayerInfo::getGameProfile).collect(Collectors.toList());
	}

	@Override
	public Proxy getProxy() {
		return mc.func_110437_J();
	}

	@Override
	public RenderTypeBuilder<?, ?> getRenderBuilder() {
		return renderBuilder;
	}

	@Override
	public AllTagManagers getBuiltinTags() {
		return tags;
	}

	@Override
	public BiomeHandler<?> getBiomeHandler() {
		return BiomeHandlerImpl.impl;
	}
}

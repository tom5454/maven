package com.tom.cpm.common;

import java.util.function.BiConsumer;

import net.minecraft.entity.player.EntityPlayer;

import com.tom.cpm.shared.animation.ServerAnimationState;

public class PlayerAnimUpdater implements BiConsumer<EntityPlayer, ServerAnimationState> {

	@Override
	public void accept(EntityPlayer t, ServerAnimationState u) {
		u.updated = true;
		u.creativeFlying = t.field_71075_bZ.field_75100_b;
		u.falling = t.field_70143_R;
		u.health = t.func_110143_aJ() / t.func_110138_aP();
		u.air = Math.max(t.func_70086_ai() / 300f, 0);
		u.hunger = t.func_71024_bL().func_75116_a() / 20f;
		u.inMenu = t.field_71070_bA != t.field_71069_bz;
	}

}

package com.tom.cpm.client;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.resources.SkinManager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBow;
import net.minecraft.item.ItemSkull;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.util.ResourceLocation;

import net.minecraftforge.fml.common.registry.FMLControlledNamespacedRegistry;
import net.minecraftforge.fml.common.registry.GameData;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTexture.Type;

import com.tom.cpl.block.entity.ActiveEffect;
import com.tom.cpl.math.MathHelper;
import com.tom.cpl.util.Hand;
import com.tom.cpl.util.HandAnimation;
import com.tom.cpm.common.EntityTypeHandlerImpl;
import com.tom.cpm.common.PlayerInventory;
import com.tom.cpm.common.WorldImpl;
import com.tom.cpm.shared.animation.AnimationState;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.model.SkinType;
import com.tom.cpm.shared.model.render.PlayerModelSetup.ArmPose;
import com.tom.cpm.shared.skin.PlayerTextureLoader;

public class PlayerProfile extends Player<EntityPlayer> {
	public static boolean inGui;
	private final GameProfile profile;
	private String skinType;

	public static GameProfile getPlayerProfile(EntityPlayer player) {
		if (player == null)return null;
		GameProfile profile = player.func_146103_bH();
		if (profile.getProperties().isEmpty()) {
			NetHandlerPlayClient conn = Minecraft.func_71410_x().func_147114_u();
			if (conn != null) {
				NetworkPlayerInfo info = conn.func_175102_a(profile.getId());
				if(info != null)profile = info.func_178845_a();
			}
		}
		return profile;
	}

	public PlayerProfile(GameProfile profile) {
		this.profile = new GameProfile(profile.getId(), profile.getName());
		cloneProperties(profile.getProperties(), this.profile.getProperties());

		if(profile.getId() != null)
			this.skinType = DefaultPlayerSkin.func_177332_b(profile.getId());
	}

	public PlayerProfile() {
		this(Minecraft.func_71410_x().func_110432_I().func_148256_e());
	}

	@Override
	public SkinType getSkinType() {
		return SkinType.get(skinType);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((profile == null) ? 0 : profile.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		PlayerProfile other = (PlayerProfile) obj;
		if (profile == null) {
			if (other.profile != null) return false;
		} else if (!profile.equals(other.profile)) return false;
		return true;
	}

	@Override
	protected PlayerTextureLoader initTextures() {
		return new PlayerTextureLoader(Minecraft.func_71410_x().func_152342_ad().field_152796_d) {

			@Override
			protected CompletableFuture<Void> load0() {
				Map<Type, MinecraftProfileTexture> map = Minecraft.func_71410_x().func_152342_ad().func_152788_a(profile);
				defineAll(map, MinecraftProfileTexture::getUrl, MinecraftProfileTexture::getHash);
				if (map.containsKey(Type.SKIN)) {
					MinecraftProfileTexture tex = map.get(Type.SKIN);
					skinType = tex.getMetadata("model");

					if (skinType == null) {
						skinType = "default";
					}
					return CompletableFuture.completedFuture(null);
				}
				CompletableFuture<Void> cf = new CompletableFuture<>();
				Minecraft.func_71410_x().func_152342_ad().func_152790_a(profile, new SkinManager.SkinAvailableCallback() {

					@Override
					public void func_180521_a(Type typeIn, ResourceLocation location, MinecraftProfileTexture profileTexture) {
						defineTexture(typeIn, profileTexture.getUrl(), profileTexture.getHash());
						switch (typeIn) {
						case SKIN:
							skinType = profileTexture.getMetadata("model");

							if (skinType == null) {
								skinType = "default";
							}
							ClientProxy.mc.getDefinitionLoader().execute(() -> Minecraft.getMinecraft().addScheduledTask(() -> cf.complete(null)));
							break;

						default:
							break;
						}
					}
				}, true);
				return cf;
			}
		};
	}

	@Override
	public UUID getUUID() {
		return profile.getId();
	}

	@Override
	public void updateFromPlayer(AnimationState animState, EntityPlayer player) {
		animState.resetPlayer();
		if(player.func_70608_bn())animState.sleeping = true;
		if(player.field_70128_L)animState.dying = true;
		if(player.func_70115_ae() && (player.field_70154_o != null && player.field_70154_o.shouldRiderSit()))animState.riding = true;
		if(player.func_70093_af())animState.sneaking = true;
		if(player.func_70051_ag())animState.sprinting = true;
		if(player.func_71039_bw() && player.func_71011_bu() != null) {
			animState.usingAnimation = HandAnimation.of(player.func_71011_bu().func_77975_n());
		}
		if(player.func_70090_H())animState.retroSwimming = true;
		animState.moveAmountX = (float) (player.field_70165_t - player.field_70169_q);
		animState.moveAmountY = (float) (player.field_70163_u - player.field_70167_r);
		animState.moveAmountZ = (float) (player.field_70161_v - player.field_70166_s);
		animState.yaw = player.field_70759_as * 2 - player.field_70761_aq;
		animState.pitch = player.field_70125_A;
		animState.bodyYaw = player.field_70759_as;

		animState.encodedState = MinecraftObject.LAYER_CODEC.getValue(player::isWearing);

		ItemStack is = player.func_71124_b(4);
		animState.hasSkullOnHead = is != null && is.func_77973_b() instanceof ItemSkull;
		animState.wearingHelm = is != null;
		animState.wearingBody = player.func_71124_b(3) != null;
		animState.wearingLegs = player.func_71124_b(2) != null;
		animState.wearingBoots = player.func_71124_b(1) != null;
		animState.mainHand = Hand.RIGHT;
		animState.activeHand = animState.mainHand;
		animState.hurtTime = player.field_70737_aN;
		animState.isOnLadder = player.func_70617_f_();
		animState.isBurning = player.func_90999_ad();
		animState.inGui = inGui;
		PlayerInventory.setInv(animState, player.field_71071_by);
		WorldImpl.setWorld(animState, player);
		if (player.field_70154_o != null)animState.vehicle = EntityTypeHandlerImpl.impl.wrap(player.field_70154_o.getClass());
		player.func_70651_bq().forEach(e -> {
			FMLControlledNamespacedRegistry<Potion> reg = GameData.getPotionRegistry();
			String id = reg.getNameForObject(reg.getObjectById(e.getPotionID())).toString();
			animState.allEffects.add(new ActiveEffect(id, e.getAmplifier(), e.getDuration(), !e.getIsShowParticles()));
		});

		if(player.func_71011_bu() != null && player.func_71011_bu().func_77973_b() instanceof ItemBow) {
			float f = 20F;
			float f1 = MathHelper.clamp(player.func_71057_bx(), 0.0F, f);
			animState.bowPullback = f1 / f;
		}
	}

	@Override
	public void updateFromModel(AnimationState animState, Object model) {
		if(model instanceof ModelPlayer) {
			ModelPlayer m = (ModelPlayer) model;
			animState.resetModel();
			animState.attackTime = m.field_78095_p;
			animState.leftArm = ArmPose.EMPTY;
			if(m.field_78120_m == 1)animState.rightArm = ArmPose.ITEM;
			else if(m.field_78120_m == 3)animState.rightArm = ArmPose.BLOCK;
			if(m.field_78119_l == 1)animState.leftArm = ArmPose.ITEM;
			else if(m.field_78119_l == 3)animState.leftArm = ArmPose.BLOCK;
			if(m.field_78118_o)animState.rightArm = ArmPose.BOW_AND_ARROW;
		}
	}

	@Override
	public String getName() {
		return profile.getName();
	}

	@Override
	public Object getGameProfile() {
		return profile;
	}
}

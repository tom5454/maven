package com.tom.cpm.client;

import java.io.IOException;
import java.lang.reflect.Method;
import java.net.URI;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import net.minecraft.client.ClientBrandRetriever;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.gui.GuiErrorScreen;
import net.minecraft.client.gui.GuiPageButtonList;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.ResourceLocation;

import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.fml.common.Loader;

import com.tom.cpl.gui.Frame;
import com.tom.cpl.gui.IGui;
import com.tom.cpl.gui.KeyCodes;
import com.tom.cpl.gui.KeyboardEvent;
import com.tom.cpl.gui.MouseEvent;
import com.tom.cpl.gui.NativeGuiComponents;
import com.tom.cpl.gui.NativeGuiComponents.NativeConstructor;
import com.tom.cpl.gui.UIColors;
import com.tom.cpl.gui.elements.FileChooserPopup;
import com.tom.cpl.gui.elements.TextField;
import com.tom.cpl.gui.elements.TextField.ITextField;
import com.tom.cpl.item.Stack;
import com.tom.cpl.math.Box;
import com.tom.cpl.math.Vec2i;
import com.tom.cpl.text.IText;
import com.tom.cpl.util.AWTChooser;
import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.common.ItemStackHandlerImpl;
import com.tom.cpm.shared.gui.panel.Panel3d;
import com.tom.cpm.shared.util.Log;

public class GuiImpl extends GuiScreen implements IGui {
	private static final KeyCodes CODES = new LWJGLKeyCodes();
	private static final NativeGuiComponents nativeComponents = new NativeGuiComponents();
	private Frame gui;
	private GuiScreen parent;
	private CtxStack stack;
	private UIColors colors;
	private Consumer<Runnable> closeListener;
	private int vanillaScale = -1;

	static {
		nativeComponents.register(TextField.class, local(GuiImpl::createTextField));
		nativeComponents.register(FileChooserPopup.class, AWTChooser::new);
		nativeComponents.register(Panel3d.class, Panel3dImpl::new);
	}

	public GuiImpl(Function<IGui, Frame> creator, GuiScreen parent) {
		this.colors = new UIColors();
		this.parent = parent;
		try {
			this.gui = creator.apply(this);
		} catch (Throwable e) {
			onGuiException("Error creating gui", e, true);
		}
	}

	private static <G extends Supplier<IGui>, N> NativeConstructor<G, N> local(Function<GuiImpl, N> fac) {
		return f -> fac.apply((GuiImpl) f.get());
	}

	@Override
	public boolean func_73868_f() {
		return false;
	}

	@Override
	public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
		this.func_146276_q_();
		try {
			GL11.glEnable(GL11.GL_SCISSOR_TEST);
			stack = new CtxStack(field_146294_l, field_146295_m);
			gui.draw(mouseX, mouseY, partialTicks);
		} catch (Throwable e) {
			onGuiException("Error drawing gui", e, true);
		} finally {
			GL11.glDisable(GL11.GL_SCISSOR_TEST);
			String s = "Minecraft 1.8.9 (" + this.field_146297_k.func_175600_c() + "/" + ClientBrandRetriever.getClientModName() + ") " + Loader.instance().getIndexedModList().get(CustomPlayerModels.ID).getDisplayVersion();
			field_146289_q.func_78276_b(s, field_146294_l - field_146289_q.func_78256_a(s) - 4, 2, 0xff000000);
			s = "FPS: " + Minecraft.func_175610_ah();
			field_146289_q.func_78276_b(s, field_146294_l - field_146289_q.func_78256_a(s) - 4, 11, 0xff000000);
		}
		if(field_146297_k.field_71439_g != null && gui.enableChat()) {
			try {
				ScaledResolution res = new ScaledResolution(field_146297_k);
				Method m = GuiIngameForge.class.getDeclaredMethod("renderChat", int.class, int.class);
				m.setAccessible(true);
				m.invoke(field_146297_k.field_71456_v, res.func_78326_a(), res.func_78328_b());
			} catch (Throwable e) {
			}
		}
	}

	@Override
	public void func_146281_b() {
		Keyboard.enableRepeatEvents(false);
		if(vanillaScale != -1 && vanillaScale != field_146297_k.field_71474_y.field_74335_Z) {
			field_146297_k.field_71474_y.field_74335_Z = vanillaScale;
		}
		if(parent != null) {
			GuiScreen p = parent;
			parent = null;
			field_146297_k.func_147108_a(p);
		}
	}

	@Override
	public void drawBox(int x, int y, int w, int h, int color) {
		x += getOffset().x;
		y += getOffset().y;
		func_73734_a(x, y, x+w, y+h, color);
	}

	@Override
	public void func_73866_w_() {
		Keyboard.enableRepeatEvents(true);
		try {
			gui.init(field_146294_l, field_146295_m);
		} catch (Throwable e) {
			onGuiException("Error in init gui", e, true);
		}
	}

	@Override
	public void drawText(int x, int y, String text, int color) {
		x += getOffset().x;
		y += getOffset().y;
		field_146289_q.func_78276_b(text, x, y, color);
	}

	@Override
	protected void func_73869_a(char typedChar, int keyCode) throws IOException {
		try {
			KeyboardEvent evt = new KeyboardEvent(keyCode, 0, typedChar, Keyboard.getKeyName(keyCode));
			gui.keyPressed(evt);
			if(!evt.isConsumed()) {
				if(field_146297_k.field_71439_g != null && field_146297_k.field_71474_y.field_74310_D.func_151463_i() == keyCode && field_146297_k.field_71474_y.field_74343_n != EntityPlayer.EnumChatVisibility.HIDDEN) {
					field_146297_k.func_147108_a(new Overlay());
				}
			}
		} catch (Throwable e) {
			onGuiException("Error processing key event", e, false);
		}
	}

	@Override
	protected void func_73864_a(int mouseX, int mouseY, int mouseButton) throws IOException {
		try {
			gui.mouseClick(new MouseEvent(mouseX, mouseY, mouseButton));
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
		}
	}

	@Override
	protected void func_146273_a(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
		try {
			gui.mouseDrag(new MouseEvent(mouseX, mouseY, clickedMouseButton));
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
		}
	}

	@Override
	protected void func_146286_b(int mouseX, int mouseY, int state) {
		try {
			gui.mouseRelease(new MouseEvent(mouseX, mouseY, state));
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
		}
	}

	@Override
	public void func_146274_d() throws IOException {
		super.func_146274_d();
		int i = Mouse.getEventDWheel();
		if (i > 0) {
			i = 1;
		}

		if (i < 0) {
			i = -1;
		}

		if(i != 0) {
			try {
				int x = Mouse.getEventX() * this.field_146294_l / this.field_146297_k.field_71443_c;
				int y = this.field_146295_m - Mouse.getEventY() * this.field_146295_m / this.field_146297_k.field_71440_d - 1;
				gui.mouseWheel(new MouseEvent(x, y, i));
			} catch (Throwable e) {
				onGuiException("Error processing mouse event", e, false);
			}
		}
	}

	@Override
	public void displayError(String e) {
		GuiScreen p = parent;
		parent = null;
		Minecraft.func_71410_x().func_147108_a(new GuiErrorScreen("Custom Player Models", I18n.func_135052_a("error.cpm.crash", e)) {
			private GuiScreen parent = p;

			@Override
			public void func_146281_b() {
				if(parent != null) {
					GuiScreen p = parent;
					parent = null;
					field_146297_k.func_147108_a(p);
				}
			}
		});
	}

	@Override
	public void closeGui() {
		if(closeListener != null) {
			closeListener.accept(() -> this.mc.displayGuiScreen((GuiScreen)null));
		} else
			this.field_146297_k.func_147108_a((GuiScreen)null);
	}

	@Override
	public void drawTexture(int x, int y, int w, int h, int u, int v, String texture) {
		field_146297_k.func_110434_K().func_110577_a(new ResourceLocation("cpm", "textures/gui/" + texture + ".png"));
		x += getOffset().x;
		y += getOffset().y;
		GlStateManager.func_179131_c(1, 1, 1, 1);
		func_73729_b(x, y, u, v, w, h);
	}

	@Override
	public void drawTexture(int x, int y, int w, int h, int u, int v, String texture, int color) {
		field_146297_k.func_110434_K().func_110577_a(new ResourceLocation("cpm", "textures/gui/" + texture + ".png"));
		x += getOffset().x;
		y += getOffset().y;
		float a = (color >> 24 & 255) / 255.0F;
		float r = (color >> 16 & 255) / 255.0F;
		float g = (color >> 8 & 255) / 255.0F;
		float b = (color & 255) / 255.0F;
		GlStateManager.func_179131_c(r, g, b, a);
		func_73729_b(x, y, u, v, w, h);
	}

	@Override
	public void drawTexture(int x, int y, int width, int height, float u1, float v1, float u2, float v2) {
		x += getOffset().x;
		y += getOffset().y;
		GlStateManager.func_179131_c(1, 1, 1, 1);
		Tessellator tessellator = Tessellator.func_178181_a();
		WorldRenderer bufferbuilder = tessellator.func_178180_c();
		bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
		bufferbuilder.func_181662_b(x, y + height, 0.0D).func_181673_a(u1, v2).func_181675_d();
		bufferbuilder.func_181662_b(x + width, y + height, 0.0D).func_181673_a(u2, v2).func_181675_d();
		bufferbuilder.func_181662_b(x + width, y, 0.0D).func_181673_a(u2, v1).func_181675_d();
		bufferbuilder.func_181662_b(x, y, 0.0D).func_181673_a(u1, v1).func_181675_d();
		tessellator.func_78381_a();
	}

	@Override
	public String i18nFormat(String key, Object... obj) {
		return I18n.func_135052_a(key, obj);
	}

	@Override
	public void setupCut() {
		float multiplierX = field_146297_k.field_71443_c / (float)field_146294_l;
		float multiplierY = field_146297_k.field_71440_d / (float)field_146295_m;
		Box box = getContext().cutBox;
		GL11.glScissor((int) (box.x * multiplierX), field_146297_k.field_71440_d - (int) ((box.y + box.h) * multiplierY),
				(int) (box.w * multiplierX), (int) (box.h * multiplierY));
	}

	@Override
	public int textWidth(String text) {
		return field_146289_q.func_78256_a(text);
	}

	private ITextField createTextField() {
		return new TxtField();
	}

	private class TxtField implements ITextField, GuiPageButtonList.GuiResponder {
		private GuiTextField field;
		private Runnable eventListener;
		private Vec2i currentOff = new Vec2i(0, 0);
		private Box bounds = new Box(0, 0, 0, 0);
		private boolean refreshTextBox;
		public TxtField() {
			this.field = new GuiTextField(0, field_146289_q, 0, 0, 0, 0);
			this.field.func_146203_f(1024*1024);
			this.field.func_146185_a(false);
			this.field.func_146189_e(true);
			this.field.func_146193_g(colors.label_text_color);
			this.field.func_175207_a(this);
		}

		@Override
		public void draw(int mouseX, int mouseY, float partialTicks, Box bounds) {
			Vec2i off = getOffset();
			field.field_146209_f = bounds.x + off.x + 4;
			field.field_146210_g = bounds.y + off.y + 6;
			currentOff.x = off.x;
			currentOff.y = off.y;
			this.bounds.x = bounds.x;
			this.bounds.y = bounds.y;
			this.bounds.w = bounds.w;
			this.bounds.h = bounds.h;
			field.field_146218_h = bounds.w - 5;
			field.field_146219_i = bounds.h - 12;
			if(refreshTextBox) {
				field.func_146202_e();
				refreshTextBox = false;
			}
			field.func_146194_f();
		}

		@Override
		public void keyPressed(KeyboardEvent e) {
			if(e.isConsumed())return;
			if(field.func_146201_a(e.charTyped, e.keyCode))
				e.consume();
		}

		@Override
		public void mouseClick(MouseEvent e) {
			if(e.isConsumed()) {
				field.func_146192_a(Integer.MIN_VALUE, Integer.MIN_VALUE, e.btn);
				return;
			}
			field.field_146209_f = bounds.x + currentOff.x;
			field.field_146210_g = bounds.y + currentOff.y;
			field.field_146218_h = bounds.w;
			field.field_146219_i = bounds.h;
			field.func_146192_a(e.x + currentOff.x, e.y + currentOff.y, e.btn);
			if(bounds.isInBounds(e.x, e.y))e.consume();
		}

		@Override
		public String getText() {
			return field.func_146179_b();
		}

		@Override
		public void setText(String txt) {
			field.func_146180_a(txt);
			refreshTextBox = true;
		}

		@Override
		public void setEventListener(Runnable eventListener) {
			this.eventListener = eventListener;
		}

		@Override
		public void func_175321_a(int id, boolean value) {
		}

		@Override
		public void func_175320_a(int id, float value) {
		}

		@Override
		public void func_175319_a(int id, String value) {
			if(eventListener != null)eventListener.run();
		}

		@Override
		public void setEnabled(boolean enabled) {
			field.func_146184_c(enabled);
		}

		@Override
		public boolean isFocused() {
			return field.func_146206_l();
		}

		@Override
		public void setFocused(boolean focused) {
			field.func_146195_b(focused);
		}

		@Override
		public int getCursorPos() {
			return field.func_146198_h();
		}

		@Override
		public void setCursorPos(int pos) {
			field.func_146190_e(pos);
		}
	}

	@Override
	public UIColors getColors() {
		return colors;
	}

	@Override
	public void setCloseListener(Consumer<Runnable> listener) {
		this.closeListener = listener;
	}

	@Override
	public boolean isShiftDown() {
		return func_146272_n();
	}

	@Override
	public boolean isCtrlDown() {
		return func_146271_m();
	}

	@Override
	public boolean isAltDown() {
		return func_175283_s();
	}

	public class Overlay extends GuiChat {

		@Override
		public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
			GuiImpl.this.func_73863_a(Integer.MIN_VALUE, Integer.MIN_VALUE, partialTicks);
			super.func_73863_a(mouseX, mouseY, partialTicks);
		}

		public GuiScreen getGui() {
			return GuiImpl.this;
		}
	}

	@Override
	public KeyCodes getKeyCodes() {
		return CODES;
	}

	@Override
	public void drawGradientBox(int x, int y, int w, int h, int topLeft, int topRight, int bottomLeft,
			int bottomRight) {
		int left = x;
		int top = y;
		int right = x + w;
		int bottom = y + h;
		float atr = (topRight >> 24 & 255) / 255.0F;
		float rtr = (topRight >> 16 & 255) / 255.0F;
		float gtr = (topRight >> 8 & 255) / 255.0F;
		float btr = (topRight & 255) / 255.0F;
		float atl = (topLeft >> 24 & 255) / 255.0F;
		float rtl = (topLeft >> 16 & 255) / 255.0F;
		float gtl = (topLeft >> 8 & 255) / 255.0F;
		float btl = (topLeft & 255) / 255.0F;
		float abl = (bottomLeft >> 24 & 255) / 255.0F;
		float rbl = (bottomLeft >> 16 & 255) / 255.0F;
		float gbl = (bottomLeft >> 8 & 255) / 255.0F;
		float bbl = (bottomLeft & 255) / 255.0F;
		float abr = (bottomRight >> 24 & 255) / 255.0F;
		float rbr = (bottomRight >> 16 & 255) / 255.0F;
		float gbr = (bottomRight >> 8 & 255) / 255.0F;
		float bbr = (bottomRight & 255) / 255.0F;
		GlStateManager.func_179090_x();
		GlStateManager.func_179147_l();
		GlStateManager.func_179118_c();
		GlStateManager.func_179120_a(770, 771, 1, 0);
		GlStateManager.func_179103_j(7425);
		Tessellator tessellator = Tessellator.func_178181_a();
		WorldRenderer bufferbuilder = tessellator.func_178180_c();
		bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
		bufferbuilder.func_181662_b(right, top, this.field_73735_i).func_181666_a(rtr, gtr, btr, atr).func_181675_d();
		bufferbuilder.func_181662_b(left, top, this.field_73735_i).func_181666_a(rtl, gtl, btl, atl).func_181675_d();
		bufferbuilder.func_181662_b(left, bottom, this.field_73735_i).func_181666_a(rbl, gbl, bbl, abl).func_181675_d();
		bufferbuilder.func_181662_b(right, bottom, this.field_73735_i).func_181666_a(rbr, gbr, bbr, abr).func_181675_d();
		tessellator.func_78381_a();
		GlStateManager.func_179103_j(7424);
		GlStateManager.func_179084_k();
		GlStateManager.func_179141_d();
		GlStateManager.func_179098_w();
	}

	@Override
	public NativeGuiComponents getNative() {
		return nativeComponents;
	}

	@Override
	public void setClipboardText(String text) {
		func_146275_d(text);
	}

	@Override
	public Frame getFrame() {
		return gui;
	}

	@Override
	public String getClipboardText() {
		return func_146277_j();
	}

	@Override
	public void setScale(int value) {
		if(value != field_146297_k.field_71474_y.field_74335_Z) {
			if(vanillaScale == -1)vanillaScale = field_146297_k.field_71474_y.field_74335_Z;
			if(value == -1) {
				if(field_146297_k.field_71474_y.field_74335_Z != vanillaScale) {
					field_146297_k.field_71474_y.field_74335_Z = vanillaScale;
					vanillaScale = -1;
					ScaledResolution scaledresolution = new ScaledResolution(this.field_146297_k);
					int j = scaledresolution.func_78326_a();
					int k = scaledresolution.func_78328_b();
					this.func_146280_a(this.field_146297_k, j, k);
				}
			} else {
				field_146297_k.field_71474_y.field_74335_Z = value;
				ScaledResolution scaledresolution = new ScaledResolution(this.field_146297_k);
				int j = scaledresolution.func_78326_a();
				int k = scaledresolution.func_78328_b();
				this.func_146280_a(this.field_146297_k, j, k);
			}
		}
	}

	@Override
	public int getScale() {
		return field_146297_k.field_71474_y.field_74335_Z;
	}

	@Override
	public int getMaxScale() {
		return 4;
	}

	@Override
	public CtxStack getStack() {
		return stack;
	}

	@Override
	public void func_73876_c() {
		try {
			gui.tick();
		} catch (Throwable e) {
			onGuiException("Error in tick gui", e, true);
		}
	}

	@Override
	public void drawFormattedText(float x, float y, IText text, int color, float scale) {
		x += getOffset().x;
		y += getOffset().y;
		GlStateManager.func_179094_E();
		GlStateManager.func_179109_b(x, y, 0);
		GlStateManager.func_179152_a(scale, scale, scale);
		field_146289_q.func_78276_b(text.<IChatComponent>remap().func_150254_d(), 0, 0, color);
		GlStateManager.func_179121_F();
	}

	@Override
	public int textWidthFormatted(IText text) {
		return field_146289_q.func_78256_a(text.<IChatComponent>remap().func_150254_d());
	}

	@Override
	public void openURL0(String url) {
		try {
			Class<?> oclass = Class.forName("java.awt.Desktop");
			Object object = oclass.getMethod("getDesktop").invoke((Object)null);
			oclass.getMethod("browse", URI.class).invoke(object, new URI(url));
		} catch (Throwable throwable1) {
			Throwable throwable = throwable1.getCause();
			Log.error("Couldn't open link: " + (throwable == null ? "<UNKNOWN>" : throwable.getMessage()));
		}
	}

	public void onOpened() {
		vanillaScale = -1;
	}

	@Override
	public void drawStack(int x, int y, Stack stack) {
		x += getOffset().x;
		y += getOffset().y;
		ItemStack s = ItemStackHandlerImpl.impl.unwrap(stack);
		GlStateManager.func_179126_j();
		RenderHelper.func_74520_c();
		this.field_146296_j.func_180450_b(s, x, y);
		this.field_146296_j.func_180453_a(this.field_146289_q, s, x, y, null);
		GlStateManager.func_179097_i();
	}

	@Override
	public void drawStackTooltip(int mx, int my, Stack stack) {
		ItemStack s = ItemStackHandlerImpl.impl.unwrap(stack);
		func_146285_a(s, mx, my);
	}
}

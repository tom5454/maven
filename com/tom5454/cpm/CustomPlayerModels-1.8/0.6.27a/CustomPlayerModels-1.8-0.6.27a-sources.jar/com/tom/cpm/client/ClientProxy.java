package com.tom.cpm.client;

import java.util.concurrent.Executor;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiCustomizeSkin;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiSelectWorld;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.C17PacketCustomPayload;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.IChatComponent;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.GuiScreenEvent.DrawScreenEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import com.tom.cpl.text.FormatText;
import com.tom.cpm.CommonProxy;
import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.common.Command;
import com.tom.cpm.common.PlayerAnimUpdater;
import com.tom.cpm.lefix.FixSSL;
import com.tom.cpm.shared.config.ConfigKeys;
import com.tom.cpm.shared.config.ModConfig;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import com.tom.cpm.shared.editor.gui.EditorGui;
import com.tom.cpm.shared.gui.GestureGui;
import com.tom.cpm.shared.model.RenderManager;
import com.tom.cpm.shared.model.TextureSheetType;
import com.tom.cpm.shared.network.NetHandler;

import io.netty.buffer.Unpooled;

public class ClientProxy extends CommonProxy {
	public static final ResourceLocation DEFAULT_CAPE = new ResourceLocation("cpm:textures/template/cape.png");
	public static MinecraftObject mc;
	private Minecraft minecraft;
	public static ClientProxy INSTANCE;
	public RenderManager<GameProfile, EntityPlayer, ModelBase, Void> manager;
	public NetHandler<ResourceLocation, EntityPlayer, NetHandlerPlayClient> netHandler;

	@Override
	public void init() {
		super.init();
		FixSSL.fixup();
		INSTANCE = this;
		minecraft = Minecraft.func_71410_x();
		mc = new MinecraftObject(minecraft);
		MinecraftForge.EVENT_BUS.register(this);
		KeyBindings.init();
		manager = new RenderManager<>(mc.getPlayerRenderManager(), mc.getDefinitionLoader(), PlayerProfile::getPlayerProfile);
		manager.setGPGetters(GameProfile::getProperties, Property::getValue);
		netHandler = new NetHandler<>(ResourceLocation::new);
		Executor ex = minecraft::addScheduledTask;
		netHandler.setExecutor(() -> ex);
		netHandler.setSendPacketClient(d -> new PacketBuffer(Unpooled.wrappedBuffer(d)), (c, rl, pb) -> c.addToSendQueue(new C17PacketCustomPayload(rl.toString(), pb)));
		netHandler.setPlayerToLoader(EntityPlayer::getGameProfile);
		netHandler.setGetPlayerById(id -> {
			Entity ent = Minecraft.getMinecraft().theWorld.getEntityByID(id);
			if(ent instanceof EntityPlayer) {
				return (AbstractClientPlayer) ent;
			}
			return null;
		});
		netHandler.setGetClient(() -> minecraft.thePlayer);
		netHandler.setGetNet(c -> ((EntityPlayerSP)c).sendQueue);
		netHandler.setDisplayText(f -> minecraft.ingameGUI.getChatGUI().printChatMessage(f.remap()));
		netHandler.setGetPlayerAnimGetters(new PlayerAnimUpdater());
		new Command(ClientCommandHandler.instance::registerCommand, true);
	}

	@Override
	public void apiInit() {
		CustomPlayerModels.api.buildClient().voicePlayer(EntityPlayer.class, EntityPlayer::getUniqueID).localModelApi(GameProfile::new).
		renderApi(ModelBase.class, GameProfile.class).init();
	}

	@SubscribeEvent
	public void playerRenderPre(RenderPlayerEvent.Pre event) {
		manager.bindPlayer(event.entityPlayer, null, event.renderer.func_177087_b());
		manager.bindSkin(event.renderer.func_177087_b(), TextureSheetType.SKIN);
	}

	@SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
	public void playerRenderPreC(RenderPlayerEvent.Pre event) {
		if(event.isCanceled())manager.unbindFlush(event.renderer.func_177087_b());
	}

	@SubscribeEvent
	public void playerRenderPost(RenderPlayerEvent.Post event) {
		manager.unbindFlush(event.renderer.func_177087_b());
	}

	@SubscribeEvent
	public void initGui(GuiScreenEvent.InitGuiEvent.Post evt) {
		if((evt.gui instanceof GuiMainMenu && ModConfig.getCommonConfig().getSetBoolean(ConfigKeys.TITLE_SCREEN_BUTTON, true)) ||
				evt.gui instanceof GuiCustomizeSkin) {
			evt.buttonList.add(new Button(0, 0));
		}
	}

	@SubscribeEvent
	public void buttonPress(GuiScreenEvent.ActionPerformedEvent.Pre evt) {
		if(evt.button instanceof Button) {
			Minecraft.func_71410_x().func_147108_a(new GuiImpl(EditorGui::new, evt.gui));
		}
	}

	@SubscribeEvent
	public void openGui(GuiOpenEvent openGui) {
		if(openGui.gui == null && minecraft.field_71462_r instanceof GuiImpl.Overlay) {
			openGui.gui = ((GuiImpl.Overlay) minecraft.field_71462_r).getGui();
		}
		if(openGui.gui instanceof GuiMainMenu && !(minecraft.field_71462_r instanceof GuiSelectWorld || minecraft.field_71462_r instanceof GuiMainMenu) && EditorGui.doOpenEditor()) {
			openGui.gui = new GuiImpl(EditorGui::new, openGui.gui);
		}
		if(openGui.gui instanceof GuiImpl)((GuiImpl)openGui.gui).onOpened();
	}

	@SubscribeEvent
	public void drawGuiPre(DrawScreenEvent.Pre evt) {
		PlayerProfile.inGui = true;
	}

	@SubscribeEvent
	public void drawGuiPost(DrawScreenEvent.Post evt) {
		PlayerProfile.inGui = false;
	}

	public void renderSkull(ModelBase skullModel, GameProfile profile) {
		manager.bindSkull(profile, null, skullModel);
		manager.bindSkin(skullModel, TextureSheetType.SKIN);
	}

	public void renderArmor(ModelBase modelArmor, ModelBase modelLeggings,
			ModelBiped player) {
		manager.bindArmor(player, modelArmor, 1);
		manager.bindArmor(player, modelLeggings, 2);
		manager.bindSkin(modelArmor, TextureSheetType.ARMOR1);
		manager.bindSkin(modelLeggings, TextureSheetType.ARMOR2);
	}

	@SubscribeEvent
	public void renderTick(RenderTickEvent evt) {
		if(evt.phase == Phase.START) {
			mc.getPlayerRenderManager().getAnimationEngine().update(evt.renderTickTime);
		}
	}

	@SubscribeEvent
	public void clientTick(ClientTickEvent evt) {
		if(evt.phase == Phase.START && !minecraft.func_147113_T()) {
			mc.getPlayerRenderManager().getAnimationEngine().tick();

			if(minecraft.field_71439_g != null && minecraft.field_71439_g.field_70122_E && minecraft.field_71474_y.field_74314_A.func_151470_d()) {
				manager.jump(minecraft.field_71439_g);
			}
		}

		if (minecraft.field_71439_g == null || evt.phase == Phase.START)
			return;

		if(KeyBindings.gestureMenuBinding.func_151468_f()) {
			minecraft.func_147108_a(new GuiImpl(GestureGui::new, null));
		}

		if(KeyBindings.renderToggleBinding.func_151468_f()) {
			Player.setEnableRendering(!Player.isEnableRendering());
		}

		mc.getPlayerRenderManager().getAnimationEngine().updateKeys(KeyBindings.quickAccess);

		CustomPlayerModels.api.clientApi().tickListeners(minecraft.func_147113_T());
	}

	@SubscribeEvent
	public void onRenderName(RenderLivingEvent.Specials.Pre<AbstractClientPlayer> evt) {
		if(evt.entity instanceof AbstractClientPlayer) {
			if(!Player.isEnableNames())
				evt.setCanceled(true);
			if(Player.isEnableLoadingInfo() && canRenderName(evt.entity)) {
				FormatText st = INSTANCE.manager.getStatus(((AbstractClientPlayer) evt.entity).func_146103_bH(), ModelDefinitionLoader.PLAYER_UNIQUE);
				if(st != null) {
					double d0 = evt.entity.func_70068_e(minecraft.func_175606_aa());
					if (d0 < 32*32) {
						Scoreboard scoreboard = ((EntityPlayer) evt.entity).func_96123_co();
						ScoreObjective scoreobjective = scoreboard.func_96539_a(2);
						double y = evt.y;
						if (scoreobjective != null)
							y += evt.renderer.func_76983_a().field_78288_b * 1.15F * 0.025F;

						GlStateManager.func_179094_E();
						GlStateManager.func_179109_b(0, 0.125F, 0);
						String str = ((IChatComponent) st.remap()).func_150254_d();
						GlStateManager.func_179092_a(516, 0.1F);

						if (evt.entity.func_70093_af()) {
							FontRenderer fontrenderer = minecraft.field_71466_p;
							GlStateManager.func_179094_E();
							GlStateManager.func_179109_b((float)evt.x, (float)y + evt.entity.field_70131_O + 0.5F - (evt.entity.func_70631_g_() ? evt.entity.field_70131_O / 2.0F : 0.0F), (float)evt.z);
							GL11.glNormal3f(0.0F, 1.0F, 0.0F);
							GlStateManager.func_179114_b(-minecraft.func_175598_ae().field_78735_i, 0.0F, 1.0F, 0.0F);
							GlStateManager.func_179114_b(minecraft.func_175598_ae().field_78732_j, 1.0F, 0.0F, 0.0F);
							GlStateManager.func_179152_a(-0.02666667F / 2, -0.02666667F / 2, 0.02666667F / 2);
							GlStateManager.func_179109_b(0.0F, 9.374999F, 0.0F);
							GlStateManager.func_179140_f();
							GlStateManager.func_179132_a(false);
							GlStateManager.func_179147_l();
							GlStateManager.func_179090_x();
							GlStateManager.func_179120_a(770, 771, 1, 0);
							int i = fontrenderer.func_78256_a(str) / 2;
							Tessellator tessellator = Tessellator.func_178181_a();
							WorldRenderer worldrenderer = tessellator.func_178180_c();
							worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
							worldrenderer.func_181662_b(-i - 1, -1.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
							worldrenderer.func_181662_b(-i - 1, 8.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
							worldrenderer.func_181662_b(i + 1, 8.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
							worldrenderer.func_181662_b(i + 1, -1.0D, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
							tessellator.func_78381_a();
							GlStateManager.func_179098_w();
							GlStateManager.func_179132_a(true);
							fontrenderer.func_78276_b(str, -fontrenderer.func_78256_a(str) / 2, 0, 553648127);
							GlStateManager.func_179145_e();
							GlStateManager.func_179084_k();
							GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
							GlStateManager.func_179121_F();
						} else {
							renderLivingLabel(evt.entity, str, evt.x, y - (evt.entity.func_70631_g_() ? (double)(evt.entity.field_70131_O / 2.0F) : 0.0D), evt.z, 64);
						}
						GlStateManager.func_179121_F();
					}
				}
			}
		}
	}

	protected boolean canRenderName(EntityLivingBase entity) {
		EntityPlayerSP entityplayersp = Minecraft.func_71410_x().field_71439_g;

		if (entity instanceof EntityPlayer && entity != entityplayersp) {
			Team team = entity.func_96124_cp();
			Team team1 = entityplayersp.func_96124_cp();

			if (team != null) {
				Team.EnumVisible team$enumvisible = team.func_178770_i();

				switch (team$enumvisible) {
				case ALWAYS:
					return true;
				case NEVER:
					return false;
				case HIDE_FOR_OTHER_TEAMS:
					return team1 == null || team.func_142054_a(team1);
				case HIDE_FOR_OWN_TEAM:
					return team1 == null || !team.func_142054_a(team1);
				default:
					return true;
				}
			}
		}

		return Minecraft.func_71382_s() && !entity.func_98034_c(entityplayersp) && entity.field_70153_n == null;
	}

	protected void renderLivingLabel(Entity entityIn, String str, double x, double y, double z, int maxDistance) {
		double d0 = entityIn.func_70068_e(minecraft.func_175598_ae().field_78734_h);

		if (d0 <= maxDistance * maxDistance) {
			FontRenderer fontrenderer = minecraft.field_71466_p;
			float f = 1.6F;
			float f1 = 0.016666668F * f / 2;
			GlStateManager.func_179094_E();
			GlStateManager.func_179109_b((float)x + 0.0F, (float)y + entityIn.field_70131_O + 0.5F, (float)z);
			GL11.glNormal3f(0.0F, 1.0F, 0.0F);
			GlStateManager.func_179114_b(-minecraft.func_175598_ae().field_78735_i, 0.0F, 1.0F, 0.0F);
			GlStateManager.func_179114_b(minecraft.func_175598_ae().field_78732_j, 1.0F, 0.0F, 0.0F);
			GlStateManager.func_179152_a(-f1, -f1, f1);
			GlStateManager.func_179140_f();
			GlStateManager.func_179132_a(false);
			GlStateManager.func_179097_i();
			GlStateManager.func_179147_l();
			GlStateManager.func_179120_a(770, 771, 1, 0);
			Tessellator tessellator = Tessellator.func_178181_a();
			WorldRenderer worldrenderer = tessellator.func_178180_c();
			int i = 0;

			if (str.equals("deadmau5"))i = -10;

			int j = fontrenderer.func_78256_a(str) / 2;
			GlStateManager.func_179090_x();
			worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
			worldrenderer.func_181662_b(-j - 1, -1 + i, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
			worldrenderer.func_181662_b(-j - 1, 8 + i, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
			worldrenderer.func_181662_b(j + 1, 8 + i, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
			worldrenderer.func_181662_b(j + 1, -1 + i, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
			tessellator.func_78381_a();
			GlStateManager.func_179098_w();
			fontrenderer.func_78276_b(str, -fontrenderer.func_78256_a(str) / 2, i, 553648127);
			GlStateManager.func_179126_j();
			GlStateManager.func_179132_a(true);
			fontrenderer.func_78276_b(str, -fontrenderer.func_78256_a(str) / 2, i, -1);
			GlStateManager.func_179145_e();
			GlStateManager.func_179084_k();
			GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
			GlStateManager.func_179121_F();
		}
	}

	public static class Button extends GuiButton {

		public Button(int x, int y) {
			super(99, x, y, 100, 20, I18n.func_135052_a("button.cpm.open_editor"));
		}

	}

	public void onLogout() {
		mc.onLogOut();
	}

	//Copy from LayerCape
	public static void renderCape(AbstractClientPlayer playerIn, float partialTicks, ModelPlayer model, ModelDefinition modelDefinition) {
		GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.func_179094_E();
		GlStateManager.func_179109_b(0.0F, 0.0F, 0.125F);
		float f1, f2, f3;

		if(playerIn != null) {
			double lvt_10_1_ = playerIn.field_71091_bM
					+ (playerIn.field_71094_bP - playerIn.field_71091_bM) * partialTicks
					- (playerIn.field_70169_q + (playerIn.field_70165_t - playerIn.field_70169_q) * partialTicks);
			double lvt_12_1_ = playerIn.field_71096_bN
					+ (playerIn.field_71095_bQ - playerIn.field_71096_bN) * partialTicks
					- (playerIn.field_70167_r + (playerIn.field_70163_u - playerIn.field_70167_r) * partialTicks);
			double lvt_14_1_ = playerIn.field_71097_bO
					+ (playerIn.field_71085_bR - playerIn.field_71097_bO) * partialTicks
					- (playerIn.field_70166_s + (playerIn.field_70161_v - playerIn.field_70166_s) * partialTicks);
			float lvt_16_1_ = playerIn.field_70760_ar
					+ (playerIn.field_70761_aq - playerIn.field_70760_ar) * partialTicks;
			double lvt_17_1_ = MathHelper.func_76126_a(lvt_16_1_ * 0.017453292F);
			double lvt_19_1_ = (-MathHelper.func_76134_b(lvt_16_1_ * 0.017453292F));
			f1 = (float) lvt_12_1_ * 10.0F;
			f1 = MathHelper.func_76131_a(f1, -6.0F, 32.0F);
			f2 = (float) (lvt_10_1_ * lvt_17_1_ + lvt_14_1_ * lvt_19_1_) * 100.0F;
			f3 = (float) (lvt_10_1_ * lvt_19_1_ - lvt_14_1_ * lvt_17_1_) * 100.0F;
			if (f2 < 0.0F) {
				f2 = 0.0F;
			}

			float lvt_24_1_ = playerIn.field_71107_bF
					+ (playerIn.field_71109_bG - playerIn.field_71107_bF) * partialTicks;
			f1 += MathHelper.func_76126_a((playerIn.field_70141_P
					+ (playerIn.field_70140_Q - playerIn.field_70141_P) * partialTicks)
					* 6.0F) * 32.0F * lvt_24_1_;
			if (playerIn.func_70093_af()) {
				f1 += 25.0F;
				model.field_178729_w.field_78797_d = 2.0F;
			} else {
				model.field_178729_w.field_78797_d = 0.0F;
			}
		} else {
			f1 = 0;
			f2 = 0;
			f3 = 0;
		}

		model.field_178729_w.field_78795_f = (float) -Math.toRadians(6.0F + f2 / 2.0F + f1);
		model.field_178729_w.field_78796_g = (float) Math.toRadians(180.0F - f3 / 2.0F);
		model.field_178729_w.field_78808_h = (float) Math.toRadians(f3 / 2.0F);
		mc.getPlayerRenderManager().setModelPose(model);
		model.field_178729_w.field_78795_f = 0;
		model.field_178729_w.field_78796_g = 0;
		model.field_178729_w.field_78808_h = 0;
		model.func_178728_c(0.0625F);
		GlStateManager.func_179121_F();
	}
}

package com.tom.cpm.client;

import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.tom.cpl.render.RenderTypeBuilder.TextureHandler;

public class ModelTexture implements TextureHandler<class_2960, class_1921> {
	private CallbackInfoReturnable<class_2960> texture;
	private Function<class_2960, class_1921> renderType;

	public ModelTexture(CallbackInfoReturnable<class_2960> texture,
			Function<class_2960, class_1921> renderType) {
		this.texture = texture;
		this.renderType = renderType;
	}

	public ModelTexture(Function<class_2960, class_1921> renderType) {
		this(new CallbackInfoReturnable<>("", true), renderType);
	}

	public ModelTexture(class_2960 tex, Function<class_2960, class_1921> renderType) {
		this(new CallbackInfoReturnable<>("", true, tex), renderType);
	}

	public ModelTexture(CallbackInfoReturnable<class_2960> texture) {
		this(texture, PlayerRenderManager.entity);
	}

	public ModelTexture() {
		this(PlayerRenderManager.entity);
	}

	public ModelTexture(class_2960 tex) {
		this(tex, PlayerRenderManager.entity);
	}

	@Override
	public class_2960 getTexture() {
		return texture.getReturnValue();
	}

	@Override
	public void setTexture(class_2960 texture) {
		this.texture.setReturnValue(texture);
	}

	@Override
	public class_1921 getRenderType() {
		return renderType.apply(getTexture());
	}
}

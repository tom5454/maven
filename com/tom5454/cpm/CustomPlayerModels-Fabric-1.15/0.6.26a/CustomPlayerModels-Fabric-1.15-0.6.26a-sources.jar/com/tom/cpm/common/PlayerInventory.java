package com.tom.cpm.common;

import com.tom.cpl.item.Inventory;
import com.tom.cpl.item.NamedSlot;
import com.tom.cpl.item.Stack;
import com.tom.cpm.shared.animation.AnimationState;
import net.minecraft.class_1304;

public class PlayerInventory implements Inventory {
	private net.minecraft.class_1661 inv;

	public static void setInv(AnimationState a, net.minecraft.class_1661 inv) {
		if(!(a.playerInventory instanceof PlayerInventory))a.playerInventory = new PlayerInventory();
		((PlayerInventory) a.playerInventory).inv = inv;
	}

	@Override
	public int size() {
		return inv == null ? 0 : inv.method_5439();
	}

	@Override
	public Stack getInSlot(int i) {
		return ItemStackHandlerImpl.impl.wrap(inv.method_5438(i));
	}

	@Override
	public void reset() {
		inv = null;
	}

	@Override
	public int getNamedSlotId(NamedSlot slot) {
		switch (slot) {
		case MAIN_HAND: return inv.field_7545;
		case ARMOR_BOOTS: return class_1304.field_6166.method_5927() + inv.field_7547.size();
		case ARMOR_CHESTPLATE: return class_1304.field_6174.method_5927() + inv.field_7547.size();
		case ARMOR_HELMET: return class_1304.field_6169.method_5927() + inv.field_7547.size();
		case ARMOR_LEGGINGS: return class_1304.field_6172.method_5927() + inv.field_7547.size();
		case OFF_HAND: return inv.field_7547.size() + inv.field_7548.size();
		default: throw new IllegalArgumentException("Unexpected value: " + slot);
		}
	}
}

package com.tom.cpm.mixin;

import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2484;
import net.minecraft.class_2631;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_607;
import net.minecraft.class_824;
import net.minecraft.class_827;
import net.minecraft.class_836;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.mojang.authlib.GameProfile;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.shared.model.TextureSheetType;

@Mixin(class_836.class)
public abstract class SkullTileEntityRendererMixin extends class_827<class_2631> {
	public SkullTileEntityRendererMixin(class_824 p_i226006_1_) {
		super(p_i226006_1_);
	}

	@Shadow private static @Final Map<class_2484.class_2485, class_607> MODEL_BY_TYPE;

	@Redirect(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/RenderType;entityTranslucent("
					+ "Lnet/minecraft/util/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"
			),
			method = "getRenderType(Lnet/minecraft/block/SkullBlock$ISkullType;Lcom/mojang/authlib/GameProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;")
	private static class_1921 onGetRenderType(class_2960 resLoc, class_2484.class_2485 skullType, GameProfile gameProfileIn) {
		class_607 model = MODEL_BY_TYPE.get(skullType);
		ModelTexture mt = new ModelTexture(resLoc);
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.SKIN);
		return mt.getRenderType();
	}

	@Redirect(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/RenderType;entityCutoutNoCull("
					+ "Lnet/minecraft/util/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;",
					ordinal = 0
			),
			method = "getRenderType(Lnet/minecraft/block/SkullBlock$ISkullType;Lcom/mojang/authlib/GameProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;")
	private static class_1921 onGetRenderTypeNoSkin(class_2960 resLoc, class_2484.class_2485 skullType, GameProfile gameProfileIn) {
		class_607 model = MODEL_BY_TYPE.get(skullType);
		ModelTexture mt = new ModelTexture(resLoc);
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.SKIN);
		return mt.getRenderType();
	}

	@Inject(at = @At("HEAD"),
			method = "renderSkull(Lnet/minecraft/util/Direction;FLnet/minecraft/block/SkullBlock$ISkullType;"
					+ "Lcom/mojang/authlib/GameProfile;FLcom/mojang/blaze3d/matrix/MatrixStack;"
					+ "Lnet/minecraft/client/renderer/IRenderTypeBuffer;I)V")
	private static void onRenderPre(class_2350 directionIn, float p_228879_1_, class_2484.class_2485 skullType, GameProfile gameProfileIn, float animationProgress, class_4587 matrixStackIn, class_4597 buffer, int combinedLight, CallbackInfo cbi) {
		if (skullType == class_2484.class_2486.field_11510 && gameProfileIn != null) {
			class_607 model = MODEL_BY_TYPE.get(skullType);
			CustomPlayerModelsClient.INSTANCE.renderSkull(model, gameProfileIn, buffer);
		}
	}

	@Inject(at = @At("RETURN"),
			method = "renderSkull(Lnet/minecraft/util/Direction;FLnet/minecraft/block/SkullBlock$ISkullType;"
					+ "Lcom/mojang/authlib/GameProfile;FLcom/mojang/blaze3d/matrix/MatrixStack;"
					+ "Lnet/minecraft/client/renderer/IRenderTypeBuffer;I)V")
	private static void onRenderPost(class_2350 directionIn, float p_228879_1_, class_2484.class_2485 skullType, GameProfile gameProfileIn, float animationProgress, class_4587 matrixStackIn, class_4597 buffer, int combinedLight, CallbackInfo cbi) {
		if (skullType == class_2484.class_2486.field_11510 && gameProfileIn != null) {
			class_607 model = MODEL_BY_TYPE.get(skullType);
			CustomPlayerModelsClient.INSTANCE.renderSkullPost(buffer, model);
		}
	}
}

package com.tom.cpm.mixin.of;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_742;
import net.optifine.player.PlayerItemModel;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.shared.model.TextureSheetType;

@Mixin(PlayerItemModel.class)
public class PlayerItemModelMixin_OF {

	@Redirect(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/entity/player/AbstractClientPlayerEntity;"
					+ "getSkinTextureLocation()Lnet/minecraft/util/ResourceLocation;"
			), method = "render(Lnet/minecraft/client/renderer/entity/model/BipedModel;"
					+ "Lnet/minecraft/client/entity/player/AbstractClientPlayerEntity;"
					+ "Lcom/mojang/blaze3d/matrix/MatrixStack;Lnet/minecraft/client/renderer/IRenderTypeBuffer;II)V")
	public class_2960 getPlayerSkin(class_742 pe, class_572 modelBiped, class_742 player, class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, int packedOverlayIn) {
		ModelTexture mt = new ModelTexture(player.method_3117());
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(modelBiped, mt, TextureSheetType.SKIN);
		return mt.getTexture();
	}
}

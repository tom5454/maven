package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.PlayerRenderManager;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;

@Mixin(class_970.class)
public abstract class ArmorLayerMixin extends class_3887<class_1309, class_572<class_1309>> {

	public ArmorLayerMixin(class_3883<class_1309, class_572<class_1309>> p_i50926_1_) {
		super(p_i50926_1_);
	}

	private @Final @Shadow class_572<class_1309> innerModel;
	private @Final @Shadow class_572<class_1309> outerModel;

	@Inject(at = @At("HEAD"),
			method = "render(Lcom/mojang/blaze3d/matrix/MatrixStack;Lnet/minecraft/client/renderer/IRenderTypeBuffer;I"
					+ "Lnet/minecraft/entity/LivingEntity;FFFFFF)V")
	public void preRender(class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, class_1309 entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo cbi) {
		if(method_17165() instanceof class_572) {
			CustomPlayerModelsClient.INSTANCE.renderArmor(outerModel, innerModel, method_17165());
		}
	}

	@Inject(at = @At("RETURN"),
			method = "render(Lcom/mojang/blaze3d/matrix/MatrixStack;Lnet/minecraft/client/renderer/IRenderTypeBuffer;I"
					+ "Lnet/minecraft/entity/LivingEntity;FFFFFF)V")
	public void postRender(class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, class_1309 entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbind(outerModel);
		CustomPlayerModelsClient.INSTANCE.manager.unbind(innerModel);
	}

	@Inject(at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/entity/layers/ArmorLayer;usesInnerModel(Lnet/minecraft/inventory/EquipmentSlotType;)Z"),
			method = "renderArmorPiece(Lcom/mojang/blaze3d/matrix/MatrixStack;Lnet/minecraft/client/renderer/IRenderTypeBuffer;"
					+ "Lnet/minecraft/entity/LivingEntity;FFFFFFLnet/minecraft/inventory/EquipmentSlotType;I)V",
					locals = LocalCapture.CAPTURE_FAILHARD)
	private void setupModel(class_4587 matrixStackIn, class_4597 bufferIn, class_1309 entityLivingBaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, class_1304 slotIn, int packedLightIn, CallbackInfo cbi, class_1799 itemstack, class_1738 armoritem, class_572<class_1309> armor) {
		class_572<class_1309> model = method_17165();
		PlayerRenderManager m = CustomPlayerModelsClient.mc.getPlayerRenderManager();
		m.copyModelForArmor(model.field_3391, armor.field_3391);
		m.copyModelForArmor(model.field_3398, armor.field_3398);
		m.copyModelForArmor(model.field_3390, armor.field_3390);
		m.copyModelForArmor(model.field_3397, armor.field_3397);
		m.copyModelForArmor(model.field_3401, armor.field_3401);
		m.copyModelForArmor(model.field_3392, armor.field_3392);
	}
}

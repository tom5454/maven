package com.tom.cpm.client;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.function.BooleanSupplier;
import net.minecraft.class_1068;
import net.minecraft.class_1071.class_1072;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1770;
import net.minecraft.class_1799;
import net.minecraft.class_2190;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4050;
import net.minecraft.class_591;
import net.minecraft.class_634;
import net.minecraft.class_640;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.minecraft.MinecraftProfileTexture;
import com.mojang.authlib.minecraft.MinecraftProfileTexture.Type;
import com.mojang.blaze3d.systems.RenderSystem;

import com.tom.cpl.block.entity.ActiveEffect;
import com.tom.cpl.math.MathHelper;
import com.tom.cpl.util.Hand;
import com.tom.cpl.util.HandAnimation;
import com.tom.cpm.common.EntityTypeHandlerImpl;
import com.tom.cpm.common.PlayerInventory;
import com.tom.cpm.common.WorldImpl;
import com.tom.cpm.shared.animation.AnimationState;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.model.SkinType;
import com.tom.cpm.shared.model.render.PlayerModelSetup.ArmPose;
import com.tom.cpm.shared.skin.PlayerTextureLoader;

public class PlayerProfile extends Player<class_1657> {
	public static boolean inGui;
	public static BooleanSupplier inFirstPerson;
	static {
		inFirstPerson = () -> false;
		Platform.initPlayerProfile();
	}

	private final GameProfile profile;
	private String skinType;

	public static GameProfile getPlayerProfile(class_1657 player) {
		if (player == null)return null;
		GameProfile profile = player.method_7334();
		if (profile.getProperties().isEmpty()) {
			class_634 conn = class_310.method_1551().method_1562();
			if (conn != null) {
				class_640 info = conn.method_2871(profile.getId());
				if(info != null)profile = info.method_2966();
			}
		}
		return profile;
	}

	public PlayerProfile(GameProfile profile) {
		this.profile = new GameProfile(profile.getId(), profile.getName());
		cloneProperties(profile.getProperties(), this.profile.getProperties());

		if(profile.getId() != null)
			this.skinType = class_1068.method_4647(profile.getId());
	}

	@Override
	public SkinType getSkinType() {
		return SkinType.get(skinType);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((profile == null) ? 0 : profile.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) return true;
		if (obj == null) return false;
		if (getClass() != obj.getClass()) return false;
		PlayerProfile other = (PlayerProfile) obj;
		if (profile == null) {
			if (other.profile != null) return false;
		} else if (!profile.equals(other.profile)) return false;
		return true;
	}

	@Override
	public UUID getUUID() {
		return profile.getId();
	}

	@Override
	public void updateFromPlayer(AnimationState animState, class_1657 player) {
		class_4050 p = player.method_18376();
		animState.resetPlayer();
		switch (p) {
		case field_18077:
			animState.elytraFlying = true;
			break;
		case field_18078:
			animState.sleeping = true;
			break;
		case field_18080:
			animState.tridentSpin = true;
			break;
		default:
			break;
		}
		animState.sneaking = player.method_18276();
		animState.crawling = player.method_20448();
		animState.swimming = player.method_20232();
		if(!player.method_5805())animState.dying = true;
		if(Platform.isSitting(player))animState.riding = true;
		if(player.method_5624())animState.sprinting = true;
		if(player.method_6115()) {
			animState.usingAnimation = HandAnimation.of(player.method_6030().method_7976());
		}
		if(player.method_5799())animState.retroSwimming = true;
		animState.moveAmountX = (float) (player.method_23317() - player.field_6014);
		animState.moveAmountY = (float) (player.method_23318() - player.field_6036);
		animState.moveAmountZ = (float) (player.method_23321() - player.field_5969);
		animState.yaw = player.field_6031;
		animState.pitch = player.field_5965;
		animState.bodyYaw = player.field_6283;

		animState.encodedState = MinecraftObject.LAYER_CODEC.getValue(player::method_7348);

		class_1799 is = player.method_6118(class_1304.field_6169);
		animState.hasSkullOnHead = is.method_7909() instanceof class_1747 && ((class_1747)is.method_7909()).method_7711() instanceof class_2190;
		animState.wearingHelm = !is.method_7960();
		is = player.method_6118(class_1304.field_6174);
		animState.wearingElytra = is.method_7909() instanceof class_1770;
		animState.wearingBody = !is.method_7960();
		animState.wearingLegs = !player.method_6118(class_1304.field_6172).method_7960();
		animState.wearingBoots = !player.method_6118(class_1304.field_6166).method_7960();
		animState.mainHand = Hand.of(player.method_6068());
		animState.activeHand = Hand.of(animState.mainHand, player.method_6058());
		animState.swingingHand = Hand.of(animState.mainHand, player.field_6266);
		animState.hurtTime = player.field_6235;
		animState.isOnLadder = player.method_6101();
		animState.isBurning = player.method_5862();
		animState.inGui = inGui;
		animState.firstPersonMod = inFirstPerson.getAsBoolean();
		PlayerInventory.setInv(animState, player.field_7514);
		WorldImpl.setWorld(animState, player);
		if (player.method_5854() != null)animState.vehicle = EntityTypeHandlerImpl.impl.wrap(player.method_5854().method_5864());
		player.method_6026().forEach(e -> animState.allEffects.add(new ActiveEffect(class_2378.field_11159.method_10221(e.method_5579()).toString(), e.method_5578(), e.method_5584(), !e.method_5581())));

		if(player.method_6030().method_7909() instanceof class_1764) {
			float f = class_1764.method_7775(player.method_6030());
			float f1 = MathHelper.clamp(player.method_6048(), 0.0F, f);
			animState.crossbowPullback = f1 / f;
		}

		if(player.method_6030().method_7909() instanceof class_1753) {
			float f = 20F;
			float f1 = MathHelper.clamp(player.method_6048(), 0.0F, f);
			animState.bowPullback = f1 / f;
		}

		animState.parrotLeft = !player.method_7356().method_10558("id").isEmpty();
		animState.parrotRight = !player.method_7308().method_10558("id").isEmpty();
	}

	@Override
	public void updateFromModel(AnimationState animState, Object model) {
		if(model instanceof class_591) {
			class_591 m = (class_591) model;
			animState.resetModel();
			animState.attackTime = m.field_3447;
			animState.swimAmount = m.field_3396;
			animState.leftArm = ArmPose.of(m.field_3399);
			animState.rightArm = ArmPose.of(m.field_3395);
		}
	}

	@Override
	protected PlayerTextureLoader initTextures() {
		return new PlayerTextureLoader(class_310.method_1551().method_1582().field_5305) {

			@Override
			protected CompletableFuture<Void> load0() {
				Map<Type, MinecraftProfileTexture> map = class_310.method_1551().method_1582().method_4654(profile);
				defineAll(map, MinecraftProfileTexture::getUrl, MinecraftProfileTexture::getHash);
				if (map.containsKey(Type.SKIN)) {
					MinecraftProfileTexture tex = map.get(Type.SKIN);
					skinType = tex.getMetadata("model");

					if (skinType == null) {
						skinType = "default";
					}
					return CompletableFuture.completedFuture(null);
				}
				CompletableFuture<Void> cf = new CompletableFuture<>();
				class_310.method_1551().method_1582().method_4652(profile, new class_1072() {

					@Override
					public void onSkinTextureAvailable(Type typeIn, class_2960 location, MinecraftProfileTexture profileTexture) {
						defineTexture(typeIn, profileTexture.getUrl(), profileTexture.getHash());
						switch (typeIn) {
						case SKIN:
							skinType = profileTexture.getMetadata("model");

							if (skinType == null) {
								skinType = "default";
							}
							RenderSystem.recordRenderCall(() -> cf.complete(null));
							break;

						default:
							break;
						}
					}
				}, true);
				return cf;
			}
		};
	}

	@Override
	public String getName() {
		return profile.getName();
	}

	@Override
	public Object getGameProfile() {
		return profile;
	}
}

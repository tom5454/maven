package com.tom.cpm.client;

import java.util.OptionalDouble;
import net.minecraft.class_1921;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4668;

public class CustomRenderTypes extends class_1921 {
	public static final class_1921 LINES_NO_NEPTH = method_24048("cpm:lines_no_depth", class_290.field_1576, 1, 256, class_1921.class_4688.method_23598().method_23609(new class_4668.class_4677(OptionalDouble.empty())).method_23607(field_21354).method_23615(field_21370).method_23604(field_21346).method_23616(field_21349).method_23617(false));
	public static final class_1921 ENTITY_COLOR = method_23580(Platform.WHITE);
	public static final class_1921 ENTITY_COLOR_EYES = method_23026(Platform.WHITE);

	public CustomRenderTypes(String nameIn, class_293 formatIn, int drawModeIn, int bufferSizeIn,
			boolean useDelegateIn, boolean needsSortingIn, Runnable setupTaskIn, Runnable clearTaskIn) {
		super(nameIn, formatIn, drawModeIn, bufferSizeIn, useDelegateIn, needsSortingIn, setupTaskIn, clearTaskIn);
	}

	public static class_1921 linesNoDepth() {
		return LINES_NO_NEPTH;
	}

	public static class_1921 entityColorTranslucent() {
		return ENTITY_COLOR;
	}

	public static class_1921 entityColorEyes() {
		return ENTITY_COLOR_EYES;
	}
}

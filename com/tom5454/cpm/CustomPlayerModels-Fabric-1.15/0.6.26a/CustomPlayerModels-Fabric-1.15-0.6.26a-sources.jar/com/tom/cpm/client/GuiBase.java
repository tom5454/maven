package com.tom.cpm.client;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL11;
import net.minecraft.class_1074;
import net.minecraft.class_155;
import net.minecraft.class_156;
import net.minecraft.class_1659;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2585;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_342;
import net.minecraft.class_408;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.client.ClientBrandRetriever;
import com.mojang.blaze3d.systems.RenderSystem;

import com.tom.cpl.gui.Frame;
import com.tom.cpl.gui.IGui;
import com.tom.cpl.gui.KeyCodes;
import com.tom.cpl.gui.KeyboardEvent;
import com.tom.cpl.gui.MouseEvent;
import com.tom.cpl.gui.NativeGuiComponents;
import com.tom.cpl.gui.NativeGuiComponents.NativeConstructor;
import com.tom.cpl.gui.UIColors;
import com.tom.cpl.gui.elements.FileChooserPopup;
import com.tom.cpl.gui.elements.TextField;
import com.tom.cpl.gui.elements.TextField.ITextField;
import com.tom.cpl.item.Stack;
import com.tom.cpl.math.Box;
import com.tom.cpl.math.Vec2i;
import com.tom.cpl.text.IText;
import com.tom.cpm.client.MinecraftObject.DynTexture;
import com.tom.cpm.common.ItemStackHandlerImpl;
import com.tom.cpm.shared.MinecraftCommonAccess;
import com.tom.cpm.shared.gui.panel.Panel3d;

public class GuiBase extends class_437 implements IGui {
	protected static final KeyCodes CODES = new GLFWKeyCodes();
	protected static final NativeGuiComponents nativeComponents = new NativeGuiComponents();
	protected Frame gui;
	protected class_437 parent;
	protected CtxStack stack;
	protected UIColors colors;
	protected Consumer<Runnable> closeListener;
	protected int keyModif;
	protected boolean noScissorTest;
	protected int vanillaScale = -1;

	static {
		nativeComponents.register(TextField.class, local(GuiBase::createTextField));
		nativeComponents.register(FileChooserPopup.class, TinyFDChooser::new);
		nativeComponents.register(Panel3d.class, Panel3dImpl::new);
	}

	public GuiBase(Function<IGui, Frame> creator, class_437 parent) {
		super(new class_2585(""));
		this.colors = new UIColors();
		this.parent = parent;
		try {
			this.gui = creator.apply(this);
		} catch (Throwable e) {
			onGuiException("Error creating gui", e, true);
		}
		noScissorTest = isCtrlDown();
	}

	private static <G extends Supplier<IGui>, N> NativeConstructor<G, N> local(Function<GuiBase, N> fac) {
		return f -> fac.apply((GuiBase) f.get());
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void render(int mouseX, int mouseY, float partialTicks) {
		renderBackground(0);
		try {
			RenderSystem.pushMatrix();
			RenderSystem.translated(0, 0, 500);
			GL11.glEnable(GL11.GL_SCISSOR_TEST);
			stack = new CtxStack(width, height);
			gui.draw(mouseX, mouseY, partialTicks);
		} catch (Throwable e) {
			onGuiException("Error drawing gui", e, true);
		} finally {
			if(!noScissorTest)
				GL11.glDisable(GL11.GL_SCISSOR_TEST);
			String modVer = MinecraftCommonAccess.get().getModVersion();
			String s = "Minecraft " + class_155.method_16673().getName() + " (" + minecraft.method_1515() + "/" + ClientBrandRetriever.getClientModName() + ("release".equalsIgnoreCase(minecraft.method_1547()) ? "" : "/" + minecraft.method_1547()) + ") " + modVer;
			font.method_1729(s, width - font.method_1727(s) - 4, 2, 0xff000000);
			s = minecraft.field_1770;
			if(noScissorTest)s += " No Scissor";
			font.method_1729(s, width - font.method_1727(s) - 4, 11, 0xff000000);
			RenderSystem.popMatrix();
		}
	}

	@Override
	public void removed() {
		this.minecraft.field_1774.method_1462(false);
		if(vanillaScale >= 0 && vanillaScale != minecraft.field_1690.field_1868) {
			minecraft.field_1690.field_1868 = vanillaScale;
			vanillaScale = -999;
			minecraft.method_15993();
		}
	}

	@Override
	public void onClose() {
		class_437 p = parent;
		parent = null;
		minecraft.method_1507(p);
	}

	@Override
	public void drawBox(int x, int y, int w, int h, int color) {
		x += getOffset().x;
		y += getOffset().y;
		fill(x, y, x+w, y+h, color);
	}

	@Override
	public void drawBox(float x, float y, float w, float h, int color) {
		x += getOffset().x;
		y += getOffset().y;

		float minX = x;
		float minY = y;
		float maxX = x+w;
		float maxY = y+h;

		if (minX < maxX) {
			float i = minX;
			minX = maxX;
			maxX = i;
		}

		if (minY < maxY) {
			float j = minY;
			minY = maxY;
			maxY = j;
		}
		float f3 = (color >> 24 & 255) / 255.0F;
		float f = (color >> 16 & 255) / 255.0F;
		float f1 = (color >> 8 & 255) / 255.0F;
		float f2 = (color & 255) / 255.0F;
		class_287 bufferbuilder = class_289.method_1348().method_1349();
		RenderSystem.enableBlend();
		RenderSystem.disableTexture();
		RenderSystem.defaultBlendFunc();
		bufferbuilder.method_1328(7, class_290.field_1576);
		bufferbuilder.method_22912(minX, maxY, 0.0F).method_22915(f, f1, f2, f3).method_1344();
		bufferbuilder.method_22912(maxX, maxY, 0.0F).method_22915(f, f1, f2, f3).method_1344();
		bufferbuilder.method_22912(maxX, minY, 0.0F).method_22915(f, f1, f2, f3).method_1344();
		bufferbuilder.method_22912(minX, minY, 0.0F).method_22915(f, f1, f2, f3).method_1344();
		bufferbuilder.method_1326();
		class_286.method_1309(bufferbuilder);
		RenderSystem.enableTexture();
		RenderSystem.disableBlend();
	}

	@Override
	protected void init() {
		this.minecraft.field_1774.method_1462(true);
		try {
			gui.init(width, height);
		} catch (Throwable e) {
			onGuiException("Error in init gui", e, true);
		}
	}
	@Override
	public void drawText(int x, int y, String text, int color) {
		x += getOffset().x;
		y += getOffset().y;
		RenderSystem.pushMatrix();
		RenderSystem.translatef(0, 0, 50);
		font.method_1729(text, x, y, color);
		RenderSystem.popMatrix();
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		try {
			this.keyModif = modifiers;
			KeyboardEvent evt = new KeyboardEvent(keyCode, scanCode, (char) -1, GLFW.glfwGetKeyName(keyCode, scanCode));
			gui.keyPressed(evt);
			if(!evt.isConsumed() && gui.enableChat()) {
				if(gui.enableChat() && minecraft.field_1724 != null && minecraft.field_1690.field_1890.method_1417(keyCode, scanCode) && minecraft.field_1690.field_1877 != class_1659.field_7536) {
					RenderSystem.recordRenderCall(() -> {
						int scale = vanillaScale;
						vanillaScale = -1;
						minecraft.method_1507(new Overlay());
						vanillaScale = scale;
					});
					return true;
				}
			}
			return true;
		} catch (Throwable e) {
			onGuiException("Error processing key event", e, false);
			return true;
		}
	}

	@Override
	public boolean charTyped(char codePoint, int modifiers) {
		try {
			this.keyModif = modifiers;
			KeyboardEvent evt = new KeyboardEvent(-1, -1, codePoint, null);
			gui.keyPressed(evt);
			return evt.isConsumed();
		} catch (Throwable e) {
			onGuiException("Error processing key event", e, false);
			return true;
		}
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		try {
			MouseEvent evt = new MouseEvent((int) mouseX, (int) mouseY, button);
			gui.mouseClick(evt);
			return evt.isConsumed();
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
			return true;
		}
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
		try {
			MouseEvent evt = new MouseEvent((int) mouseX, (int) mouseY, button);
			gui.mouseDrag(evt);
			return evt.isConsumed();
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
			return true;
		}
	}

	@Override
	public boolean mouseReleased(double mouseX, double mouseY, int button) {
		try {
			MouseEvent evt = new MouseEvent((int) mouseX, (int) mouseY, button);
			gui.mouseRelease(evt);
			return evt.isConsumed();
		} catch (Throwable e) {
			onGuiException("Error processing mouse event", e, false);
			return true;
		}
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
		if(delta != 0) {
			try {
				MouseEvent evt = new MouseEvent((int) mouseX, (int) mouseY, (int) delta);
				gui.mouseWheel(evt);
				return evt.isConsumed();
			} catch (Throwable e) {
				onGuiException("Error processing mouse event", e, false);
				return true;
			}
		}
		return false;
	}

	@Override
	public void displayError(String e) {
		class_437 p = parent;
		parent = null;
		class_310.method_1551().method_1507(new CrashScreen(e, p));
	}

	private static class CrashScreen extends class_437 {
		private String error;
		private class_437 parent;

		public CrashScreen(String error, class_437 p) {
			super(new class_2585("Error"));
			this.error = error;
			parent = p;
		}

		@Override
		public void render(int mouseX, int mouseY, float partialTicks) {
			this.renderBackground();
			String[] txt = IGui.wordWrap(class_1074.method_4662("error.cpm.crash", error), width - 200, font::method_1727).split("\\\\");
			for (int i = 0; i < txt.length; i++) {
				drawCenteredString(this.font, txt[i], this.width / 2, 15 + i * 10, 16777215);
			}
			super.render(mouseX, mouseY, partialTicks);
		}

		@Override
		protected void init() {
			super.init();
			this.addButton(new class_4185(this.width / 2 - 100, 140, 200, 20, class_1074.method_4662("gui.back"), (p_213034_1_) -> {
				this.minecraft.method_1507((class_437)null);
			}));
		}

		@Override
		public void onClose() {
			if(parent != null) {
				class_437 p = parent;
				parent = null;
				minecraft.method_1507(p);
			}
		}
	}

	@Override
	public void closeGui() {
		if(closeListener != null) {
			closeListener.accept(this::onClose);
		} else
			onClose();
	}

	@Override
	public void drawTexture(int x, int y, int w, int h, int u, int v, String texture) {
		minecraft.method_1531().method_22813(new class_2960("cpm", "textures/gui/" + texture + ".png"));
		x += getOffset().x;
		y += getOffset().y;
		RenderSystem.color4f(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		blit(x, y, u, v, w, h);
		RenderSystem.disableBlend();
	}

	@Override
	public void drawTexture(int x, int y, int w, int h, int u, int v, String texture, int color) {
		minecraft.method_1531().method_22813(new class_2960("cpm", "textures/gui/" + texture + ".png"));
		x += getOffset().x;
		y += getOffset().y;
		float a = (color >> 24 & 255) / 255.0F;
		float r = (color >> 16 & 255) / 255.0F;
		float g = (color >> 8 & 255) / 255.0F;
		float b = (color & 255) / 255.0F;
		RenderSystem.color4f(r, g, b, a);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		blit(x, y, u, v, w, h);
		RenderSystem.disableBlend();
	}

	@Override
	public void drawTexture(int x, int y, int width, int height, float u1, float v1, float u2, float v2) {
		x += getOffset().x;
		y += getOffset().y;
		RenderSystem.color4f(1, 1, 1, 1);
		minecraft.method_1531().method_22813(DynTexture.getBoundLoc());
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		class_289 tessellator = class_289.method_1348();
		class_287 bufferbuilder = tessellator.method_1349();
		bufferbuilder.method_1328(7, class_290.field_1585);
		float bo = getBlitOffset();
		bufferbuilder.method_22912(x, y + height, bo).method_22913(u1, v2).method_1344();
		bufferbuilder.method_22912(x + width, y + height, bo).method_22913(u2, v2).method_1344();
		bufferbuilder.method_22912(x + width, y, bo).method_22913(u2, v1).method_1344();
		bufferbuilder.method_22912(x, y, bo).method_22913(u1, v1).method_1344();
		bufferbuilder.method_1326();
		RenderSystem.enableAlphaTest();
		class_286.method_1309(bufferbuilder);
		RenderSystem.disableBlend();
	}

	@Override
	public String i18nFormat(String key, Object... obj) {
		return class_1074.method_4662(key, obj);
	}

	@Override
	public void setupCut() {
		if(!noScissorTest) {
			int dw = minecraft.method_22683().method_4489();
			int dh = minecraft.method_22683().method_4506();
			float multiplierX = dw / (float)width;
			float multiplierY = dh / (float)height;
			Box box = getContext().cutBox;
			GL11.glScissor((int) (box.x * multiplierX), dh - (int) ((box.y + box.h) * multiplierY),
					(int) (box.w * multiplierX), (int) (box.h * multiplierY));
		}
	}

	@Override
	public int textWidth(String text) {
		return font.method_1727(text);
	}

	private ITextField createTextField() {
		return new TxtField();
	}

	private class TxtField implements ITextField, Consumer<String> {
		private class_342 field;
		private Runnable eventListener;
		private Vec2i currentOff = new Vec2i(0, 0);
		private Box bounds = new Box(0, 0, 0, 0);
		private boolean settingText, updateField, enabled;
		public TxtField() {
			this.field = new class_342(font, 0, 0, 0, 0, class_1074.method_4662("narrator.cpm.field"));
			this.field.method_1880(1024*1024);
			this.field.method_1858(false);
			this.field.method_1862(true);
			this.field.method_1868(colors.label_text_color);
			this.field.method_1863(this);
			this.enabled = true;
		}

		@Override
		public void draw(int mouseX, int mouseY, float partialTicks, Box bounds) {
			Vec2i off = getOffset();
			field.x = bounds.x + off.x + 4;
			field.y = bounds.y + off.y + 6;
			currentOff.x = off.x;
			currentOff.y = off.y;
			this.bounds.x = bounds.x;
			this.bounds.y = bounds.y;
			this.bounds.w = bounds.w;
			this.bounds.h = bounds.h;
			field.setWidth(bounds.w - 5);
			Platform.setHeight(field, bounds.h - 12);
			if(updateField) {
				settingText = true;
				field.method_1872();
				settingText = false;
				updateField = false;
			}
			field.render(mouseX, mouseY, partialTicks);
		}

		@Override
		public void keyPressed(KeyboardEvent evt) {
			if(evt.isConsumed())return;
			if(evt.keyCode == -1) {
				if(field.charTyped(evt.charTyped, keyModif))
					evt.consume();
			} else {
				if(field.keyPressed(evt.keyCode, evt.scancode, keyModif) || field.method_20315())
					evt.consume();
			}
		}

		@Override
		public void mouseClick(MouseEvent evt) {
			if(evt.isConsumed()) {
				field.mouseClicked(Integer.MIN_VALUE, Integer.MIN_VALUE, evt.btn);
				return;
			}
			field.x = bounds.x + currentOff.x;
			field.y = bounds.y + currentOff.y;
			field.setWidth(bounds.w);
			Platform.setHeight(field, bounds.h);
			if(field.mouseClicked(evt.x + currentOff.x, evt.y + currentOff.y, evt.btn))
				evt.consume();
		}

		@Override
		public String getText() {
			return field.method_1882();
		}

		@Override
		public void setText(String txt) {
			this.settingText = true;
			field.method_1852(txt);
			this.settingText = false;
			this.updateField = true;
		}

		@Override
		public void setEventListener(Runnable eventListener) {
			this.eventListener = eventListener;
		}

		@Override
		public void accept(String value) {
			if(eventListener != null && !settingText && enabled)eventListener.run();
		}

		@Override
		public void setEnabled(boolean enabled) {
			field.method_1888(enabled);
			this.enabled = enabled;
		}

		@Override
		public boolean isFocused() {
			return field.isFocused();
		}

		@Override
		public void setFocused(boolean focused) {
			field.method_1876(focused);
		}

		@Override
		public int getCursorPos() {
			return field.method_1881();
		}

		@Override
		public void setCursorPos(int pos) {
			field.method_1875(pos);
		}

		@Override
		public void setSelectionPos(int pos) {
			field.method_1884(pos);
		}

		@Override
		public int getSelectionPos() {
			return field.field_2101;
		}
	}

	@Override
	public UIColors getColors() {
		return colors;
	}

	@Override
	public void setCloseListener(Consumer<Runnable> listener) {
		this.closeListener = listener;
	}

	@Override
	public boolean isShiftDown() {
		return hasShiftDown();
	}

	@Override
	public boolean isCtrlDown() {
		return hasControlDown();
	}

	@Override
	public boolean isAltDown() {
		return hasAltDown();
	}

	public class Overlay extends class_408 {

		public Overlay() {
			super("");
		}

		@Override
		public void render(int mouseX, int mouseY, float partialTicks) {
			RenderSystem.pushMatrix();
			RenderSystem.translatef(0, 0, -100);
			GuiBase.this.render(Integer.MIN_VALUE, Integer.MIN_VALUE, partialTicks);
			RenderSystem.popMatrix();
			RenderSystem.pushMatrix();
			RenderSystem.translatef(0, 0, 900);
			super.render(mouseX, mouseY, partialTicks);
			RenderSystem.popMatrix();
		}

		public class_437 getGui() {
			return GuiBase.this;
		}
	}

	@Override
	public KeyCodes getKeyCodes() {
		return CODES;
	}

	@Override
	public void drawGradientBox(int x, int y, int w, int h, int topLeft, int topRight, int bottomLeft,
			int bottomRight) {
		x += getOffset().x;
		y += getOffset().y;
		int left = x;
		int top = y;
		int right = x + w;
		int bottom = y + h;
		float atr = (topRight >> 24 & 255) / 255.0F;
		float rtr = (topRight >> 16 & 255) / 255.0F;
		float gtr = (topRight >> 8 & 255) / 255.0F;
		float btr = (topRight & 255) / 255.0F;
		float atl = (topLeft >> 24 & 255) / 255.0F;
		float rtl = (topLeft >> 16 & 255) / 255.0F;
		float gtl = (topLeft >> 8 & 255) / 255.0F;
		float btl = (topLeft & 255) / 255.0F;
		float abl = (bottomLeft >> 24 & 255) / 255.0F;
		float rbl = (bottomLeft >> 16 & 255) / 255.0F;
		float gbl = (bottomLeft >> 8 & 255) / 255.0F;
		float bbl = (bottomLeft & 255) / 255.0F;
		float abr = (bottomRight >> 24 & 255) / 255.0F;
		float rbr = (bottomRight >> 16 & 255) / 255.0F;
		float gbr = (bottomRight >> 8 & 255) / 255.0F;
		float bbr = (bottomRight & 255) / 255.0F;
		RenderSystem.disableTexture();
		RenderSystem.enableBlend();
		RenderSystem.disableAlphaTest();
		RenderSystem.defaultBlendFunc();
		RenderSystem.shadeModel(7425);
		class_289 tessellator = class_289.method_1348();
		class_287 bufferbuilder = tessellator.method_1349();
		bufferbuilder.method_1328(7, class_290.field_1576);
		bufferbuilder.method_22912(right, top, this.getBlitOffset()).method_22915(rtr, gtr, btr, atr).method_1344();
		bufferbuilder.method_22912(left, top, this.getBlitOffset()).method_22915(rtl, gtl, btl, atl).method_1344();
		bufferbuilder.method_22912(left, bottom, this.getBlitOffset()).method_22915(rbl, gbl, bbl, abl).method_1344();
		bufferbuilder.method_22912(right, bottom, this.getBlitOffset()).method_22915(rbr, gbr, bbr, abr).method_1344();
		tessellator.method_1350();
		RenderSystem.shadeModel(7424);
		RenderSystem.disableBlend();
		RenderSystem.enableAlphaTest();
		RenderSystem.enableTexture();
	}

	@Override
	public NativeGuiComponents getNative() {
		return nativeComponents;
	}

	@Override
	public void setClipboardText(String text) {
		minecraft.field_1774.method_1455(text);
	}

	@Override
	public Frame getFrame() {
		return gui;
	}

	@Override
	public String getClipboardText() {
		return minecraft.field_1774.method_1460();
	}

	@Override
	public void setScale(int value) {
		if(vanillaScale == -999)return;
		if(value != minecraft.field_1690.field_1868) {
			if(vanillaScale == -1)vanillaScale = minecraft.field_1690.field_1868;
			if(value == -1) {
				if(minecraft.field_1690.field_1868 != vanillaScale) {
					minecraft.field_1690.field_1868 = vanillaScale;
					vanillaScale = -1;
					minecraft.method_15993();
				}
			} else {
				minecraft.field_1690.field_1868 = value;
				minecraft.method_15993();
			}
		}
	}

	@Override
	public int getScale() {
		return minecraft.field_1690.field_1868;
	}

	@Override
	public int getMaxScale() {
		return minecraft.method_22683().method_4476(0, minecraft.method_1573()) + 1;
	}

	@Override
	public CtxStack getStack() {
		return stack;
	}

	@Override
	public void tick() {
		try {
			gui.tick();
		} catch (Throwable e) {
			onGuiException("Error in tick gui", e, true);
		}
	}

	@Override
	public void drawFormattedText(float x, float y, IText text, int color, float scale) {
		x += getOffset().x;
		y += getOffset().y;
		RenderSystem.pushMatrix();
		RenderSystem.translatef(x, y, 50);
		RenderSystem.scalef(scale, scale, scale);
		font.method_1729(text.<class_2561>remap().method_10863(), 0, 0, color);
		RenderSystem.popMatrix();
	}

	@Override
	public int textWidthFormatted(IText text) {
		return font.method_1727(text.<class_2561>remap().getString());
	}

	@Override
	public void openURL0(String url) {
		class_156.method_668().method_670(url);
	}

	public void onOpened() {
		vanillaScale = -1;
	}

	@Override
	public void drawStack(int x, int y, Stack stack) {
		x += getOffset().x;
		y += getOffset().y;
		class_1799 s = ItemStackHandlerImpl.impl.unwrap(stack);
		this.itemRenderer.method_4026(this.minecraft.field_1724, s, x, y);
		this.itemRenderer.method_4022(font, s, x, y, null);
	}

	@Override
	public void drawStackTooltip(int mx, int my, Stack stack) {
		class_1799 s = ItemStackHandlerImpl.impl.unwrap(stack);
		renderTooltip(s, mx, my);
		RenderSystem.disableRescaleNormal();
	}
}

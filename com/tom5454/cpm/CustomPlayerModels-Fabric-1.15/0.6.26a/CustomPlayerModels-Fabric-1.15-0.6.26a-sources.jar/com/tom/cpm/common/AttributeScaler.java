package com.tom.cpm.common;

import java.util.Collections;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1322.class_1323;
import net.minecraft.class_1324;
import net.minecraft.class_1612;
import net.minecraft.class_3222;
import com.tom.cpm.shared.network.NetHandler.ScalerInterface;
import com.tom.cpm.shared.util.ScalingOptions;

public class AttributeScaler implements ScalerInterface<class_3222, List<class_1320>> {
	private static final UUID CPM_ATTR_UUID = UUID.fromString("24bba381-9615-4530-8fcf-4fc42393a4b5");

	@Override
	public void setScale(List<class_1320> key, class_3222 player, float value) {
		key.forEach(a -> {
			class_1324 ai = player.method_6127().method_6205(a);
			if (ai != null) {
				ai.method_6200(CPM_ATTR_UUID);
				if (Math.abs(value - 1) > 0.01f)
					ai.method_6197(new class_1322(CPM_ATTR_UUID, "cpm", value - 1, class_1323.field_6330).method_6187(false));
			}
		});
	}

	@Override
	public List<class_1320> toKey(ScalingOptions opt) {
		switch (opt) {
		case HEALTH: return Collections.singletonList(class_1612.field_7359);
		case ATTACK_DMG: return Collections.singletonList(class_1612.field_7363);
		case ATTACK_KNOCKBACK: return Collections.singletonList(class_1612.field_7361);
		case ATTACK_SPEED: return Collections.singletonList(class_1612.field_7356);
		case DEFENSE: return Collections.singletonList(class_1612.field_7358);
		case MOB_VISIBILITY: return Collections.singletonList(class_1612.field_7365);
		case MOTION: return Collections.singletonList(class_1612.field_7357);
		case KNOCKBACK_RESIST: return Collections.singletonList(class_1612.field_7360);
		case REACH: return PlatformCommon.getReachAttr();
		default: return null;
		}
	}

	@Override
	public String getMethodName() {
		return ATTRIBUTE;
	}
}

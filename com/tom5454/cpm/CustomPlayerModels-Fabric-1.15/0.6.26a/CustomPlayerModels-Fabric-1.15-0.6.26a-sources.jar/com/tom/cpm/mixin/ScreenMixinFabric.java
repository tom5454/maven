package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.IScreen;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_437;

@Mixin(class_437.class)
public abstract class ScreenMixinFabric implements IScreen {

	protected @Shadow abstract class_339 addButton(class_339 button);

	@Inject(method = "init(Lnet/minecraft/client/Minecraft;II)V", at = @At("TAIL"))
	private void afterInitScreen(class_310 client, int width, int height, CallbackInfo ci) {
		CustomPlayerModelsClient.guiInitPost((class_437) (Object) this);
	}

	@Override
	public void cpm$addWidget(class_339 w) {
		addButton(w);
	}
}

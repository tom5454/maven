package com.tom.cpm.common;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1959;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import com.tom.cpl.block.BiomeHandler;

public class BiomeHandlerImpl extends BiomeHandler<class_1959> {
	public static final BiomeHandlerImpl impl = new BiomeHandlerImpl();

	@Override
	public List<com.tom.cpl.block.Biome> listNativeEntries(String tag) {
		class_2960 rl = class_2960.method_12829(tag);
		class_1959 b = class_2378.field_11153.method_10223(rl);
		if (b != null)return Collections.singletonList(wrap(b));
		return Collections.emptyList();
	}

	@Override
	public List<String> listNativeTags() {
		return Collections.emptyList();
	}

	@Override
	public com.tom.cpl.block.Biome emptyObject() {
		return wrap(null);
	}

	@Override
	public boolean isInTag(String tag, class_1959 state) {
		return getBiomeId(state).equals(tag);
	}

	@Override
	public List<String> listTags(class_1959 state) {
		return Collections.emptyList();
	}

	@Override
	public List<com.tom.cpl.block.Biome> getAllElements() {
		return class_2378.field_11153.method_10220().map(this::wrap).collect(Collectors.toList());
	}

	@Override
	public boolean equals(class_1959 a, class_1959 b) {
		return a == b;
	}

	@Override
	public String getBiomeId(class_1959 state) {
		return class_2378.field_11153.method_10221(state).toString();
	}

	@Override
	public float getTemperature(class_1959 state) {
		return state.method_8712();
	}

	@Override
	public float getHumidity(class_1959 state) {
		return state.method_8715();
	}

	@Override
	public RainType getRainType(class_1959 state) {
		return RainType.get(state.method_8694().name());
	}

	@Override
	public boolean isAvailable() {
		return true;
	}
}

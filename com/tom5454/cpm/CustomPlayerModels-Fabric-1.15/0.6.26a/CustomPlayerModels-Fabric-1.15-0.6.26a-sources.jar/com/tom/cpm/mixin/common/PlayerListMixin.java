package com.tom.cpm.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.tom.cpm.common.ServerHandler;
import net.minecraft.class_2535;
import net.minecraft.class_2874;
import net.minecraft.class_3222;
import net.minecraft.class_3324;

@Mixin(class_3324.class)
public class PlayerListMixin {

	@Inject(at = @At("RETURN"), method = "placeNewPlayer(Lnet/minecraft/network/NetworkManager;Lnet/minecraft/entity/player/ServerPlayerEntity;)V")
	public void onOnPlayerConnect(class_2535 connection, class_3222 player, CallbackInfo cbi) {
		ServerHandler.onPlayerJoin(player);
	}

	@Inject(method = "respawn(Lnet/minecraft/entity/player/ServerPlayerEntity;Lnet/minecraft/world/dimension/DimensionType;Z)Lnet/minecraft/entity/player/ServerPlayerEntity;", at = @At("TAIL"))
	private void afterRespawn(class_3222 player, class_2874 dimension, boolean alive, CallbackInfoReturnable<class_3222> cir) {
		if(!alive)ServerHandler.netHandler.onRespawn(cir.getReturnValue());
	}
}

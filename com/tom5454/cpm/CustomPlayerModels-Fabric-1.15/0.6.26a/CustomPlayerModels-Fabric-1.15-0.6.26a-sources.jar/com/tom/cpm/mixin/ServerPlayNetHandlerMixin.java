package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpl.util.NettyByteBufInputStream;
import com.tom.cpm.client.Platform;
import com.tom.cpm.common.ServerHandler;
import com.tom.cpm.shared.MinecraftObjectHolder;
import com.tom.cpm.shared.config.PlayerData;
import com.tom.cpm.shared.network.NetH.ServerNetH;
import net.minecraft.class_2817;
import net.minecraft.class_3244;

@Mixin(class_3244.class)
public class ServerPlayNetHandlerMixin implements ServerNetH {
	private boolean cpm$hasMod;
	private PlayerData cpm$data;

	@Override
	public boolean cpm$hasMod() {
		return cpm$hasMod;
	}

	@Override
	public void cpm$setHasMod(boolean v) {
		this.cpm$hasMod = v;
	}

	@Inject(at = @At("HEAD"), method = "handleCustomPayload(Lnet/minecraft/network/play/client/CCustomPayloadPacket;)V", cancellable = true)
	public void onProcessCustomPayload(class_2817 packet, CallbackInfo cbi) {
		if(Platform.getName(packet).method_12836().equals(MinecraftObjectHolder.NETWORK_ID)) {
			ServerHandler.netHandler.receiveServer(Platform.getName(packet), new NettyByteBufInputStream(Platform.getData(packet)), this);
			cbi.cancel();
		}
	}

	@Override
	public PlayerData cpm$getEncodedModelData() {
		return cpm$data;
	}

	@Override
	public void cpm$setEncodedModelData(PlayerData data) {
		cpm$data = data;
	}
}

package com.tom.cpm.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.common.ServerHandler;
import net.minecraft.class_1657;

@Mixin(class_1657.class)
public class PlayerEntityMixin {

	@Inject(at = @At("HEAD"), method = "jumpFromGround()V")
	public void onJump(CallbackInfo cbi) {
		ServerHandler.jump(this);
	}
}

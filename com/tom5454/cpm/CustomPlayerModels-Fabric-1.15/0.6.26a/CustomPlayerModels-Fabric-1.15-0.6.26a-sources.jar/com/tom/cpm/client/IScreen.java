package com.tom.cpm.client;

import net.minecraft.class_339;

public interface IScreen {
	void cpm$addWidget(class_339 w);
}

package com.tom.cpm;

import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_54;
import net.minecraft.class_57;
import com.tom.cpm.common.ServerNetworkImpl;

public interface SidedHandler {
	public void getTracking(class_54 player, Consumer<class_54> f);
	public Set<class_54> getTrackingPlayers(class_57 entity);
	public List<class_54> getPlayersOnline();
	public ServerNetworkImpl getServer(class_54 pl);
}

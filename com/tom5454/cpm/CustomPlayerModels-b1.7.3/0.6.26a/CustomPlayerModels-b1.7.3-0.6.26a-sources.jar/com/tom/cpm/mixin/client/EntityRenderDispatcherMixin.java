package com.tom.cpm.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import com.tom.cpm.client.RetroGL;
import net.minecraft.class_578;

@Mixin(class_578.class)
public class EntityRenderDispatcherMixin {

	@Redirect(at = @At(value = "INVOKE", target = "Lorg/lwjgl/opengl/GL11;glColor3f(FFF)V", remap = false), method = "method_1921(Lnet/minecraft/entity/Entity;F)V")
	public void onRenderC(float r, float g, float b) {
		RetroGL.lightColor3f(r, g, b);
	}
}

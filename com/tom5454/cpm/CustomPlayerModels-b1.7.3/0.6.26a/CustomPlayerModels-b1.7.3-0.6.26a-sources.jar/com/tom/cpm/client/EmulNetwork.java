package com.tom.cpm.client;

import net.minecraft.class_54;
import net.minecraft.class_57;
import net.minecraft.class_580;
import net.minecraft.client.Minecraft;
import net.modificationstation.stationapi.api.util.Identifier;

import com.tom.cpm.common.ServerHandler;
import com.tom.cpm.common.ServerNetworkImpl;
import com.tom.cpm.shared.config.PlayerData;
import com.tom.cpm.shared.io.FastByteArrayInputStream;

public class EmulNetwork {
	public static final ClientNetworkImpl emulClient = new EmulClient();
	public static final ServerNetworkImpl emulServer = new EmulServer();

	public static ClientNetworkImpl getClient(class_54 pl) {
		if (pl instanceof class_580) {
			return (ClientNetworkImpl) ((class_580) pl).field_2505;
		}
		return EmulNetwork.emulClient;
	}

	public static void reset() {
		emulServer.cpm$setEncodedModelData(null);
		emulServer.cpm$setHasMod(false);
		emulClient.cpm$setHasMod(false);
	}

	private static class EmulClient extends EmulNetwork implements ClientNetworkImpl {
		private boolean hasMod;

		@Override
		public boolean cpm$hasMod() {
			return hasMod;
		}

		@Override
		public void cpm$setHasMod(boolean v) {
			hasMod = v;
		}

		@Override
		public void cpm$sendPacket(Identifier id, byte[] data) {
			ServerHandler.netHandler.receiveServer(id, new FastByteArrayInputStream(data), emulServer);
		}

		@Override
		public class_57 cpm$getEntityByID(int id) {
			return Minecraft.field_2791.field_2806;
		}

		@Override
		public String cpm$getConnectedServer() {
			return null;
		}
	}

	private static class EmulServer extends EmulNetwork implements ServerNetworkImpl {
		private boolean hasMod;
		private PlayerData pd;

		@Override
		public boolean cpm$hasMod() {
			return hasMod;
		}

		@Override
		public void cpm$setHasMod(boolean v) {
			hasMod = v;
		}

		@Override
		public void cpm$sendPacket(Identifier id, byte[] data) {
			CustomPlayerModelsClient.netHandler.receiveClient(id, new FastByteArrayInputStream(data), emulClient);
		}

		@Override
		public PlayerData cpm$getEncodedModelData() {
			return pd;
		}

		@Override
		public void cpm$setEncodedModelData(PlayerData data) {
			this.pd = data;
		}

		@Override
		public void cpm$sendChat(String msg) {
			Minecraft.field_2791.field_2820.method_1949(msg);
		}

		@Override
		public class_54 cpm$getPlayer() {
			return Minecraft.field_2791.field_2806;
		}

		@Override
		public void cpm$kickPlayer(String msg) {
		}
	}
}

package com.tom.cpm.client;

import java.util.function.Supplier;
import net.minecraft.class_163;
import net.minecraft.class_173;
import net.minecraft.class_87;
import org.lwjgl.opengl.GL11;
import com.tom.cpl.math.MatrixStack;
import com.tom.cpl.math.Vec4f;
import com.tom.cpl.render.VBuffers;
import com.tom.cpm.shared.model.PlayerModelParts;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.render.ModelRenderManager;
import com.tom.cpm.shared.model.render.VanillaModelPart;
import com.tom.cpm.shared.retro.RedirectHolderRetro;

public class PlayerRenderManager extends ModelRenderManager<Void, Void, class_163, class_173> {
	private static final float scale = 0.0625F;

	public PlayerRenderManager() {
		setFactory(new RedirectHolderFactory<Void, Void, class_163>() {

			@Override
			public <M> RedirectHolder<?, Void, Void, class_163> create(
					M model, String arg) {
				if(model instanceof class_87) {
					if ("armor1".equals(arg))
						return new RedirectHolderArmor1(PlayerRenderManager.this, (class_87) model);
					else if("armor2".equals(arg))
						return new RedirectHolderArmor2(PlayerRenderManager.this, (class_87) model);
					else
						return new RedirectHolderPlayer(PlayerRenderManager.this, (class_87) model);
				}
				return null;
			}
		});
		setRedirectFactory(new RedirectRendererFactory<class_173, Void, class_163>() {

			@Override
			public RedirectRenderer<class_163> create(class_173 model,
					RedirectHolder<class_173, ?, Void, class_163> access, Supplier<class_163> modelPart,
					VanillaModelPart part) {
				return new RedirectModelPart((RDH) access, modelPart, part);
			}

		});
		setVis(m -> m.field_2299, (m, v) -> m.field_2299 = v);
		setModelPosGetters(m -> m.field_2292, m -> m.field_2293, m -> m.field_2294);
		setModelRotGetters(m -> m.field_2295, m -> m.field_2296, m -> m.field_2297);
		setModelSetters((m, x, y, z) -> {
			m.field_2292 = x;
			m.field_2293 = y;
			m.field_2294 = z;
		}, (m, x, y, z) -> {
			m.field_2295 = x;
			m.field_2296 = y;
			m.field_2297 = z;
		});
		setRenderPart(new class_163(0, 0));
	}

	private static class RedirectHolderPlayer extends RDH {
		private RedirectRenderer<class_163> head;

		public RedirectHolderPlayer(PlayerRenderManager mngr, class_87 model) {
			super(mngr, model);
			head = registerHead(new Field<>(() -> model.field_619, v -> model.field_619 = v, PlayerModelParts.HEAD));
			register(new Field<>(() -> model.field_621    , v -> model.field_621     = v, PlayerModelParts.BODY));
			register(new Field<>(() -> model.field_622, v -> model.field_622 = v, PlayerModelParts.RIGHT_ARM));
			register(new Field<>(() -> model.field_623 , v -> model.field_623  = v, PlayerModelParts.LEFT_ARM));
			register(new Field<>(() -> model.field_624, v -> model.field_624 = v, PlayerModelParts.RIGHT_LEG));
			register(new Field<>(() -> model.field_625 , v -> model.field_625  = v, PlayerModelParts.LEFT_LEG));

			register(new Field<>(() -> model.field_620, v -> model.field_620 = v, null)).setCopyFrom(head);

			register(new Field<>(() -> model.field_627,    v -> model.field_627    = v, RootModelType.CAPE));
		}
	}

	private static class RedirectHolderArmor1 extends RDH {

		public RedirectHolderArmor1(PlayerRenderManager mngr, class_87 model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_619,     v -> model.field_619     = v, RootModelType.ARMOR_HELMET));
			register(new Field<>(() -> model.field_621,     v -> model.field_621     = v, RootModelType.ARMOR_BODY));
			register(new Field<>(() -> model.field_622, v -> model.field_622 = v, RootModelType.ARMOR_RIGHT_ARM));
			register(new Field<>(() -> model.field_623,  v -> model.field_623  = v, RootModelType.ARMOR_LEFT_ARM));
			register(new Field<>(() -> model.field_624, v -> model.field_624 = v, RootModelType.ARMOR_RIGHT_FOOT));
			register(new Field<>(() -> model.field_625,  v -> model.field_625  = v, RootModelType.ARMOR_LEFT_FOOT));

			register(new Field<>(() -> model.field_620, v -> model.field_620 = v, null));
		}

	}

	private static class RedirectHolderArmor2 extends RDH {

		public RedirectHolderArmor2(PlayerRenderManager mngr, class_87 model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_621,     v -> model.field_621     = v, RootModelType.ARMOR_LEGGINGS_BODY));
			register(new Field<>(() -> model.field_624, v -> model.field_624 = v, RootModelType.ARMOR_RIGHT_LEG));
			register(new Field<>(() -> model.field_625,  v -> model.field_625  = v, RootModelType.ARMOR_LEFT_LEG));
		}

	}

	private abstract static class RDH extends RedirectHolderRetro<class_173, class_163> {

		public RDH(ModelRenderManager<Void, Void, class_163, class_173> mngr, class_173 model) {
			super(mngr, model);
		}
	}

	private static class RedirectModelPart extends class_163 implements RedirectRenderer<class_163> {
		private final RDH holder;
		private final VanillaModelPart part;
		private final Supplier<class_163> parentProvider;
		private class_163 parent;
		private VBuffers buffers;

		public RedirectModelPart(RDH holder, Supplier<class_163> parent, VanillaModelPart part) {
			super(0, 0);
			this.holder = holder;
			this.parentProvider = parent;
			this.part = part;
		}

		@Override
		public void method_1815(float scale) {
			this.buffers = new VBuffers(RetroGL::buffer);
			render();
			buffers.finishAll();
		}

		@Override
		public class_163 swapIn() {
			if(parent != null) {
				return this;
			}
			parent = parentProvider.get();
			copyModel(parent, this);
			return this;
		}

		@Override
		public class_163 swapOut() {
			if(parent == null) {
				return parentProvider.get();
			}
			class_163 p = parent;
			parent = null;
			return p;
		}

		private static void copyModel(class_163 s, class_163 d) {
			d.field_2292 = s.field_2292;
			d.field_2293 = s.field_2293;
			d.field_2294 = s.field_2294;
			d.field_2295   = s.field_2295  ;
			d.field_2296   = s.field_2296  ;
			d.field_2297   = s.field_2297  ;
			d.field_2299      = s.field_2299     ;
			d.field_2300       = s.field_2300      ;
		}

		@Override
		public RedirectHolder<?, ?, ?, class_163> getHolder() {
			return holder;
		}

		@Override
		public class_163 getParent() {
			return parent;
		}

		@Override
		public VanillaModelPart getPart() {
			return part;
		}

		@Override
		public void renderParent() {
			parent.method_1815(scale);
		}

		@Override
		public VBuffers getVBuffers() {
			return buffers;
		}

		@Override
		public Vec4f getColor() {
			return RetroGL.getColor();
		}

		@Override
		public void method_1820(float scale) {
			MatrixStack.Entry e = getPartTransform();
			if(e != null) {
				multiplyStacks(e);
			} else {
				if (this.field_2295 == 0.0F && this.field_2296 == 0.0F && this.field_2297 == 0.0F) {
					if (this.field_2292 != 0.0F || this.field_2293 != 0.0F || this.field_2294 != 0.0F) {
						GL11.glTranslatef(this.field_2292 * scale, this.field_2293 * scale, this.field_2294 * scale);
					}
				} else {
					GL11.glTranslatef(this.field_2292 * scale, this.field_2293 * scale, this.field_2294 * scale);
					if (this.field_2297 != 0.0F) {
						GL11.glRotatef(this.field_2297 * 57.295776F, 0.0F, 0.0F, 1.0F);
					}

					if (this.field_2296 != 0.0F) {
						GL11.glRotatef(this.field_2296 * 57.295776F, 0.0F, 1.0F, 0.0F);
					}

					if (this.field_2295 != 0.0F) {
						GL11.glRotatef(this.field_2295 * 57.295776F, 1.0F, 0.0F, 0.0F);
					}
				}
			}
		}
	}

	public static void multiplyStacks(MatrixStack.Entry e) {
		e.getMatrix().multiplyNative(GL11::glMultMatrix);
	}
}

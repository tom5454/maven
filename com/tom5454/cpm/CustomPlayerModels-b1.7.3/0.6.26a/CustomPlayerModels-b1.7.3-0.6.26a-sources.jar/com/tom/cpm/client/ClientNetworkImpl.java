package com.tom.cpm.client;

import net.minecraft.class_57;
import net.modificationstation.stationapi.api.util.Identifier;

import com.tom.cpm.shared.network.NetH;

public interface ClientNetworkImpl extends NetH {
	void cpm$sendPacket(Identifier id, byte[] data);
	class_57 cpm$getEntityByID(int id);
	String cpm$getConnectedServer();
}

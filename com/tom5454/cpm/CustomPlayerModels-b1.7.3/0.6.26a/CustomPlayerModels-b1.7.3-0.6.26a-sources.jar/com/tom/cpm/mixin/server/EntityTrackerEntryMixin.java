package com.tom.cpm.mixin.server;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_11;
import net.minecraft.class_174;
import net.minecraft.class_54;
import net.minecraft.class_57;
import net.minecraft.class_69;
import com.tom.cpm.common.ServerHandler;
import com.tom.cpm.shared.network.NetH.ServerNetH;

@Mixin(class_174.class)
public class EntityTrackerEntryMixin {
	public @Shadow class_57 field_597;

	@Inject(at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;method_943()Z"), method = "method_601(Lnet/minecraft/class_69;)V")
	public void onStartTracking(class_69 trackingPlayer, CallbackInfo cbi) {
		class_11 handler = trackingPlayer.field_255;
		if (((ServerNetH) handler).cpm$hasMod()) {
			ServerHandler.netHandler.sendPlayerData((class_54) field_597, trackingPlayer);
		}
	}
}

package com.tom.cpm.mixin.client;

import java.net.InetSocketAddress;
import java.net.SocketAddress;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import net.minecraft.class_117;
import net.minecraft.class_169;
import net.minecraft.class_219;
import net.minecraft.class_454;
import net.minecraft.class_57;
import net.minecraft.client.Minecraft;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;
import net.modificationstation.stationapi.api.util.Identifier;

import com.tom.cpm.client.ClientNetworkImpl;

@Mixin(class_219.class)
public abstract class ClientNetworkHandlerMixin implements ClientNetworkImpl {
	private @Shadow @Final Minecraft minecraft;
	private @Shadow class_117 connection;
	private @Shadow class_454 field_1973;
	private boolean cpm$hasMod;

	public @Shadow abstract void sendPacket(class_169 packet);

	@Override
	public boolean cpm$hasMod() {
		return cpm$hasMod;
	}

	@Override
	public void cpm$setHasMod(boolean v) {
		cpm$hasMod = v;
	}

	@Override
	public void cpm$sendPacket(Identifier id, byte[] data) {
		MessagePacket p = new MessagePacket(id);
		p.bytes = data;
		sendPacket(p);
	}

	@Override
	public class_57 cpm$getEntityByID(int id) {
		if (minecraft.field_2806.field_1591 == id)return minecraft.field_2806;
		return field_1973.method_1496(id);
	}

	@Override
	public String cpm$getConnectedServer() {
		SocketAddress sa = connection.field_1282;
		if (sa instanceof InetSocketAddress)
			return ((InetSocketAddress) sa).getHostString();
		return null;
	}
}

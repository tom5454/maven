package com.tom.cpm;

import com.tom.cpm.common.ServerHandler;
import com.tom.cpm.shared.config.PlayerData;
import net.minecraft.class_54;

public class PlayerDataExt extends PlayerData {
	private int skinLayer;

	public PlayerDataExt() {
	}

	public boolean hasModel() {
		return data == null;
	}

	public static int getSkinLayer(class_54 player) {
		PlayerData pd = ServerHandler.netHandler.getSNetH(player).cpm$getEncodedModelData();
		return pd == null ? 0 : ((PlayerDataExt)pd).skinLayer;
	}

	public static void setSkinLayer(class_54 player, int layer) {
		PlayerData pd = ServerHandler.netHandler.getSNetH(player).cpm$getEncodedModelData();
		((PlayerDataExt)pd).skinLayer = layer;
	}
}

package com.tom.cpm.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_124;
import net.minecraft.class_165;
import net.minecraft.class_187;
import net.minecraft.class_202;
import net.minecraft.class_31;
import net.minecraft.class_8;
import net.modificationstation.stationapi.api.nbt.NbtIntArray;
import net.modificationstation.stationapi.api.nbt.NbtLongArray;

import com.tom.cpl.item.ItemStackHandler;
import com.tom.cpl.item.NbtMapper;
import com.tom.cpl.item.Stack;
import com.tom.cpl.nbt.NBTTagCompound;

@SuppressWarnings("unchecked")
public class ItemStackHandlerImpl extends ItemStackHandler<class_31> {
	private static final String AIR = "minecraft:air";
	public static final ItemStackHandlerImpl impl = new ItemStackHandlerImpl();
	public static final NBT nbt = new NBT();

	@Override
	public int getCount(class_31 stack) {
		return stack == null ? 0 : stack.field_751;
	}

	@Override
	public int getMaxCount(class_31 stack) {
		return stack == null ? 0 : stack.method_709();
	}

	@Override
	public int getDamage(class_31 stack) {
		return stack == null ? 0 : stack.method_722();
	}

	@Override
	public int getMaxDamage(class_31 stack) {
		return stack == null ? 0 : stack.method_723();
	}

	@Override
	public boolean itemEquals(class_31 a, class_31 b) {
		return a == null && b == null ? true : (a != null && b != null ? (!a.method_717() ? a.method_702(b) : a.method_694() == b.method_694()) : false);
	}

	@Override
	public boolean itemEqualsFull(class_31 a, class_31 b) {
		return (a == null && b == null ? true : (a != null && b != null ? a.method_702(b) : false)) && class_31.method_703(a, b);
	}

	@Override
	public List<String> listNativeTags() {
		//return Arrays.stream(OreDictionary.getOreNames()).map(t -> "#oredict:" + t).collect(Collectors.toList());
		return Collections.emptyList();
	}

	@Override
	public List<Stack> getAllElements() {
		ArrayList<class_31> stacks = new ArrayList<>();
		for (int i = 0; i < class_124.field_468.length; i++) {
			class_124 item = class_124.field_468[i];
			if (item == null)continue;
			stacks.add(new class_31(item));
		}
		return stacks.stream().map(this::wrap).collect(Collectors.toList());
	}

	public static interface NBTPrimitive {
		public long cpm$getLong();
		public int cpm$getInt();
		public short cpm$getShort();
		public byte cpm$getByte();
		public double cpm$getDouble();
		public float cpm$getFloat();
	}

	public static class NBT extends NbtMapper<class_187, class_8, class_202, NBTPrimitive> {

		@Override
		public long getLong(NBTPrimitive t) {
			return t.cpm$getLong();
		}

		@Override
		public int getInt(NBTPrimitive t) {
			return t.cpm$getInt();
		}

		@Override
		public short getShort(NBTPrimitive t) {
			return t.cpm$getShort();
		}

		@Override
		public byte getByte(NBTPrimitive t) {
			return t.cpm$getByte();
		}

		@Override
		public double getDouble(NBTPrimitive t) {
			return t.cpm$getDouble();
		}

		@Override
		public float getFloat(NBTPrimitive t) {
			return t.cpm$getFloat();
		}

		@Override
		public NBTPrimitive asNumber(class_187 t) {
			return t instanceof NBTPrimitive ? (NBTPrimitive) t : null;
		}

		@Override
		public String getString(class_187 t) {
			return t.toString();
		}

		@Override
		public class_187 getTag(class_8 t, String name) {
			return (class_187) t.field_1199.get(name);
		}

		@Override
		public class_202 asList(class_187 t) {
			return t instanceof class_202 ? (class_202) t : null;
		}

		@Override
		public class_8 asCompound(class_187 t) {
			return t instanceof class_8 ? (class_8) t : null;
		}

		@Override
		public int listSize(class_202 t) {
			return t.method_1398();
		}

		@Override
		public class_187 getAt(class_202 t, int i) {
			return t.method_1396(i);
		}

		@Override
		public boolean contains(class_8 t, String name, int type) {
			if(!t.method_1023(name))return false;
			return ((class_187) t.field_1199.get(name)).method_629() == type;
		}

		@Override
		public class_8 newCompound() {
			return new class_8();
		}

		@Override
		public class_202 newList() {
			return new class_202();
		}

		@SuppressWarnings("unchecked")
		@Override
		public Iterable<String> keys(class_8 t) {
			return t.field_1199.keySet();
		}

		@Override
		public int getId(class_187 t) {
			return t.method_629();
		}

		@Override
		public byte[] getByteArray(class_187 t) {
			return t instanceof class_165 ? ((class_165) t).field_576 : new byte[0];
		}

		@Override
		public int[] getIntArray(class_187 t) {
			return t instanceof NbtIntArray ? ((NbtIntArray) t).data : new int[0];
		}

		@Override
		public long[] getLongArray(class_187 t) {
			return t instanceof NbtLongArray ? ((NbtLongArray) t).data : new long[0];
		}
	}

	@Override
	public NBTTagCompound getTag(class_31 stack) {
		return stack != null && stack.getStationNbt() != null ? nbt.wrap(stack.getStationNbt()) : null;
	}

	@Override
	public List<Stack> listNativeEntries(String tag) {
		/*if(tag.charAt(0) == '#') {
			if (tag.startsWith("#oredict:")) {
				tag = tag.substring(9);
				if (oreIDs.containsKey(tag)) {
					return OreDictionary.getOres(tag).stream().map(this::wrap).collect(Collectors.toList());
				}
			}//TODO idmeta
		} else {
			ResourceLocation rl = tryParse(tag);//TODO
			Item item = (Item) GameData.getItemRegistry().getObject(rl);
			if (item != null) {
				return Collections.singletonList(wrap(new ItemStack(item)));
			}
		}*/
		return Collections.emptyList();
	}

	@Override
	public boolean isInTag(String tag, class_31 stack) {
		if(tag.charAt(0) == '#') {
			/*if (tag.startsWith("#oredict:")) {
				tag = tag.substring(9);
				if (oreIDs.containsKey(tag)) {
					return OreDictionary.getOreID(stack) == OreDictionary.getOreID(tag);
				}
			}*/
			return checkIdMetaTags(tag, stack.field_753, stack.method_722());
		} else if(stack == null) {
			return false;
		} else {
			return getItemId(stack).equals(tag);
		}
	}

	public static boolean checkIdMetaTags(String tag, int id, int meta) {
		if (tag.startsWith("#id:")) {
			tag = tag.substring(4);
			Integer i = parseInt(tag);
			if (i == null)return false;
			return i == id;
		} else if (tag.startsWith("#idmeta:")) {
			tag = tag.substring(8);
			String[] sp = tag.split("/");
			if (sp.length != 2)return false;
			Integer i = parseInt(sp[0]);
			Integer m = parseInt(sp[1]);
			if (i == null || m == null)return false;
			return i == id && m == meta;
		}
		return false;
	}

	private static Integer parseInt(String tag) {
		try {
			return Integer.parseInt(tag);
		} catch (NumberFormatException e) {
			return null;
		}
	}

	@Override
	public List<String> listTags(class_31 stack) {
		if(stack == null)return Collections.emptyList();
		List<String> tags = new ArrayList<>();
		tags.add("#idmeta:" + stack.field_753 + "/" + stack.method_722());
		tags.add("#id:" + stack.field_753);
		/*int id = OreDictionary.getOreID(stack);
		if (id == -1)return tags;
		tags.add("#oredict:" + OreDictionary.getOreName(id));*/
		return tags;
	}

	@Override
	public String getItemId(class_31 stack) {
		if(stack == null)return AIR;
		return "unloc:" + stack.method_694().method_443();
	}

	@Override
	public Stack emptyObject() {
		return wrap(null);
	}

	@Override
	public String getItemDisplayName(class_31 stack) {
		return stack.method_694().method_469();
	}
}

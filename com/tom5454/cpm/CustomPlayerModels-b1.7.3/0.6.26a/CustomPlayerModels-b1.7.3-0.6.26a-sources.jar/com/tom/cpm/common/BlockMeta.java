package com.tom.cpm.common;

import net.minecraft.class_17;

public class BlockMeta {
	private final int block;
	private final int meta;

	public BlockMeta(int block, int meta) {
		this.block = block;
		this.meta = meta;
	}

	public int getBlockId() {
		return block;
	}

	public class_17 getBlock() {
		return class_17.field_1937[block];
	}

	public int getMeta() {
		return meta;
	}
}

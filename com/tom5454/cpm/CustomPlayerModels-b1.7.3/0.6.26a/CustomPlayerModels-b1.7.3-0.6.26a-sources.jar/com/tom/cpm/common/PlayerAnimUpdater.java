package com.tom.cpm.common;

import java.util.function.BiConsumer;
import net.minecraft.class_54;
import com.tom.cpm.shared.animation.ServerAnimationState;

public class PlayerAnimUpdater implements BiConsumer<class_54, ServerAnimationState> {

	@Override
	public void accept(class_54 t, ServerAnimationState u) {
		u.updated = true;
		u.falling = t.field_1636;
		u.health = t.field_1036 / 20f;
		u.air = Math.max(t.field_1614 / 300f, 0);
		//u.hunger = t.getFoodStats().getFoodLevel() / 20f;
		u.inMenu = t.field_521 != t.field_520;
	}

}

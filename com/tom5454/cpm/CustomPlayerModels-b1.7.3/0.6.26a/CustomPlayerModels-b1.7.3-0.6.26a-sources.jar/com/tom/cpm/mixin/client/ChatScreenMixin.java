package com.tom.cpm.mixin.client;

import net.minecraft.class_211;
import net.minecraft.class_32;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_211.class)
public class ChatScreenMixin extends class_32 {

	@Override
	public boolean method_121() {
		return false;
	}
}

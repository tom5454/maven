package com.tom.cpm.client;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_127;
import net.minecraft.class_173;
import net.minecraft.class_189;
import net.minecraft.class_245;
import net.minecraft.class_33;
import net.minecraft.class_34;
import net.minecraft.class_54;
import net.minecraft.class_57;
import net.minecraft.class_578;
import net.minecraft.class_67;
import net.minecraft.class_86;
import net.minecraft.class_87;
import net.minecraft.client.Minecraft;
import net.modificationstation.stationapi.api.util.Identifier;

import com.tom.cpl.text.FormatText;
import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.SidedHandler;
import com.tom.cpm.common.PlayerAnimUpdater;
import com.tom.cpm.common.ServerNetworkImpl;
import com.tom.cpm.retro.GameProfile;
import com.tom.cpm.retro.GameProfileManager;
import com.tom.cpm.retro.MCExecutor;
import com.tom.cpm.retro.NetHandlerExt;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import com.tom.cpm.shared.gui.GestureGui;
import com.tom.cpm.shared.model.RenderManager;
import com.tom.cpm.shared.model.TextureSheetType;

public class CustomPlayerModelsClient implements ClientModInitializer, SidedHandler {
	public static MinecraftObject mc;
	private Minecraft minecraft;
	public static CustomPlayerModelsClient INSTANCE;
	public RenderManager<GameProfile, class_54, class_173, Void> manager;
	public static NetHandlerExt<Identifier, class_54, ClientNetworkImpl> netHandler = new NetHandlerExt<>((a, b) -> Identifier.of(a + ":" + b));

	@Override
	public void onInitializeClient() {
		INSTANCE = this;
		minecraft = Minecraft.field_2791;
		CustomPlayerModels.proxy = this;
		mc = new MinecraftObject(minecraft);
		manager = new RenderManager<>(mc.getPlayerRenderManager(), mc.getDefinitionLoader(), e -> GameProfileManager.getProfile(e.field_528));
		netHandler.setExecutor(() -> MCExecutor.ex);
		netHandler.setSendPacketClient(ClientNetworkImpl::cpm$sendPacket);
		netHandler.setPlayerToLoader(e -> GameProfileManager.getProfile(e.field_528));
		netHandler.setGetPlayerById(id -> {
			class_57 ent = EmulNetwork.getClient(minecraft.field_2806).cpm$getEntityByID(id);
			if(ent instanceof class_54) {
				return (class_54) ent;
			}
			return null;
		});
		netHandler.setGetClient(() -> minecraft.field_2806);
		netHandler.setGetNet(EmulNetwork::getClient);
		netHandler.setDisplayText(f -> minecraft.field_2820.method_1949(f.remap()));
		netHandler.setGetPlayerAnimGetters(new PlayerAnimUpdater());
		apiInit();
		Lang.init();
	}

	public void apiInit() {
		CustomPlayerModels.api.buildClient().localModelApi(GameProfile::new).
		renderApi(class_173.class, GameProfile.class).init();
	}

	public void playerRenderPre(class_86 renderer, class_54 entityPlayer) {
		manager.bindPlayer(entityPlayer, null, renderer.field_294);
		manager.bindSkin(renderer.field_294, TextureSheetType.SKIN);
		class_87 model = renderer.field_294;
		manager.bindArmor(model, renderer.field_295, 1);
		manager.bindArmor(model, renderer.field_296, 2);
		manager.bindSkin(renderer.field_295, TextureSheetType.ARMOR1);
		manager.bindSkin(renderer.field_296, TextureSheetType.ARMOR2);
	}

	public void playerRenderPost(class_86 renderer) {
		manager.unbind(renderer.field_296);
		manager.unbind(renderer.field_295);
		manager.unbindFlush(renderer.field_294);
	}

	public void clientTickStart() {
		if(!minecraft.field_2813) {
			mc.getPlayerRenderManager().getAnimationEngine().tick();

			if(minecraft.field_2806 != null && minecraft.field_2806.field_1623 && Keyboard.isKeyDown(minecraft.field_2824.field_1472.field_2381)) {
				manager.jump(minecraft.field_2806);
			}
		}
	}

	public void clientTickEnd() {
		if (minecraft.field_2806 == null)
			return;

		if (minecraft.field_2816 == null) {
			if(Keyboard.isKeyDown(KeyBindings.gestureMenuBinding.field_2381)) {
				minecraft.method_2112(new GuiImpl(GestureGui::new, null));
			}

			if(Keyboard.isKeyDown(KeyBindings.renderToggleBinding.field_2381)) {
				Player.setEnableRendering(!Player.isEnableRendering());
			}

			mc.getPlayerRenderManager().getAnimationEngine().updateKeys(KeyBindings.quickAccess);
		}

		CustomPlayerModels.api.clientApi().tickListeners(minecraft.field_2813);
	}

	public boolean onRenderName(class_245 renderer, class_127 entity, double xIn, double yIn, double zIn) {
		boolean res = false;
		if(entity instanceof class_54) {
			if(!Player.isEnableNames())
				res = true;
			if(Player.isEnableLoadingInfo() && canRenderName(entity)) {
				GameProfile gp = GameProfileManager.getProfile(((class_54) entity).field_528);
				FormatText st = INSTANCE.manager.getStatus(gp, ModelDefinitionLoader.PLAYER_UNIQUE);
				if(st != null) {
					float f = 1.6F;
					float f1 = 0.016666668F * f / 2;
					double d3 = entity.method_1352(class_578.field_2489.field_2496);

					if (d3 < 32*32) {
						double y = yIn;
						GL11.glPushMatrix();
						GL11.glTranslated(0, 0.125F, 0);
						String s = st.remap();

						if (entity.method_1373()) {
							class_34 fontrenderer = minecraft.field_2815;
							GL11.glPushMatrix();
							GL11.glTranslatef((float)xIn + 0.0F, (float)y + entity.field_1633 + 0.5F, (float)zIn);
							GL11.glNormal3f(0.0F, 1.0F, 0.0F);
							GL11.glRotatef(-class_578.field_2489.field_2497, 0.0F, 1.0F, 0.0F);
							GL11.glRotatef(class_578.field_2489.field_2498, 1.0F, 0.0F, 0.0F);
							GL11.glScalef(-f1, -f1, f1);
							GL11.glDisable(GL11.GL_LIGHTING);
							GL11.glTranslatef(0.0F, 0.25F / f1, 0.0F);
							GL11.glDepthMask(false);
							GL11.glEnable(GL11.GL_BLEND);
							RetroGL.glBlendFunc(770, 771, 1, 0);
							class_67 tessellator = class_67.field_2054;
							GL11.glDisable(GL11.GL_TEXTURE_2D);
							tessellator.method_1695();
							int i = fontrenderer.method_1901(s) / 2;
							tessellator.method_1690(0.0F, 0.0F, 0.0F, 0.25F);
							tessellator.method_1687(-i - 1, -1.0D, 0.0D);
							tessellator.method_1687(-i - 1, 8.0D, 0.0D);
							tessellator.method_1687(i + 1, 8.0D, 0.0D);
							tessellator.method_1687(i + 1, -1.0D, 0.0D);
							tessellator.method_1685();
							GL11.glEnable(GL11.GL_TEXTURE_2D);
							GL11.glDepthMask(true);
							fontrenderer.method_1906(s, -fontrenderer.method_1901(s) / 2, 0, 553648127);
							GL11.glEnable(GL11.GL_LIGHTING);
							GL11.glDisable(GL11.GL_BLEND);
							GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
							GL11.glPopMatrix();
						} else {
							this.renderLivingLabel(entity, xIn, y, zIn, s, f1, d3);
						}
						GL11.glPopMatrix();
					}
				}
			}
		}
		return res;
	}

	protected boolean canRenderName(class_127 p_110813_1_) {
		return Minecraft.method_2146() && p_110813_1_.field_1594 == null;
	}

	protected void renderLivingLabel(class_127 p_96449_1_, double p_96449_2_, double p_96449_4_, double p_96449_6_, String p_96449_8_, float p_96449_9_, double p_96449_10_) {
		if (p_96449_1_.method_943())this.renderLivingLabel0(p_96449_1_, p_96449_8_, p_96449_2_, p_96449_4_ - 1.5D, p_96449_6_, 64);
		else this.renderLivingLabel0(p_96449_1_, p_96449_8_, p_96449_2_, p_96449_4_, p_96449_6_, 64);
	}

	protected void renderLivingLabel0(class_57 p_147906_1_, String p_147906_2_, double p_147906_3_, double p_147906_5_, double p_147906_7_, int p_147906_9_) {
		double d3 = p_147906_1_.method_1352(class_578.field_2489.field_2496);

		if (d3 <= p_147906_9_ * p_147906_9_) {
			class_34 fontrenderer = minecraft.field_2815;
			float f = 1.6F;
			float f1 = 0.016666668F * f / 2;
			GL11.glPushMatrix();
			GL11.glTranslatef((float)p_147906_3_ + 0.0F, (float)p_147906_5_ + p_147906_1_.field_1633 + 0.5F, (float)p_147906_7_);
			GL11.glNormal3f(0.0F, 1.0F, 0.0F);
			GL11.glRotatef(-class_578.field_2489.field_2497, 0.0F, 1.0F, 0.0F);
			GL11.glRotatef(class_578.field_2489.field_2498, 1.0F, 0.0F, 0.0F);
			GL11.glScalef(-f1, -f1, f1);
			GL11.glDisable(GL11.GL_LIGHTING);
			GL11.glDepthMask(false);
			GL11.glDisable(GL11.GL_DEPTH_TEST);
			GL11.glEnable(GL11.GL_BLEND);
			RetroGL.glBlendFunc(770, 771, 1, 0);
			class_67 tessellator = class_67.field_2054;
			byte b0 = 0;

			if (p_147906_2_.equals("deadmau5"))b0 = -10;

			GL11.glDisable(GL11.GL_TEXTURE_2D);
			tessellator.method_1695();
			int j = fontrenderer.method_1901(p_147906_2_) / 2;
			tessellator.method_1690(0.0F, 0.0F, 0.0F, 0.25F);
			tessellator.method_1687(-j - 1, -1 + b0, 0.0D);
			tessellator.method_1687(-j - 1, 8 + b0, 0.0D);
			tessellator.method_1687(j + 1, 8 + b0, 0.0D);
			tessellator.method_1687(j + 1, -1 + b0, 0.0D);
			tessellator.method_1685();
			GL11.glEnable(GL11.GL_TEXTURE_2D);
			fontrenderer.method_1906(p_147906_2_, -fontrenderer.method_1901(p_147906_2_) / 2, b0, 553648127);
			GL11.glEnable(GL11.GL_DEPTH_TEST);
			GL11.glDepthMask(true);
			fontrenderer.method_1906(p_147906_2_, -fontrenderer.method_1901(p_147906_2_) / 2, b0, -1);
			GL11.glEnable(GL11.GL_LIGHTING);
			GL11.glDisable(GL11.GL_BLEND);
			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
			GL11.glPopMatrix();
		}
	}

	public static class Button extends class_33 {

		public Button(int x, int y) {
			super(99, x, y, 100, 20, Lang.format("button.cpm.open_editor"));
		}

	}

	public void onLogout() {
		mc.onLogOut();
	}

	//Copy from PlayerEntityRenderer.method_827
	public static void renderCape(class_54 playerIn, float partialTicks, class_87 model, ModelDefinition modelDefinition) {
		GL11.glPushMatrix();
		GL11.glTranslatef(0.0F, 0.0F, 0.125F);
		float f5, f6, f7;
		if(playerIn != null) {
			double d3 = playerIn.field_530 + (playerIn.field_533 - playerIn.field_530) * partialTicks
					- (playerIn.field_1597 + (playerIn.field_1600 - playerIn.field_1597) * partialTicks);
			double d4 = playerIn.field_531 + (playerIn.field_534 - playerIn.field_531) * partialTicks
					- (playerIn.field_1598 + (playerIn.field_1601 - playerIn.field_1598) * partialTicks);
			double d0 = playerIn.field_532 + (playerIn.field_535 - playerIn.field_532) * partialTicks
					- (playerIn.field_1599 + (playerIn.field_1602 - playerIn.field_1599) * partialTicks);
			float f4 = playerIn.field_1013 + (playerIn.field_1012 - playerIn.field_1013) * partialTicks;

			double d1 = class_189.method_644(f4 * (float)Math.PI / 180.0F);
			double d2 = (-class_189.method_646(f4 * (float)Math.PI / 180.0F));
			f5 = (float)d4 * 10.0F;

			if (f5 < -6.0F)
			{
				f5 = -6.0F;
			}

			if (f5 > 32.0F)
			{
				f5 = 32.0F;
			}

			f6 = (float)(d3 * d1 + d0 * d2) * 100.0F;
			f7 = (float)(d3 * d2 - d0 * d1) * 100.0F;

			if (f6 < 0.0F)
			{
				f6 = 0.0F;
			}

			float var18 = playerIn.field_524 + (playerIn.field_525 - playerIn.field_524) * partialTicks;
			f5 += class_189.method_644((playerIn.field_1634 + (playerIn.field_1635 - playerIn.field_1634) * partialTicks) * 6.0F) * 32.0F * var18;
			if (playerIn.method_1373()) {
				f5 += 25.0F;
			}
		} else {
			f5 = 0;
			f6 = 0;
			f7 = 0;
		}

		model.field_627.field_2295 = (float) -Math.toRadians(6.0F + f6 / 2.0F + f5);
		model.field_627.field_2296 = (float) Math.toRadians(180.0F - f7 / 2.0F);
		model.field_627.field_2297 = (float) Math.toRadians(f7 / 2.0F);
		mc.getPlayerRenderManager().setModelPose(model);
		model.field_627.field_2295 = 0;
		model.field_627.field_2296 = 0;
		model.field_627.field_2297 = 0;
		model.method_606(0.0625F);
		GL11.glPopMatrix();
	}

	public static SidedHandler makeProxy() {
		return new CustomPlayerModelsClient();
	}

	@Override
	public void getTracking(class_54 player, Consumer<class_54> f) {
	}

	@Override
	public Set<class_54> getTrackingPlayers(class_57 entity) {
		return Collections.emptySet();
	}

	@Override
	public List<class_54> getPlayersOnline() {
		return Collections.singletonList(minecraft.field_2806);
	}

	@Override
	public ServerNetworkImpl getServer(class_54 pl) {
		return EmulNetwork.emulServer;
	}
}

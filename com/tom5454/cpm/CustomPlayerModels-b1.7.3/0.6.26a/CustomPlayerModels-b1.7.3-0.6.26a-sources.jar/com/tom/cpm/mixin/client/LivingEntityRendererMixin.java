package com.tom.cpm.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.IBipedModel;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.client.RetroGL;
import net.minecraft.class_127;
import net.minecraft.class_173;
import net.minecraft.class_245;
import net.minecraft.class_86;
import net.minecraft.class_87;

@Mixin(class_245.class)
public class LivingEntityRendererMixin {
	private static final String RENDER_METHOD = "render(Lnet/minecraft/entity/LivingEntity;DDDFF)V";
	private static final String MODEL_RENDER_METHOD = "Lnet/minecraft/client/render/entity/model/EntityModel;render(FFFFFF)V";

	private void onRenderPart(class_173 model, int callLoc) {
		RetroGL.renderCallLoc = callLoc;
		Object r = this;
		if (r instanceof class_86 && model instanceof class_87) {
			class_86 rp = (class_86) r;
			if(model == rp.field_295 || model == rp.field_296) {
				PlayerRenderManager m = CustomPlayerModelsClient.mc.getPlayerRenderManager();
				class_87 player = rp.field_294;
				class_87 armor = (class_87) model;
				m.copyModelForArmor(player.field_621, armor.field_621);
				m.copyModelForArmor(player.field_619, armor.field_619);
				m.copyModelForArmor(player.field_623, armor.field_623);
				m.copyModelForArmor(player.field_625, armor.field_625);
				m.copyModelForArmor(player.field_622, armor.field_622);
				m.copyModelForArmor(player.field_624, armor.field_624);
				((IBipedModel) armor).cpm$setNoSetup(true);
			}
		}
	}

	@Inject(at = @At(value = "HEAD"), method = RENDER_METHOD)
	public void onRender(class_127 arg, double d, double e, double f, float g, float h, CallbackInfo cbi) {
		RetroGL.renderCallLoc = 0;
	}

	@Redirect(at = @At(value = "INVOKE", target = "Lorg/lwjgl/opengl/GL11;glColor4f(FFFF)V", remap = false), method = RENDER_METHOD)
	public void onRenderC(float r, float g, float b, float a) {
		RetroGL.color4f(r, g, b, a);
	}

	@Redirect(at = @At(value = "INVOKE", target = MODEL_RENDER_METHOD, ordinal = 0), method = RENDER_METHOD)
	public void onRender0(class_173 model, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch,
			float scale) {
		onRenderPart(model, 0);
		model.method_1211(limbAngle, limbDistance, animationProgress, headYaw, headPitch, scale);
	}

	@Redirect(at = @At(value = "INVOKE", target = MODEL_RENDER_METHOD, ordinal = 1), method = RENDER_METHOD)
	public void onRender1(class_173 model, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch,
			float scale) {
		onRenderPart(model, 1);
		model.method_1211(limbAngle, limbDistance, animationProgress, headYaw, headPitch, scale);
	}

	@Redirect(at = @At(value = "INVOKE", target = MODEL_RENDER_METHOD, ordinal = 2), method = RENDER_METHOD)
	public void onRender2(class_173 model, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch,
			float scale) {
		onRenderPart(model, 2);
		model.method_1211(limbAngle, limbDistance, animationProgress, headYaw, headPitch, scale);
	}

	@Redirect(at = @At(value = "INVOKE", target = MODEL_RENDER_METHOD, ordinal = 3), method = RENDER_METHOD)
	public void onRender3(class_173 model, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch,
			float scale) {
		onRenderPart(model, 3);
		model.method_1211(limbAngle, limbDistance, animationProgress, headYaw, headPitch, scale);
	}

	@Redirect(at = @At(value = "INVOKE", target = MODEL_RENDER_METHOD, ordinal = 4), method = RENDER_METHOD)
	public void onRender4(class_173 model, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch,
			float scale) {
		onRenderPart(model, 4);
		model.method_1211(limbAngle, limbDistance, animationProgress, headYaw, headPitch, scale);
	}

	@Redirect(at = @At(value = "INVOKE", target = MODEL_RENDER_METHOD, ordinal = 5), method = RENDER_METHOD)
	public void onRender5(class_173 model, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch,
			float scale) {
		onRenderPart(model, 5);
		model.method_1211(limbAngle, limbDistance, animationProgress, headYaw, headPitch, scale);
	}
}

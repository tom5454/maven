package com.tom.cpm.server;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_174;
import net.minecraft.class_39;
import net.minecraft.class_488;
import net.minecraft.class_54;
import net.minecraft.class_57;
import net.minecraft.class_69;
import net.minecraft.class_73;
import net.minecraft.server.MinecraftServer;

import com.tom.cpl.text.IText;
import com.tom.cpm.SidedHandler;
import com.tom.cpm.common.Command;
import com.tom.cpm.common.ServerNetworkImpl;
import com.tom.cpm.shared.util.Log;

public class ServerSidedHandler implements SidedHandler {

	@Override
	public void getTracking(class_54 player, Consumer<class_54> f) {
		MinecraftServer server = (MinecraftServer) FabricLoader.getInstance().getGameInstance();
		class_73 ws = (class_73) player.field_1596;
		class_488 et = server.method_2165(ws.field_216.field_2179);
		for (class_174 tr : (Set<class_174>) et.field_2004) {
			if (tr.field_597 instanceof class_54 && tr.field_610.contains(player)) {
				f.accept((class_54) tr.field_597);
			}
		}
	}

	@Override
	@SuppressWarnings("unchecked")
	public Set<class_54> getTrackingPlayers(class_57 entity) {
		MinecraftServer server = (MinecraftServer) FabricLoader.getInstance().getGameInstance();
		class_73 ws = (class_73) entity.field_1596;
		class_488 et = server.method_2165(ws.field_216.field_2179);
		class_174 entry = (class_174) et.field_2005.method_772(entity.field_1591);
		if (entry == null)
			return Collections.emptySet();
		else
			return entry.field_610;
	}

	@SuppressWarnings({ "unchecked", "deprecation" })
	@Override
	public List<class_54> getPlayersOnline() {
		MinecraftServer server = (MinecraftServer) FabricLoader.getInstance().getGameInstance();
		return server.field_2842.field_578;
	}

	@Override
	public ServerNetworkImpl getServer(class_54 pl) {
		return (ServerNetworkImpl) ((class_69) pl).field_255;
	}

	public static final Command.CommandHandlerBase<class_39> cpm = new Command.CommandHandlerBase<>() {

		@Override
		protected void sendMessage(class_39 sender, String string) {
			sender.method_1409(string);
		}

		@SuppressWarnings("deprecation")
		@Override
		public void sendSuccess(class_39 sender, IText text) {
			String t = text.remap();
			sender.method_1409(t);
			String r = sender.method_1410();
			t = "[" + r + ": " + t + "]";
			Log.info(t);
			MinecraftServer server = (MinecraftServer) FabricLoader.getInstance().getGameInstance();
			server.field_2842.method_588("\u00A77\u00A7o" + t);
		}
	};
}

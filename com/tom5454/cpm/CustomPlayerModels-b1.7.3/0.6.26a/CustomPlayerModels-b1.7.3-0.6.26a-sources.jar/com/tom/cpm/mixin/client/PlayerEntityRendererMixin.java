package com.tom.cpm.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.minecraft.class_173;
import net.minecraft.class_245;
import net.minecraft.class_54;
import net.minecraft.class_86;
import net.minecraft.class_87;
import net.minecraft.client.Minecraft;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.RetroGL;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.TextureSheetType;
import com.tom.cpm.shared.model.render.ModelRenderManager.BoundPlayer;

@Mixin(class_86.class)
public class PlayerEntityRendererMixin extends class_245 {
	public PlayerEntityRendererMixin(class_173 arg, float f) {
		super(arg, f);
	}

	public @Shadow class_87 bipedModel;
	public @Shadow class_87 field_295;
	public @Shadow class_87 field_296;

	@Inject(at = @At(value = "HEAD"), method = "renderHand()V")
	public void onHandPre(CallbackInfo cbi) {
		RetroGL.renderCallLoc = 0;
		CustomPlayerModelsClient.INSTANCE.manager.bindHand(Minecraft.field_2791.field_2806, null, bipedModel);
		CustomPlayerModelsClient.INSTANCE.manager.bindSkin(bipedModel, TextureSheetType.SKIN);
	}

	@Inject(at = @At(value = "RETURN"), method = "renderHand()V")
	public void onHandPost(CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbindFlush(bipedModel);
	}

	@Inject(at = @At(value = "HEAD"), method = "render(Lnet/minecraft/entity/player/PlayerEntity;DDDFF)V")
	public void onRenderPre(class_54 arg, double d, double e, double f, float g, float h, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.playerRenderPre((class_86) (Object) this, arg);
	}

	@Inject(at = @At(value = "RETURN"), method = "render(Lnet/minecraft/entity/player/PlayerEntity;DDDFF)V")
	public void onRenderPost(class_54 arg, double d, double e, double f, float g, float h, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.playerRenderPost((class_86) (Object) this);
	}

	@Redirect(at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/PlayerEntityRenderer;method_2027(Ljava/lang/String;Ljava/lang/String;)Z"), method = "method_827(Lnet/minecraft/entity/player/PlayerEntity;F)V")
	public boolean onRenderCape(class_86 r, String string, String string2, class_54 player, float partialTicks) {
		class_87 model = bipedModel;
		BoundPlayer pl = CustomPlayerModelsClient.INSTANCE.manager.getPlayerFromModel(model);
		if(pl != null) {
			ModelDefinition def = pl.definition;
			if(def != null && def.hasRoot(RootModelType.CAPE)) {
				CustomPlayerModelsClient.mc.getPlayerRenderManager().rebindModel(model);
				CustomPlayerModelsClient.INSTANCE.manager.bindSkin(model, TextureSheetType.CAPE);
				CustomPlayerModelsClient.renderCape(player, partialTicks, model, def);
				return false;
			}
		}
		return method_2027(string, string2);
	}

	@Inject(at = @At("HEAD"), method = "method_821(Lnet/minecraft/entity/player/PlayerEntity;DDD)V", cancellable = true)
	protected void onRenderName(class_54 entity, double x, double y, double z, CallbackInfo cbi) {
		if (CustomPlayerModelsClient.INSTANCE.onRenderName(this, entity, x, y, z)) {
			cbi.cancel();
		}
	}
}

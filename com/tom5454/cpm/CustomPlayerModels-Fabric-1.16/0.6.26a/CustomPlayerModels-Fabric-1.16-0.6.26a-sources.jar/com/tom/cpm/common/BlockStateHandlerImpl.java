package com.tom.cpm.common;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3494;
import com.tom.cpl.block.BlockStateHandler;
import com.tom.cpl.item.Stack;

public class BlockStateHandlerImpl extends BlockStateHandler<class_2680> {
	public static final BlockStateHandlerImpl impl = new BlockStateHandlerImpl();

	@Override
	public String getBlockId(class_2680 stack) {
		return class_2378.field_11146.method_10221(stack.method_26204()).toString();
	}

	@Override
	public List<String> getBlockStates(class_2680 stack) {
		return stack.method_28501().stream().map(p -> p.method_11899()).collect(Collectors.toList());
	}

	private Stream<Map.Entry<class_2769<?>, Comparable<?>>> getProp(class_2680 state, String property) {
		return state.method_11656().entrySet().stream().filter(e -> e.getKey().method_11899().equals(property));
	}

	@Override
	public String getPropertyValue(class_2680 state, String property) {
		return getProp(state, property).map(this::propValue).findFirst().orElse(null);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private String propValue(Map.Entry<class_2769<?>, Comparable<?>> e) {
		class_2769 p = e.getKey();
		return p.method_11901(e.getValue());
	}

	@Override
	public int getPropertyValueInt(class_2680 state, String property) {
		return getProp(state, property).mapToInt(e -> {
			Object o = state.method_11654(e.getKey());
			return o instanceof Number ? ((Number) o).intValue() : -1;
		}).findFirst().orElse(-1);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> getAllValuesFor(class_2680 state, String property) {
		return getProp(state, property).flatMap(e -> e.getKey().method_11898().stream().map(v -> {
			class_2769 p = e.getKey();
			return p.method_11901(v);
		})).collect(Collectors.toList());
	}

	@Override
	public List<String> listTags(class_2680 stack) {
		return class_3481.method_15073().method_30206(stack.method_26204()).stream().map(e -> "#" + e).collect(Collectors.toList());
	}

	@Override
	public List<com.tom.cpl.block.BlockState> listNativeEntries(String tag) {
		List<com.tom.cpl.block.BlockState> stacks = new ArrayList<>();
		if (tag.charAt(0) == '#') {
			class_2960 rl = class_2960.method_12829(tag.substring(1));
			if (rl != null) {
				class_3494<class_2248> i = class_3481.method_15073().method_30210(rl);
				i.method_15138().stream().map(b -> wrap(b.method_9564())).forEach(stacks::add);
			}
		} else {
			class_2960 rl = class_2960.method_12829(tag);
			class_2248 item = class_2378.field_11146.method_10223(rl);
			if (item != null) {
				stacks.add(wrap(item.method_9564()));
			}
		}
		return stacks;
	}

	@Override
	public List<String> listNativeTags() {
		return class_3481.method_15073().method_30211().stream().map(class_2960::toString).collect(Collectors.toList());
	}

	@Override
	public List<com.tom.cpl.block.BlockState> getAllElements() {
		return class_2378.field_11146.method_10220().map(b -> wrap(b.method_9564())).collect(Collectors.toList());
	}

	@Override
	public boolean isInTag(String tag, class_2680 stack) {
		if (tag.charAt(0) == '#') {
			class_2960 rl = class_2960.method_12829(tag.substring(1));
			if (rl != null) {
				class_3494<class_2248> i = class_3481.method_15073().method_30210(rl);
				return stack.method_26164(i);
			}
		} else {
			return getBlockId(stack).equals(tag);
		}
		return false;
	}

	@Override
	public boolean equals(class_2680 a, class_2680 b) {
		return a.method_26204() == b.method_26204();
	}

	@Override
	public Stack getStackFromState(class_2680 state) {
		return ItemStackHandlerImpl.impl.wrap(new class_1799(state.method_26204()));
	}

	@Override
	public boolean equalsFull(class_2680 a, class_2680 b) {
		return a.equals(b);
	}

	@Override
	public com.tom.cpl.block.BlockState emptyObject() {
		return wrap(class_2246.field_10124.method_9564());
	}
}

package com.tom.cpm.client;

import java.util.Random;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4581;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_563;
import net.minecraft.class_569;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_630;
import com.tom.cpl.math.Vec4f;
import com.tom.cpl.render.VBuffers;
import com.tom.cpm.client.MinecraftObject.DynTexture;
import com.tom.cpm.client.optifine.OptifineTexture;
import com.tom.cpm.client.optifine.RedirectRendererOF;
import com.tom.cpm.client.vr.VRPlayerRenderer;
import com.tom.cpm.shared.model.PlayerModelParts;
import com.tom.cpm.shared.model.RootModelType;
import com.tom.cpm.shared.model.TextureSheetType;
import com.tom.cpm.shared.model.render.BatchedBuffers;
import com.tom.cpm.shared.model.render.ModelRenderManager;
import com.tom.cpm.shared.model.render.VanillaModelPart;
import com.tom.cpm.shared.skin.TextureProvider;

public class PlayerRenderManager extends ModelRenderManager<class_4597, ModelTexture, class_630, class_3879> {
	public static final Function<class_2960, class_1921> armor = class_1921::method_25448;
	public static final Function<class_2960, class_1921> entity = class_1921::method_23580;

	public PlayerRenderManager() {
		setFactory(new RedirectHolderFactory<class_4597, ModelTexture, class_630>() {

			@SuppressWarnings("unchecked")
			@Override
			public <M> RedirectHolder<?, class_4597, ModelTexture, class_630> create(
					M model, String arg) {
				if("api".equals(arg) && model instanceof class_572) {
					return new RedirectHolderApi(PlayerRenderManager.this, (class_572<class_1309>) model);
				} else if(CustomPlayerModelsClient.vrLoaded && VRPlayerRenderer.isVRPlayer(model)) {
					return VRPlayerRenderer.createVRPlayer(PlayerRenderManager.this, model);
				} else if(model instanceof class_591) {
					return new RedirectHolderPlayer(PlayerRenderManager.this, (class_591<class_1309>) model);
				} else if(model instanceof class_569) {
					return new RedirectHolderSkull(PlayerRenderManager.this, (class_569) model);
				} else if(model instanceof class_563) {
					return new RedirectHolderElytra(PlayerRenderManager.this, (class_563<class_1309>) model);
				} else if(model instanceof class_572 && "armor1".equals(arg)) {
					return new RedirectHolderArmor1(PlayerRenderManager.this, (class_572<class_1309>) model);
				} else if(model instanceof class_572 && "armor2".equals(arg)) {
					return new RedirectHolderArmor2(PlayerRenderManager.this, (class_572<class_1309>) model);
				}
				return null;
			}
		});
		setRedirectFactory(new RedirectRendererFactory<class_3879, ModelTexture, class_630>() {

			@Override
			public RedirectRenderer<class_630> create(class_3879 model,
					RedirectHolder<class_3879, ?, ModelTexture, class_630> access,
					Supplier<class_630> modelPart, VanillaModelPart part) {
				return CustomPlayerModelsClient.optifineLoaded ?
						new RedirectRendererOF((RDH) access, modelPart, part) :
							new RedirectModelRendererVanilla((RDH) access, modelPart, part);
			}
		});
		setVis(m -> m.field_3665, (m, v) -> m.field_3665 = v);
		setModelPosGetters(m -> m.field_3657, m -> m.field_3656, m -> m.field_3655);
		setModelRotGetters(m -> m.field_3654, m -> m.field_3675, m -> m.field_3674);
		setModelSetters((m, x, y, z) -> {
			m.field_3657 = x;
			m.field_3656 = y;
			m.field_3655 = z;
		}, (m, x, y, z) -> {
			m.field_3654 = x;
			m.field_3675 = y;
			m.field_3674 = z;
		});
		setRenderPart(new class_630(0, 0, 0, 0));
	}

	public static abstract class RDH extends ModelRenderManager.RedirectHolder<class_3879, class_4597, ModelTexture, class_630> {

		public RDH(
				ModelRenderManager<class_4597, ModelTexture, class_630, class_3879> mngr,
				class_3879 model) {
			super(mngr, model);
			batch = new BatchedBuffers<>(this, class_4597::getBuffer);
		}

		@Override
		public void setupRenderSystem(ModelTexture cbi, TextureSheetType tex) {
			CustomPlayerModelsClient.mc.renderBuilder.build(renderTypes, cbi);
		}

		@Override
		protected void bindTexture(ModelTexture cbi, TextureProvider skin) {
			skin.bind();
			OptifineTexture.applyOptifineTexture(cbi.getTexture(), skin);
			cbi.setTexture(DynTexture.getBoundLoc());
		}

		@Override
		public void swapOut0() {
		}

		@Override
		public void swapIn0() {}
	}

	private static class RedirectHolderPlayer extends RDH {
		private RedirectRenderer<class_630> head;

		public RedirectHolderPlayer(PlayerRenderManager mngr, class_591<class_1309> model) {
			super(mngr, model);
			head = registerHead(new Field<>(    () -> model.field_3398    , v -> model.field_3398     = v, PlayerModelParts.HEAD));
			register(new Field<>(() -> model.field_3391    , v -> model.field_3391     = v, PlayerModelParts.BODY));
			register(new Field<>(() -> model.field_3401, v -> model.field_3401 = v, PlayerModelParts.RIGHT_ARM));
			register(new Field<>(() -> model.field_3390 , v -> model.field_3390  = v, PlayerModelParts.LEFT_ARM));
			register(new Field<>(() -> model.field_3392, v -> model.field_3392 = v, PlayerModelParts.RIGHT_LEG));
			register(new Field<>(() -> model.field_3397 , v -> model.field_3397  = v, PlayerModelParts.LEFT_LEG));

			register(new Field<>(() -> model.field_3394        , v -> model.field_3394         = v, null)).setCopyFrom(head);
			register(new Field<>(() -> model.field_3484 , v -> model.field_3484  = v, null));
			register(new Field<>(() -> model.field_3486, v -> model.field_3486 = v, null));
			register(new Field<>(() -> model.field_3482  , v -> model.field_3482   = v, null));
			register(new Field<>(() -> model.field_3479 , v -> model.field_3479  = v, null));
			register(new Field<>(() -> model.field_3483     , v -> model.field_3483      = v, null));

			register(new Field<>(() -> model.field_3485, v -> model.field_3485 = v, RootModelType.CAPE));
		}
	}

	private static class RedirectHolderApi extends RDH {
		private RedirectRenderer<class_630> head;

		public RedirectHolderApi(PlayerRenderManager mngr, class_572<class_1309> model) {
			super(mngr, model);
			head = registerHead(new Field<>(    () -> model.field_3398    , v -> model.field_3398     = v, PlayerModelParts.HEAD));
			register(new Field<>(() -> model.field_3391    , v -> model.field_3391     = v, PlayerModelParts.BODY));
			register(new Field<>(() -> model.field_3401, v -> model.field_3401 = v, PlayerModelParts.RIGHT_ARM));
			register(new Field<>(() -> model.field_3390 , v -> model.field_3390  = v, PlayerModelParts.LEFT_ARM));
			register(new Field<>(() -> model.field_3392, v -> model.field_3392 = v, PlayerModelParts.RIGHT_LEG));
			register(new Field<>(() -> model.field_3397 , v -> model.field_3397  = v, PlayerModelParts.LEFT_LEG));

			register(new Field<>(() -> model.field_3394        , v -> model.field_3394         = v, null)).setCopyFrom(head);
			if(model instanceof class_591) {
				class_591<class_1309> pm = (class_591<class_1309>) model;
				register(new Field<>(() -> pm.field_3484 , v -> pm.field_3484  = v, null));
				register(new Field<>(() -> pm.field_3486, v -> pm.field_3486 = v, null));
				register(new Field<>(() -> pm.field_3482  , v -> pm.field_3482   = v, null));
				register(new Field<>(() -> pm.field_3479 , v -> pm.field_3479  = v, null));
				register(new Field<>(() -> pm.field_3483     , v -> pm.field_3483      = v, null));

				register(new Field<>(() -> pm.field_3485, v -> pm.field_3485 = v, RootModelType.CAPE));
			}
		}

		@Override
		protected boolean isDirectMode() {
			return true;
		}
	}

	private static class RedirectHolderSkull extends RDH {

		public RedirectHolderSkull(PlayerRenderManager mngr, class_569 model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_3564, v -> model.field_3564 = v, PlayerModelParts.HEAD));
			register(new Field<>(() -> model.field_3377 , v -> model.field_3377  = v, null));
		}

	}

	private static class RedirectHolderElytra extends RDH {

		public RedirectHolderElytra(PlayerRenderManager mngr, class_563<class_1309> model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_3364, v -> model.field_3364 = v, RootModelType.ELYTRA_RIGHT));
			register(new Field<>(() -> model.field_3365,  v -> model.field_3365  = v, RootModelType.ELYTRA_LEFT));
		}

	}

	private static class RedirectHolderArmor1 extends RDH {

		public RedirectHolderArmor1(PlayerRenderManager mngr, class_572<class_1309> model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_3398,     v -> model.field_3398     = v, RootModelType.ARMOR_HELMET));
			register(new Field<>(() -> model.field_3391,     v -> model.field_3391     = v, RootModelType.ARMOR_BODY));
			register(new Field<>(() -> model.field_3401, v -> model.field_3401 = v, RootModelType.ARMOR_RIGHT_ARM));
			register(new Field<>(() -> model.field_3390,  v -> model.field_3390  = v, RootModelType.ARMOR_LEFT_ARM));
			register(new Field<>(() -> model.field_3392, v -> model.field_3392 = v, RootModelType.ARMOR_RIGHT_FOOT));
			register(new Field<>(() -> model.field_3397,  v -> model.field_3397  = v, RootModelType.ARMOR_LEFT_FOOT));

			register(new Field<>(() -> model.field_3394 , v -> model.field_3394  = v, null));
		}

	}

	private static class RedirectHolderArmor2 extends RDH {

		public RedirectHolderArmor2(PlayerRenderManager mngr, class_572<class_1309> model) {
			super(mngr, model);

			register(new Field<>(() -> model.field_3391,     v -> model.field_3391     = v, RootModelType.ARMOR_LEGGINGS_BODY));
			register(new Field<>(() -> model.field_3392, v -> model.field_3392 = v, RootModelType.ARMOR_RIGHT_LEG));
			register(new Field<>(() -> model.field_3397,  v -> model.field_3397  = v, RootModelType.ARMOR_LEFT_LEG));
		}

	}

	public static abstract class RedirectModelRendererBase extends class_630 implements RedirectRenderer<class_630> {
		protected final RDH holder;
		protected final VanillaModelPart part;
		protected final Supplier<class_630> parentProvider;
		protected class_630 parent;
		protected VBuffers buffers;

		public RedirectModelRendererBase(RDH holder, Supplier<class_630> parent, VanillaModelPart part) {
			super(0, 0, 0, 0);
			this.part = part;
			this.holder = holder;
			this.parentProvider = parent;
		}

		@Override
		public VBuffers getVBuffers() {
			return buffers;
		}

		@Override
		public class_630 swapIn() {
			if(parent != null)return this;
			parent = parentProvider.get();
			holder.copyModel(parent, this);
			return this;
		}

		@Override
		public class_630 swapOut() {
			if(parent == null)return parentProvider.get();
			class_630 p = parent;
			parent = null;
			return p;
		}

		@Override
		public RedirectHolder<?, ?, ?, class_630> getHolder() {
			return holder;
		}

		@Override
		public class_630 getParent() {
			return parent;
		}

		@Override
		public VanillaModelPart getPart() {
			return part;
		}

		protected float red, green, blue, alpha;

		@Override
		public Vec4f getColor() {
			return new Vec4f(red, green, blue, alpha);
		}

		@Override
		public void method_22703(class_4587 stack) {
			com.tom.cpl.math.MatrixStack.Entry e = getPartTransform();
			if(e != null) {
				multiplyStacks(e, stack);
			} else
				super.method_22703(stack);
		}

		@Override
		public class_628 method_22700(Random pRandom) {
			if(parent != null)return parent.method_22700(pRandom);
			return super.method_22700(pRandom);
		}
	}

	public static class RedirectModelRendererVanilla extends RedirectModelRendererBase {

		public RedirectModelRendererVanilla(RDH holder, Supplier<class_630> parent, VanillaModelPart part) {
			super(holder, parent, part);
		}

		private class_4587 matrixStackIn;
		private class_4588 bufferIn;
		private int packedLightIn, packedOverlayIn;

		@Override
		public void method_22699(class_4587 matrixStackIn, class_4588 bufferIn, int packedLightIn, int packedOverlayIn, float red, float green, float blue, float alpha) {
			if(!holder.renderTypes.isInitialized()) {
				holder.copyModel(this, parent);
				parent.method_22699(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
				holder.logWarning();
				return;
			}
			this.matrixStackIn   = matrixStackIn  ;
			this.bufferIn        = bufferIn       ;
			this.packedLightIn   = packedLightIn  ;
			this.packedOverlayIn = packedOverlayIn;
			this.red             = red            ;
			this.green           = green          ;
			this.blue            = blue           ;
			this.alpha           = alpha          ;
			this.buffers = holder.nextBatch(() -> new VBufferOut(packedLightIn, packedOverlayIn, matrixStackIn), bufferIn);
			//this.buffers = new VBuffers(rt -> new VBuffer(holder.addDt.getBuffer(rt.getNativeType()), packedLightIn, packedOverlayIn, matrixStackIn), new VBuffer(bufferIn, packedLightIn, packedOverlayIn, matrixStackIn));
			render();
			//holder.addDt.getBuffer(holder.renderTypes.get(RenderMode.DEFAULT).getNativeType());
			this.matrixStackIn = null;
			this.bufferIn = null;
		}

		@Override
		public void renderParent() {
			parent.method_22699(matrixStackIn, bufferIn, packedLightIn, packedOverlayIn, red, green, blue, alpha);
		}
	}

	public static void multiplyStacks(com.tom.cpl.math.MatrixStack.Entry e, class_4587 stack) {
		stack.method_23760().method_23761().method_22672(Platform.createMatrix(e.getMatrixArray()));
		stack.method_23760().method_23762().method_22855(new class_4581(Platform.createMatrix(e.getNormalArray())));
	}
}

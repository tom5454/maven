package com.tom.cpm.client.vr;

import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.shared.animation.AnimationState.VRState;
import com.tom.cpm.shared.model.render.ModelRenderManager.RedirectHolder;
import net.minecraft.class_4597;
import net.minecraft.class_630;

public class VRPlayerRenderer {

	public static <M> boolean isVRPlayer(M model) {
		return false;
	}

	public static <M> RedirectHolder<?, class_4597, ModelTexture, class_630> createVRPlayer(
			PlayerRenderManager playerRenderManager, M model) {
		throw new UnsupportedOperationException();
	}

	public static VRState getVRState(Object model) {
		return VRState.FIRST_PERSON;
	}
}

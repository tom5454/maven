package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import com.tom.cpm.client.LivingRendererAccess;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_3883;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_898;
import net.minecraft.class_922;

@Mixin(class_922.class)
public abstract class LivingRendererMixin<T extends class_1309, M extends class_583<T>> extends class_897<T> implements class_3883<T, M>, LivingRendererAccess {

	protected LivingRendererMixin(class_898 p_i46179_1_) {
		super(p_i46179_1_);
	}

	@Inject(at = @At("HEAD"), method = "getRenderType(Lnet/minecraft/entity/LivingEntity;ZZZ)Lnet/minecraft/client/renderer/RenderType;", cancellable = true)
	public void onGetRenderType(class_1309 player, boolean pBodyVisible, boolean pTranslucent, boolean pGlowing, CallbackInfoReturnable<class_1921> cbi) {
		if(!pBodyVisible) {
			cpm$onGetRenderType(player, pTranslucent, pGlowing, cbi);
		}
	}

	@Override
	public void cpm$onGetRenderType(class_1309 player, boolean pTranslucent, boolean pGlowing, CallbackInfoReturnable<class_1921> cbi) {}
}

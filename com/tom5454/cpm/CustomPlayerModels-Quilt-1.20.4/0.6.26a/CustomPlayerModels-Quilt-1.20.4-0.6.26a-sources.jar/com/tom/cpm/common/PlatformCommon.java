package com.tom.cpm.common;

import java.util.List;
import net.minecraft.class_1320;
import net.minecraft.class_1959;
import com.tom.cpm.shared.util.Log;

public class PlatformCommon {

	public static class_1959.class_5482 getClimateSettings(class_1959 b) {
		return b.field_26393;
	}

	public static List<class_1320> getReachAttr() {
		try {
			Class<?> clz = Class.forName("com.jamieswhiteshirt.reachentityattributes.ReachEntityAttributes");
			class_1320 a1 = (class_1320) clz.getDeclaredField("REACH").get(null);
			class_1320 a2 = (class_1320) clz.getDeclaredField("ATTACK_RANGE").get(null);
			Log.info("Loaded Reach Entity Attributes scaler");
			return List.of(a1, a2);
		} catch (Throwable e) {
		}
		return null;
	}

	public static List<class_1320> getStepHeightAttr() {
		return null;
	}
}

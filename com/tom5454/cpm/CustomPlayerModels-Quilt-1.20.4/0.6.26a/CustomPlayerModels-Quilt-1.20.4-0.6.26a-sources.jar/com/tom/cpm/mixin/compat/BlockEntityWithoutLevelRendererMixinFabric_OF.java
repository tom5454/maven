package com.tom.cpm.mixin.compat;

import java.util.Map;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2190;
import net.minecraft.class_2248;
import net.minecraft.class_2484;
import net.minecraft.class_2487;
import net.minecraft.class_2631;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5598;
import net.minecraft.class_756;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.mojang.authlib.GameProfile;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.RefHolder;

@Mixin(class_756.class)
public class BlockEntityWithoutLevelRendererMixinFabric_OF {
	private @Shadow Map<class_2484.class_2485, class_5598> skullModels;

	@Inject(at = @At("HEAD"), method = "renderRaw", require = 0, remap = false)
	//Optifine
	public void onRenderOF(class_1799 itemStack, class_4587 matrices, class_4597 multiBufferSource, int light, int arg5, CallbackInfo ci) {
		class_1792 item = itemStack.method_7909();
		if (item instanceof class_1747) {
			class_2248 block = ((class_1747)item).method_7711();
			if (block instanceof class_2190) {
				class_2487 compoundTag = itemStack.method_7969();
				GameProfile gameProfile = compoundTag != null
						? class_2631.method_52589(compoundTag)
								: null;
				class_2484.class_2485 skullType = ((class_2190)block).method_9327();
				class_5598 skullmodelbase = this.skullModels.get(skullType);
				RefHolder.CPM_MODELS = skullModels;
				if(skullType == class_2484.class_2486.field_11510 && gameProfile != null) {
					CustomPlayerModelsClient.INSTANCE.renderSkull(skullmodelbase, gameProfile, multiBufferSource);
				}
			}
		}
	}
}

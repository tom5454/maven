package com.tom.cpm.client;

import java.nio.FloatBuffer;
import net.minecraft.class_2960;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4597.class_4598;
import net.minecraft.class_4608;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import com.mojang.blaze3d.systems.RenderSystem;
import com.tom.cpl.math.Box;
import com.tom.cpl.math.Mat4f;
import com.tom.cpl.math.Vec2i;
import com.tom.cpl.render.RenderTypes;
import com.tom.cpl.render.VBuffers;
import com.tom.cpl.util.Image;
import com.tom.cpm.client.MinecraftObject.DynTexture;
import com.tom.cpm.shared.gui.ViewportCamera;
import com.tom.cpm.shared.gui.panel.Panel3d;
import com.tom.cpm.shared.gui.panel.Panel3d.Panel3dNative;
import com.tom.cpm.shared.model.render.RenderMode;

public class Panel3dImpl extends Panel3dNative {
	private class_310 mc;

	public Panel3dImpl(Panel3d panel) {
		super(panel);
		mc = class_310.method_1551();
	}

	@Override
	public void render(float partialTicks) {
		RenderSystem.backupProjectionMatrix();
		ViewportCamera cam = panel.getCamera();
		float pitch = (float) Math.asin(cam.look.y);
		float yaw = cam.look.getYaw();
		Box bounds = getBounds();
		Vec2i off = panel.getGui().getOffset();
		float size = cam.camDist;

		GuiBase gui = panel.getGui().getNativeGui();
		class_332 guiGraphics = gui.getMCGraphics();

		Quaternionf quaternion = class_7833.field_40718.rotationDegrees(180.0F);
		Quaternionf quaternion1 = class_7833.field_40714.rotation(-pitch);
		quaternion.mul(quaternion1);

		try {
			guiGraphics.method_51448().method_22903();
			guiGraphics.method_51448().method_46416(off.x + bounds.w / 2, off.y + bounds.h / 2, 100.0f);
			guiGraphics.method_51448().method_34425(new Matrix4f().scaling(size, size, -size / 10f));
			guiGraphics.method_51448().method_22907(quaternion);
			class_308.method_34742();

			guiGraphics.method_51448().method_22907(class_7833.field_40716.rotation((float) (yaw + Math.PI)));
			guiGraphics.method_51448().method_46416(-cam.position.x, -cam.position.y, -cam.position.z);

			class_4598 bufs = guiGraphics.method_51450();
			int light = class_765.method_23687(15, 15);
			panel.render(new com.tom.cpl.math.MatrixStack(), new VBuffers(rt -> new VBuffer(bufs.getBuffer(rt.getNativeType()), light, class_4608.field_21444, guiGraphics.method_51448())), partialTicks);
			bufs.method_22993();
		} finally {
			guiGraphics.method_51448().method_22909();
			class_308.method_24211();
		}
	}

	@Override
	public RenderTypes<RenderMode> getRenderTypes() {
		return getRenderTypes0(DynTexture.getBoundLoc());
	}

	@Override
	public RenderTypes<RenderMode> getRenderTypes(String texture) {
		return getRenderTypes0(new class_2960("cpm", "textures/gui/" + texture + ".png"));
	}

	@Override
	public Image takeScreenshot(Vec2i size) {
		GuiBase gui = panel.getGui().getNativeGui();
		int dw = mc.method_22683().method_4489();
		int dh = mc.method_22683().method_4506();
		float multiplierX = dw / (float)gui.field_22789;
		float multiplierY = dh / (float)gui.field_22790;
		int width = (int) (multiplierX * size.x);
		int height = (int) (multiplierY * size.y);
		FloatBuffer buffer = BufferUtils.createFloatBuffer(width * height * 3);
		GL11.glReadPixels((int) (multiplierX * renderPos.x), mc.method_22683().method_4506() - height - (int) (multiplierY * renderPos.y), width, height, GL11.GL_RGB, GL11.GL_FLOAT, buffer);
		Image img = new Image(width, height);
		for(int y = 0;y<height;y++) {
			for(int x = 0;x<width;x++) {
				float r = buffer.get((x + y * width) * 3);
				float g = buffer.get((x + y * width) * 3 + 1);
				float b = buffer.get((x + y * width) * 3 + 2);
				int color = 0xff000000 | (((int)(r * 255)) << 16) | (((int)(g * 255)) << 8) | ((int)(b * 255));
				img.setRGB(x, height - y - 1, color);
			}
		}
		Image rImg = new Image(size.x, size.y);
		rImg.draw(img, 0, 0, size.x, size.y);
		return rImg;
	}

	@Override
	public Mat4f getView() {
		GuiBase gui = panel.getGui().getNativeGui();
		return Mat4f.map(gui.getMCGraphics().method_51448().method_23760().method_23761(), Matrix4f::get);
	}

	@Override
	public Mat4f getProjection() {
		return Mat4f.map(RenderSystem.getProjectionMatrix(), Matrix4f::get);
	}
}

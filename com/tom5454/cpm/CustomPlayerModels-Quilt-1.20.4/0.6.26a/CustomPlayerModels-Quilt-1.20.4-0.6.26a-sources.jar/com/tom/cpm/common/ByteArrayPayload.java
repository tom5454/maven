package com.tom.cpm.common;

import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

public record ByteArrayPayload(class_2960 id, byte[] data) implements class_8710 {

	public ByteArrayPayload(class_2960 id, class_2540 b) {
		this(id, toArray(b));
	}

	@Override
	public void method_53028(class_2540 b) {
		b.method_52983(data);
	}

	private static byte[] toArray(class_2540 b) {
		byte[] d = new byte[b.readableBytes()];
		b.method_52979(d);
		return d;
	}
}

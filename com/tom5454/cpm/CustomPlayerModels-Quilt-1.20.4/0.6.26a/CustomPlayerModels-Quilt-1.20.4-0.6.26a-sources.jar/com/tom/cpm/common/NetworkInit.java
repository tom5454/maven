package com.tom.cpm.common;

import java.util.HashMap;
import java.util.concurrent.Executor;
import net.minecraft.class_2658;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import com.tom.cpm.shared.network.NetHandler;

public class NetworkInit {
	private static boolean initialized = false;

	public static void initNetworking(NetHandler<class_2960, ?, ?> netH, Executor exec) {
		if(initialized)return;
		initialized = true;
		exec.execute(() -> {
			class_2658.field_45693 = new HashMap<>(class_2658.field_45693);
			class_2817.field_45694 = new HashMap<>(class_2817.field_45694);
			netH.registerIn(id -> class_2817.field_45694.put(id, b -> new ByteArrayPayload(id, b)));
			netH.registerOut(id -> class_2658.field_45693.put(id, b -> new ByteArrayPayload(id, b)));
		});
	}
}

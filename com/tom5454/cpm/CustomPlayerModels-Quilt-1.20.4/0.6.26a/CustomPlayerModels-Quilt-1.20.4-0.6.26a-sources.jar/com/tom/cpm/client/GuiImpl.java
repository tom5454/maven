package com.tom.cpm.client;

import java.util.function.Function;
import net.minecraft.class_332;
import net.minecraft.class_437;
import com.tom.cpl.gui.Frame;
import com.tom.cpl.gui.IGui;

public class GuiImpl extends GuiBase {

	public GuiImpl(Function<IGui, Frame> creator, class_437 parent) {
		super(creator, parent);
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTicks) {
		super.method_25394(graphics, mouseX, mouseY, partialTicks);
		if(field_22787.field_1724 != null && gui.enableChat()) {
			graphics.method_51448().method_22903();
			graphics.method_51448().method_46416(0, 0, 800);
			field_22787.field_1705.method_1743().method_1805(graphics, field_22787.field_1705.method_1738(), mouseX, mouseY);
			graphics.method_51448().method_22909();
		}
	}
}

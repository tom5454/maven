package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Desc;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.PlayerRenderManager;
import com.tom.cpm.shared.model.TextureSheetType;
import net.minecraft.class_1309;
import net.minecraft.class_1738;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;

@Mixin(class_970.class)
public abstract class HumanoidArmorLayerMixin extends class_3887<class_1309, class_572<class_1309>> {

	public HumanoidArmorLayerMixin(class_3883<class_1309, class_572<class_1309>> pRenderer) {
		super(pRenderer);
	}

	private @Final @Shadow class_572<class_1309> innerModel;
	private @Final @Shadow class_572<class_1309> outerModel;
	@Shadow abstract class_2960 getArmorLocation(class_1738 armorItem, boolean bl, String string);

	@Inject(at = @At("HEAD"),
			method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I"
					+ "Lnet/minecraft/world/entity/LivingEntity;FFFFFF)V")
	public void preRender(class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, class_1309 entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo cbi) {
		if(method_17165() instanceof class_572) {
			CustomPlayerModelsClient.INSTANCE.renderArmor(outerModel, innerModel, method_17165());
		}
	}

	@Inject(at = @At("RETURN"),
			method = "render(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I"
					+ "Lnet/minecraft/world/entity/LivingEntity;FFFFFF)V")
	public void postRender(class_4587 matrixStackIn, class_4597 bufferIn, int packedLightIn, class_1309 entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.manager.unbind(outerModel);
		CustomPlayerModelsClient.INSTANCE.manager.unbind(innerModel);
	}

	@Inject(at = @At("HEAD"), method = "renderModel(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I"
			+ "Lnet/minecraft/world/item/ArmorItem;Lnet/minecraft/client/model/HumanoidModel;ZFFFLjava/lang/String;)V")
	private void preRenderTexture(class_4587 p_117107_, class_4597 p_117108_, int p_117109_, class_1738 p_117110_, class_572<class_1309> model, boolean p_117113_, float p_117114_, float p_117115_, float p_117116_, String p_117117_, CallbackInfo cbi) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, new ModelTexture(getArmorLocation(p_117110_, p_117113_, p_117117_), PlayerRenderManager.armor), model == innerModel ? TextureSheetType.ARMOR2 : TextureSheetType.ARMOR1);
	}

	@Inject(at = @At("HEAD"), target = @Desc(value = "renderModel", args = {class_4587.class, class_4597.class, int.class, class_1738.class, class_3879.class, boolean.class, float.class, float.class, float.class, class_2960.class}), remap = false, require = 0, expect = 0)
	private void preRenderTexture(class_4587 p_289664_, class_4597 p_289689_, int p_289681_, class_1738 p_289650_, net.minecraft.class_3879 model, boolean p_289668_, float p_289678_, float p_289674_, float p_289693_, class_2960 resLoc, CallbackInfo cbi) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, new ModelTexture(resLoc, PlayerRenderManager.armor), model == innerModel ? TextureSheetType.ARMOR2 : TextureSheetType.ARMOR1);
	}

	@Inject(at = @At("HEAD"), target = @Desc(value = "renderModel", args = {class_4587.class, class_4597.class, int.class, class_1738.class, class_572.class, boolean.class, float.class, float.class, float.class, class_2960.class}), remap = false, require = 0, expect = 0)
	private void preRenderTexture(class_4587 p_289664_, class_4597 p_289689_, int p_289681_, class_1738 p_289650_, class_572 model, boolean p_289668_, float p_289678_, float p_289674_, float p_289693_, class_2960 resLoc, CallbackInfo cbi) {
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, new ModelTexture(resLoc, PlayerRenderManager.armor), model == innerModel ? TextureSheetType.ARMOR2 : TextureSheetType.ARMOR1);
	}
}

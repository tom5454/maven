package com.tom.cpm.client;

import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer;
import org.quiltmc.qsl.command.api.client.ClientCommandRegistrationCallback;
import org.quiltmc.qsl.lifecycle.api.client.event.ClientTickEvents;
import org.quiltmc.qsl.resource.loader.api.ResourceLoader;
import org.quiltmc.qsl.screen.api.client.ScreenEvents;
import com.tom.cpl.tag.AllTagManagers;
import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.shared.config.ConfigKeys;
import com.tom.cpm.shared.config.ModConfig;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.editor.gui.EditorGui;
import com.tom.cpm.shared.gui.GestureGui;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_4185;
import net.minecraft.class_440;
import net.minecraft.class_442;

public class CustomPlayerModelsClient extends ClientBase implements ClientModInitializer {
	public static CustomPlayerModelsClient INSTANCE;

	@Override
	public void onInitializeClient(ModContainer container) {
		CustomPlayerModels.LOG.info("Customizable Player Models Client Init started");
		INSTANCE = this;
		init0();
		mc.setTags(new AllTagManagers(ResourceLoader.get(class_3264.field_14188), CPMTagLoaderFabric::new));
		ClientTickEvents.START.register(cl -> {
			if(!cl.method_1493())
				mc.getPlayerRenderManager().getAnimationEngine().tick();
		});
		KeyBindings.init();
		ClientTickEvents.END.register(client -> {
			if (client.field_1724 == null)
				return;

			if(KeyBindings.gestureMenuBinding.method_1436()) {
				client.method_1507(new GuiImpl(GestureGui::new, null));
			}

			if(KeyBindings.renderToggleBinding.method_1436()) {
				Player.setEnableRendering(!Player.isEnableRendering());
			}

			mc.getPlayerRenderManager().getAnimationEngine().updateKeys(KeyBindings.quickAccess);

			CustomPlayerModels.api.clientApi().tickListeners(minecraft.method_1493());
		});
		ScreenEvents.AFTER_INIT.register((screen, client, firstInit) -> {
			if((screen instanceof class_442 && ModConfig.getCommonConfig().getSetBoolean(ConfigKeys.TITLE_SCREEN_BUTTON, true)) ||
					screen instanceof class_440) {
				screen.getButtons().add(
						class_4185.method_46430(class_2561.method_43471("button.cpm.open_editor"), b -> class_310.method_1551().method_1507(new GuiImpl(EditorGui::new, screen))).
						method_46434(0, 0, 100, 20).method_46431());
			}
		});
		ScreenEvents.BEFORE_RENDER.register((_1, _2, _3, _4, _5) -> PlayerProfile.inGui = true);
		ScreenEvents.AFTER_RENDER.register((_1, _2, _3, _4, _5) -> PlayerProfile.inGui = false);
		init1();
		ClientCommandRegistrationCallback.EVENT.register((d, b, e) -> new ClientCommand(d));
		CustomPlayerModels.LOG.info("Customizable Player Models Client Initialized");
		apiInit();
	}

	public void onLogout() {
		mc.onLogOut();
	}
}

package com.tom.cpm.client;

import org.joml.Matrix3f;
import org.joml.Matrix4f;
import com.tom.cpm.shared.model.render.BatchedBuffers.BufferOutput;
import net.minecraft.class_4587;
import net.minecraft.class_4588;

public class VBufferOut implements BufferOutput<class_4588> {
	private int light, overlay;
	private Matrix4f mat4;
	private Matrix3f mat3;

	public VBufferOut(int light, int overlay, class_4587 matrixStackIn) {
		this.light = light;
		this.overlay = overlay;
		mat4 = new Matrix4f(matrixStackIn.method_23760().method_23761());
		mat3 = new Matrix3f(matrixStackIn.method_23760().method_23762());
	}

	@Override
	public void push(class_4588 buffer, float x, float y, float z, float red, float green,
			float blue, float alpha, float u, float v, float nx, float ny, float nz) {
		buffer.method_22918(mat4, x, y, z);
		buffer.method_22915(red, green, blue, alpha);
		buffer.method_22913(u, v);
		buffer.method_22922(overlay);
		buffer.method_22916(light);
		buffer.method_23763(mat3, nx, ny, nz);
		buffer.method_1344();
	}
}

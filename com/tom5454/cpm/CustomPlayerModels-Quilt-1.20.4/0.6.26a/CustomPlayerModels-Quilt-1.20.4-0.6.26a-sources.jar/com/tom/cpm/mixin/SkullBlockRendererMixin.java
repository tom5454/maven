package com.tom.cpm.mixin;

import java.util.Map;
import net.minecraft.class_1921;
import net.minecraft.class_2350;
import net.minecraft.class_2484;
import net.minecraft.class_2631;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5598;
import net.minecraft.class_836;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import com.mojang.authlib.GameProfile;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.client.ModelTexture;
import com.tom.cpm.client.RefHolder;
import com.tom.cpm.shared.model.TextureSheetType;

@Mixin(class_836.class)
public class SkullBlockRendererMixin {
	@Shadow private @Final Map<class_2484.class_2485, class_5598> modelByType;

	@Inject(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/blockentity/SkullBlockRenderer;"
					+ "getRenderType(Lnet/minecraft/world/level/block/SkullBlock$Type;Lcom/mojang/authlib/GameProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;"
			),
			method = "render(Lnet/minecraft/world/level/block/entity/SkullBlockEntity;F"
					+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;II)V",
					locals = LocalCapture.CAPTURE_FAILHARD)
	public void onRender(class_2631 skullBlockEntity, float f, class_4587 matrixStack, class_4597 buffer, int i, int arg5, CallbackInfo ci, float g, class_2680 blockState, boolean bl, class_2350 direction, int k, float h, class_2484.class_2485 skullType, class_5598 model) {
		RefHolder.CPM_MODELS = modelByType;
		GameProfile gameProfile = skullBlockEntity.method_11334();
		if(skullType == class_2484.class_2486.field_11510 && gameProfile != null) {
			CustomPlayerModelsClient.INSTANCE.renderSkull(model, gameProfile, buffer);
		}
	}

	@Redirect(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/RenderType;entityTranslucent("
					+ "Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"
			),
			method = "getRenderType(Lnet/minecraft/world/level/block/SkullBlock$Type;Lcom/mojang/authlib/GameProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;")
	private static class_1921 onGetRenderType(class_2960 resLoc, class_2484.class_2485 skullType, GameProfile gameProfileIn) {
		if(RefHolder.CPM_MODELS == null)return class_1921.method_23580(resLoc);
		class_5598 model = RefHolder.CPM_MODELS.get(skullType);
		RefHolder.CPM_MODELS = null;
		ModelTexture mt = new ModelTexture(resLoc);
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.SKIN);
		return mt.getRenderType();
	}

	@Redirect(at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/renderer/RenderType;entityCutoutNoCullZOffset("
					+ "Lnet/minecraft/resources/ResourceLocation;)Lnet/minecraft/client/renderer/RenderType;"
			),
			method = "getRenderType(Lnet/minecraft/world/level/block/SkullBlock$Type;Lcom/mojang/authlib/GameProfile;)"
					+ "Lnet/minecraft/client/renderer/RenderType;")
	private static class_1921 onGetRenderTypeNoSkin(class_2960 resLoc, class_2484.class_2485 skullType, GameProfile gameProfileIn) {
		if(RefHolder.CPM_MODELS == null)return class_1921.method_28116(resLoc);
		class_5598 model = RefHolder.CPM_MODELS.get(skullType);
		RefHolder.CPM_MODELS = null;
		ModelTexture mt = new ModelTexture(resLoc);
		CustomPlayerModelsClient.mc.getPlayerRenderManager().bindSkin(model, mt, TextureSheetType.SKIN);
		return mt.getRenderType();
	}

	@Inject(at = @At("RETURN"),
			method = "renderSkull(Lnet/minecraft/core/Direction;FF"
					+ "Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;I"
					+ "Lnet/minecraft/client/model/SkullModelBase;Lnet/minecraft/client/renderer/RenderType;)V")
	private static void renderSkullPost(class_2350 direction, float yaw, float animationProgress, class_4587 matrices, class_4597 vertexConsumers, int light, class_5598 model, class_1921 renderLayer, CallbackInfo cbi) {
		CustomPlayerModelsClient.INSTANCE.renderSkullPost(vertexConsumers, model);
	}
}

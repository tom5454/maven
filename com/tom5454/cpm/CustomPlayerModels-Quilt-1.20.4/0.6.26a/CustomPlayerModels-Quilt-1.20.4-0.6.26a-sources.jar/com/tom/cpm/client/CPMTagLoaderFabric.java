package com.tom.cpm.client;

import org.quiltmc.qsl.resource.loader.api.ResourceLoader;
import org.quiltmc.qsl.resource.loader.api.reloader.IdentifiableResourceReloader;
import com.tom.cpl.tag.TagManager;
import net.minecraft.class_2960;

public class CPMTagLoaderFabric extends CPMTagLoader implements IdentifiableResourceReloader {

	public CPMTagLoaderFabric(ResourceLoader mc, TagManager<?> tags, String prefix) {
		super(l -> mc.registerReloader((CPMTagLoaderFabric) l), tags, prefix);
	}

	@Override
	public class_2960 getQuiltId() {
		return id;
	}
}
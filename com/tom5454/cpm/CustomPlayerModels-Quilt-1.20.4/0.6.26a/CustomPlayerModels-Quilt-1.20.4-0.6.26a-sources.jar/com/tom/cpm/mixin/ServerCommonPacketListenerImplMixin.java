package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.common.ByteArrayPayload;
import com.tom.cpm.common.ServerNetHandler;
import net.minecraft.class_2817;
import net.minecraft.class_8609;

@Mixin(class_8609.class)
public class ServerCommonPacketListenerImplMixin implements ServerNetHandler {

	@Inject(at = @At("HEAD"), method = "handleCustomPayload(Lnet/minecraft/network/protocol/common/ServerboundCustomPayloadPacket;)V", cancellable = true)
	public void onProcessCustomPayload(class_2817 packet, CallbackInfo cbi) {
		if(packet.comp_1647() instanceof ByteArrayPayload p) {
			cpm$handleCustomPayload(p);
			cbi.cancel();
		}
	}
}

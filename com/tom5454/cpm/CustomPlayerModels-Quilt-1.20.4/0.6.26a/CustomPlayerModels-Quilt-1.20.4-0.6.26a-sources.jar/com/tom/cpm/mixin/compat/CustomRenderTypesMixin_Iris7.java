package com.tom.cpm.mixin.compat;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import net.irisshaders.batchedentityrendering.impl.BlendingStateHolder;
import net.irisshaders.batchedentityrendering.impl.TransparencyType;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import com.tom.cpm.client.CustomRenderTypes;

@Mixin(CustomRenderTypes.class)
public class CustomRenderTypesMixin_Iris7 {

	@Overwrite(remap = false)
	public static class_1921 glowingEyes(class_2960 rl) {
		class_1921 rt = class_1921.method_23026(rl);
		((BlendingStateHolder) rt).setTransparencyType(TransparencyType.DECAL);
		return rt;
	}
}

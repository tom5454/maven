package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.common.ByteArrayPayload;
import com.tom.cpm.shared.io.FastByteArrayInputStream;
import com.tom.cpm.shared.network.NetH;
import net.minecraft.class_634;
import net.minecraft.class_8588;
import net.minecraft.class_8710;

@Mixin(class_634.class)
public class ClientPacketListenerMixin implements NetH {
	private boolean cpm$hasMod;

	@Override
	public boolean cpm$hasMod() {
		return cpm$hasMod;
	}

	@Override
	public void cpm$setHasMod(boolean v) {
		this.cpm$hasMod = v;
	}

	@Inject(at = @At("HEAD"), method = "handleCustomPayload(Lnet/minecraft/network/protocol/common/custom/CustomPacketPayload;)V", cancellable = true, require = 0)
	public void onHandleCustomPayload(class_8710 packet, CallbackInfo cbi) {
		if(packet instanceof ByteArrayPayload p) {
			CustomPlayerModelsClient.INSTANCE.netHandler.receiveClient(packet.comp_1678(), new FastByteArrayInputStream(p.data()), this);
			cbi.cancel();
		}
	}

	@Inject(at = @At("RETURN"), method = "handleConfigurationStart(Lnet/minecraft/network/protocol/game/ClientboundStartConfigurationPacket;)V", cancellable = true)
	public void onReconfigure(class_8588 packet, CallbackInfo cbi) {
		CustomPlayerModelsClient.mc.onLogOut();
	}
}

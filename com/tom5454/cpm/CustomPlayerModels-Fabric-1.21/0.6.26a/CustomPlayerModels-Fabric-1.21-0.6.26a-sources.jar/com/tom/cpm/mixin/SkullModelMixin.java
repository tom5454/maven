package com.tom.cpm.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import com.tom.cpm.client.PlayerRenderManager.RedirectModelRendererBase;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_607;
import net.minecraft.class_630;

@Mixin(class_607.class)
public class SkullModelMixin {
	public @Shadow class_630 head;

	@Inject(at = @At("HEAD"), method = "renderToBuffer(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;III)V", cancellable = true)
	public void renderToBuffer(class_4587 ps, class_4588 p_103816_, int p_103817_, int p_103818_, int p_103819_, CallbackInfo cbi) {
		if (head instanceof RedirectModelRendererBase) {
			head.method_22699(ps, p_103816_, p_103817_, p_103818_, p_103819_);
			cbi.cancel();
		}
	}
}

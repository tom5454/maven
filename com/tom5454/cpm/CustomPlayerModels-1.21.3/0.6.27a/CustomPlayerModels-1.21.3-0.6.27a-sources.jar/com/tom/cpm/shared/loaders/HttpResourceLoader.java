package com.tom.cpm.shared.loaders;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Base64;
import java.util.zip.GZIPInputStream;

import com.tom.cpm.shared.config.ConfigKeys;
import com.tom.cpm.shared.config.ResourceLoader;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.definition.SafetyException.BlockReason;
import com.tom.cpm.shared.io.HTTPIO;

public abstract class HttpResourceLoader implements ResourceLoader {

	protected abstract URL createURL(String path) throws IOException;

	@Override
	public byte[] loadResource(String path, ResourceEncoding enc, ModelDefinition def) throws IOException {
		URL url = createURL(path);
		return loadResource(url, enc, def);
	}

	protected byte[] loadResource(URL url, ResourceEncoding enc, ModelDefinition def) throws IOException {
		InputStream web = null;
		HttpURLConnection connection = null;
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			connection = HTTPIO.createUrlConnection(url, false);
			connection.setRequestProperty("Accept-Encoding", "gzip");
			web = connection.getInputStream();

			if ("gzip".equals(connection.getContentEncoding())) {
				web = new GZIPInputStream(web);
			}

			byte[] buffer = new byte[10240];

			int totalBytesDownloaded = 0;
			int bytesJustDownloaded = 0;
			while((bytesJustDownloaded = web.read(buffer)) > 0) {
				out.write(buffer, 0, bytesJustDownloaded);
				totalBytesDownloaded += bytesJustDownloaded;
				if(def != null)
					def.check(ConfigKeys.MAX_LINK_SIZE, totalBytesDownloaded / 1024, BlockReason.LINK_OVERFLOW);
			}
			switch (enc) {
			case NO_ENCODING:
				return out.toByteArray();

			case BASE64:
				return Base64.getDecoder().decode(new String(out.toByteArray()));

			default:
				throw new IOException("Unsupported file encoding");
			}
		} finally {
			if(connection != null)connection.disconnect();
			if(web != null)
				try {
					web.close();
				} catch (IOException e) {
				}
		}
	}

}

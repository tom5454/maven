package com.tom.cpm;

import java.io.File;
import java.util.Collections;
import java.util.EnumSet;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.event.lifecycle.InterModProcessEvent;
import net.neoforged.fml.loading.FMLEnvironment;
import net.neoforged.fml.loading.FMLPaths;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.common.NeoForgeVersion;
import net.neoforged.neoforge.common.VersionChecker;
import net.neoforged.neoforge.event.server.ServerStartingEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.HandlerThread;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

import com.tom.cpl.config.ModConfigFile;
import com.tom.cpm.api.CPMPlugin;
import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.common.AnnotationFinder;
import com.tom.cpm.common.PlatformCommon.PacketRegistryP;
import com.tom.cpm.common.ServerHandler;
import com.tom.cpm.shared.MinecraftObjectHolder;
import com.tom.cpm.shared.PlatformFeature;
import com.tom.cpm.shared.config.ModConfig;
import com.tom.cpm.shared.util.IVersionCheck;
import com.tom.cpm.shared.util.VersionCheck;

@Mod("cpm")
public class CustomPlayerModels extends CommonBase {

	public CustomPlayerModels(IEventBus bus) {
		bus.addListener(this::doClientStuff);
		bus.addListener(this::setup);
		bus.addListener(this::processIMC);
		bus.addListener(this::onPayloadRegister);
		MinecraftObjectHolder.setCommonObject(this);

		if (FMLEnvironment.getDist() == Dist.CLIENT) CustomPlayerModelsClient.INSTANCE.preInit(bus);

		NeoForge.EVENT_BUS.register(this);
	}

	private void doClientStuff(final FMLClientSetupEvent event) {
		CustomPlayerModelsClient.INSTANCE.init();
	}

	public void setup(FMLCommonSetupEvent evt) {
		cfg = new ModConfigFile(new File(FMLPaths.CONFIGDIR.get().toFile(), "cpm.json"));
		NeoForge.EVENT_BUS.register(new ServerHandler());
		LOG.info("Customizable Player Models Initialized");
	}

	private void processIMC(final InterModProcessEvent event) {
		event.getIMCStream().forEach(m -> {
			if(m.method().equals("api")) {
				api.registerSupplier(m.senderModId(), m.messageSupplier());
			}
		});
		AnnotationFinder.getInstances(CPMPlugin.class).forEach(api::registerPluginClass);
		apiInit();
		if(FMLEnvironment.getDist() == Dist.CLIENT)CustomPlayerModelsClient.apiInit();
	}

	@SubscribeEvent
	public void onStart(ServerStartingEvent e) {
		MinecraftObjectHolder.setServerObject(new MinecraftServerObject(e.getServer()));
	}

	@SubscribeEvent
	public void onStop(ServerStoppingEvent e) {
		ModConfig.getWorldConfig().save();
		MinecraftObjectHolder.setServerObject(null);
	}

	private void onPayloadRegister(RegisterPayloadHandlersEvent event) {
		PayloadRegistrar registrar = event.registrar("1").optional().executesOn(HandlerThread.NETWORK);
		PacketRegistryP.register(registrar::playToClient, registrar::playToServer, registrar::playBidirectional);
	}

	private static final EnumSet<PlatformFeature> features = EnumSet.of(
			PlatformFeature.EDITOR_HELD_ITEM,
			PlatformFeature.EDITOR_SUPPORTED
			);

	@Override
	public EnumSet<PlatformFeature> getSupportedFeatures() {
		return features;
	}

	@Override
	public String getMCBrand() {
		return "(neoforge/" + NeoForgeVersion.getVersion() + ")";
	}

	@Override
	public String getModVersion() {
		return ModList.get().getModContainerById("cpm").map(m -> m.getModInfo().getVersion().toString()).orElse("?UNKNOWN?");
	}

	@Override
	public IVersionCheck getVersionCheck() {
		return VersionCheck.get(() -> ModList.get().getModContainerById("cpm").map(c -> VersionChecker.getResult(c.getModInfo()).changes()).orElse(Collections.emptyMap()));
	}
}

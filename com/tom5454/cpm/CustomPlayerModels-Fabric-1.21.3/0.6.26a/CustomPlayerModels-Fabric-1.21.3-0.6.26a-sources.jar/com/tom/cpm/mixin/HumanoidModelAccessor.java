package com.tom.cpm.mixin;

import net.minecraft.class_10034;
import net.minecraft.class_1306;
import net.minecraft.class_572;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_572.class)
public interface HumanoidModelAccessor {

	@Invoker
	class_572.class_573 callGetArmPose(final class_10034 playerRenderState, final class_1306 humanoidArm);
}

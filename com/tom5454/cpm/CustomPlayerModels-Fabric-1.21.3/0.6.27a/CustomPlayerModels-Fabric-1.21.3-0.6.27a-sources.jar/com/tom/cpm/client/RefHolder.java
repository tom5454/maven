package com.tom.cpm.client;

import java.util.Map;
import net.minecraft.class_2484;
import net.minecraft.class_5598;

public class RefHolder {
	public static Map<class_2484.class_2485, class_5598> CPM_MODELS;
}

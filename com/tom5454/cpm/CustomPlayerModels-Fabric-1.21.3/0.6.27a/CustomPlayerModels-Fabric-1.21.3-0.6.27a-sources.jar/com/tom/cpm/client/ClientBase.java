package com.tom.cpm.client;

import java.util.function.Function;
import net.minecraft.class_10034;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_2817;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3879;
import net.minecraft.class_4597;
import net.minecraft.class_563;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_634;
import net.minecraft.class_742;
import net.minecraft.class_746;
import net.minecraft.class_8710;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.common.ByteArrayPayload;
import com.tom.cpm.common.PlayerAnimUpdater;
import com.tom.cpm.mixinplugin.IrisDetector;
import com.tom.cpm.mixinplugin.OFDetector;
import com.tom.cpm.shared.model.RenderManager;
import com.tom.cpm.shared.network.NetHandler;
import com.tom.cpm.shared.util.Log;

public abstract class ClientBase {
	public static final class_2960 DEFAULT_CAPE = class_2960.method_60654("cpm:textures/template/cape.png");
	public static boolean optifineLoaded, irisLoaded, vrLoaded;
	public static MinecraftObject mc;
	protected class_310 minecraft;
	public RenderManager<GameProfile, net.minecraft.class_1657, class_3879, class_4597> manager;
	public NetHandler<class_8710.class_9154<ByteArrayPayload>, net.minecraft.class_1657, class_634> netHandler;

	public void init0() {
		minecraft = class_310.method_1551();
		mc = new MinecraftObject(minecraft);
		optifineLoaded = OFDetector.doApply();
		vrLoaded = Platform.isModLoaded("vivecraft");
		irisLoaded = IrisDetector.doApply();
		if(optifineLoaded)Log.info("Optifine detected, enabling optifine compatibility");
		if(vrLoaded)Log.info("ViveCraft detected, enabling ViveCraft compatibility");
		if(irisLoaded)Log.info("Iris detected, enabling iris compatibility");
	}

	public void init1() {
		manager = new RenderManager<>(mc.getPlayerRenderManager(), mc.getDefinitionLoader(), PlayerProfile::getPlayerProfile);
		manager.setGPGetters(GameProfile::getProperties, Property::value);
		netHandler = new NetHandler<>((k, v) -> new class_8710.class_9154<>(class_2960.method_43902(k, v)));
		netHandler.setExecutor(() -> minecraft);
		netHandler.setSendPacketClient(Function.identity(), (c, rl, pb) -> c.method_52787(new class_2817(new ByteArrayPayload(rl, pb))));
		netHandler.setPlayerToLoader(net.minecraft.class_1657::method_7334);
		netHandler.setGetPlayerById(id -> {
			class_1297 ent = class_310.method_1551().field_1687.method_8469(id);
			if(ent instanceof net.minecraft.class_1657) {
				return (net.minecraft.class_1657) ent;
			}
			return null;
		});
		netHandler.setGetClient(() -> minecraft.field_1724);
		netHandler.setGetNet(c -> ((class_746)c).field_3944);
		netHandler.setDisplayText(t -> minecraft.field_1724.method_7353(t.remap(), false));
		netHandler.setGetPlayerAnimGetters(new PlayerAnimUpdater());
	}

	public static void apiInit() {
		CustomPlayerModels.api.buildClient().voicePlayer(net.minecraft.class_1657.class, net.minecraft.class_1657::method_5667).
		renderApi(class_3879.class, class_2960.class, class_1921.class, class_4597.class, GameProfile.class, ModelTexture::new).
		localModelApi(GameProfile::new).init();
	}

	public void playerRenderPost(class_4597 buffer, class_591 model) {
		manager.unbindFlush(model);
	}

	public void renderHand(class_4597 buffer, class_591 model) {
		renderHand(minecraft.field_1724, buffer, model);
	}

	public void renderHand(class_742 pl, class_4597 buffer, class_591 model) {
		manager.bindHand(pl, buffer, model);
	}

	public void renderHandPost(class_4597 buffer, class_572 model) {
		manager.unbindFlush(model);
	}

	public void renderSkull(class_3879 skullModel, GameProfile profile, class_4597 buffer) {
		manager.bindSkull(profile, buffer, skullModel);
	}

	public void renderSkullPost(class_4597 buffer, class_3879 model) {
		manager.unbindFlush(model);
	}

	public void renderElytra(class_572<class_10034> player, class_563 model) {
		manager.bindElytra(player, model);
	}

	public void renderArmor(class_572<class_10034> modelArmor, class_572<class_10034> modelLeggings,
			class_572<class_10034> player) {
		manager.bindArmor(player, modelArmor, 1);
		manager.bindArmor(player, modelLeggings, 2);
	}

	public void updateJump() {
		if(minecraft.field_1724.method_24828() && minecraft.field_1724.field_3913.field_54155.comp_3163()) {
			manager.jump(minecraft.field_1724);
		}
	}
}

package com.tom.cpm.common;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.command.WrongUsageException;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;

import com.tom.cpl.command.StringCommandHandler;
import com.tom.cpl.text.IText;

import com.tom.cpl.command.StringCommandHandler.CommandImpl;

public class Command extends StringCommandHandler<MinecraftServer, ICommandSender, CommandException> {

	public Command(Consumer<CommandBase> register, boolean client) {
		super(i -> register.accept(new Cmd(i)), client);
	}

	private static class Cmd extends CommandBase {
		private CommandImpl impl;

		public Cmd(CommandImpl i) {
			this.impl = i;
		}

		@Override
		public String func_71517_b() {
			return impl.getName();
		}

		@Override
		public String func_71518_a(ICommandSender sender) {
			return "commands." + impl.getName() + ".usage";
		}

		@Override
		public void func_184881_a(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
			impl.execute(server, sender, args);
		}

		@Override
		public List<String> func_184883_a(MinecraftServer server, ICommandSender sender, String[] args,
				BlockPos pos) {
			return impl.getTabCompletions(server, sender, args);
		}

		@Override
		public int func_82362_a() {
			return impl.isOp() ? 2 : 0;
		}
	}

	@Override
	public String toStringPlayer(Object pl) {
		return ((EntityPlayer)pl).func_70005_c_();
	}

	@Override
	public void sendSuccess(ICommandSender sender, IText text) {
		if(sender.func_174792_t_()) {
			sender.func_145747_a(text.remap());
		}
	}

	@Override
	public CommandException generic(String text, Object... format) {
		return new CommandException(text, format);
	}

	@Override
	public CommandException wrongUsage(String text, Object... format) {
		return new WrongUsageException(text, format);
	}

	@Override
	public Object getPlayerObj(MinecraftServer server, ICommandSender sender, String name) throws CommandException {
		return CommandBase.func_184888_a(server, sender, name);
	}

	@Override
	public CommandException checkExc(Exception exc) {
		if(exc instanceof CommandException)return (CommandException) exc;
		return new CommandException("commands.generic.exception");
	}

	@Override
	public List<String> getOnlinePlayers(MinecraftServer server) {
		return Arrays.asList(server.func_71213_z());
	}
}

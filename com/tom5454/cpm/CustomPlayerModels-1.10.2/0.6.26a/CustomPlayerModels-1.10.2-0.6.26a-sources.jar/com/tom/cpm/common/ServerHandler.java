package com.tom.cpm.common;

import net.minecraft.entity.EntityTrackerEntry;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.network.NetHandlerPlayServer;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.server.SPacketChat;
import net.minecraft.network.play.server.SPacketCustomPayload;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.WorldServer;

import net.minecraftforge.event.entity.living.LivingEvent.LivingJumpEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Loader;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.ServerTickEvent;

import com.tom.cpm.shared.network.NetH.ServerNetH;
import com.tom.cpm.shared.network.NetHandler;

import io.netty.buffer.Unpooled;

public class ServerHandler {

	public static NetHandler<ResourceLocation, EntityPlayerMP, NetHandlerPlayServer> netHandler;

	static {
		netHandler = new NetHandler<>(ResourceLocation::new);
		netHandler.setGetPlayerUUID(EntityPlayerMP::func_110124_au);
		netHandler.setSendPacketServer(d -> new PacketBuffer(Unpooled.wrappedBuffer(d)), (c, rl, pb) -> c.func_147359_a(new SPacketCustomPayload(rl.toString(), pb)), ent -> ((WorldServer)ent.field_70170_p).func_73039_n().getTrackingPlayers(ent), e -> (EntityPlayerMP) e);
		netHandler.setFindTracking((p, f) -> {
			for(EntityTrackerEntry tr : ((WorldServer)p.field_70170_p).func_73039_n().field_72793_b) {
				if(tr.func_187260_b() instanceof EntityPlayer && tr.field_73134_o.contains(p)) {
					f.accept((EntityPlayerMP) tr.func_187260_b());
				}
			}
		});
		netHandler.setSendChat((p, m) -> p.field_71135_a.func_147359_a(new SPacketChat(m.remap())));
		netHandler.setExecutor(() -> FMLCommonHandler.instance().getMinecraftServerInstance()::func_152344_a);
		netHandler.setGetNet(spe -> spe.field_71135_a);
		netHandler.setGetPlayer(net -> net.field_147369_b);
		netHandler.setGetPlayerId(EntityPlayerMP::func_145782_y);
		netHandler.setGetOnlinePlayers(() -> FMLCommonHandler.instance().getMinecraftServerInstance().func_184103_al().func_181057_v());
		netHandler.setKickPlayer((p, m) -> p.field_71135_a.func_147360_c(m.toString()));
		netHandler.setGetPlayerAnimGetters(new PlayerAnimUpdater());
		netHandler.addScaler(new AttributeScaler());
		if(Loader.isModLoaded("chiseled_me")) {
			netHandler.addScaler(new ChiseledMeScaler());
		}
	}

	@SubscribeEvent
	public void onPlayerJoin(PlayerLoggedInEvent evt) {
		netHandler.onJoin((EntityPlayerMP) evt.player);
	}

	@SubscribeEvent
	public void onTrackingStart(PlayerEvent.StartTracking evt) {
		NetHandlerPlayServer handler = ((EntityPlayerMP)evt.getEntityPlayer()).field_71135_a;
		if(((ServerNetH)handler).cpm$hasMod()) {
			if(evt.getTarget() instanceof EntityPlayer) {
				netHandler.sendPlayerData((EntityPlayerMP) evt.getTarget(), (EntityPlayerMP) evt.getEntityPlayer());
			}
		}
	}

	@SubscribeEvent
	public void onTick(ServerTickEvent evt) {
		if(evt.phase == Phase.END) {
			netHandler.tick();
		}
	}

	@SubscribeEvent
	public void onJump(LivingJumpEvent evt) {
		if(evt.getEntityLiving() instanceof EntityPlayerMP) {
			netHandler.onJump((EntityPlayerMP) evt.getEntityLiving());
		}
	}
}

package com.tom.cpm.common;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumSkyBlock;

import com.tom.cpl.block.Biome;
import com.tom.cpl.block.BlockState;
import com.tom.cpl.block.World;
import com.tom.cpl.util.WeakStorage;
import com.tom.cpm.shared.animation.AnimationState;

import com.tom.cpl.block.World.WeatherType;

public class WorldImpl implements World {
	public WeakStorage<net.minecraft.world.World> level = new WeakStorage<>();
	public BlockPos base;

	public static void setWorld(AnimationState a, Entity ent) {
		if(!(a.world instanceof WorldImpl))a.world = new WorldImpl();
		WorldImpl i = (WorldImpl) a.world;
		net.minecraft.world.World l = ent.field_70170_p;
		i.level.set(l);
		i.base = ent.func_180425_c();
		a.dayTime = l.func_72820_D();
		a.skyLight = l.func_175642_b(EnumSkyBlock.SKY, i.base);
		a.blockLight = l.func_175642_b(EnumSkyBlock.BLOCK, i.base);
	}

	@Override
	public BlockState getBlock(int x, int y, int z) {
		return level.call(l -> BlockStateHandlerImpl.impl.wrap(l.func_180495_p(base.func_177982_a(x, y, z))), BlockState.AIR);
	}

	@Override
	public boolean isCovered() {
		return level.call(l -> l.func_175678_i(base), false);
	}

	@Override
	public int getYHeight() {
		return base.func_177956_o();
	}

	@Override
	public int getMaxHeight() {
		return level.call(l -> l.func_72800_K(), 0);
	}

	@Override
	public int getMinHeight() {
		return 0;
	}

	@Override
	public WeatherType getWeather() {
		return level.call(l -> l.func_72911_I() ? WeatherType.THUNDER : l.func_72896_J() ? WeatherType.RAIN : WeatherType.CLEAR, WeatherType.CLEAR);
	}

	@Override
	public Biome getBiome() {
		return level.call(l -> BiomeHandlerImpl.impl.wrap(l.func_180494_b(base)), null);
	}

	@Override
	public String getDimension() {
		return level.call(l -> l.field_73011_w.func_186058_p().func_186065_b(), null);
	}
}

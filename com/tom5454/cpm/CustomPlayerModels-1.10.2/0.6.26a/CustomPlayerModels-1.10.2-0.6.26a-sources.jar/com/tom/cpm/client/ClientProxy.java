package com.tom.cpm.client;

import java.util.concurrent.Executor;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiCustomizeSkin;
import net.minecraft.client.gui.GuiMainMenu;
import net.minecraft.client.gui.GuiWorldSelection;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBiped;
import net.minecraft.client.model.ModelElytra;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.VertexBuffer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.ITextComponent;

import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.client.event.GuiScreenEvent;
import net.minecraftforge.client.event.GuiScreenEvent.DrawScreenEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import net.minecraftforge.fml.common.gameevent.TickEvent.RenderTickEvent;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;

import com.tom.cpl.text.FormatText;
import com.tom.cpm.CommonProxy;
import com.tom.cpm.CustomPlayerModels;
import com.tom.cpm.common.Command;
import com.tom.cpm.common.PlayerAnimUpdater;
import com.tom.cpm.lefix.FixSSL;
import com.tom.cpm.shared.config.ConfigKeys;
import com.tom.cpm.shared.config.ModConfig;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import com.tom.cpm.shared.editor.gui.EditorGui;
import com.tom.cpm.shared.gui.GestureGui;
import com.tom.cpm.shared.model.RenderManager;
import com.tom.cpm.shared.model.TextureSheetType;
import com.tom.cpm.shared.network.NetHandler;

import io.netty.buffer.Unpooled;

public class ClientProxy extends CommonProxy {
	public static final ResourceLocation DEFAULT_CAPE = new ResourceLocation("cpm:textures/template/cape.png");
	public static MinecraftObject mc;
	private Minecraft minecraft;
	public static ClientProxy INSTANCE;
	public RenderManager<GameProfile, EntityPlayer, ModelBase, Void> manager;
	public NetHandler<ResourceLocation, EntityPlayer, NetHandlerPlayClient> netHandler;

	@Override
	public void init() {
		super.init();
		FixSSL.fixup();
		INSTANCE = this;
		minecraft = Minecraft.func_71410_x();
		mc = new MinecraftObject(minecraft);
		MinecraftForge.EVENT_BUS.register(this);
		KeyBindings.init();
		manager = new RenderManager<>(mc.getPlayerRenderManager(), mc.getDefinitionLoader(), PlayerProfile::getPlayerProfile);
		manager.setGPGetters(GameProfile::getProperties, Property::getValue);
		netHandler = new NetHandler<>(ResourceLocation::new);
		Executor ex = minecraft::func_152344_a;
		netHandler.setExecutor(() -> ex);
		netHandler.setSendPacketClient(d -> new PacketBuffer(Unpooled.wrappedBuffer(d)), (c, rl, pb) -> c.func_147297_a(new CPacketCustomPayload(rl.toString(), pb)));
		netHandler.setPlayerToLoader(EntityPlayer::func_146103_bH);
		netHandler.setGetPlayerById(id -> {
			Entity ent = Minecraft.func_71410_x().field_71441_e.func_73045_a(id);
			if(ent instanceof EntityPlayer) {
				return (EntityPlayer) ent;
			}
			return null;
		});
		netHandler.setGetClient(() -> minecraft.field_71439_g);
		netHandler.setGetNet(c -> ((EntityPlayerSP)c).field_71174_a);
		netHandler.setDisplayText(f -> minecraft.field_71456_v.func_146158_b().func_146227_a(f.remap()));
		netHandler.setGetPlayerAnimGetters(new PlayerAnimUpdater());
		new Command(ClientCommandHandler.instance::func_71560_a, true);
	}

	@Override
	public void apiInit() {
		CustomPlayerModels.api.buildClient().voicePlayer(EntityPlayer.class, EntityPlayer::func_110124_au).localModelApi(GameProfile::new).
		renderApi(ModelBase.class, GameProfile.class).init();
	}

	@SubscribeEvent
	public void playerRenderPre(RenderPlayerEvent.Pre event) {
		manager.bindPlayer(event.getEntityPlayer(), null, event.getRenderer().func_177087_b());
		manager.bindSkin(event.getRenderer().func_177087_b(), TextureSheetType.SKIN);
	}

	@SubscribeEvent(priority = EventPriority.LOWEST, receiveCanceled = true)
	public void playerRenderPreC(RenderPlayerEvent.Pre event) {
		if(event.isCanceled())manager.unbindFlush(event.getRenderer().func_177087_b());
	}

	@SubscribeEvent
	public void playerRenderPost(RenderPlayerEvent.Post event) {
		manager.unbindFlush(event.getRenderer().func_177087_b());
	}

	@SubscribeEvent
	public void initGui(GuiScreenEvent.InitGuiEvent.Post evt) {
		if((evt.getGui() instanceof GuiMainMenu && ModConfig.getCommonConfig().getSetBoolean(ConfigKeys.TITLE_SCREEN_BUTTON, true)) ||
				evt.getGui() instanceof GuiCustomizeSkin) {
			evt.getButtonList().add(new Button(0, 0));
		}
	}

	@SubscribeEvent
	public void buttonPress(GuiScreenEvent.ActionPerformedEvent.Pre evt) {
		if(evt.getButton() instanceof Button) {
			Minecraft.func_71410_x().func_147108_a(new GuiImpl(EditorGui::new, evt.getGui()));
		}
	}

	@SubscribeEvent
	public void openGui(GuiOpenEvent openGui) {
		if(openGui.getGui() == null && minecraft.field_71462_r instanceof GuiImpl.Overlay) {
			openGui.setGui(((GuiImpl.Overlay) minecraft.field_71462_r).getGui());
		}
		if(openGui.getGui() instanceof GuiMainMenu && !(minecraft.field_71462_r instanceof GuiWorldSelection || minecraft.field_71462_r instanceof GuiMainMenu) && EditorGui.doOpenEditor()) {
			openGui.setGui(new GuiImpl(EditorGui::new, openGui.getGui()));
		}
		if(openGui.getGui() instanceof GuiImpl)((GuiImpl)openGui.getGui()).onOpened();
	}

	@SubscribeEvent
	public void drawGuiPre(DrawScreenEvent.Pre evt) {
		PlayerProfile.inGui = true;
	}

	@SubscribeEvent
	public void drawGuiPost(DrawScreenEvent.Post evt) {
		PlayerProfile.inGui = false;
	}

	public void renderSkull(ModelBase skullModel, GameProfile profile) {
		manager.bindSkull(profile, null, skullModel);
		manager.bindSkin(skullModel, TextureSheetType.SKIN);
	}

	public void renderElytra(ModelBiped player, ModelElytra model) {
		manager.bindElytra(player, model);
		manager.bindSkin(model, TextureSheetType.ELYTRA);
	}

	public void renderArmor(ModelBase modelArmor, ModelBase modelLeggings,
			ModelBiped player) {
		manager.bindArmor(player, modelArmor, 1);
		manager.bindArmor(player, modelLeggings, 2);
		manager.bindSkin(modelArmor, TextureSheetType.ARMOR1);
		manager.bindSkin(modelLeggings, TextureSheetType.ARMOR2);
	}

	@SubscribeEvent
	public void renderTick(RenderTickEvent evt) {
		if(evt.phase == Phase.START) {
			mc.getPlayerRenderManager().getAnimationEngine().update(evt.renderTickTime);
		}
	}

	@SubscribeEvent
	public void clientTick(ClientTickEvent evt) {
		if(evt.phase == Phase.START && !minecraft.func_147113_T()) {
			mc.getPlayerRenderManager().getAnimationEngine().tick();

			if(minecraft.field_71439_g != null && minecraft.field_71439_g.field_70122_E && minecraft.field_71474_y.field_74314_A.func_151470_d()) {
				manager.jump(minecraft.field_71439_g);
			}
		}

		if (minecraft.field_71439_g == null || evt.phase == Phase.START)
			return;

		if(KeyBindings.gestureMenuBinding.func_151468_f()) {
			minecraft.func_147108_a(new GuiImpl(GestureGui::new, null));
		}

		if(KeyBindings.renderToggleBinding.func_151468_f()) {
			Player.setEnableRendering(!Player.isEnableRendering());
		}

		mc.getPlayerRenderManager().getAnimationEngine().updateKeys(KeyBindings.quickAccess);

		CustomPlayerModels.api.clientApi().tickListeners(minecraft.func_147113_T());
	}

	@SubscribeEvent
	public void onRenderName(RenderLivingEvent.Specials.Pre<AbstractClientPlayer> evt) {
		if(evt.getEntity() instanceof AbstractClientPlayer) {
			if(!Player.isEnableNames())
				evt.setCanceled(true);
			if(Player.isEnableLoadingInfo() && canRenderName(evt.getEntity())) {
				FormatText st = INSTANCE.manager.getStatus(((AbstractClientPlayer) evt.getEntity()).func_146103_bH(), ModelDefinitionLoader.PLAYER_UNIQUE);
				if(st != null) {
					double d0 = evt.getEntity().func_70068_e(minecraft.func_175606_aa());
					if (d0 < 32*32) {
						Scoreboard scoreboard = ((EntityPlayer) evt.getEntity()).func_96123_co();
						ScoreObjective scoreobjective = scoreboard.func_96539_a(2);
						double y = evt.getY();
						if (scoreobjective != null)
							y += evt.getRenderer().func_76983_a().field_78288_b * 1.15F * 0.025F;
						GlStateManager.func_179094_E();
						GlStateManager.func_179109_b(0, 0.25F, 0);
						String str = ((ITextComponent) st.remap()).func_150254_d();
						renderLivingLabel(evt.getEntity(), str, evt.getX(), y, evt.getZ(), 64);
						GlStateManager.func_179121_F();
					}
				}
			}
		}
	}

	protected boolean canRenderName(Entity entity) {
		EntityPlayerSP entityplayersp = Minecraft.func_71410_x().field_71439_g;
		boolean flag = !entity.func_98034_c(entityplayersp);

		if (entity != entityplayersp) {
			Team team = entity.func_96124_cp();
			Team team1 = entityplayersp.func_96124_cp();

			if (team != null) {
				Team.EnumVisible team$enumvisible = team.func_178770_i();

				switch (team$enumvisible) {
				case ALWAYS:
					return flag;
				case NEVER:
					return false;
				case HIDE_FOR_OTHER_TEAMS:
					return team1 == null ? flag : team.func_142054_a(team1) && (team.func_98297_h() || flag);
				case HIDE_FOR_OWN_TEAM:
					return team1 == null ? flag : !team.func_142054_a(team1) && flag;
				default:
					return true;
				}
			}
		}

		return Minecraft.func_71382_s() && flag && !entity.func_184207_aI();
	}

	protected void renderLivingLabel(Entity entityIn, String str, double x, double y, double z, int maxDistance) {
		double d0 = entityIn.func_70068_e(minecraft.func_175598_ae().field_78734_h);

		if (d0 <= maxDistance * maxDistance) {
			boolean flag = entityIn.func_70093_af();
			float f = minecraft.func_175598_ae().field_78735_i;
			float f1 = minecraft.func_175598_ae().field_78732_j;
			boolean flag1 = minecraft.func_175598_ae().field_78733_k.field_74320_O == 2;
			float f2 = entityIn.field_70131_O + 0.5F - (flag ? 0.25F : 0.0F);
			int i = "deadmau5".equals(str) ? -10 : 10;
			drawNameplate(minecraft.field_71466_p, str, (float)x, (float)y + f2, (float)z, i, f, f1, flag1, flag);
		}
	}

	public static void drawNameplate(FontRenderer fontRendererIn, String str, float x, float y, float z, int verticalShift, float viewerYaw, float viewerPitch, boolean isThirdPersonFrontal, boolean isSneaking) {
		GlStateManager.func_179094_E();
		GlStateManager.func_179109_b(x, y, z);
		GlStateManager.func_187432_a(0.0F, 1.0F, 0.0F);
		GlStateManager.func_179114_b(-viewerYaw, 0.0F, 1.0F, 0.0F);
		GlStateManager.func_179114_b((isThirdPersonFrontal ? -1 : 1) * viewerPitch, 1.0F, 0.0F, 0.0F);
		GlStateManager.func_179152_a(-0.025F / 2, -0.025F / 2, 0.025F / 2);
		GlStateManager.func_179140_f();
		GlStateManager.func_179132_a(false);

		if (!isSneaking)
		{
			GlStateManager.func_179097_i();
		}

		GlStateManager.func_179147_l();
		GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
		int i = fontRendererIn.func_78256_a(str) / 2;
		GlStateManager.func_179090_x();
		Tessellator tessellator = Tessellator.func_178181_a();
		VertexBuffer bufferbuilder = tessellator.func_178180_c();
		bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181706_f);
		bufferbuilder.func_181662_b(-i - 1, -1 + verticalShift, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
		bufferbuilder.func_181662_b(-i - 1, 8 + verticalShift, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
		bufferbuilder.func_181662_b(i + 1, 8 + verticalShift, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
		bufferbuilder.func_181662_b(i + 1, -1 + verticalShift, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
		tessellator.func_78381_a();
		GlStateManager.func_179098_w();

		if (!isSneaking)
		{
			fontRendererIn.func_78276_b(str, -fontRendererIn.func_78256_a(str) / 2, verticalShift, 553648127);
			GlStateManager.func_179126_j();
		}

		GlStateManager.func_179132_a(true);
		fontRendererIn.func_78276_b(str, -fontRendererIn.func_78256_a(str) / 2, verticalShift, isSneaking ? 553648127 : -1);
		GlStateManager.func_179145_e();
		GlStateManager.func_179084_k();
		GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.func_179121_F();
	}

	public static class Button extends GuiButton {

		public Button(int x, int y) {
			super(99, x, y, 100, 20, I18n.func_135052_a("button.cpm.open_editor"));
		}

	}

	public void onLogout() {
		mc.onLogOut();
	}

	//Copy from LayerCape
	public static void renderCape(AbstractClientPlayer playerIn, float partialTicks, ModelPlayer model, ModelDefinition modelDefinition) {
		GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
		GlStateManager.func_179094_E();
		float f1, f2, f3;

		if(playerIn != null) {
			double lvt_10_1_ = playerIn.field_71091_bM
					+ (playerIn.field_71094_bP - playerIn.field_71091_bM) * partialTicks
					- (playerIn.field_70169_q + (playerIn.field_70165_t - playerIn.field_70169_q) * partialTicks);
			double lvt_12_1_ = playerIn.field_71096_bN
					+ (playerIn.field_71095_bQ - playerIn.field_71096_bN) * partialTicks
					- (playerIn.field_70167_r + (playerIn.field_70163_u - playerIn.field_70167_r) * partialTicks);
			double lvt_14_1_ = playerIn.field_71097_bO
					+ (playerIn.field_71085_bR - playerIn.field_71097_bO) * partialTicks
					- (playerIn.field_70166_s + (playerIn.field_70161_v - playerIn.field_70166_s) * partialTicks);
			float lvt_16_1_ = playerIn.field_70760_ar
					+ (playerIn.field_70761_aq - playerIn.field_70760_ar) * partialTicks;
			double lvt_17_1_ = MathHelper.func_76126_a(lvt_16_1_ * 0.017453292F);
			double lvt_19_1_ = (-MathHelper.func_76134_b(lvt_16_1_ * 0.017453292F));
			f1 = (float) lvt_12_1_ * 10.0F;
			f1 = MathHelper.func_76131_a(f1, -6.0F, 32.0F);
			f2 = (float) (lvt_10_1_ * lvt_17_1_ + lvt_14_1_ * lvt_19_1_) * 100.0F;
			f3 = (float) (lvt_10_1_ * lvt_19_1_ - lvt_14_1_ * lvt_17_1_) * 100.0F;
			if (f2 < 0.0F) {
				f2 = 0.0F;
			}

			float lvt_24_1_ = playerIn.field_71107_bF
					+ (playerIn.field_71109_bG - playerIn.field_71107_bF) * partialTicks;
			f1 += MathHelper.func_76126_a((playerIn.field_70141_P
					+ (playerIn.field_70140_Q - playerIn.field_70141_P) * partialTicks)
					* 6.0F) * 32.0F * lvt_24_1_;
			if (playerIn.func_70093_af()) {
				f1 += 25.0F;
				model.field_178729_w.field_78797_d = 2.0F;
			} else {
				model.field_178729_w.field_78797_d = 0.0F;
			}
		} else {
			f1 = 0;
			f2 = 0;
			f3 = 0;
		}

		model.field_178729_w.field_78795_f = (float) -Math.toRadians(6.0F + f2 / 2.0F + f1);
		model.field_178729_w.field_78796_g = (float) Math.toRadians(180.0F - f3 / 2.0F);
		model.field_178729_w.field_78808_h = (float) Math.toRadians(f3 / 2.0F);
		mc.getPlayerRenderManager().setModelPose(model);
		model.field_178729_w.field_78795_f = 0;
		model.field_178729_w.field_78796_g = 0;
		model.field_178729_w.field_78808_h = 0;
		model.func_178728_c(0.0625F);
		GlStateManager.func_179121_F();
	}
}

package com.tom.cpm.mixinplugin;

import net.minecraftforge.fml.loading.LoadingModList;

public class MixinModLoaded {

	public static boolean isLoaded(String id) {
		return LoadingModList.getModFileById(id) != null;
	}

}

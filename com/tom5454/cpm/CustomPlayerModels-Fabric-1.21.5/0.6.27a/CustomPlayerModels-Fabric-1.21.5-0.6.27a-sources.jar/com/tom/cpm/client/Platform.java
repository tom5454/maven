package com.tom.cpm.client;

import java.util.function.Supplier;
import net.minecraft.class_10799;
import net.minecraft.class_1657;
import net.minecraft.class_2535;
import net.minecraft.class_339;
import com.mojang.blaze3d.pipeline.RenderPipeline;

import com.tom.cpm.mixinplugin.MixinModLoaded;

import io.netty.channel.Channel;

public class Platform {

	public static boolean isSitting(class_1657 player) {
		return player.method_5765();
	}

	public static void setHeight(class_339 w, int h) {
		w.field_22759 = h;
	}

	public static Channel getChannel(class_2535 conn) {
		return conn.field_11651;
	}

	public static boolean isModLoaded(String id) {
		return MixinModLoaded.isLoaded(id);
	}

	public static Supplier<RenderPipeline> registerPipeline(Supplier<RenderPipeline> factory) {
		var p = factory.get();
		class_10799.method_67887(p);
		return () -> p;
	}
}

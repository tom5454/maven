package com.tom.storagemod.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import net.minecraft.ChatFormatting;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.StackedItemContents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.storage.ValueInput;

import com.mojang.serialization.Codec;

import com.tom.storagemod.inventory.StoredItemStack;
import com.tom.storagemod.inventory.TerminalItemStack;
import com.tom.storagemod.menu.TerminalCraftingFiller;
import com.tom.storagemod.network.NetworkHandler;
import com.tom.storagemod.platform.Platform;

import io.netty.buffer.Unpooled;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;

public class TerminalSyncManager {
	private static final int MAX_PACKET_SIZE = 64000;
	private Object2IntMap<StoredItemStack> idMap = new Object2IntOpenHashMap<>();
	private Int2ObjectMap<StoredItemStack> idMap2 = new Int2ObjectArrayMap<>();
	private Map<StoredItemStack, TerminalItemStack> items = new HashMap<>();
	private Map<TerminalItemStack, TerminalItemStack> itemList = new HashMap<>();
	private int lastId = 1, lastChangeID = -1;
	private RegistryFriendlyByteBuf workBuf;

	public TerminalSyncManager(RegistryAccess reg) {
		workBuf = Platform.makeRegByteBuf(Unpooled.buffer(MAX_PACKET_SIZE, MAX_PACKET_SIZE * 2), reg);
	}

	private void write(RegistryFriendlyByteBuf buf, TerminalItemStack stack) {
		ItemStack st = stack.getStack();
		byte flags = (byte) (stack.getQuantity() == 0 ? 1 : 0);
		boolean wr = true;
		int id = idMap.getInt(stack);
		if(id != 0) {
			flags |= 4;
			wr = false;
		}
		buf.writeByte(flags);
		buf.writeVarInt(idMap.computeIfAbsent(stack, s -> {
			int i = lastId++;
			idMap2.put(i, (StoredItemStack) s);
			return i;
		}));
		if (wr) {
			ItemStack.STREAM_CODEC.encode(buf, st);
		}
		if (stack.getQuantity() != 0) {
			buf.writeVarLong(stack.getQuantity());
			buf.writeVarInt(stack.getUsedSlotCount());
		}
	}

	private void writeMiniStack(RegistryFriendlyByteBuf buf, TerminalItemStack stack) {
		int id = idMap.getInt(stack);
		byte flags = (byte) ((stack.getQuantity() == 0 ? 1 : 0) | 2);
		buf.writeByte(flags);
		buf.writeVarInt(id);
		ItemStack is = new ItemStack(stack.getStack().getItem());
		is.set(DataComponents.LORE, new ItemLore(List.of(Component.translatable("tooltip.toms_storage.nbt_overflow").withStyle(ChatFormatting.RED))));
		ItemStack.STREAM_CODEC.encode(buf, is);
		if (stack.getQuantity() != 0) {
			buf.writeVarLong(stack.getQuantity());
			buf.writeVarInt(stack.getUsedSlotCount());
		}
	}

	private TerminalItemStack read(RegistryFriendlyByteBuf buf) {
		byte flags = buf.readByte();
		int id = buf.readVarInt();
		boolean rd = (flags & 4) == 0;
		TerminalItemStack stack;
		if(rd) {
			stack = new TerminalItemStack(ItemStack.STREAM_CODEC.decode(buf));
		} else {
			var st = idMap2.get(id);
			if (st == null) {
				ItemStack is = new ItemStack(Items.BARRIER);
				is.set(DataComponents.LORE, new ItemLore(List.of(Component.translatable("tooltip.toms_storage.item_sync_error").withStyle(ChatFormatting.RED))));
				stack = new TerminalItemStack(is);
			} else
				stack = new TerminalItemStack(st.getStack());
		}
		if ((flags & 1) == 0) {
			stack.setCount(buf.readVarLong());
			stack.setUsedSlotCount(buf.readVarInt());
		}
		idMap.put(stack, id);
		idMap2.put(id, stack);
		return stack;
	}

	public void update(int changeID, Map<StoredItemStack, TerminalItemStack> items, ServerPlayer player, Consumer<CompoundTag> extraSync) {
		if (changeID != lastChangeID) {
			lastChangeID = changeID;
			List<TerminalItemStack> toWrite = new ArrayList<>();
			items.forEach((s, c) -> {
				TerminalItemStack pc = this.items.remove(s);
				if(pc == null || !c.equalDetails(pc)) {
					toWrite.add(c);
				}
			});
			this.items.forEach((s, c) -> {
				toWrite.add(new TerminalItemStack(s.getStack(), 0L));
			});
			this.items.clear();
			this.items.putAll(items);
			if(!toWrite.isEmpty()) {
				workBuf.writerIndex(0);
				int j = 0;
				for (int i = 0; i < toWrite.size(); i++, j++) {
					TerminalItemStack stack = toWrite.get(i);
					int li = workBuf.writerIndex();
					try {
						write(workBuf, stack);
					} catch (IndexOutOfBoundsException e) {
						workBuf.writerIndex(li);
						writeMiniStack(workBuf, stack);
					}
					int s = workBuf.writerIndex();
					if((s > MAX_PACKET_SIZE || j > 32000) && j > 1) {
						CompoundTag t = writeBuf("d", workBuf, li);
						t.putShort("l", (short) j);
						NetworkHandler.sendTo(player, t);
						j = 0;
						workBuf.writerIndex(0);
						if(s - li > MAX_PACKET_SIZE) {
							writeMiniStack(workBuf, stack);
						} else {
							workBuf.writeBytes(workBuf, li, s - li);
						}
					}
				}
				if(j > 0 || extraSync != null) {
					CompoundTag t;
					if(j > 0) {
						t = writeBuf("d", workBuf, workBuf.writerIndex());
						t.putShort("l", (short) j);
					} else t = new CompoundTag();
					if(extraSync != null)extraSync.accept(t);
					NetworkHandler.sendTo(player, t);
					return;
				}
			}
		}
		if(extraSync != null) {
			CompoundTag t = new CompoundTag();
			extraSync.accept(t);
			NetworkHandler.sendTo(player, t);
		}
	}

	public boolean receiveUpdate(RegistryAccess registryAccess, ValueInput tag) {
		var d = tag.read("d", Codec.BYTE_BUFFER);
		d.ifPresent(b -> {
			RegistryFriendlyByteBuf buf = Platform.makeRegByteBuf(Unpooled.wrappedBuffer(b), registryAccess);
			List<TerminalItemStack> in = new ArrayList<>();
			short len = (short) tag.getShortOr("l", (short) 0);
			for (int i = 0; i < len; i++) {
				in.add(read(buf));
			}
			in.forEach(s -> {
				if(s.getQuantity() == 0) {
					this.itemList.remove(s);
				} else {
					this.itemList.put(s, s);
				}
			});
		});
		return d.isPresent();
	}

	public void sendInteract(StoredItemStack intStack, SlotAction action, boolean mod) {
		FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
		int flags = mod ? 1 : 0;
		if(intStack == null) {
			buf.writeByte(flags | 2);
		} else {
			buf.writeByte(flags);
			buf.writeVarInt(idMap.getInt(intStack));
			buf.writeVarLong(intStack.getQuantity());
		}
		buf.writeEnum(action);
		NetworkHandler.sendDataToServer(writeBuf("a", buf, buf.writerIndex()));
	}

	private CompoundTag writeBuf(String id, FriendlyByteBuf buf, int len) {
		byte[] data = new byte[len];
		buf.getBytes(0, data);
		CompoundTag tag = new CompoundTag();
		tag.putByteArray(id, data);
		return tag;
	}

	public void receiveInteract(ValueInput tag, InteractHandler handler) {
		tag.read("a", Codec.BYTE_BUFFER).ifPresent(b -> {
			FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.wrappedBuffer(b));
			byte flags = buf.readByte();
			StoredItemStack stack;
			if((flags & 2) != 0) {
				stack = null;
			} else {
				stack = idMap2.get(buf.readVarInt());
				long count = buf.readVarLong();
				if (stack != null) {
					stack = new StoredItemStack(stack.getStack());
					stack.setCount(count);
				}
			}
			handler.onInteract(stack, buf.readEnum(SlotAction.class), (flags & 1) != 0);
		});
	}

	public List<TerminalItemStack> getAsList() {
		return new ArrayList<>(this.itemList.values());
	}

	public void fillStackedContents(StackedItemContents stc) {
		items.forEach((s, c) -> stc.accountSimpleStack(c.getActualStack()));
	}

	public long getAmount(StoredItemStack stack) {
		StoredItemStack s = itemList.get(stack);
		return s != null ? s.getQuantity() : 0L;
	}

	public static interface InteractHandler {
		void onInteract(StoredItemStack intStack, SlotAction action, boolean mod);
	}

	public static enum SlotAction {
		PULL_OR_PUSH_STACK, PULL_ONE, SPACE_CLICK, SHIFT_PULL, GET_HALF, GET_QUARTER, CRAFT;
		public static final SlotAction[] VALUES = values();
	}

	public void fillCraftingFiller(TerminalCraftingFiller terminalCraftingFiller) {
		items.forEach((s, c) -> terminalCraftingFiller.accountStack(c.getActualStack()));
	}
}

package com.tom.storagemod.block.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import net.minecraft.world.Clearable;
import net.minecraft.world.Container;
import net.minecraft.world.Containers;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.Nameable;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

import com.tom.storagemod.Content;
import com.tom.storagemod.menu.FilingCabinetMenu;
import com.tom.storagemod.util.FilingCabinetContainer;

public class FilingCabinetBlockEntity extends BlockEntity implements MenuProvider, Nameable, Clearable {
	private FilingCabinetContainer inv = new FilingCabinetContainer(512, this::setChanged, this::canInteractWith);
	private Component name;

	public FilingCabinetBlockEntity(BlockPos p_155229_, BlockState p_155230_) {
		super(Content.filingCabinetBE.get(), p_155229_, p_155230_);
	}

	@Override
	protected void saveAdditional(ValueOutput tag) {
		super.saveAdditional(tag);
		inv.storeTag(tag, "inventory");
		tag.storeNullable("CustomName", ComponentSerialization.CODEC, this.name);
	}

	@Override
	protected void loadAdditional(ValueInput tag) {
		super.loadAdditional(tag);
		inv.fromTag(tag, "inventory");
		this.name = parseCustomNameSafe(tag, "CustomName");
	}

	@Override
	public AbstractContainerMenu createMenu(int p_39954_, Inventory p_39955_, Player p_39956_) {
		return new FilingCabinetMenu(p_39954_, p_39955_, inv);
	}

	public Component getDefaultName() {
		return Component.translatable("menu.toms_storage.filing_cabinet");
	}

	public Container getInv() {
		return inv;
	}

	private boolean canInteractWith(Player player) {
		if(level.getBlockEntity(worldPosition) != this)return false;
		return player.distanceToSqr(this.worldPosition.getX() + 0.5D, this.worldPosition.getY() + 0.5D, this.worldPosition.getZ() + 0.5D) < 64;
	}

	@Override
	public Component getName() {
		return this.name != null ? this.name : this.getDefaultName();
	}

	@Override
	public Component getDisplayName() {
		return this.getName();
	}

	@Override
	public Component getCustomName() {
		return this.name;
	}

	@Override
	public void preRemoveSideEffects(BlockPos pos, BlockState state) {
		Containers.dropContents(level, pos, inv);
	}

	@Override
	public void clearContent() {
		inv.clearContent();
	}
}

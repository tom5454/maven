package com.tom.storagemod.screen;

import java.util.function.Consumer;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;

import com.tom.storagemod.StorageMod;
import com.tom.storagemod.menu.FilingCabinetMenu;

public class FilingCabinetScreen extends TSContainerScreen<FilingCabinetMenu> {
	private static final Identifier CONTAINER_BACKGROUND = Identifier.parse("textures/gui/container/generic_54.png");
	private static final Identifier SCROLLER_SPRITE = Identifier.parse("container/creative_inventory/scroller");
	private static final Identifier SIDE_SCROLLBAR = Identifier.tryBuild(StorageMod.modid, "textures/gui/side_scrollbar.png");
	private final int containerRows;
	private int lastScroll;
	protected float currentScroll;
	protected boolean isScrolling;
	protected boolean wasClicking;

	public FilingCabinetScreen(FilingCabinetMenu inv, Inventory p_97742_, Component p_97743_) {
		super(inv, p_97742_, p_97743_, 176, 114 + inv.getRowCount() * 18);
		this.containerRows = inv.getRowCount();
		this.inventoryLabelY = this.imageHeight - 94;
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
		boolean flag = GLFW.glfwGetMouseButton(Minecraft.getInstance().getWindow().handle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) != GLFW.GLFW_RELEASE;
		int i = this.leftPos;
		int j = this.topPos;
		int k = i + 174;
		int l = j + 18;
		int i1 = k + 14;
		int j1 = l + containerRows * 18;

		if (!this.wasClicking && flag && mouseX >= k && mouseY >= l && mouseX < i1 && mouseY < j1) {
			this.isScrolling = true;
		}

		if (!flag) {
			this.isScrolling = false;
		}
		this.wasClicking = flag;

		if (this.isScrolling) {
			this.currentScroll = (mouseY - l - 7.5F) / (j1 - l - 15.0F);
			this.currentScroll = Mth.clamp(this.currentScroll, 0.0F, 1.0F);
		}
		super.extractRenderState(graphics, mouseX, mouseY, a);
		i = k;
		j = l;
		k = j1;
		graphics.blitSprite(RenderPipelines.GUI_TEXTURED, SCROLLER_SPRITE, i, j + (int) ((k - j - 17) * this.currentScroll), 12, 15);
	}

	@Override
	public void extractBackground(final GuiGraphicsExtractor gr, final int mouseX, final int mouseY,
			final float a) {
		super.extractBackground(gr, mouseX, mouseY, a);
		int i = (this.width - this.imageWidth) / 2;
		int j = (this.height - this.imageHeight) / 2;
		gr.blit(RenderPipelines.GUI_TEXTURED, CONTAINER_BACKGROUND, i, j, 0, 0, this.imageWidth, this.containerRows * 18 + 17, 256, 256);
		gr.blit(RenderPipelines.GUI_TEXTURED, CONTAINER_BACKGROUND, i, j + this.containerRows * 18 + 17, 0, 126, this.imageWidth, 96, 256, 256);
		gr.blit(RenderPipelines.GUI_TEXTURED, SIDE_SCROLLBAR, i + 170, j, 0, 0, 24, 115, 24, 115, 24, 115);
	}

	@Override
	protected void containerTick() {
		int i = (this.menu.getContainerSize() + 9 - 1) / 9 - containerRows;
		int scroll = (int) (currentScroll * i + 0.5D);

		if (lastScroll != scroll) {
			scroll(scroll);
			this.lastScroll = scroll;
		}
	}

	private void scroll(int id) {
		getMenu().setRow(id);
		this.minecraft.gameMode.handleInventoryButtonClick(this.menu.containerId, id);
	}

	@Override
	public boolean mouseScrolled(double p_mouseScrolled_1_, double p_mouseScrolled_3_, double xd, double p_mouseScrolled_5_) {
		int i = (this.menu.getContainerSize() + 9 - 1) / 9 - 5;
		this.currentScroll = (float)(this.currentScroll - p_mouseScrolled_5_ / i);
		this.currentScroll = Mth.clamp(this.currentScroll, 0.0F, 1.0F);
		return true;
	}

	@Override
	public void getExclusionAreas(Consumer<Box> consumer) {
	}
}
